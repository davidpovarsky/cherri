from pathlib import Path
import hashlib, importlib.util, json, os, pwd, shutil, socket, stat, sys, time, traceback
assert socket.gethostname() == "torah-social" and os.getuid() == 0
sys.dont_write_bytecode = True
P = Path("/var/cache/cherri-native-contract-producers-20261126")
O = P / "caller-exact-file-signing-02"
O.mkdir(mode=0o700)
C = O / "commands"; C.mkdir()
B = Path("/var/tmp/cherri-fn04-exact-file-signing-20261127-02")
PACKETS = P / "caller-input-hosted-independent-intake-01/bundle"
H = Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py")
BIN = Path("/mnt/development/projects/agent-workspaces/cherri-remote/p15-s9eed-d9c-k19-20261127/runtime/bin/cherri")
AUTH = Path("/var/cache/cherri-current-runtime-pair-9eed-20261126")
COMPILER = "5b689c938c73420ef36b3f077764d30f8946f31a"
SIGNER = "9eed0d556c6b11c78100c99daf8e0a73bb864a26"
BIN_SHA = "32e87ea2feca9ff9acb4f1e709343d71c2364e746718b59a639fabdab599c95d"
URL = "https://sign.shortcuty.app/api/v1/sign?response=json"
CASES = ("nested_false", "nested_true", "without_functions")
def sha(raw): return hashlib.sha256(raw).hexdigest()
def need(v, reason):
    if not v: raise ValueError(reason)
def strict(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, "DUPLICATE_JSON_KEY")
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs)
def read(path, limit=32*1024*1024):
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and not path.is_symlink() and before.st_size <= limit, "REGULAR_BOUND_FILE")
    raw = path.read_bytes(); after = path.lstat()
    need((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) ==
         (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and len(raw)==before.st_size,
         "STABLE_FILE_READ")
    return raw
def pinned(path, expected):
    raw=read(path); need(sha(raw)==expected,"FILE_SHA_PIN"); return raw
need(sha(read(H))=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85","QUALIFIED_CAPTURE")
spec=importlib.util.spec_from_file_location("owned",H); owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
owned.original(O/"owner.original.py",read(Path(__file__)))
authority_raw=pinned(AUTH/"result.original.json","d84f28a3dad9d2e09fe462a1ce48fa1bf4a73e68dbe7495d946b5306f105b390")
authority=strict(authority_raw)
info_raw=pinned(AUTH/"cherri.build-info.original.txt","17e2f84d960903cb0b3641804392187876e60100fc212423b8c7333b0a68dba5")
need(authority["status"]=="PASS_ORIGINAL_PAIR_RESTORED_AND_ACTUAL_CAPABILITIES" and
     authority["compilerSource"]==SIGNER and authority["sourceUnchanged"] is True and
     authority["products"]["cherri"]["sha256"]==BIN_SHA and authority["products"]["cherri"]["bytes"]==24891121,
     "AUTHENTICATED_SIGNER_BUILD")
need(b"vcs.revision="+SIGNER.encode() in info_raw and b"vcs.modified=false" in info_raw and
     b"CGO_ENABLED=0" in info_raw and b"GOOS=linux" in info_raw and b"GOARCH=arm64" in info_raw, "SIGNER_BUILD_INFO")
owned.original(O/"signer-build-authority.original.json",authority_raw)
owned.original(O/"signer-build-info.original.txt",info_raw)
intake_raw=pinned(PACKETS/"intake.original.json","505933619bcb8bea604bbc375b31cf57824bddfaa514e354784ebb86f00e3678")
intake=strict(intake_raw)
need(intake["status"]=="PASS_BOUND_THREE_PACKETS_FOUR_EVENTS" and intake["compilerCommitSha"]==COMPILER and
     intake["packetCount"]==3 and intake["namedPasses"]==4 and intake["sourceUnchanged"] is True and
     intake["allParentsReapedAndGroupsAbsent"] is True, "ACTUAL_PACKET_BUNDLE")
owned.original(O/"packet-intake.original.json",intake_raw)
for name,pin in intake["inputs"].items():
    need(Path(name).name==name,"INPUT_NAME")
    raw=read(PACKETS/name);need(len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],"PACKET_RAW_ORIGINAL")
def identity():
    raw=pinned(BIN,BIN_SHA); s=BIN.lstat()
    need(len(raw)==24891121 and s.st_uid==1002 and stat.S_IMODE(s.st_mode)==0o700,"LIVE_SIGNER_IDENTITY")
    return {"path":str(BIN),"bytes":len(raw),"sha256":sha(raw),"uid":s.st_uid,"gid":s.st_gid,
            "mode":stat.S_IMODE(s.st_mode),"dev":s.st_dev,"ino":s.st_ino,
            "mtime_ns":s.st_mtime_ns,"ctime_ns":s.st_ctime_ns}
before=identity()
role=pwd.getpwuid(before["uid"]).pw_name;need(role=="chatgpt-agent","SIGNER_ROLE")
B.mkdir(mode=0o700);os.chown(B,before["uid"],before["gid"])
owned.original(O/"signer-before.original.json",before)
prepared={}
import plistlib
for case in CASES:
    rows=[row for row in intake["packets"] if row["caseId"]==case];need(len(rows)==1,"EXACT_PACKET_CASE")
    row=rows[0]; directory=PACKETS/case
    data={}
    for kind,name in (("packet","packet.derived.json"),("source","source.original.cherri"),("unsigned","unsigned.original.plist")):
        raw=read(directory/name);pin=row[kind];need(len(raw)==pin["bytes"] and sha(raw)==pin["sha256"],"ORIGINAL_PACKET_BYTES")
        data[kind]=raw
    name=row["workflowName"];need(name.startswith("CherriFN04") and name.replace("_","").isalnum(),"PUBLIC_FIXTURE_NAME")
    graph=plistlib.loads(data["unsigned"])
    packet=strict(data["packet"])
    need(packet["workflowName"]==name and packet["caseId"]==case and
         packet["sourceSha256"]==sha(data["source"]) and packet["unsignedSha256"]==sha(data["unsigned"]) and
         type(graph["WFWorkflowActions"]) is list and packet["actionCount"]==len(graph["WFWorkflowActions"]),
         "ORIGINAL_PACKET_NAME_AND_GRAPH")
    case_dir=B/case;case_dir.mkdir(mode=0o700);os.chown(case_dir,before["uid"],before["gid"])
    unsigned=case_dir/(name+".unsigned.shortcut");source=case_dir/"source.original.cherri"
    for target,raw in ((unsigned,data["unsigned"]),(source,data["source"]),(case_dir/"packet.derived.json",data["packet"])):
        with target.open("xb") as stream: stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.chown(target,before["uid"],before["gid"]);os.chmod(target,0o400)
    prepared[case]={"name":name,"directory":str(case_dir),"unsigned":str(unsigned),"source":str(source),
                    "signed":str(case_dir/(name+".shortcut")),"manifest":str(case_dir/"provenance.original.json"),
                    "sourcePin":row["source"],"unsignedPin":row["unsigned"],
                    "actions":len(graph["WFWorkflowActions"])}
result={"schema":"cherri-fn04-exact-file-canonical-signing/1","status":"FAIL","compilerCommitSha":COMPILER,
        "signerCompilerCommitSha":SIGNER,"signerBinary":before,"packetIntakeSHA256":sha(intake_raw),
        "signerBuildAuthoritySHA256":sha(authority_raw),"signerBuildInfoSHA256":sha(info_raw),
        "signingServer":URL,"signingMethod":"HUBSIGN_REMOTE_SERVICE","providerFallback":False,
        "compiled":False,"nativeExecuted":False,"appleSignatureValidated":False,
        "formalAcceptanceGranted":False,"wholeOwnerSeconds":420,"childSeconds":120,"httpSeconds":45,
        "prepared":prepared,"processes":[],"cases":[]}
start=time.monotonic()
env={key:value for key,value in os.environ.items() if key in ("PATH","HOME","LANG","LC_ALL","LC_CTYPE","TZ")}
try:
    with owned.WholeBudget(420,cleanup_seconds=5,final_reserve=30) as budget:
        for case in CASES:
            entry=prepared[case]
            need(not Path(entry["signed"]).exists() and not Path(entry["manifest"]).exists(),"CREATE_ONLY_SIGNED_OUTPUT")
            argv=["/usr/sbin/runuser","-u",role,"--",str(BIN),"sign",entry["unsigned"],"--output",entry["signed"],
                  "--signing-server",URL,"--source-file",entry["source"],"--compiler-sha",COMPILER,
                  "--manifest-out",entry["manifest"]]
            process=owned.run_owned(argv,cwd=Path(entry["directory"]),env=env,output=C,name="sign-"+case,budget=budget,seconds=120)
            result["processes"].append(process)
            owned.require_success(process)
            need(process["cleanup"]["parentReaped"] and process["cleanup"]["after"]["state"]=="ABSENT","SIGNER_PROCESS_CLEANUP")
            signed=read(Path(entry["signed"]));manifest_raw=read(Path(entry["manifest"]));manifest=strict(manifest_raw)
            expected={"schemaVersion":"1.4","compilerCommitSha":COMPILER,"signingMethod":"HUBSIGN_REMOTE_SERVICE",
                "serviceName":"Custom Signing Server","shortcutName":entry["name"],"sourceFile":"source.original.cherri",
                "sourceSha256":entry["sourcePin"]["sha256"],"unsignedFile":Path(entry["unsigned"]).name,
                "unsignedPlistSha256":entry["unsignedPin"]["sha256"],"unsignedByteSize":entry["unsignedPin"]["bytes"],
                "nativeActionCount":entry["actions"],"signedFile":Path(entry["signed"]).name,
                "signedArtifactSha256":sha(signed),"signedByteSize":len(signed),"headerMagic":"AEA1",
                "verificationTier":"AEA1_HEADER_PASS"}
            need(manifest==expected,"EXACT_SIGNING_PROVENANCE")
            need(len(signed)>=16 and signed[:4]==b"AEA1" and any(signed[4:]),"STRUCTURAL_AEA_ONLY")
            need(sha(read(Path(entry["unsigned"])))==entry["unsignedPin"]["sha256"] and
                 sha(read(Path(entry["source"])))==entry["sourcePin"]["sha256"],"NO_RECOMPILE_OR_INPUT_MUTATION")
            result["cases"].append({"caseId":case,"workflowName":entry["name"],"signed":{"bytes":len(signed),"sha256":sha(signed)},
                                    "manifest":{"bytes":len(manifest_raw),"sha256":sha(manifest_raw)},
                                    "processLabel":"sign-"+case,"verificationTier":"AEA1_HEADER_PASS"})
        result["status"]="PASS_THREE_EXACT_UNSIGNED_PACKETS_SIGNED_STRUCTURAL_ONLY"
except BaseException as error:
    result["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
    try:
        after=identity();owned.original(O/"signer-after.original.json",after)
        need(after==before,"SIGNER_CHANGED")
        for entry in prepared.values():
            need(sha(read(Path(entry["unsigned"])))==entry["unsignedPin"]["sha256"] and
                 sha(read(Path(entry["source"])))==entry["sourcePin"]["sha256"],"CLOSING_ORIGINAL_BYTES")
        result["sourceAndSignerUnchanged"]=True
    except BaseException as error:
        result["status"]="FAIL";result["closingError"]={"type":type(error).__name__,"message":str(error)}
    result["elapsedSeconds"]=time.monotonic()-start
    pin=owned.original(O/"result.original.json",result)
    print(json.dumps({"receipt":str(O/"result.original.json"),"sha256":pin["sha256"],"status":result["status"],
                      "cases":result["cases"],"elapsedSeconds":result["elapsedSeconds"],"error":result.get("error"),
                      "closingError":result.get("closingError")},sort_keys=True))
