import unittest,json,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
rows=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  rows.append({"event":"run","test":test.id()});super().startTest(test)
 def addSuccess(self,test):
  rows.append({"event":"pass","test":test.id()});super().addSuccess(test)
 def addFailure(self,test,err):
  rows.append({"event":"fail","test":test.id()});super().addFailure(test,err)
 def addError(self,test,err):
  rows.append({"event":"error","test":test.id()});super().addError(test,err)
 def addSkip(self,test,why):
  rows.append({"event":"skip","test":test.id(),"why":why});super().addSkip(test,why)
 def addSubTest(self,test,subtest,err):
  rows.append({"event":"pass" if err is None else "fail","test":subtest.id(),"subtest":True});super().addSubTest(test,subtest,err)
suite=unittest.defaultTestLoader.loadTestsFromNames(["test_function_envelope_r2_launch","test_function_envelope_r2_runtime"])
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
Path(sys.argv[2]).write_text(json.dumps({"schema":"cherri-r2-python-adapter-controls/1","status":"PASS" if result.wasSuccessful() else "FAIL","testsRun":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skips":len(result.skipped),"subtestPasses":sum(x.get("subtest",False) and x["event"]=="pass" for x in rows),"events":rows,"nativeInvocation":False,"goCommands":0},indent=2,sort_keys=True)+"\n")
raise SystemExit(0 if result.wasSuccessful() else 1)
