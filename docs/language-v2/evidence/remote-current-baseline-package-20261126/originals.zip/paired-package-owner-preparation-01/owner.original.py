"""Fixed qualification of the two original paired-package methods on 874159.

The original test source retains its four synthetic Go build limits of 120s,
Go metadata limits, package/archive/mode checks and role/source/platform faults.
This is consumer plumbing qualification, not a final compiler-pair build.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys
import time

P=Path(__file__).resolve().parent
PINS={
 "fixed_source_owner.py":"8452dcf07565838816122a027c9800998b3b67ec6b917b5ac66fe8fd38625e81",
 "owned_source_process.py":"4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85",
 "observe_go_exclusive.py":"97e699223bc7438e6d4f9de643d9ebc27497e28e9c3a31715f93652c35248ba8"}
for name,digest in PINS.items():
 if hashlib.sha256((P/name).read_bytes()).hexdigest()!=digest:
  raise SystemExit("PAIRED_OWNER_DEPENDENCY_CHANGED:"+name)
spec=importlib.util.spec_from_file_location("paired_package_fixed_owner",P/"fixed_source_owner.py")
fixed=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=fixed
spec.loader.exec_module(fixed)
W=Path("/mnt/development/projects/releases/cherri-p10r15-consumer-paired-source-20261126-02")
HEAD="874159842467c7ede40e3dc3518220aa86d53cdc"
TREE="b60ccbef097b237a01082af382c7ff2106a136c8"
BRANCH="agent/cherri-p10r15-consumer-final-alignment-20261126"
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/paired-package-qualification-01")
TEST_FILE="tools/p10r15/test_remote_package_preflight.py"
TEST_SHA="d18e0c543f59957c0746aded754cffb373423fd72e172dbbbb4ff34b018331fb"
IDS=[
 "test_remote_package_preflight.PairedPackagePreflight.test_staging_inspects_actual_roles_source_and_platform",
 "test_remote_package_preflight.PairedPackagePreflight.test_real_paired_archive_passes_promotion_package_boundary"]
ARGV=["/usr/sbin/runuser","-u","ubuntu","--","python3","-B","-m","unittest","-v",*IDS]
ADMISSION={"root":939524096,"development":1073741824,"shm":402653184,"memoryAvailable":3221225472}

def main():
 fixed.require(len(sys.argv)==1,"PAIRED_FIXED_NO_ARGUMENT_ROUTE")
 with fixed.owned.WholeBudget(600,cleanup_seconds=8,final_reserve=20) as budget:
  fixed.require(E.parent.resolve(strict=True)==E.parent and not E.exists(),"PAIRED_FRESH_OUTPUT")
  E.mkdir(mode=0o750)
  os.chown(E,1001,1001)
  owner=fixed.SourceOwner({"worktree":str(W)},E,budget)
  before=after=None
  shallow_before=shallow_after=None
  failures=[]; processes=[]; observed=[]
  fixed.owned.original(E/"owner.original.py",Path(__file__).read_bytes())
  for name in PINS:
   fixed.owned.original(E/name,(P/name).read_bytes())
  fixed.owned.original(E/"selection.original.json",{
   "schema":"cherri-paired-package-fixed-selection/1","source":HEAD,"tree":TREE,"branch":BRANCH,
   "worktree":str(W),"cwd":str(W/"tools/p10r15"),"argv":ARGV,"expectedTestIds":IDS,
   "testFile":TEST_FILE,"testFileSHA256":TEST_SHA,"wholeOwnerSeconds":600,
   "fixedPythonCommandSeconds":540,"originalGoBuildSeconds":[120,120,120,120],
   "originalGoEnvSeconds":30,"originalGoVersionMetadataSeconds":120,
   "ordinaryCheckout":True,"shallow":True,"ancestryQualification":False,
   "mainCompilerBuild":False,"sourceWrites":False,"liveWrites":False})
  try:
   before=owner.snapshot()
   fixed.owned.original(E/"source-before.original.json",before)
   fixed.require((before["head"],before["tree"],before["branch"],before["status"])==(HEAD,TREE,BRANCH,""),"PAIRED_CLEAN_EXACT_SOURCE")
   shallow_before=owner.read(W/".git/shallow")
   fixed.require(shallow_before==(HEAD+"\n").encode(),"PAIRED_EXACT_SHALLOW_BOUNDARY")
   fixed.owned.original(E/"shallow-before.original.txt",shallow_before)
   remote=owner.git("-c","credential.helper=","-c","credential.helper=!gh auth git-credential","ls-remote","--heads","origin","refs/heads/"+BRANCH)
   fixed.owned.original(E/"remote-ref.original.txt",remote)
   fixed.require(remote.decode().strip().split()==[HEAD,"refs/heads/"+BRANCH],"PAIRED_PUBLISHED_SOURCE")
   fixed.require(fixed.sha(owner.read(fixed.GO))==fixed.GO_SHA256,"PAIRED_GO_BINARY_PIN")
   raw_test=owner.read(W/TEST_FILE)
   fixed.require(fixed.sha(raw_test)==TEST_SHA,"PAIRED_ORIGINAL_TEST_PIN")
   fixed.owned.original(E/"test_remote_package_preflight.original.py",raw_test)
   fixed.owned.original(E/"environment.original.json",owner.env)
   _,stdout,stderr=owner.observe_concurrent_owner()
   decision=json.loads(owner.read(stdout))
   fixed.require(not owner.read(stderr) and decision.get("admitted") is True and decision.get("blockedPids")==[],"PAIRED_EXCLUSIVE_GO_ADMISSION")
   available=fixed.free()
   admitted=all(available[k]>=v for k,v in ADMISSION.items())
   fixed.owned.original(E/"preflight.original.json",{"free":available,"admission":ADMISSION,"liveFloor":fixed.LIVE_FLOORS,"admitted":admitted})
   fixed.require(admitted,"PAIRED_CAPACITY_ADMISSION")
   owner.sequence+=1
   name=f"{owner.sequence:03d}-paired-package-original-two"
   row=fixed.owned.run_owned(ARGV,cwd=W/"tools/p10r15",env=owner.env,output=owner.commands,name=name,budget=budget,seconds=540,monitor=owner.monitor)
   processes.append(row)
   stdout=owner.read(owner.commands/(name+".stdout.original"))
   stderr=owner.read(owner.commands/(name+".stderr.original"))
   fixed.owned.require_success(row)
   text=stderr.decode("utf-8")
   matches=re.findall(r"^(test_[A-Za-z0-9_]+) \((test_remote_package_preflight\.PairedPackagePreflight\.(test_[A-Za-z0-9_]+))\) \.\.\. (ok|FAIL|ERROR|skipped.*)$",text,re.M)
   for short,test_id,long_name,status in matches:
    fixed.require(short==long_name,"PAIRED_TEST_ID_FORMAT")
    observed.append({"id":test_id,"status":status})
   fixed.require([x["id"] for x in observed]==IDS and all(x["status"]=="ok" for x in observed),"PAIRED_EXACT_TWO_TERMINAL_RESULTS")
   fixed.require(re.search(r"^Ran 2 tests in [0-9.]+s$",text,re.M) is not None and text.rstrip().endswith("\nOK"),"PAIRED_EXACT_SUMMARY")
   fixed.owned.original(E/"observed-tests.original.json",observed)
  except BaseException as error:
   failures.append({"stage":"execution","type":type(error).__name__,"message":str(error)})
  finally:
   with budget.finalizing():
    try:
     if before is not None:
      after=owner.snapshot(finalizing=True)
      fixed.owned.original(E/"source-after.original.json",after)
      fixed.require(before==after,"PAIRED_SOURCE_CHANGED")
      shallow_after=owner.read(W/".git/shallow")
      fixed.owned.original(E/"shallow-after.original.txt",shallow_after)
      fixed.require(shallow_after==shallow_before,"PAIRED_SHALLOW_BOUNDARY_CHANGED")
    except BaseException as error:
     failures.append({"stage":"post-source","type":type(error).__name__,"message":str(error)})
    if budget.cancel_signal is not None or time.monotonic()>=budget.deadline:
     failures.append({"stage":"owner","type":"CANCELLED_OR_DEADLINE","signal":budget.cancel_signal})
    passed=not failures and len(processes)==1 and before is not None and before==after and shallow_before==shallow_after and len(observed)==2
    report={
     "schema":"cherri-paired-package-owned-qualification/1",
     "source":HEAD,"tree":TREE,"branch":BRANCH,
     "status":"PASS" if passed else "FAIL" if processes else "NOT_RUN",
     "failures":failures,"processes":processes,"observedTests":observed,
     "sourceUnchanged":before is not None and before==after,
     "shallowBoundaryUnchanged":shallow_before is not None and shallow_before==shallow_after,
     "ordinaryCheckout":True,"shallow":True,"ancestryQualification":False,
     "minimumFree":owner.minimum,"wholeOwnerSeconds":600,"elapsedSeconds":time.monotonic()-budget.started,
     "mainCompilerBuild":False,"nativeAcceptance":False,"finalTupleAcceptance":False,"liveWrites":False,
     "testFileSHA256":TEST_SHA,"ownerSHA256":fixed.sha(Path(__file__).read_bytes()),"dependencySHA256":PINS}
    with budget.defer():
     pin=fixed.owned.original(E/"result.original.json",report)
 print(json.dumps({"result":str(E/"result.original.json"),"sha256":pin["sha256"],"status":report["status"],"failures":failures,"observedTests":observed,"elapsedSeconds":report["elapsedSeconds"]}),flush=True)
 return 0 if passed else 1
if __name__=="__main__":
 raise SystemExit(main())
