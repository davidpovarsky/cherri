import pathlib,json,hashlib,subprocess,sys,unittest,os,signal,time,datetime,traceback,re
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/package-inventory-qualification-01');E.mkdir(parents=True,exist_ok=False)
(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'tools/p10r15'))
names=['test_remote_package_inventory','test_remote_package_preflight.SourcePackagePreflight','test_remote_promotion']
def flatten(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from flatten(x)
  else:yield x
expected=sorted(t.id() for t in flatten(unittest.defaultTestLoader.loadTestsFromNames(names)))
assert len(expected)==len(set(expected)) and len(expected)>=20
(E/'selection.original.json').write_text(json.dumps({'modules':names,'expected':expected,'count':len(expected),'scope':'Actual Python/Git/filesystem controls; no Go or live mutation.'},indent=2)+'\n')
h=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],text=True,timeout=30).strip()
r={'schema':'cherri-package-inventory-python-qualification/1','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'874159842467c7ede40e3dc3518220aa86d53cdc','expected':expected,'timeoutSeconds':120,'liveMutation':False}
p=None
try:
 assert git('rev-parse','HEAD')==r['source'] and not git('status','--porcelain=v1')
 paths=['remote_release_gates.py','promote_remote_release.py','package_skill.py','stage_remote_release.py','remote_stage_baseline.py','remote_immutable_successor.py','verify_remote_smoke.py','test_remote_package_inventory.py','test_remote_package_preflight.py','test_remote_promotion.py']
 pins={x:h((W/'tools/p10r15'/x).read_bytes()) for x in paths};r['inputHashes']=pins
 argv=['/usr/sbin/runuser','-u','ubuntu','--','python3','-B','-m','unittest','-v',*names];r['argv']=argv
 with (E/'stdout.original.bin').open('wb') as out,(E/'stderr.original.bin').open('wb') as err:
  p=subprocess.Popen(argv,cwd=W/'tools/p10r15',env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'},stdout=out,stderr=err,start_new_session=True)
  r['pid']=p.pid;r['pgid']=os.getpgid(p.pid);r['sid']=os.getsid(p.pid)
  assert r['pid']==r['pgid']==r['sid']
  start=time.monotonic();r['exitCode']=p.wait(timeout=120);r['seconds']=time.monotonic()-start
 raw=(E/'stderr.original.bin').read_text()
 events=re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. (ok|FAIL|ERROR)$',raw,re.M)
 seen=sorted(x[0] for x in events)
 r.update(observedNamed=len(events),passed=sum(x[1]=='ok' for x in events),failed=sum(x[1]!='ok' for x in events),inventoryExact=seen==expected)
 assert git('rev-parse','HEAD')==r['source'] and not git('status','--porcelain=v1')
 assert all(h((W/'tools/p10r15'/x).read_bytes())==v for x,v in pins.items())
 r['sourceUnchanged']=True
 r['status']='PASS' if r['exitCode']==0 and seen==expected and all(x[1]=='ok' for x in events) else 'FAILED_TESTS_OR_INVENTORY'
except Exception as e:r.update(status='FAILED_OWNER',error=str(e),traceback=traceback.format_exc())
finally:
 if p:
  try:os.killpg(p.pid,0);alive=True
  except ProcessLookupError:alive=False
  if alive:
   os.killpg(p.pid,signal.SIGTERM);time.sleep(0.2)
   try:os.killpg(p.pid,0);os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:r['cleanupIncomplete']=True
 for key in ['stdout','stderr']:
  f=E/(key+'.original.bin')
  if f.exists():r[key+'SHA256']=h(f.read_bytes())
 r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();f=E/'result.original.json';f.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'path':str(f),'sha256':h(f.read_bytes()),**{k:r.get(k) for k in ['status','observedNamed','passed','failed','inventoryExact','seconds','error']}}))
