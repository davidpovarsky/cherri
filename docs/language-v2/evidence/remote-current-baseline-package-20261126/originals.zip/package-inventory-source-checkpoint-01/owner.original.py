import pathlib,subprocess,json,hashlib,os,datetime
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126')
P=E/'package-inventory-proposal-01';O=E/'package-inventory-source-checkpoint-01';O.mkdir(exist_ok=False)
(O/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
def g(*a):
 p=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],capture_output=True,text=True,timeout=35)
 assert p.returncode==0,p.stderr
 return p.stdout.strip()
assert g('rev-parse','HEAD')=='23da232f8afa58e9b4f0666263559c8daaa1bc73' and not g('status','--porcelain=v1')
m=json.loads((P/'manifest.original.json').read_text())
for f in m['files']:
 p=W/f['path'];data=(P/'proposed'/f['path']).read_bytes()
 assert hashlib.sha256(data).hexdigest()==f['sha256']
 assert (hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None)==f['beforeSHA256']
 p.write_bytes(data);p.chmod(0o644);os.chown(p,1001,1001)
g('diff','--check')
(O/'source.diff.original.patch').write_text(g('diff','--',*[f['path'] for f in m['files'] if f['beforeSHA256']])+'\n')
g('add','--',*[f['path'] for f in m['files']])
(O/'commit.original.txt').write_text(g('-c','user.name=David Povarsky','-c','user.email=davidpovarsky@users.noreply.github.com','commit','-m','remote: derive package inventories from the committed Skill source [skip ci]')+'\n')
head=g('rev-parse','HEAD');tree=g('rev-parse','HEAD^{tree}');assert not g('status','--porcelain=v1')
g('-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','origin','agent/cherri-p10r15-consumer-final-alignment-20261126')
assert g('ls-remote','--heads','origin','agent/cherri-p10r15-consumer-final-alignment-20261126').split()[0]==head
r={'status':'PUBLISHED_SOURCE_NOT_YET_QUALIFIED','head':head,'tree':tree,'files':m['files'],'liveMutation':False,'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()}
out=O/'result.original.json';out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'head':head,'tree':tree,'status':r['status']}))
