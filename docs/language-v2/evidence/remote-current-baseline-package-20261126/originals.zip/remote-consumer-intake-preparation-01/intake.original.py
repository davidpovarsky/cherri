
from pathlib import Path
import json,hashlib,re,subprocess,datetime
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126")
O=E/"remote-consumer-independent-intake-01"
O.mkdir(mode=0o750)
W=Path("/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125")
pins={
"current-baseline-qualification-01/result.original.json":"f13205b585193b9928973d3170968db4831e29c8a3c90b04d6b497c64fdeca8e",
"package-inventory-red-01/result.original.json":"41a4d043510f1fdeac3f813862cf61d7f6ecace6fbc3c6914a4ae465748904c8",
"package-inventory-qualification-01/result.original.json":"ddb5584fbc5f4947be7b90c8fb4a9621e4ac6a206733095bfbebd0985b2a26f3",
"paired-package-qualification-01/result.original.json":"28c7336b65df004da0acee928589f038ac29c1b47647cf369a75c7be34682b3e",
"current-installed-baseline-actual-01/current-installed.original.json":"49a87a596c62e3bf37f340c45441480c221beba5cb3801aea57e4a267adceef0",
"current-installed-baseline-actual-01/result.original.json":"1fc29542465d91e3d68fa0850ce070f371414baf2c7bc34b9f86f0ca5c3c50e8",
"paired-package-preparation-01/result.original.json":"74e5ffcf72a0c0f62ca2fbbe99321440f416b3cbb9ae817ebe36b6c11caf1c4d",
"paired-package-preparation-02/result.original.json":"d49985c03461cecbf234fc9a02f4667785835ef28da3604491c4d4fbac8f070c"}
refs=[]
def check(value,message):
 if not value:raise ValueError(message)
def load(rel,pin=None):
 p=E/rel;b=p.read_bytes();d=hashlib.sha256(b).hexdigest()
 if pin is not None:check(d==pin,"PIN:"+rel)
 refs.append({"path":rel,"bytes":len(b),"sha256":d})
 return json.loads(b)
def stream(rel,pin):
 p=E/rel;b=p.read_bytes();check(hashlib.sha256(b).hexdigest()==pin,"STREAM:"+rel)
 refs.append({"path":rel,"bytes":len(b),"sha256":pin})
 return b
def gitblob(commit,path):
 r=subprocess.run(["/usr/sbin/runuser","-u","ubuntu","--","git","--no-replace-objects","-C",str(W),"show",commit+":"+path],capture_output=True,timeout=25)
 check(r.returncode==0,"GIT_BLOB:"+path)
 return r.stdout
try:
 records={name:load(name,pin) for name,pin in pins.items()}
 expected_all=[]; groups=[]
 for rel,n,source in [
  ("current-baseline-qualification-01",41,"23da232f8afa58e9b4f0666263559c8daaa1bc73"),
  ("package-inventory-qualification-01",22,"874159842467c7ede40e3dc3518220aa86d53cdc")]:
  r=records[rel+"/result.original.json"];sel=load(rel+"/selection.original.json")
  check(r["status"]=="PASS" and r["source"]==source and r["exitCode"]==0 and r["sourceUnchanged"] is True,"QUALIFICATION_STATUS:"+rel)
  check(r["passed"]==n and r["failed"]==0 and r["observedNamed"]==n and r["inventoryExact"] is True,"QUALIFICATION_COUNTS:"+rel)
  check(r["expected"]==sel["expected"] and len(set(r["expected"]))==n,"ORIGINAL_SELECTION:"+rel)
  stdout=stream(rel+"/stdout.original.bin",r["stdoutSHA256"])
  stderr=stream(rel+"/stderr.original.bin",r["stderrSHA256"]).decode()
  found=re.findall(r"^test_[A-Za-z0-9_]+ \(([^()]+)\) \.\.\. (ok|FAIL|ERROR|skipped.*)$",stderr,re.M)
  check([x[0] for x in found]==r["expected"] and all(x[1]=="ok" for x in found),"RAW_TERMINALS:"+rel)
  check(re.search(r"^Ran "+str(n)+r" tests in [0-9.]+s$",stderr,re.M) is not None and stderr.rstrip().endswith("\nOK"),"RAW_SUMMARY:"+rel)
  for name,pin in r["inputHashes"].items():
   check(hashlib.sha256(gitblob(source,"tools/p10r15/"+name)).hexdigest()==pin,"SOURCE_INPUT:"+name)
  expected_all+=r["expected"]
  groups.append({"source":source,"count":n,"selection":r["expected"],"result":rel+"/result.original.json","resultSHA256":pins[rel+"/result.original.json"],"runType":"original Python/Git/filesystem qualification"})
 rel="paired-package-qualification-01";r=records[rel+"/result.original.json"];sel=load(rel+"/selection.original.json")
 check(r["status"]=="PASS" and r["failures"]==[] and r["source"]=="874159842467c7ede40e3dc3518220aa86d53cdc","PAIRED_STATUS")
 check(r["sourceUnchanged"] is True and r["shallowBoundaryUnchanged"] is True and r["shallow"] is True and r["ancestryQualification"] is False,"PAIRED_SOURCE_GUARDS")
 check(sel["originalGoBuildSeconds"]==[120,120,120,120] and sel["originalGoEnvSeconds"]==30 and sel["originalGoVersionMetadataSeconds"]==120,"PAIRED_ORIGINAL_CHILD_BOUNDS")
 check(sel["wholeOwnerSeconds"]==r["wholeOwnerSeconds"]==600 and len(r["processes"])==1,"PAIRED_OWNER_BOUNDS")
 row=r["processes"][0]
 check(row["status"]=="PASS" and row["exitCode"]==0 and row["error"] is None and not row["cancelled"] and not row["timedOut"] and not row["wholeDeadlineExceeded"],"PAIRED_PROCESS")
 check(row["cleanup"]["parentReaped"] and row["cleanup"]["noLiveGroupMembers"] and row["cleanup"]["after"]["state"]=="ABSENT","PAIRED_GROUP_CLEANUP")
 stdout=stream(rel+"/commands/"+row["name"]+".stdout.original",row["stdout"]["sha256"])
 stderr=stream(rel+"/commands/"+row["name"]+".stderr.original",row["stderr"]["sha256"]).decode()
 found=re.findall(r"^test_[A-Za-z0-9_]+ \(([^()]+)\) \.\.\. (ok|FAIL|ERROR|skipped.*)$",stderr,re.M)
 check([x[0] for x in found]==sel["expectedTestIds"] and all(x[1]=="ok" for x in found) and len(found)==2,"PAIRED_RAW_TWO_TERMINALS")
 check([x["id"] for x in r["observedTests"]]==sel["expectedTestIds"] and all(x["status"]=="ok" for x in r["observedTests"]),"PAIRED_RESULT_TERMINALS")
 before=load(rel+"/source-before.original.json");after=load(rel+"/source-after.original.json")
 check(before==after and before["head"]==r["source"] and before["tree"]==r["tree"] and before["status"]=="","PAIRED_PHYSICAL_BEFORE_AFTER")
 check((E/rel/"shallow-before.original.txt").read_bytes()==(E/rel/"shallow-after.original.txt").read_bytes()==(r["source"]+"\n").encode(),"PAIRED_SHALLOW_ORIGINALS")
 test=gitblob(r["source"],sel["testFile"])
 check(hashlib.sha256(test).hexdigest()==r["testFileSHA256"]==sel["testFileSHA256"],"PAIRED_TEST_SOURCE")
 check(test==(E/rel/"test_remote_package_preflight.original.py").read_bytes(),"PAIRED_PRESERVED_TEST_BYTES")
 for name,pin in r["dependencySHA256"].items():
  stream(rel+"/"+name,pin)
 expected_all+=sel["expectedTestIds"]
 groups.append({"source":r["source"],"count":2,"selection":sel["expectedTestIds"],"result":rel+"/result.original.json","resultSHA256":pins[rel+"/result.original.json"],"runType":"original paired-package methods with four real synthetic Go builds","notFinalCompilerBuild":True})
 check(len(expected_all)==65 and len(set(expected_all))==65,"DISTINCT_JOINED_65_IDENTITIES")
 red=records["package-inventory-red-01/result.original.json"]
 check(red["status"]=="EXPECTED_RED" and red["exitCode"]==1,"ORIGINAL_PACKAGE_RED")
 redtext=stream("package-inventory-red-01/stderr.original.bin",red["stderrSHA256"]).decode()
 check("24 != 23" in redtext and "FAILED (failures=1)" in redtext,"ORIGINAL_COUNT_RED")
 baseline=records["current-installed-baseline-actual-01/current-installed.original.json"]
 actual=records["current-installed-baseline-actual-01/result.original.json"]
 check(baseline["schema"]=="cherri-current-installed-baseline/1" and baseline["kind"]=="CURRENT_INSTALLED" and baseline["historyUnavailable"] is True and baseline["historicalAcceptance"] is False and baseline["livePromotion"] is False,"CURRENT_NOT_HISTORICAL")
 check(len(baseline["state"]["protected"])==10 and len(baseline["state"]["runtimeFiles"])==6 and set(baseline["state"]["sources"])=={"compiler","docs","skill"},"CURRENT_CLOSED_STATE")
 check(actual["status"]=="PASS_ACTUAL_CURRENT_BASELINE" and actual["liveMutation"] is False and actual["historicalAcceptance"] is False and actual["capture"]["sha256"]==pins["current-installed-baseline-actual-01/current-installed.original.json"],"CURRENT_ACTUAL_READBACK")
 for cmd in actual["commands"]:
  check(cmd["exitCode"]==0,"CURRENT_READ_COMMAND")
  for key in ("stdout","stderr"):stream("current-installed-baseline-actual-01/"+cmd["name"]+"."+key+".original.bin",cmd[key+"SHA256"])
 unchanged=[]
 for path in ("remote_current_baseline.py","remote_stage_baseline.py","stage_remote_release.py","test_remote_current_baseline.py"):
  raw=gitblob("23da232f8afa58e9b4f0666263559c8daaa1bc73","tools/p10r15/"+path)
  check(raw==gitblob("874159842467c7ede40e3dc3518220aa86d53cdc","tools/p10r15/"+path),"BASELINE_PRODUCTION_EVOLUTION:"+path)
  unchanged.append({"path":"tools/p10r15/"+path,"sha256":hashlib.sha256(raw).hexdigest()})
 check(records["paired-package-preparation-01/result.original.json"]["status"]=="FAILED_PREPARATION_NO_GO","RETAINED_PREPARATION_FAILURE")
 check(records["paired-package-preparation-02/result.original.json"]["status"]=="PREPARED_ORDINARY_EXACT_PHYSICAL_SOURCE","ACTUAL_PREPARATION")
 report={"schema":"cherri-remote-consumer-component-independent-intake/1","status":"PASS_COMPONENT_JOIN","checkedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"groups":groups,"distinctPassedIdentities":65,"singleRun":False,"source":r["source"],"tree":r["tree"],"baselineFilesUnchanged23daTo874":unchanged,"currentInstalledCapture":pins["current-installed-baseline-actual-01/current-installed.original.json"],"historyUnavailable":True,"historicalAcceptance":False,"finalTupleAcceptance":False,"nativeAcceptance":False,"livePromotion":False,"requiredFutureGates":["final source/documentation/skill tuple","original39 entrypoints","original58 signing","exact source/runtime archive and unpack checks","actual signed smoke","live promotion/rollback/reapply","final implementation D03/179"],"verifiedOriginals":refs}
except BaseException as e:
 report={"schema":"cherri-remote-consumer-component-independent-intake/1","status":"FAIL","error":{"type":type(e).__name__,"message":str(e)},"verifiedOriginals":refs}
raw=json.dumps(report,indent=2,sort_keys=True).encode()+b"\n"
(O/"result.original.json").write_bytes(raw)
print(json.dumps({"status":report["status"],"path":str(O/"result.original.json"),"sha256":hashlib.sha256(raw).hexdigest(),"identities":report.get("distinctPassedIdentities"),"error":report.get("error")}))
raise SystemExit(0 if report["status"]=="PASS_COMPONENT_JOIN" else 1)
