import pathlib,subprocess,json,hashlib,datetime
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
C=pathlib.Path('/mnt/development/projects/releases/cherri-p10r15-consumer-paired-source-20261126-02')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126')
old=E/'paired-package-preparation-01'
failure={'status':'FAILED_PREPARATION_NO_GO','reason':'Local hardlink creation was not permitted for one shared object; no ownership, permission or safe.directory change attempted.','stderrSHA256':hashlib.sha256((old/'clone.stderr.original.bin').read_bytes()).hexdigest(),'partialDestinationExists':pathlib.Path('/mnt/development/projects/releases/cherri-p10r15-consumer-paired-source-20261126').exists(),'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert not (old/'result.original.json').exists();(old/'result.original.json').write_text(json.dumps(failure,indent=2)+'\n')
O=E/'paired-package-preparation-02';O.mkdir(exist_ok=False);(O/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
B='agent/cherri-p10r15-consumer-final-alignment-20261126';H='874159842467c7ede40e3dc3518220aa86d53cdc'
commands=[]
def run(name,args,timeout=90):
 p=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--',*args],capture_output=True,timeout=timeout)
 (O/(name+'.stdout.original.bin')).write_bytes(p.stdout);(O/(name+'.stderr.original.bin')).write_bytes(p.stderr)
 commands.append({'name':name,'argv':args,'exitCode':p.returncode,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()})
 if p.returncode:raise RuntimeError(p.stderr.decode()[-1500:])
 return p.stdout.decode().strip()
r={'source':H,'checkout':str(C),'commands':commands,'noGoExecuted':True,'noBorrowedObjectStore':True,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 assert run('source-head',['git','-C',str(W),'rev-parse','HEAD'])==H
 assert not run('source-status',['git','-C',str(W),'status','--porcelain=v1'])
 assert not C.exists()
 run('clone',['git','clone','--no-local','--depth=1','--single-branch','--branch',B,str(W),str(C)])
 run('origin',['git','-C',str(C),'remote','set-url','origin','https://github.com/davidpovarsky/cherri.git'])
 assert run('head',['git','-C',str(C),'rev-parse','HEAD'])==H
 assert run('tree',['git','-C',str(C),'rev-parse','HEAD^{tree}'])=='b60ccbef097b237a01082af382c7ff2106a136c8'
 assert not run('status',['git','-C',str(C),'status','--porcelain=v1'])
 assert (C/'.git').is_dir() and not (C/'.git/objects/info/alternates').exists()
 r.update(status='PREPARED_ORDINARY_EXACT_PHYSICAL_SOURCE',tree='b60ccbef097b237a01082af382c7ff2106a136c8',branch=B,shallow=(C/'.git/shallow').read_text().splitlines(),scope='One exact commit with full physical source for paired-package tests; no ancestry qualification or final release clone claim.')
except Exception as e:r.update(status='FAILED_PREPARATION_NO_GO',error=str(e))
finally:
 f=O/'result.original.json';f.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'status':r['status'],'error':r.get('error'),'checkout':str(C),'failed01SHA256':hashlib.sha256((old/'result.original.json').read_bytes()).hexdigest()}))
