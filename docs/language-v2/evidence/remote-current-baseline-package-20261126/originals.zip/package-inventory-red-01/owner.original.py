import pathlib,subprocess,hashlib,json,datetime,os
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/package-inventory-red-01')
E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
h=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],text=True).strip()
head=git('rev-parse','HEAD');assert head=='83f8fa8c48cfb01000f18255c0727fa9d314127f' and not git('status','--porcelain=v1')
files=['tools/p10r15/package_skill.py','tools/p10r15/remote_release_gates.py','tools/p10r15/promote_remote_release.py','tools/p10r15/test_remote_package_preflight.py']
pins={}
for rel in files:
 data=(W/rel).read_bytes();p=E/'source-originals'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);pins[rel]=h(data)
argv=['python3','-B','-m','unittest','-v','test_remote_package_preflight.SourcePackagePreflight.test_real_source_archive_reaches_required_runtime_boundary']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--',*argv],cwd=W/'tools/p10r15',env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'},capture_output=True,timeout=60)
(E/'stdout.original.bin').write_bytes(p.stdout);(E/'stderr.original.bin').write_bytes(p.stderr)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1')
assert all(h((W/rel).read_bytes())==s for rel,s in pins.items())
r={'schema':'cherri-package-original-inventory-red/1','status':'EXPECTED_RED' if p.returncode==1 and b'24 != 23' in p.stderr and b'Ran 1 test' in p.stderr else 'UNEXPECTED_RESULT','source':head,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'exitCode':p.returncode,'sourceFiles':pins,'stdoutSHA256':h(p.stdout),'stderrSHA256':h(p.stderr),'scope':'One unchanged original source-package Python regression; actual committed Skill inventory. No Go, runtime pair, candidate stage or live change.'}
out=E/'result.original.json';out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'result':str(out),'sha256':h(out.read_bytes()),'status':r['status'],'stderr':p.stderr.decode()}))
