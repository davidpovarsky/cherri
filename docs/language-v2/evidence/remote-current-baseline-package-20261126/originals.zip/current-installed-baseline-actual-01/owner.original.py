import pathlib,subprocess,json,hashlib,os,pwd,datetime,traceback
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
L=pathlib.Path('/mnt/development/projects/agent-workspaces/cherri-remote')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/current-installed-baseline-actual-01')
E.mkdir(parents=True,exist_ok=False);os.chown(E,1002,1002);E.chmod(0o750)
(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
h=lambda b:hashlib.sha256(b).hexdigest()
username=pwd.getpwuid(1002).pw_name
commands=[]
def git(*a):return subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],text=True,timeout=30).strip()
def execute(name,args):
 p=subprocess.run(['/usr/sbin/runuser','-u',username,'--',*args],capture_output=True,timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'})
 (E/(name+'.stdout.original.bin')).write_bytes(p.stdout);(E/(name+'.stderr.original.bin')).write_bytes(p.stderr)
 commands.append({'name':name,'argv':args,'exitCode':p.returncode,'stdoutSHA256':h(p.stdout),'stderrSHA256':h(p.stderr)})
 if p.returncode:raise RuntimeError(name+': '+p.stderr.decode()[-1500:])
 return json.loads(p.stdout)
r={'schema':'cherri-current-installed-baseline-production-intake/1','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':commands,'historicalAcceptance':False,'liveMutation':False}
try:
 assert git('rev-parse','HEAD')=='23da232f8afa58e9b4f0666263559c8daaa1bc73' and not git('status','--porcelain=v1')
 output=E/'current-installed.original.json'
 capture=execute('capture',['python3','-B',str(W/'tools/p10r15/remote_current_baseline.py'),'--live-home',str(L),'--public-alias','/home/chatgpt-agent/workspaces/cherri-remote','--output',str(output)])
 assert capture['sha256']==h(output.read_bytes())
 code='import sys,json\nsys.path.insert(0,'+repr(str(W/'tools/p10r15'))+')\nfrom remote_stage_baseline import wrapper_templates\np,w,v,t=wrapper_templates('+repr(str(L))+',None,None,None,None,installed=True,current_baseline='+repr(str(output))+',current_sha='+repr(capture['sha256'])+')\nprint(json.dumps({"protected":p,"witness":w,"templates":t}))\n'
 readback=execute('readback',['python3','-B','-c',code])
 state=json.loads(output.read_text())
 assert state['kind']=='CURRENT_INSTALLED' and state['historyUnavailable'] is True and state['historicalAcceptance'] is False
 assert readback['witness']['acceptanceGranted'] is False and len(readback['protected'])==10
 assert state['state']['pure']['manifestSHA256']=='ccdc5ef66b0184a89ed62061e3e49ec1b36fe721d0b597fce6d65fd594d74e82'
 assert git('rev-parse','HEAD')=='23da232f8afa58e9b4f0666263559c8daaa1bc73' and not git('status','--porcelain=v1')
 r.update(status='PASS_ACTUAL_CURRENT_BASELINE',source='23da232f8afa58e9b4f0666263559c8daaa1bc73',capture=capture,protectedFiles=len(readback['protected']),runtimeFiles=len(state['state']['runtimeFiles']),forkSources=state['state']['sources'],pureSources=state['state']['pure']['sources'],pureStaticFiles=len(state['state']['pure']['files']),packStaticFiles=len(state['state']['pure']['packFiles']))
except Exception as e:r.update(status='FAILED',error=str(e),traceback=traceback.format_exc())
finally:
 r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();out=E/'result.original.json';out.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'path':str(out),'sha256':h(out.read_bytes()),**{k:r.get(k) for k in ['status','capture','protectedFiles','runtimeFiles','pureStaticFiles','packStaticFiles','error']}}))
 if r['status']=='FAILED':raise SystemExit(1)
