import pathlib,subprocess,hashlib,json,os,datetime
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
C=pathlib.Path('/mnt/development/projects/releases/cherri-p10r15-consumer-paired-source-20261126')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/paired-package-preparation-01')
E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
B='agent/cherri-p10r15-consumer-final-alignment-20261126';H='874159842467c7ede40e3dc3518220aa86d53cdc'
commands=[]
def run(name,args,cwd=None,timeout=60):
 p=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--',*args],cwd=cwd,capture_output=True,timeout=timeout)
 (E/(name+'.stdout.original.bin')).write_bytes(p.stdout);(E/(name+'.stderr.original.bin')).write_bytes(p.stderr)
 commands.append({'name':name,'argv':args,'exitCode':p.returncode,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()})
 assert p.returncode==0,p.stderr.decode()[-1500:]
 return p.stdout.decode().strip()
assert run('source-head',['git','-C',str(W),'rev-parse','HEAD'])==H
assert not run('source-status',['git','-C',str(W),'status','--porcelain=v1'])
assert not C.exists()
run('clone',['git','clone','--no-checkout','--local',str(W),str(C)])
run('origin',['git','-C',str(C),'remote','set-url','origin','https://github.com/davidpovarsky/cherri.git'])
run('checkout',['git','-C',str(C),'checkout','-B',B,H])
assert run('head',['git','-C',str(C),'rev-parse','HEAD'])==H
assert run('tree',['git','-C',str(C),'rev-parse','HEAD^{tree}'])=='b60ccbef097b237a01082af382c7ff2106a136c8'
assert not run('status',['git','-C',str(C),'status','--porcelain=v1'])
assert (C/'.git').is_dir() and not (C/'.git/objects/info/alternates').exists()
r={'status':'PREPARED_ORDINARY_EXACT_SOURCE','source':H,'tree':'b60ccbef097b237a01082af382c7ff2106a136c8','branch':B,'checkout':str(C),'commands':commands,'noGoExecuted':True,'noBorrowedObjectStore':True,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
out=E/'result.original.json';out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'checkout':str(C),'status':r['status']}))
