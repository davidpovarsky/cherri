import pathlib,subprocess,sys,json,hashlib,datetime,time,plistlib,platform,traceback
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-505-refresh-20261123')
EVIDENCE=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-ai01-compat-20261123')
OUTPUT=EVIDENCE/'calibration-r7-752c41b7'
IMPLEMENTATION='752c41b74f64fd633e63792fd4685156fabe913c'
COMPILER=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-r7-arm64-pair-20261123/attempt-02/cherri')
COMPILER_SOURCE='ca316a3dee252456c4bec751594cf249c709b331'
COMPILER_HASH='42f6e42e7b6a8ea6f523a752fd2f06b96265e733fa00ad808190e062d1266301'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,timeout=15)
assert git('rev-parse','HEAD').decode().strip()==IMPLEMENTATION
assert git('status','--porcelain')==b''
assert sys.platform=='linux' and platform.machine()=='aarch64'
sys.path.insert(0,str(ROOT/'tools/language-ai-eval'))
import evaluation_bundle as eb
import graph_validator as gv
selected=eb.reviewed_profile(eb.V2_PROFILE,require_compiler=True)
assert selected['compiler']=={'source_sha':COMPILER_SOURCE,'binary_sha256':COMPILER_HASH}
assert sha(eb.read_regular(COMPILER,512*1024*1024))==COMPILER_HASH
prepared_raw=(EVIDENCE/'calibration-inputs/prepared-plan.json').read_bytes()
prepared=json.loads(prepared_raw)
assert len(prepared['cases'])==12 and prepared['retries']==0
assert prepared['per_call_timeout_seconds']==35 and prepared['aggregate_timeout_seconds']==450
suite,parameters=eb.generate_suite(bytes(range(32)))
tasks={t['id']:t for t in suite['tasks']}
assert {(c['task_id'],c['arm']) for c in prepared['cases']}=={(t,a) for t in eb.TASK_IDS for a in ('legacy','v2')}
source_paths=['tools/language-ai-eval/'+n for n in selected['producer_files']]
source_paths+=list(eb.GUIDE_FILES.values())
source_paths+=['tests/language-v2/acceptance-contract.json','tests/language-v2/repair-regression-plan.json','tests/language-v2/backend-recovery-gates.json']
bindings={n:sha(eb.read_regular(ROOT/n)) for n in source_paths}
OUTPUT.mkdir(mode=0o700,exist_ok=False)
def write(name,obj):
 path=OUTPUT/name
 with path.open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2);f.write('\n')
cases=[]
for original in prepared['cases']:
 identity=original['task_id']+'--'+original['arm']
 directory=OUTPUT/identity
 directory.mkdir(mode=0o700)
 raw=eb.read_regular(pathlib.Path(original['source_path']),gv.MAX_SOURCE)
 assert sha(raw)==original['source_sha256']
 gv.safe_source(raw.decode('utf-8'))
 with (directory/'source.cherri').open('xb') as f:f.write(raw)
 command=[str(COMPILER),'compile',str(directory/'source.cherri'),'--mode='+original['arm'],'--output',str(directory/'output.shortcut'),'--skip-sign']
 cases.append({'task_id':original['task_id'],'arm':original['arm'],'case_id':identity,'source_sha256':sha(raw),'source_bytes':len(raw),'source_path':str(directory/'source.cherri'),'command':command,'timeout_seconds':35,'status':'NOT_STARTED'})
plan={'schema':'cherri-ai-baseline-calibration/v2','created_at':utc(),'implementation_source':IMPLEMENTATION,'compiler_source':COMPILER_SOURCE,'compiler_sha256':COMPILER_HASH,'compiler_environment':selected['compiler_environment_profile'],'prepared_plan_sha256':sha(prepared_raw),'original_archive_sha256':prepared['archive_sha256'],'original_s4_plan_sha256':prepared['original_plan_sha256'],'public_seed_scope':'original deterministic public bytes0..31, no fresh evaluation seed','source_bindings':bindings,'per_call_timeout_seconds':35,'aggregate_timeout_seconds':450,'retries':0,'model_calls':0,'network_calls':0,'local_go_builds':0,'cases':cases}
write('frozen-plan.original.json',plan)
started=time.monotonic();deadline=started+450
compile_results=[];graph_results=[];failure=None
try:
 for case in cases:
  remaining=deadline-time.monotonic()
  if remaining<=0:raise TimeoutError('CALIBRATION_AGGREGATE_DEADLINE')
  assert sha(eb.read_regular(COMPILER,512*1024*1024))==COMPILER_HASH
  directory=OUTPUT/case['case_id']
  assert sha(eb.read_regular(directory/'source.cherri',gv.MAX_SOURCE))==case['source_sha256']
  environment=gv.compiler_environment(directory,eb.V2_PROFILE)
  with (directory/'command.original.json').open('x',encoding='utf-8') as f:json.dump(case['command'],f);f.write('\n')
  began=utc();monotonic=time.monotonic();code=None;error=None
  with (directory/'compiler.stdout.original').open('xb') as stdout,(directory/'compiler.stderr.original').open('xb') as stderr:
   try:
    process=subprocess.run(case['command'],cwd=directory,stdout=stdout,stderr=stderr,env=environment,timeout=min(35,remaining),check=False)
    code=process.returncode
   except subprocess.TimeoutExpired:error='COMPILE_TIMEOUT'
   except OSError:error='COMPILE_OS_ERROR'
  record={'task_id':case['task_id'],'arm':case['arm'],'case_id':case['case_id'],'started_at':began,'finished_at':utc(),'elapsed_seconds':round(time.monotonic()-monotonic,6),'returncode':code,'error_type':error,'status':'COMPILED' if code==0 and error is None else 'COMPILE_FAILED','source_sha256':case['source_sha256'],'compiler_sha256':COMPILER_HASH,'environment_profile':selected['compiler_environment_profile'],'environment_keys':sorted(environment),'stdout_sha256':sha((directory/'compiler.stdout.original').read_bytes()),'stderr_sha256':sha((directory/'compiler.stderr.original').read_bytes())}
  output=directory/'output.shortcut'
  if output.is_file():
   raw=eb.read_regular(output,gv.MAX_PLIST)
   record.update(output_sha256=sha(raw),output_bytes=len(raw))
  with (directory/'compile-receipt.original.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
  compile_results.append(record)
  print(json.dumps({'phase':'compile','case':case['case_id'],'status':record['status'],'returncode':code}),flush=True)
 for record in compile_results:
  if time.monotonic()>deadline:raise TimeoutError('CALIBRATION_AGGREGATE_DEADLINE')
  directory=OUTPUT/record['case_id']
  result={'task_id':record['task_id'],'arm':record['arm'],'case_id':record['case_id'],'started_at':utc(),'status':'UNADJUDICATED','checks':[]}
  if record['status']=='COMPILED':
   try:
    raw=eb.read_regular(directory/'output.shortcut',gv.MAX_PLIST)
    assert sha(raw)==record['output_sha256']
    checks=gv.semantic_checks(plistlib.loads(raw),tasks[record['task_id']],parameters.get(record['task_id'],{}))
    result.update(status='PASS' if checks and all(c['passed'] for c in checks) else 'FAIL',checks=checks,graph_sha256=sha(raw))
   except (ValueError,TypeError,KeyError,plistlib.InvalidFileException) as error:
    result['error_type']=type(error).__name__
    if isinstance(error,eb.BundleError):result['error_code']=str(error)
  result['finished_at']=utc()
  with (directory/'graph-replay.original.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
  graph_results.append(result)
  print(json.dumps({'phase':'graph','case':record['case_id'],'status':result['status']}),flush=True)
except BaseException as error:
 failure={'type':type(error).__name__,'code':str(error) if isinstance(error,(eb.BundleError,TimeoutError)) else 'CALIBRATION_DRIVER_FAILED'}
finally:
 after={n:sha(eb.read_regular(ROOT/n)) for n in source_paths}
 clean=git('status','--porcelain')==b''
 head=git('rev-parse','HEAD').decode().strip()
 same_binary=sha(eb.read_regular(COMPILER,512*1024*1024))==COMPILER_HASH
 elapsed=round(time.monotonic()-started,6)
 complete=len(compile_results)==12 and len(graph_results)==12
 passed=complete and all(r['status']=='COMPILED' for r in compile_results) and all(r['status']=='PASS' for r in graph_results) and failure is None and elapsed<=450 and after==bindings and clean and head==IMPLEMENTATION and same_binary
 receipt={'schema':'cherri-ai-baseline-calibration-result/v2','status':'PASS' if passed else 'FAIL','finished_at':utc(),'implementation_source':IMPLEMENTATION,'compiler_source':COMPILER_SOURCE,'compiler_sha256':COMPILER_HASH,'compiler_environment':selected['compiler_environment_profile'],'elapsed_seconds':elapsed,'aggregate_timeout_seconds':450,'per_call_timeout_seconds':35,'expected_cases':12,'actual_compiler_invocations':len(compile_results),'compilations_passed':sum(r['status']=='COMPILED' for r in compile_results),'graph_replays':len(graph_results),'graphs_passed':sum(r['status']=='PASS' for r in graph_results),'failure':failure,'source_bindings_before':bindings,'source_bindings_after':after,'source_unchanged':bindings==after,'git_clean_after':clean,'head_after':head,'compiler_bytes_unchanged':same_binary,'model_calls':0,'fresh_evaluation_seed_created':False,'ai_quality_measured':False,'apple_runtime_proved':False,'cases':compile_results,'graphs':graph_results}
 write('result.original.json',receipt)
 print(json.dumps({'output':str(OUTPUT),'status':receipt['status'],'elapsed_seconds':elapsed,'compiler_invocations':len(compile_results),'compilations_passed':receipt['compilations_passed'],'graphs_passed':receipt['graphs_passed'],'source_clean_and_unchanged':clean and bindings==after and head==IMPLEMENTATION,'failure':failure}),flush=True)
sys.exit(0 if passed else 1)
