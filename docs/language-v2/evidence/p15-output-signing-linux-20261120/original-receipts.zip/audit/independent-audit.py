import pathlib,json,hashlib,subprocess,re,collections,datetime,math
R=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-parity-20261119")
E=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-parity-evidence-20261119\rp43-linux-dispatch")
D=E/"completed-44705394599"
A=D/"artifact-members"
S="53daeae947f729e434168a8a09661e735386c661"
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args,input=None):
 p=subprocess.run(["git","--no-replace-objects",*args],cwd=R,input=input,capture_output=True,timeout=45)
 if p.returncode:raise RuntimeError((args,p.returncode,p.stderr.decode()[:1000]))
 return p.stdout
def obj(path):return json.loads(path.read_bytes())
run=obj(E/"terminal-run.json");jobs=obj(E/"terminal-jobs.json");ars=obj(E/"terminal-artifacts.json")
assert run["id"]==44705394599 and run["head_sha"]==S and run["event"]=="workflow_dispatch" and run["run_attempt"]==1 and run["conclusion"]=="success" and run["status"]=="completed"
job=next(x for x in jobs["jobs"] if x["id"]==136183611457)
assert job["conclusion"]=="success" and all(x["conclusion"]=="success" for x in job["steps"])
ar=ars["artifacts"];assert len(ar)==1
assert ar[0]["id"]==14614159034 and not ar[0]["expired"] and ar[0]["name"]=="p10r15-cli-output-RP43-"+S+"-1"
zipdata=(D/"artifact-original.zip").read_bytes()
assert len(zipdata)==ar[0]["size_in_bytes"] and "sha256:"+sha(zipdata)==ar[0]["digest"]
assert git("rev-parse","HEAD").decode().strip()==S
assert not git("status","--porcelain=v1","--untracked-files=all").decode().rstrip("\r\n")
command=obj(A/"command.json");outer=obj(A/"process-result.json");proof=obj(A/"component-proof.json")
inner_path=next(A.glob("actual-artifacts/*/rp43-process.json"))
inner=obj(inner_path);raw_path=inner_path.with_name("rp43-go.jsonl");stderr_path=inner_path.with_name("rp43-stderr.log")
for k,v in command.items():assert outer[k]==v,k
assert outer["source_before"]==outer["source_after"]==proof["source_sha"]==inner["source_commit"]==S
assert outer["clean_before"] is True and outer["clean_after"] is True and inner["source_clean_before"] is True and inner["source_clean_after"] is True
assert outer["exit_code"]==inner["exit_code"]==0 and outer["timed_out"] is False and inner["timed_out"] is False
assert outer["go_version"]=="go version go1.25.14 linux/amd64" and inner["goos"]=="linux"
assert outer["workflow_run_id"]=="44705394599" and outer["workflow_attempt"]=="1"
assert outer["ref"]=="refs/heads/probe/cherri-p10r15-cli-output-evidence-20261120"
assert proof["requirement"]==inner["requirement"]==outer["requirement"]=="RP43"
assert outer["command"]==["go","test","-count=1","-json","-timeout","6m","./tools/language-acceptance","-run","^TestOutputSigning(ProducerInventory|EventParserControls|ActualProductionEvidence)$"]
parents=["TestP15RP43PublicOutputDestinations","TestP15RP43LinuxOutputPermissions","TestP15RP43LegacyEncodingFailurePreservesDestination","TestP15RP43EncodingFailureReturnsNoPartialBytes","TestP15RP43PublicSignerFailureBoundaries","TestP15RP43UnsignedAndAnalysisBoundaries"]
required=parents.copy()
routes=["compile_v2","file_v2","compile_legacy","file_legacy"]
for route in routes:
 required.append(parents[0]+"/"+route)
 required += [parents[0]+"/"+route+"/"+x for x in ["absolute_unicode","relative_unicode","destination_directory","parent_is_file","missing_parent"]]
 required.append(parents[1]+"/"+route)
required += [parents[3]+"/"+x for x in ["xml","binary"]]
for route in routes+["sign"]:
 required.append(parents[4]+"/"+route)
 required += [parents[4]+"/"+route+"/fault_"+str(i) for i in range(6)]
required += [parents[5]+"/"+x for x in ["implicit_unsigned/compile_v2","implicit_unsigned/file_v2","implicit_unsigned/compile_legacy","explicit_unsigned/file_legacy","check_valid_true","check_valid_false","explicit_remote_request_control"]]
assert len(required)==len(set(required))==78
assert inner["required_tests"]==inner["discovered_tests"]==required
assert inner["command"]==["go","test","-count=1","-json","-timeout","3m0s",".","-run","^("+"|".join(parents)+")$"]
for name,digest in outer["artifacts"].items():
 data=(A/name).read_bytes();assert len(data)==digest["bytes"] and sha(data)==digest["sha256"]
for path,hashkey,lenkey in [(raw_path,"raw_sha256","raw_bytes"),(stderr_path,"stderr_sha256","stderr_bytes")]:
 data=path.read_bytes();data.decode("utf-8",errors="strict")
 assert sha(data)==inner[hashkey] and len(data)==inner[lenkey]
assert inner["benchmark_sha256"]=="" and inner["benchmark_bytes"]==0
def when(s):return datetime.datetime.fromisoformat(s.replace("Z","+00:00"))
def interval(p,start,end,limit):
 a,b=when(p[start]),when(p[end]);e=p["elapsed_seconds"]
 assert type(e) in (int,float) and math.isfinite(e) and 0<=e<=limit and a<=b and abs((b-a).total_seconds()-e)<0.1
 return a,b
oa,ob=interval(outer,"started_utc","completed_utc",420)
ia,ib=interval(inner,"started_utc","finished_utc",240)
assert oa<=ia<=ib<=ob
def events(path,expected,package,a,b):
 lines=path.read_bytes().decode("utf-8",errors="strict").splitlines(); ev=[json.loads(x) for x in lines]
 assert all(x["Package"]==package for x in ev)
 assert not any(x["Action"] in ["fail","skip"] for x in ev)
 runs=[x["Test"] for x in ev if x["Action"]=="run" and x.get("Test")]
 passes=[x["Test"] for x in ev if x["Action"]=="pass" and x.get("Test")]
 assert len(runs)==len(set(runs))==len(passes)==len(set(passes))
 assert set(runs)==set(passes)
 if expected is not None:assert set(runs)==set(expected)
 assert [x["Action"] for x in ev if not x.get("Test") and x["Action"] in ["pass","fail","skip"]]==["pass"]
 active=set();done=set();last=None
 for x in ev:
  t=when(x["Time"]);assert a-datetime.timedelta(milliseconds=1)<=t<=b+datetime.timedelta(milliseconds=1)
  if last is not None:assert t>=last
  last=t
  n=x.get("Test")
  if x["Action"]=="run" and n:
   assert n not in active and n not in done
   parts=n.split("/")
   for j in range(1,len(parts)):
    parent="/".join(parts[:j])
    if parent in runs:assert parent in active and parent not in done
   active.add(n)
  if x["Action"]=="pass" and n:
   assert n in active and n not in done
   assert all(not other.startswith(n+"/") for other in active if other!=n)
   assert all(other in done for other in runs if other.startswith(n+"/"))
   assert "Elapsed" in x and 0<=x["Elapsed"]<=420
   active.remove(n);done.add(n)
 assert not active
 return ev,runs
iev,inames=events(raw_path,required,"github.com/electrikmilk/cherri",ia,ib)
oev,onames=events(A/"go-test.jsonl",None,"github.com/electrikmilk/cherri/tools/language-acceptance",oa,ob)
assert len(onames)==253
assert {x for x in onames if "/" not in x}=={"TestOutputSigningProducerInventory","TestOutputSigningEventParserControls","TestOutputSigningActualProductionEvidence"}
text="".join(x.get("Output","") for x in oev if x.get("Test")=="TestOutputSigningActualProductionEvidence")
markers=[x.split("P15_OUTPUT_SIGNING_PRODUCTION_RECEIPT:",1)[1] for x in text.splitlines() if "P15_OUTPUT_SIGNING_PRODUCTION_RECEIPT:" in x]
assert len(markers)==1 and json.loads(markers[0])==proof
files=inner["source_files"];assert len(files)==47
producer=git("show",S+":tools/language-acceptance/output_signing_execution.go").decode()
block=re.search(r"var outputSigningProductionPaths = \[\]string\{(.*?)\n\}",producer,re.S).group(1)
paths=re.findall(r'"([^"]+)"',block)
assert len(paths)==len(set(paths))==47 and [x["path"] for x in files]==paths
batch=git("cat-file","--batch",input="".join(S+":"+p+"\n" for p in paths).encode())
offset=0;checked=[]
for p,f in zip(paths,files):
 end=batch.index(b"\n",offset);header=batch[offset:end].decode().split();assert len(header)==3 and header[1]=="blob"
 length=int(header[2]);data=batch[end+1:end+1+length];assert len(data)==length and batch[end+1+length:end+2+length]==b"\n"
 offset=end+2+length
 assert sha(data)==f["sha256"],p
 checked.append({"path":p,"git_blob":header[0],"bytes":length,"sha256":sha(data)})
assert offset==len(batch)
workflow=next(x for x in checked if x["path"]==".github/workflows/p10r15-cli-output-evidence.yml")
assert workflow["sha256"]==outer["workflow_sha256"]=="6b5b4abab47db1ec79841ebc750eabb68131d6713c48d38174e43099cf484f28"
records=proof["records"];assert len(records)==2 and [x["tier"] for x in records]==["integration","security"]
for rec in records:
 assert rec["requirements"]==["RP43"] and rec["implementation_sha"]==S and rec["result"]=="passed" and rec["exit_code"]==0 and rec["command"]==inner["command"]
 assert rec["assertions"]["required_host_os"]=="linux" and rec["assertions"]["required_go_events"]=="\n".join(required) and rec["assertions"]["required_production_tests"]=="\n".join(parents)
 assert len(rec["artifacts"])==3
 for item in rec["artifacts"]:
  name=pathlib.PurePosixPath(item["path"]).name
  assert name in ["rp43-process.json","rp43-go.jsonl","rp43-stderr.log"]
  assert sha((inner_path.parent/name).read_bytes())==item["sha256"]
report=proof["report"]
assert report["phase"]=="local" and report["closure_complete"] is False and (report["total_cases"],report["passed_cases"],report["failed_cases"],report["skipped_cases"])==(1,1,0,0)
assert len(report["results"])==1 and report["results"][0]["id"]=="RP43" and report["results"][0]["passed"] is True and report["results"][0]["executed_levels"]==["integration","security"]
assert git("rev-parse","HEAD").decode().strip()==S and not git("status","--porcelain=v1","--untracked-files=all").decode().rstrip("\r\n")
summary={"source":S,"run_id":run["id"],"job_id":job["id"],"artifact_id":ar[0]["id"],"workflow_attempt":1,"run_conclusion":"success","source_clean":True,"go_version":outer["go_version"],"outer_named_passes":len(onames),"inner_named_passes":len(inames),"failures":0,"skips":0,"source_blobs_checked":len(checked),"outer_elapsed_seconds":outer["elapsed_seconds"],"inner_elapsed_seconds":inner["elapsed_seconds"],"artifact_zip_sha256":sha(zipdata),"artifact_zip_bytes":len(zipdata),"outer_raw_sha256":sha((A/"go-test.jsonl").read_bytes()),"inner_raw_sha256":sha(raw_path.read_bytes()),"actual_rp43_tiers":["integration","security"],"final_179_closed":False,"apple_signing_claim":False,"linked_requirement_credit":[],"audit_scope":"Original authenticated GitHub artifact/run identity, complete named events and ancestor ordering, all 47 immutable Git blobs, original raw/stderr hashes, exact commands/process intervals/record identities. No semantic tests rerun for this audit."}
(D/"independent-audit.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
(D/"source-audit.json").write_text(json.dumps({"source":S,"files":checked},indent=2)+"\n",encoding="utf-8")
print(json.dumps(summary))
