package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

var f01RequiredTests = []string{
	"TestP15F01StatementAndExpressionGuardRHS",
	"TestP15F01StaticSkipsMissingTarget",
	"TestP15F01BooleanStatementUsesValueNotPresence",
	"TestP15F01GuardOracleRejectsMutations",
	"TestP15F01RuntimeFixtureCompiles",
	"TestP15F01HybridEditedPredicateGuardsRHS",
}

var r06ProductionTests = []string{"TestP15R06ProductionImportFormats", "TestHYB18_SignedShortcutContainerRejected", "TestHYB20_TrailingGarbageAfterJSONRootRejected", "TestHYB21_MalformedActionEntriesRejectedWithExactIndex"}
var r07ProductionTests = []string{"TestSEM28_UserEditOnNaturalActionIsolated", "TestSEM29_UserEditInsideControlRegionIsolated", "TestSEM30_OnlyTargetActionChangesAndNoCollateralDelta", "TestSEM34_TamperDetectionAndStrictCompareAsymmetry"}

var cliProductionTests = map[string][]string{
	"CL01": {"TestP15CLIJSONCommandsAndExitStatus"},
	"CL02": {"TestP15CLIAnalysisHasNoExternalEffects"},
	"CL03": {"TestP15CLIDefaultRejectsLegacyWithGuidance"},
}

// Real install producers include source builds and multiple controlled shell
// transactions. Keep finite per-family budgets; all assertions remain unchanged.
func productionTestTimeout(required []string) time.Duration {
	budget := 3 * time.Minute
	for _, name := range required {
		// Canonical schema scenarios build and restore multiple actual consumers
		// in an isolated Git worktree; preserve a finite whole-pipeline budget.
		if strings.HasPrefix(name, "TestP15Schema") || name == "TestP15CanonicalBehaviorSourcePropagation" || name == "TestP15RP08SchemaIdentityProduction" {
			return 8 * time.Minute
		}
		if strings.HasPrefix(name, "TestP15K05") {
			return 8 * time.Minute
		}
		if strings.HasPrefix(name, "TestP15K03") {
			return 12 * time.Minute
		}
		if strings.HasPrefix(name, "TestP15K01") || strings.HasPrefix(name, "TestP15K02") || strings.HasPrefix(name, "TestP15K04") || name == "TestP15SkillFreshPinnedInstall" {
			budget = 6 * time.Minute
		}
	}
	return budget
}

// Execute named production tests with explicit discovery checks. Exit status
// alone cannot prove that any required scenario was selected.
func executeNamedProductionTests(required []string) (bool, string) {
	return executeNamedProductionTestsInPackage(".", required)
}

func executeNamedProductionTestsInPackage(packagePath string, required []string) (bool, string) {
	var ctx, cancel = context.WithTimeout(context.Background(), productionTestTimeout(required)+time.Minute)
	defer cancel()
	if len(required) == 0 {
		return false, "No production tests were selected"
	}
	command := productionTestCommandInPackage(packagePath, required)
	var cmd = exec.CommandContext(ctx, command[0], command[1:]...)
	cmd.Dir = resolveRepoRoot()
	var output, err = cmd.CombinedOutput()
	var seen = make(map[string]bool)
	var scanner = bufio.NewScanner(bytes.NewReader(output))
	scanner.Buffer(make([]byte, 4096), 2*1024*1024)
	for scanner.Scan() {
		var event struct {
			Action string
			Test   string
		}
		if json.Unmarshal(scanner.Bytes(), &event) == nil && event.Action == "pass" {
			seen[event.Test] = true
		}
	}
	var missing []string
	for _, name := range required {
		if !seen[name] {
			missing = append(missing, name)
		}
	}
	if err != nil || scanner.Err() != nil || len(missing) != 0 {
		// Retain a bounded causal diagnostic instead of discarding every nested
		// assertion or timeout line behind an undifferentiated exit status.
		tail := output
		if len(tail) > 8192 {
			tail = tail[len(tail)-8192:]
		}
		return false, fmt.Sprintf("Production tests failed or were not discovered: process=%v; missing=%v; scanner=%v; output_tail=%s", err, missing, scanner.Err(), tail)
	}
	return true, "Executed production tests: " + strings.Join(required, ", ")
}

func executeF01ProductionTests() (bool, string) {
	ok, detail := executeNamedProductionTests(f01RequiredTests)
	return ok, detail + "; signed runtime still required"
}

type ExecutionAuditRow struct {
	ID                  string   `json:"id"`
	Requirement         string   `json:"requirement"`
	Status              string   `json:"status"`
	Tier                []string `json:"tier"`
	RequiredTiers       []string `json:"required_tiers"`
	ProductionPath      []string `json:"production_path"`
	TestNames           []string `json:"test_names"`
	PositiveAndNegative bool     `json:"positive_and_negative"`
	SourceSHA           string   `json:"source_sha"`
	Evidence            []string `json:"evidence"`
	Blocker             string   `json:"blocker,omitempty"`
	Detail              string   `json:"detail"`
	Scope               string   `json:"scope"`
}

func writeExecutionAudit(runner *Runner, contracts *ContractsSet, outPath string) error {
	if err := writeLocalObservations(runner, filepath.Join(filepath.Dir(outPath), "acceptance-local-observations.json")); err != nil {
		return err
	}
	evidence, err := json.MarshalIndent(runner.records, "", "  ")
	if err != nil {
		return err
	}
	if err = os.WriteFile(filepath.Join(filepath.Dir(outPath), "acceptance-local-evidence.json"), append(evidence, '\n'), 0644); err != nil {
		return err
	}
	mapping, err := BuildRequirementsEvidenceMap(contracts)
	if err != nil {
		return err
	}
	var rows = make([]ExecutionAuditRow, 0, mapping.TotalRequirements)
	for _, declared := range mapping.Records {
		var res, exists = runner.results[declared.ID]
		var row = ExecutionAuditRow{
			ID: declared.ID, Requirement: declared.Title, Status: "UNVERIFIED",
			Tier: []string{}, RequiredTiers: declared.RequiredTiers,
			ProductionPath: []string{"tools/language-acceptance/main.go"},
			TestNames:      []string{}, SourceSHA: runner.implSHA, Evidence: []string{},
			Scope: "Local runner assertion scope only; not universal feature, installed consumer, or Apple runtime acceptance",
		}
		if exists {
			row.Detail = res.Detail
			row.Tier = res.ExecutedLevels
			if row.Tier == nil {
				row.Tier = []string{}
			}
			switch {
			case res.Passed && res.Status == "PASSED":
				row.Status = "PASS"
			case res.Status == "FAILED":
				row.Status = "FAIL"
			case res.Status == "PENDING_EXTERNAL":
				row.Status = "BLOCKED_EXTERNAL"
				row.Blocker = "Required external tier has no validated current-SHA evidence in this local run"
			case res.Status == "AI_EVAL_NOT_RUN":
				row.Status = "BLOCKED_EXTERNAL"
				row.Blocker = "Actual held-out model evaluation has no validated current-SHA evidence in this run"
			default:
				row.Blocker = "Dedicated scenario producer has not executed; linked IDs do not satisfy this obligation"
			}
			for _, record := range runner.records {
				for _, id := range record.Requirements {
					if id == declared.ID {
						row.TestNames = appendUniqueAudit(row.TestNames, record.TestID)
						row.Evidence = appendUniqueAudit(row.Evidence, "acceptance-local-evidence.json#"+record.EvidenceID)
					}
				}
			}
		}
		if gap := incompleteLocalAssertions[row.ID]; gap != "" {
			row.Blocker = gap
			row.Evidence = []string{"acceptance-local-observations.json#" + row.ID}
			row.Scope = "Observed smoke only; no formal acceptance tier proven"
		}
		if row.ID == "D03" {
			row.TestNames = []string{documentationConsumerTestID, documentationAppTestID}
			row.ProductionPath = []string{"tools/p10r15/verify_documentation_consumers.py", "skills/cherri-shortcuts/scripts/search-docs.sh", "ios/scripts/collect_ios_test_evidence.py", "ios/scripts/build_documentation_index.py", "tools/language-acceptance/documentation_generation.go", "tools/language-acceptance/documentation_intake.go", "tools/language-acceptance/documentation_consumers_intake.go", "ios/CherriApp/Documentation/DocumentationIndex.swift", "ios/CherriApp/Documentation/DocumentationSearchView.swift"}
			row.Scope = "External published/installed/app consumers only; local model tests and file existence do not prove either required tier"
		}
		if spec, ok := editorContracts.Scenarios[row.ID]; ok {
			row.TestNames = editorContractTestIDs(row.ID)
			row.ProductionPath = append([]string{}, editorContracts.SourcePaths...)
			row.PositiveAndNegative = res.Status == "PENDING_EXTERNAL"
			row.Scope = spec.Scope
			if res.Status == "NOT_RUN" {
				row.Blocker = res.Detail
			}
		}
		if tests, ok := editorProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = editorProductionPathsForID(row.ID)
			row.PositiveAndNegative = res.Passed
			row.Scope = "Executed local Cherri service/cache and desktop service benchmark only; no iOS UI latency or race tier inferred"
			if row.ID == "RP29" {
				row.Scope = editorProductionScope(row.ID)
			}
		}
		if _, ok := stateAcceptanceScenarios[row.ID]; ok {
			row.TestNames = stateAcceptanceTests(row.ID)
			row.ProductionPath = stateAcceptanceSourcePaths(row.ID)
			row.PositiveAndNegative = res.Passed
			row.Scope = stateRaceScope
			if row.ID == "BRG06" {
				row.Scope += "; " + stateSecurityScope
			} else {
				row.Scope += "; independently executed strict cold/warm small/medium/large/asset benchmark"
			}
			if res.Status == "NOT_RUN" {
				row.Blocker = res.Detail
			}
		}
		if tests, ok := moduleProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, moduleProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
			if row.ID == "IM03" && res.Status == "NOT_RUN" {
				row.Scope = "Executed preserved-source and separate service unit observations; required native behavior remains unproved"
				row.Blocker = "Required native tier has not executed; unit observations do not satisfy the complete immutable contract"
				row.Evidence = []string{"acceptance-local-observations.json#IM03"}
			}
		}
		if tests, ok := formattingProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, formattingProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := workspaceProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, workspaceProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := documentationProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, documentationProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := catalogProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, catalogProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := parserProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = []string{"internal/language/syntax/lexer.go", "internal/language/syntax/parser.go", "internal/language/syntax/format.go", "internal/language/service/service.go", "p15_parser_acceptance_test.go"}
			row.PositiveAndNegative = res.Passed
		}
		if scenario, found := mainOutputScenarios[row.ID]; found {
			row.TestNames = append([]string{}, scenario.Tests...)
			row.ProductionPath = append([]string{}, mainOutputProductionPaths...)
			row.PositiveAndNegative = res.Passed || res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope
		}
		if scenario, found := functionDefaultScenarios[row.ID]; found {
			row.TestNames = append([]string{}, scenario.Tests...)
			row.ProductionPath = append([]string{}, functionDefaultProductionPaths...)
			row.PositiveAndNegative = res.Passed || res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope
		}
		if scenario, found := numberFunctionScenarios[row.ID]; found {
			row.TestNames = scenario.tests()
			row.ProductionPath = append([]string{}, scenario.ProductionPaths...)
			row.PositiveAndNegative = res.Passed || res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope + "; actual Apple observations remain separately required"
		}
		if row.ID == "U01" {
			row.TestNames = append([]string{}, upstreamBoundaryTests...)
			row.ProductionPath = append([]string{}, upstreamBoundaryProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = upstreamBoundaryScope
		}
		if scenario, found := documentationRecoveryScenarios[row.ID]; found {
			row.TestNames = append([]string{}, scenario.Tests...)
			row.ProductionPath = append([]string{}, documentationRecoveryProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = scenario.Scope
		}
		if row.ID == "RP11" {
			row.TestNames = append([]string{}, numberWireTests...)
			row.ProductionPath = append([]string{}, numberWireProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = numberWireScope
		}
		if row.ID == "RP52" {
			row.TestNames = append([]string{}, publicFrontendTests...)
			row.ProductionPath = append([]string{}, publicFrontendProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = publicFrontendScope
		}
		if row.ID == "BRG30" {
			row.TestNames = append([]string{}, packagedSkillTests...)
			row.ProductionPath = append([]string{}, packagedSkillProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = packagedSkillScope
		}
		if row.ID == "BRG21" {
			row.TestNames = append([]string{}, purePublicTests...)
			row.ProductionPath = append([]string{}, purePublicProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = purePublicScope
		}
		if row.ID == "BRG18" {
			row.TestNames = append([]string{}, nativePathsTests...)
			row.ProductionPath = append([]string{}, nativePathsProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = nativePathsScope
		}
		if row.ID == "BRG19" {
			row.TestNames = append([]string{}, safeImportEditTests...)
			row.ProductionPath = append([]string{}, safeImportEditProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = safeImportEditScope
		}
		if row.ID == "RP43" {
			row.TestNames = append([]string{}, outputSigningTests...)
			row.ProductionPath = append([]string{}, outputSigningProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = outputSigningScope
		}
		if scenario, found := extractedInstallScenarios[row.ID]; found {
			row.TestNames = append([]string{}, scenario.Tests...)
			row.ProductionPath = append([]string{}, extractedInstallProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = scenario.Scope
		}
		if row.ID == "RP33" {
			row.TestNames = append([]string{}, structuralMigrationTests...)
			row.ProductionPath = append([]string{}, structuralMigrationProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = structuralMigrationScope
		}
		if row.ID == "RP16" {
			row.TestNames = append([]string{}, exhaustiveNodeTests...)
			row.ProductionPath = append([]string{}, exhaustiveNodeProductionPaths...)
			row.PositiveAndNegative = res.Passed
			row.Scope = exhaustiveNodeScope
		}
		if scenario, found := shortCircuitScenarios[row.ID]; found {
			row.TestNames = scenario.tests()
			row.ProductionPath = append([]string{}, shortCircuitEvidence.SourcePaths...)
			row.PositiveAndNegative = res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope
		}
		if scenario, found := combinedUnicodeScenarios[row.ID]; found {
			row.TestNames = scenario.tests()
			row.ProductionPath = append([]string{}, combinedUnicodeEvidence.SourcePaths...)
			row.PositiveAndNegative = res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope
		}
		if scenario, found := captureOrderScenarios[row.ID]; found {
			row.TestNames = scenario.tests()
			row.ProductionPath = append([]string{}, captureOrderEvidence.SourcePaths...)
			row.PositiveAndNegative = res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope
		}
		if scenario, found := loopAcceptanceScenarios[row.ID]; found {
			row.TestNames = scenario.tests()
			row.ProductionPath = append([]string{}, loopProductionPaths...)
			row.PositiveAndNegative = res.Passed || res.Status == "PENDING_EXTERNAL"
			row.Scope = scenario.Scope + "; complete Apple loop execution remains separately required"
		}
		if tests, ok := bindingProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, bindingProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
			if row.ID == "V01" || row.ID == "V03" {
				row.PositiveAndNegative = res.Passed || res.Status == "PENDING_EXTERNAL"
				row.Scope = "Verified capture and final-consumer native graph with actual CLI/mobile routes; iOS results remain separately required"
			}
		}
		if tests, ok := literalCollectionProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, literalCollectionProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed || (row.ID == "S01" || row.ID == "L02" || row.ID == "L04") && res.Status == "PENDING_EXTERNAL"
		}
		if tests, ok := metadataProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, metadataProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := nativePreservationProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, nativePreservationProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := valueFlowProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, valueFlowProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := callProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, callProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := typeProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, typeProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := skillProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, skillProductionPaths[row.ID]...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := upstreamRouteProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = append([]string{}, upstreamRouteProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := cliProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = []string{"main.go", "args.go", "language_cli_adapter.go", "p15_cli_acceptance_test.go"}
			row.PositiveAndNegative = res.Passed
		}
		if tests, ok := schemaProductionTests[row.ID]; ok {
			row.TestNames = append([]string{}, tests...)
			row.ProductionPath = []string{"actions", "tools/language-schema/main.go", "internal/language/schema/generated_registry.go", "p15_schema_production_test.go"}
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "U03" {
			row.TestNames = []string{"TestUpstreamPropagationRehearsal"}
			row.ProductionPath = []string{"actions/web.cherri", "actions/calendar.cherri", "tools/language-schema/main.go", "upstream_rehearsal_test.go", "p15_schema_production_test.go", "internal/language/schema/generated_registry.go", "internal/language/analysis/analyzer.go", "internal/language/service/service.go"}
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "F05" {
			row.TestNames = append([]string{}, loopControlScenario.TestNames...)
			row.ProductionPath = append([]string{}, loopControlScenario.ProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "AC02" {
			row.TestNames = append([]string{}, customActionScenario.TestNames...)
			row.ProductionPath = append([]string{}, customActionScenario.ProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "N02" {
			row.TestNames = []string{"tools/language-acceptance:runNumbers"}
			row.ProductionPath = []string{"internal/language/analysis/analyzer.go"}
		}
		if scenario, ok := declarationTriggerScenarios[row.ID]; ok {
			row.TestNames = append([]string{}, scenario.TestNames...)
			row.ProductionPath = append([]string{}, scenario.ProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "E07" {
			row.TestNames = []string{"tools/language-acceptance:runEditor"}
			row.ProductionPath = []string{"internal/language/service/service.go"}
			row.PositiveAndNegative = res.Status == "PENDING_EXTERNAL"
		}
		if row.ID == "R06" {
			row.TestNames = append([]string{}, r06ProductionTests...)
			row.ProductionPath = []string{"import_fidelity.go", "hybrid_import.go", "mobile_compiler.go"}
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "R07" {
			row.TestNames = append([]string{}, r07ProductionTests...)
			row.ProductionPath = []string{"semantic_import_planner.go", "hybrid_import.go", "import_provenance.go"}
			row.PositiveAndNegative = res.Passed
		}
		if producer, ok := supplementalProductionScenarios[row.ID]; ok {
			row.TestNames = append([]string{}, producer.TestNames...)
			row.ProductionPath = append([]string{}, producer.ProductionPaths...)
			row.PositiveAndNegative = res.Passed
		}
		if row.ID == "AI01" {
			row.TestNames = []string{aiMeasurementTestID(row.ID)}
			row.ProductionPath = append([]string{}, aiMeasurementSources...)
			row.Scope = "Only complete original twelve-outcome measurement with independent authenticated Asana pins; fresh public-pattern instances, no unseen-pattern or Apple claim"
		}
		if row.ID == "RP50" {
			row.TestNames = append([]string{}, aiEvaluationHarnessScenario.TestNames...)
			row.ProductionPath = append([]string{}, aiEvaluationHarnessScenario.ProductionPaths...)
			row.PositiveAndNegative = false
			row.Scope = "Actual task-runner control flow only; fake adapters do not measure model quality, and the immutable evaluation tier remains required"
			if hasLevel(res.ExecutedLevels, "external-eval") {
				row.TestNames = append(row.TestNames, aiMeasurementTestID(row.ID))
				row.ProductionPath = append(row.ProductionPath, aiMeasurementSources...)
				row.Scope = "Harness controls plus separately revalidated original twelve-outcome measurement; no unseen-pattern, Apple or global closure claim"
			}
		}
		if row.ID == "F01" {
			row.ProductionPath = []string{"internal/language/syntax/parser.go", "internal/language/analysis/analyzer.go", "internal/language/lower/lower.go", "internal/language/lower/short_circuit.go", "language_backend_adapter.go"}
			row.TestNames = append([]string{}, f01RequiredTests...)
			row.PositiveAndNegative = res.Status == "PENDING_EXTERNAL" || res.Passed
		}
		rows = append(rows, row)
	}
	var doc = map[string]any{
		"schema_version": "1", "source_sha": runner.implSHA, "generated_at": time.Now().UTC().Format(time.RFC3339),
		"acceptance_count": len(contracts.Acceptance.Cases), "repair_count": len(contracts.Repair.Cases),
		"recovery_gate_count": len(contracts.Gates.Gates), "closure_complete": false,
		"scope": "Executed local assertions and explicit unexecuted obligations; declaration mappings are not execution evidence",
		"rows":  rows,
	}
	var data, marshalErr = json.MarshalIndent(doc, "", "  ")
	if marshalErr != nil {
		return marshalErr
	}
	if err = os.MkdirAll(filepath.Dir(outPath), 0755); err != nil {
		return err
	}
	return os.WriteFile(outPath, append(data, '\n'), 0644)
}

func appendUniqueAudit(items []string, item string) []string {
	for _, existing := range items {
		if strings.EqualFold(existing, item) {
			return items
		}
	}
	return append(items, item)
}
