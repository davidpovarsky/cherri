"""Extract only the verified retained public artifact into a fresh owned directory."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent / "acceptance-ai-component-intake-44977459353"
archive = root / "artifact.original.zip"
raw = archive.read_bytes()
assert len(raw) == 1859491
assert hashlib.sha256(raw).hexdigest() == "3aac0728878c592fafe31ea4498c85390f63992babaac2c0c7f8326d2d415f51"
destination = root / "originals"
assert not destination.exists() and not destination.is_symlink()
with zipfile.ZipFile(archive) as source:
    names = source.namelist()
    assert len(names) == len(set(names)) == 114
    for name in names:
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and "\\" not in name
        assert not name.endswith("/")
    inventory = json.loads(source.read("original-inventory.json"))
    assert {row["path"] for row in inventory["members"]} == set(names) - {"original-inventory.json"}
    for row in inventory["members"]:
        data = source.read(row["path"])
        assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
    destination.mkdir(mode=0o700)
    for name in names:
        path = destination / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as output:
            output.write(source.read(name))
print("Verified and extracted 114 retained originals; no compiler or test execution.")
