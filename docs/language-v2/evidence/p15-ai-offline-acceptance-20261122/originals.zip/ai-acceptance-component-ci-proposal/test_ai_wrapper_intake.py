"""Local synthetic controls for new wrapper intake only; no Go/provider/project import."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("reviewed_ai_wrapper", HERE / "run_ai_acceptance_component_ci.py")
W = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(W)


class OfflineWrapperIntake(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="synthetic-ai-wrapper-control-")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name).resolve()
        self.root = self.base / "empty-nonrepository-subject"
        self.harness = self.base / "empty-nonrepository-harness"
        self.root.mkdir()
        self.harness.mkdir()
        self.out, self.ownership = W.create_owned_output(str(self.base / "owned-output"), (self.root, self.harness))
        self.inv = W.fixed_inventory((HERE / "ai_acceptance_ci_inventory.json").read_bytes())
        self.outer = {"started_at": "2026-11-22T00:00:00Z", "finished_at": "2026-11-22T00:00:10Z"}
        self.python = "/synthetic/nonexecuted/python3"
        self.rp50 = self.out / "producer/rp50-control"
        self.rp50.mkdir()
        self.nested = self.rp50 / "ai-harness-1234567890"
        self.nested.mkdir()
        self.discovery = {"selection_complete": True, "found": list(W.PYTHON_TESTS), "passed": list(W.PYTHON_TESTS),
                          "tests_run": 15, "failures": 0, "errors": 0, "skipped": 0,
                          "expected_failures": 0, "unexpected_successes": 0}
        marker = "    fixture.go:1: P15_RP50_HARNESS_CONTROL_DISCOVERY:" + json.dumps(self.discovery) + "\n"
        events = [self.event("start", "", 1), self.event("run", W.NESTED_TEST, 1),
                  self.event("output", W.NESTED_TEST, 2, Output=marker[:60]),
                  self.event("output", W.NESTED_TEST, 2, Output=marker[60:]),
                  self.event("pass", W.NESTED_TEST, 2, Elapsed=1), self.event("pass", "", 2, Elapsed=1)]
        self.nested_raw = b"".join((json.dumps(row) + "\n").encode() for row in events)
        self.write_process(self.nested, "ai-harness", "RP50-harness", W.NESTED_COMMAND, [W.NESTED_TEST],
                           0, 1, 3, self.nested_raw, b"")
        self.record = {"evidence_id": "synthetic-only-never-published", "requirements": ["RP50"], "tier": "harness-unit",
            "implementation_sha": W.EXPECTED_SHA, "test_id": W.PACKAGE + ":" + W.NESTED_TEST,
            "command": list(W.NESTED_COMMAND), "exit_code": 0, "result": "passed",
            "assertions": {"harness_scope": "control-flow-only", "ai_quality_measured": "false",
                           "external_evaluation": "AI_EVAL_NOT_RUN", "required_production_tests": W.NESTED_TEST,
                           "required_python_tests": "\n".join(W.PYTHON_TESTS)},
            "artifacts": [{"path": str(self.nested / ("ai-harness" + suffix)),
                           "sha256": W.sha((self.nested / ("ai-harness" + suffix)).read_bytes())}
                          for suffix in ("-process.json", "-go.jsonl", "-stderr.log")]}
        self.saved = {"implementation_sha": W.EXPECTED_SHA, "scope": "control-flow-only", "ai_quality_measured": False,
            "records": [self.record], "results": {"AI01": {"id": "AI01", "status": "AI_EVAL_NOT_RUN", "passed": False},
            "RP50": {"id": "RP50", "status": "PENDING_EXTERNAL", "passed": False, "executed_levels": ["harness-unit"]}}}
        self.save_records()
        self.canonical = self.out / "producer/canonical-missing-originals"
        self.canonical.mkdir()
        (self.canonical / "bundle").mkdir()
        self.intake = self.canonical / "actual-intake"
        self.intake.mkdir()
        for name in ("before.original.json", "after.original.json"):
            (self.canonical / name).write_bytes(b"{}\n")
        command = (self.python, "-E", "-s", "-B", str(self.root / "tools/language-ai-eval/evaluation_intake.py"),
                   "--bundle", str(self.canonical / "bundle"), "--trusted-asana-response", str(self.canonical / "before.original.json"),
                   "--output", str(self.intake / "ai-measurement-before-intake.json"))
        self.write_process(self.intake, "ai-measurement-before", "AI01+RP50", command, None, 1, 4, 5,
                           b"", b"EVALUATION_INTAKE_REJECTED\n")
        self.installed = {"files": {Path(row["path"]).name: row["sha256"] for row in self.inv["production_source_witnesses"]
                                    if row["path"] in self.inv["python_package_paths"]},
            "installed_outside_repository": True, "required_python_tests": list(W.PYTHON_TESTS),
            "scope": "installed-control-flow-only", "ai_quality_measured": False}
        self.outer_raw = self.outer_markers()

    def event(self, action, test, second, **extra):
        row = {"Time": "2026-11-22T00:00:%02dZ" % second, "Action": action, "Package": W.PACKAGE}
        if test:
            row["Test"] = test
        row.update(extra)
        return row

    def write_process(self, directory, prefix, requirement, command, tests, code, start, finish, raw, stderr):
        receipt = {"format_version": 1, "requirement": requirement, "source_commit": W.EXPECTED_SHA,
            "source_clean_before": True, "source_clean_after": True,
            "source_files": [{"path": row["path"], "sha256": row["sha256"]} for row in self.inv["production_source_witnesses"]],
            "command": list(command), "required_tests": tests, "discovered_tests": tests,
            "started_utc": "2026-11-22T00:00:%02dZ" % start, "finished_utc": "2026-11-22T00:00:%02dZ" % finish,
            "elapsed_seconds": finish - start, "exit_code": code, "timed_out": False,
            "raw_sha256": W.sha(raw), "raw_bytes": len(raw), "stderr_sha256": W.sha(stderr), "stderr_bytes": len(stderr),
            "benchmark_sha256": "", "benchmark_bytes": 0}
        (directory / (prefix + "-process.json")).write_bytes(W.encoded(receipt))
        (directory / (prefix + "-go.jsonl")).write_bytes(raw)
        (directory / (prefix + "-stderr.log")).write_bytes(stderr)

    def save_records(self):
        (self.rp50 / "original-control-records.json").write_bytes(W.encoded(self.saved))

    def change_nested_receipt(self, change):
        path = self.nested / "ai-harness-process.json"
        receipt = W.strict_json(path.read_bytes())
        change(receipt)
        path.write_bytes(W.encoded(receipt))
        self.record["artifacts"][0]["sha256"] = W.sha(path.read_bytes())
        self.save_records()

    def outer_markers(self):
        test = "TestP15BRG32InstalledAIHarness"
        first = "P15_RP50_HARNESS_CONTROL_DISCOVERY:" + json.dumps(self.discovery) + "\n"
        second = "P15_BRG32_INSTALLED_HARNESS:" + json.dumps(self.installed) + "\n"
        return b"".join((json.dumps(self.event("output", test, 6, Output=text)) + "\n").encode()
                        for text in (first[:60], first[60:], second))

    def inspect(self):
        return W.inspect_ai_originals(self.out, self.root, self.inv, self.outer, self.outer_raw, self.python)

    def test_healthy_synthetic_control_preserves_pending_and_cleanup_scope(self):
        result = self.inspect()
        self.assertEqual(result["retained_producer_files"], 9)
        self.assertEqual(result["AI01"]["status"], "AI_EVAL_NOT_RUN")
        self.assertEqual(result["RP50"]["status"], "PENDING_EXTERNAL")
        self.assertFalse(result["nested_cleanup_proved"])
        self.assertFalse(result["ai_quality_measured"])
        self.assertFalse(result["formal_acceptance_granted"])

    def test_missing_nested_original_rejects(self):
        (self.nested / "ai-harness-process.json").unlink()
        with self.assertRaises(FileNotFoundError):
            self.inspect()

    def test_reconciled_wrong_source_witness_rejects(self):
        self.change_nested_receipt(lambda row: row["source_files"][0].update(sha256="f" * 64))
        with self.assertRaisesRegex(RuntimeError, "exact production source witness"):
            self.inspect()

    def test_reconciled_child_time_outside_outer_rejects(self):
        self.change_nested_receipt(lambda row: row.update(started_utc="2026-11-22T00:00:20Z", finished_utc="2026-11-22T00:00:22Z"))
        with self.assertRaisesRegex(RuntimeError, "outside its actual interval"):
            self.inspect()

    def test_reconciled_boolean_exit_code_rejects(self):
        self.change_nested_receipt(lambda row: row.update(exit_code=False))
        with self.assertRaisesRegex(RuntimeError, "unexpected nested process result"):
            self.inspect()

    def test_reconciled_changed_command_rejects(self):
        self.change_nested_receipt(lambda row: row["command"].__setitem__(4, "-timeout=30m"))
        with self.assertRaisesRegex(RuntimeError, "command/source/inventory mismatch"):
            self.inspect()

    def test_measured_quality_claim_rejects(self):
        self.saved["ai_quality_measured"] = True
        self.save_records()
        with self.assertRaisesRegex(RuntimeError, "claim an unexecuted scope"):
            self.inspect()

    def test_installed_package_hash_change_rejects(self):
        self.installed["files"]["runner.py"] = "f" * 64
        self.outer_raw = self.outer_markers()
        with self.assertRaisesRegex(RuntimeError, "installed BRG32 receipt lost"):
            self.inspect()

    def test_incomplete_installed_python_selection_rejects(self):
        self.discovery["passed"] = self.discovery["passed"][:-1]
        self.outer_raw = self.outer_markers()
        with self.assertRaisesRegex(RuntimeError, "incomplete fixed Python discovery"):
            self.inspect()

    def test_duplicate_installed_marker_rejects(self):
        self.outer_raw += self.outer_raw
        with self.assertRaisesRegex(RuntimeError, "duplicated original marker"):
            self.inspect()

    def test_stale_canonical_success_report_rejects(self):
        (self.intake / "ai-measurement-before-intake.json").write_bytes(b"{}\n")
        with self.assertRaisesRegex(RuntimeError, "did not reject missing originals exactly"):
            self.inspect()

    def test_foreign_retained_original_rejects(self):
        (self.out / "producer/unexpected.json").write_bytes(b"{}\n")
        with self.assertRaisesRegex(RuntimeError, "unexpected or missing retained"):
            self.inspect()

    def test_ancestor_alias_inside_checkout_rejects_before_creation(self):
        alias = self.base / "alias"
        alias.symlink_to(self.root, target_is_directory=True)
        with self.assertRaisesRegex(RuntimeError, "physically outside both checkouts"):
            W.create_owned_output(str(alias / "escaped-output"), (self.root, self.harness))
        self.assertFalse((self.root / "escaped-output").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
