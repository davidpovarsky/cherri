# Bounded AI component wrapper review

Reviewed source: `run_ai_acceptance_component_ci.py`, SHA-256 `03b628513980b19b95b05ae5ceb723c8d83b314a25eda93a40d8605419821624`; inventory `b1d18e6e09748e1a2e9a6b465996f1ca6e0297cc636dce03730604b9aad8b746`; workflow `b210d3e1639b3445b61694fc3a44958445c5b9229a19e18a733e60d6df71b0ac`.

No scoped source blocker found. This review covered the new fixed inventory, physical output ownership, nested process and original-artifact intake, installed package discovery, final main-path acceptance predicate and workflow connection. The previously reviewed generic helper block was not executed again.

The inventory binds 47 exact source witnesses (46 production witnesses plus the installed BRG32 test), nine fixed parents and all 72 outer events. The full 132 Python parent inventory is explicitly not the execution selection. Both actual fifteen-control discovery receipts require complete identical fixed names, integer counts, no skipped or failed controls and unique output markers. The installed package receipt must retain all fifteen exact package file hashes.

The RP50 record is joined to its one owned generated child and all three named original artifacts. Intake recomputes original bytes and hashes, requires the exact source/command/test inventory and terminal result, checks actual child intervals inside the outer process, then parses the original Go events. Canonical missing-originals evidence requires the actual Python command and source witnesses, exit 1 without timeout, empty stdout, exact rejection stderr and no stale success report. All nine retained producer files must match the fixed path set. Synthetic Asana control inputs remain explicitly synthetic.

The outer main path checks exact subject and workflow files before and after execution. Original intake must finish successfully before `passed_all` can be true. Missing or invalid child originals cannot become success; all model-quality, formal and Apple flags remain false. The documentation correctly limits process cleanup proof to the owned outer PGID: original nested receipts lack PID/cleanup fields, and `nested_cleanup_proved` remains false. Successful fixed local controls do not satisfy the remaining external AI01/RP50 obligation or the complete BRG32 scenario.

Three relevant subject files were independently fetched from exact `824333e86b120e795ce44079e4cc45743e2668a9` and reconciled with the fixed inventory: `ai_evaluation_execution_test.go`, `ai_measurement_execution_test.go`, and `ai_measurement_execution.go`. Their connector originals are in `peer-subject-readback.original.json`. This confirmed that the actual retention paths and command protocol match the wrapper; older local staging files were not used to endorse the final retention behavior.

This was a read-only source review. No Go, Python control replay, provider request, host operation or native execution was performed. Actual CI and original-artifact intake remain required.
