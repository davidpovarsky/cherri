"""Read-only reconciliation of the existing public CI originals. No test execution."""
import collections
import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import zipfile

HERE = Path(__file__).resolve().parent
ORIGINALS = HERE / "originals"
SUBJECT = "824333e86b120e795ce44079e4cc45743e2668a9"
WORKFLOW = "ccd3ec6ca3ae9ddefc7b4bdb798ebb93ecdcb6fa"
PACKAGE = "github.com/electrikmilk/cherri/tools/language-acceptance"
SOURCE_BYTES = HERE.parent / "acceptance-ai-integration-29f35c71/combined-proposed"
WRAPPER_BYTES = HERE.parent / "ai-acceptance-component-ci-proposal"


def pairs(items):
    result = {}
    for key, value in items:
        assert key not in result, ("duplicate key", key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def read(path):
    return parse(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def tick(value):
    match = re.fullmatch(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?(Z|\+00:00)", value)
    assert match, value
    seconds = int(datetime.datetime.fromisoformat(match[1] + "+00:00").timestamp())
    return seconds * 10**9 + int((match[2] or "").ljust(9, "0"))


def number(value):
    assert type(value) in (int, float) and math.isfinite(value) and value >= 0, value
    return value


def interval(process, begin="started_at", end="finished_at"):
    first, last = tick(process[begin]), tick(process[end])
    assert first <= last
    elapsed = number(process["elapsed_seconds"])
    assert abs((last - first) / 1e9 - elapsed) < 1
    return first, last


def stream(raw_path, record, size_key="bytes", hash_key="sha256"):
    raw = raw_path.read_bytes()
    assert type(record[size_key]) is int and len(raw) == record[size_key]
    assert sha(raw) == record[hash_key]
    return raw


def ledger(path, expected, first, last):
    assert len(expected) == len(set(expected))
    expected = set(expected)
    started, terminal, active, outputs = {}, {}, set(), collections.defaultdict(str)
    package_starts, package_ends, previous, rows = 0, [], first, []
    for raw in path.read_bytes().splitlines():
        assert raw
        row = parse(raw)
        rows.append(row)
        now = tick(row["Time"])
        assert first <= now <= last and now >= previous, row
        previous = now
        assert row.get("Package") == PACKAGE, row
        action, test = row["Action"], row.get("Test")
        if not test:
            if action == "start":
                assert package_starts == 0 and not package_ends
                package_starts += 1
            elif action in ("pass", "fail", "skip"):
                assert package_starts == 1 and not package_ends and not active
                number(row.get("Elapsed"))
                package_ends.append(action)
            else:
                assert action == "output" and package_starts == 1 and not package_ends, row
            continue
        assert test in expected and package_starts == 1 and not package_ends, row
        if action == "run":
            assert test not in started
            ancestors = [name for name in expected if test.startswith(name + "/")]
            if ancestors:
                assert max(ancestors, key=len) in active, test
            started[test] = now
            active.add(test)
        elif action in ("pass", "fail", "skip"):
            assert test in active and test not in terminal
            assert not any(name.startswith(test + "/") for name in active)
            number(row.get("Elapsed"))
            terminal[test] = action
            active.remove(test)
        else:
            assert action == "output" and test in active, row
            assert isinstance(row.get("Output"), str)
            outputs[test] += row["Output"]
    assert package_starts == 1 and package_ends == ["pass"]
    assert set(started) == set(terminal) == expected and not active
    assert all(value == "pass" for value in terminal.values())
    return {"expected": len(expected), "started": len(started), "passed": len(terminal),
            "failed": 0, "skipped": 0, "unstarted": [], "unterminated": [],
            "unexpected_packages": [], "package_terminal": "pass",
            "raw_bytes": path.stat().st_size, "raw_sha256": sha(path.read_bytes()),
            "json_event_rows": len(rows)}, outputs


def marker(text, prefix):
    assert text.count(prefix) == 1, prefix
    line = text.split(prefix, 1)[1].splitlines()[0]
    return parse(line)


summary = read(ORIGINALS / "summary.json")
launch = read(ORIGINALS / "launch.json")
assert summary["source"] == launch["source"] == SUBJECT
assert summary["workflow_source"] == launch["workflow_source"] == WORKFLOW
assert summary["actual_go_started"] is summary["passed_all"] is True
assert summary["errors"] == []
for key in ("ai_quality_measured", "formal_acceptance_granted", "apple_runtime_proved", "nested_cleanup_proved"):
    assert summary[key] is False
assert summary["nested_process_terminal_receipts_complete"] is True
assert summary["cleanup_evidence_status"] == "OUTER_PGID_COMPLETE_NESTED_TERMINALS_BOUND"

archive = (HERE / "artifact.original.zip").read_bytes()
assert len(archive) == 1859491 and sha(archive) == "3aac0728878c592fafe31ea4498c85390f63992babaac2c0c7f8326d2d415f51"
original_inventory = read(ORIGINALS / "original-inventory.json")
assert original_inventory["subject"] == SUBJECT
members = original_inventory["members"]
assert len(members) == len({item["path"] for item in members}) == 113
with zipfile.ZipFile(HERE / "artifact.original.zip") as archived:
    assert len(archived.namelist()) == len(set(archived.namelist())) == 114
    assert set(archived.namelist()) == {item["path"] for item in members} | {"original-inventory.json"}
    for path in archived.namelist():
        assert archived.read(path) == (ORIGINALS / path).read_bytes()
for item in members:
    stream(ORIGINALS / item["path"], item)

fixed_raw = (ORIGINALS / "metadata/fixed-inventory-blob.stdout.original").read_bytes()
assert fixed_raw == (WRAPPER_BYTES / "ai_acceptance_ci_inventory.json").read_bytes()
assert sha(fixed_raw) == "b1d18e6e09748e1a2e9a6b465996f1ca6e0297cc636dce03730604b9aad8b746"
fixed = parse(fixed_raw)
assert fixed["subject_sha"] == SUBJECT
assert len(fixed["outer_parents"]) == 9 and len(fixed["outer_events"]) == 72
assert len(fixed["production_source_witnesses"]) == 46 and len(fixed["outer_source_witnesses"]) == 47
assert len(fixed["python_package_paths"]) == 15 and len(fixed["python_control_ids"]) == 15
assert fixed["source_package_132_selected_for_execution"] is fixed["real_model_selected"] is fixed["formal_acceptance_granted"] is False
expected_command = ["go", "test", "./tools/language-acceptance", "-run",
                    "^(" + "|".join(fixed["outer_parents"]) + ")$", "-count=1", "-json", "-timeout=9m"]
assert summary["command"] == launch["command"] == expected_command
assert launch["outer_go_timeout_seconds"] == 540 and launch["driver_timeout_seconds"] == 570
assert launch["workflow_step_timeout_seconds"] == 600
assert launch["nested_go_timeout_seconds"] == 180 and launch["nested_driver_timeout_seconds"] == 240
assert launch["python_harness_timeout_seconds"] == launch["canonical_intake_timeout_seconds"] == 120

trees = {}
for role, label, expected_tree, expected_sha, count in (
    ("subject", "source", "209be79df62637145c47ca187d7c6b870202432b", SUBJECT, 6361),
    ("workflow", "workflow", "174b8f6a479aa7f4facb5fd2c545ca2328c2bf66", WORKFLOW, 6364),
):
    api = read(HERE / (role + "-tree.github-original.json"))
    assert api["sha"] == expected_tree and api["truncated"] is False
    entries = {item["path"]: (item["mode"], item["sha"]) for item in api["tree"] if item["type"] != "tree"}
    assert len(entries) == count
    trees[role] = entries
    before = summary[label + "_before"]
    assert before == summary[label + "_after"] and before["head"] == expected_sha
    expected_branch = "" if role == "subject" else "audit/cherri-p10r15-ai-acceptance-ci-20261122"
    assert before["status"] == "" and before["branch"] == expected_branch and before["ignored_checked"] is True
    assert before["tracked_files"] == count
    allowed_origin = {"https://github.com/davidpovarsky/cherri.git"} if role == "subject" else {"https://github.com/davidpovarsky/cherri", "https://github.com/davidpovarsky/cherri.git"}
    assert before["origin"] in allowed_origin
    for phase in ("before", "after"):
        prefix = ORIGINALS / "metadata" / (phase + "-" + role)
        for field, value in (("head", expected_sha), ("branch", expected_branch), ("status", ""), ("root", before["root"]), ("origin", before["origin"])):
            raw = Path(str(prefix) + "-" + field + ".stdout.original").read_bytes()
            assert raw.decode().strip() == value
            if field == "status":
                assert raw == b""
        raw_tree = Path(str(prefix) + "-tree.stdout.original").read_bytes()
        raw_index = Path(str(prefix) + "-index.stdout.original").read_bytes()
        flags = Path(str(prefix) + "-flags.stdout.original").read_bytes()
        assert sha(raw_tree) == before["git_tree_sha256"]
        assert sha(raw_index) == before["index_stage_sha256"]
        assert sha(flags) == before["index_flags_sha256"]
        observed, staged = {}, {}
        for raw in raw_tree.split(b"\0"):
            if raw:
                metadata, path = raw.split(b"\t", 1)
                mode, kind, identity = metadata.decode().split()
                assert kind in ("blob", "commit") and path.decode() not in observed
                observed[path.decode()] = (mode, identity)
        for raw in raw_index.split(b"\0"):
            if raw:
                metadata, path = raw.split(b"\t", 1)
                mode, identity, stage = metadata.decode().split()
                assert stage == "0" and path.decode() not in staged
                staged[path.decode()] = (mode, identity)
        assert observed == staged == entries
        flag_rows = [raw for raw in flags.split(b"\0") if raw]
        assert len(flag_rows) == count and all(raw.startswith(b"H ") for raw in flag_rows)
        assert {raw[2:].decode() for raw in flag_rows} == set(entries)

outer = read(ORIGINALS / "outer-go.process.json")
outer_first, outer_last = interval(outer)
assert outer == summary["process"] and outer["command"] == expected_command
assert outer["cwd"] == summary["source_before"]["root"] and outer["budget_seconds"] == 570
metadata_count = 0
git_prefix = ["git", "--no-replace-objects", "-c", "core.fsmonitor=false"]
operations = {"root": ["rev-parse", "--show-toplevel"], "head": ["rev-parse", "HEAD"],
              "origin": ["remote", "get-url", "origin"], "branch": ["branch", "--show-current"],
              "status": ["status", "--porcelain=v1", "-z", "--untracked-files=all", "--ignored=matching"],
              "tree": ["ls-tree", "-r", "-z", "--full-tree"], "index": ["ls-files", "--stage", "-z"],
              "flags": ["ls-files", "-v", "-z"]}
for path in [*sorted((ORIGINALS / "metadata").glob("*.process.json")), ORIGINALS / "outer-go.process.json"]:
    process = read(path)
    first, last = interval(process)
    assert type(process["exit_code"]) is int and process["exit_code"] == 0
    assert process["timed_out"] is False and process["error"] is None and process["state"] == "TERMINAL"
    assert process["passed"] is True
    cleanup = process["cleanup"]
    assert type(process["pid"]) is int and process["pid"] > 1 and cleanup["owned_process_group"] == process["pid"]
    assert cleanup["complete"] is True and cleanup["orphaned_live_group"] is False
    assert cleanup["initial_members"] == cleanup["final_members"] == cleanup["signals"] == cleanup["inspection_errors"] == []
    assert cleanup["root_returncode"] == 0 and cleanup["term_budget_seconds"] == 5 and cleanup["kill_budget_seconds"] == 10
    assert process["elapsed_seconds"] < process["budget_seconds"]
    prefix = str(path)[:-len(".process.json")]
    for name in ("stdout", "stderr"):
        stream(Path(prefix + "." + name + ".original"), process[name])
    if path.parent.name == "metadata":
        metadata_count += 1
        assert process["budget_seconds"] == 30
        stem = path.name[:-len(".process.json")]
        if stem == "fixed-inventory-blob":
            command = git_prefix + ["show", WORKFLOW + ":tools/p10r15/ai_acceptance_ci_inventory.json"]
            cwd = summary["workflow_before"]["root"]
            assert last <= outer_first
        else:
            phase, role, field = stem.split("-", 2)
            expected = SUBJECT if role == "subject" else WORKFLOW
            command = git_prefix + operations[field] + ([expected] if field == "tree" else [])
            cwd = summary[("source" if role == "subject" else "workflow") + "_before"]["root"]
            assert last <= outer_first if phase == "before" else first >= outer_last
        assert process["command"] == command and process["cwd"] == cwd
assert metadata_count == 33

source_digests = {}
observed_sources = {item["path"]: item for item in summary["source_before"]["source_files"]}
assert len(observed_sources) == 47
for witness in fixed["outer_source_witnesses"]:
    path = witness["path"]
    raw = (SOURCE_BYTES / path).read_bytes()
    assert len(raw) == witness["bytes"] and sha(raw) == witness["sha256"] and blob(raw) == witness["git_blob"]
    assert trees["subject"][path] == ("100644", blob(raw))
    actual = observed_sources[path]
    for field in ("path", "bytes", "sha256", "git_blob"):
        assert actual[field] == witness[field]
    assert actual["git_mode"] == "100644"
    source_digests[path] = sha(raw)
for item in summary["workflow_before"]["source_files"]:
    raw = (WRAPPER_BYTES / Path(item["path"]).name).read_bytes()
    assert len(raw) == item["bytes"] and sha(raw) == item["sha256"]
    assert blob(raw) == item["git_blob"] and trees["workflow"][item["path"]] == ("100644", blob(raw))
assert blob(fixed_raw) == trees["workflow"]["tools/p10r15/ai_acceptance_ci_inventory.json"][1]
outer_ledger, outer_output = ledger(ORIGINALS / "outer-go.stdout.original", fixed["outer_events"], outer_first, outer_last)
for field in ("started", "passed", "failed", "skipped", "unstarted", "unterminated"):
    assert summary[field] == outer_ledger[field]

producer_files = sorted(str(path.relative_to(ORIGINALS / "producer")) for path in (ORIGINALS / "producer").rglob("*") if path.is_file())
rp50_paths = list((ORIGINALS / "producer/rp50-control").glob("ai-harness-*/ai-harness-process.json"))
assert len(rp50_paths) == 1
rp50_path = rp50_paths[0]
rp50 = read(rp50_path)
canonical_path = ORIGINALS / "producer/canonical-missing-originals/actual-intake/ai-measurement-before-process.json"
canonical = read(canonical_path)
required_producer = ["rp50-control/original-control-records.json",
                     *[str(rp50_path.parent.relative_to(ORIGINALS / "producer") / name) for name in ("ai-harness-process.json", "ai-harness-go.jsonl", "ai-harness-stderr.log")],
                     "canonical-missing-originals/before.original.json", "canonical-missing-originals/after.original.json",
                     *["canonical-missing-originals/actual-intake/" + name for name in ("ai-measurement-before-process.json", "ai-measurement-before-go.jsonl", "ai-measurement-before-stderr.log")]]
assert producer_files == sorted(required_producer) and len(producer_files) == 9
production_digests = {item["path"]: item["sha256"] for item in fixed["production_source_witnesses"]}
for path, process, exit_code, requirement in ((rp50_path, rp50, 0, "RP50-harness"), (canonical_path, canonical, 1, "AI01+RP50")):
    first, last = interval(process, "started_utc", "finished_utc")
    assert outer_first <= first <= last <= outer_last
    assert process["format_version"] == 1 and process["requirement"] == requirement
    assert process["source_commit"] == SUBJECT and process["source_clean_before"] is process["source_clean_after"] is True
    assert len(process["source_files"]) == 46 and {item["path"]: item["sha256"] for item in process["source_files"]} == production_digests
    assert type(process["exit_code"]) is int and process["exit_code"] == exit_code and process["timed_out"] is False
    assert process["benchmark_sha256"] == "" and process["benchmark_bytes"] == 0
    prefix = str(path)[:-len("-process.json")]
    stream(Path(prefix + "-go.jsonl"), process, "raw_bytes", "raw_sha256")
    stream(Path(prefix + "-stderr.log"), process, "stderr_bytes", "stderr_sha256")
rp50_command = ["go", "test", "-count=1", "-json", "-timeout", "3m0s", "./tools/language-acceptance", "-run", "^(TestP15RP50AIHarnessControlFlow)$"]
assert rp50["command"] == rp50_command and rp50["elapsed_seconds"] < 240
assert rp50["required_tests"] == rp50["discovered_tests"] == fixed["nested_rp50_events"] == ["TestP15RP50AIHarnessControlFlow"]
rp50_ledger, rp50_output = ledger(rp50_path.parent / "ai-harness-go.jsonl", fixed["nested_rp50_events"], *interval(rp50, "started_utc", "finished_utc"))

control_receipts = {}
for label, output in (("source_RP50", rp50_output["TestP15RP50AIHarnessControlFlow"]), ("installed_BRG32", outer_output["TestP15BRG32InstalledAIHarness"])):
    receipt = marker(output, "P15_RP50_HARNESS_CONTROL_DISCOVERY:")
    assert receipt["selection_complete"] is True
    assert receipt["found"] == receipt["passed"] == fixed["python_control_ids"]
    for field in ("tests_run", "failures", "errors", "skipped", "expected_failures", "unexpected_successes"):
        assert type(receipt[field]) is int and receipt[field] == (15 if field == "tests_run" else 0)
    control_receipts[label] = receipt
installed = marker(outer_output["TestP15BRG32InstalledAIHarness"], "P15_BRG32_INSTALLED_HARNESS:")
expected_package = {path.removeprefix("tools/language-ai-eval/"): source_digests[path] for path in fixed["python_package_paths"]}
assert len(expected_package) == 15 and installed["files"] == expected_package
assert installed["required_python_tests"] == fixed["python_control_ids"]
assert installed["scope"] == "installed-control-flow-only" and installed["installed_outside_repository"] is True
assert installed["ai_quality_measured"] is False
assert sorted(path for path in trees["subject"] if path.startswith("tools/language-ai-eval/")) == fixed["python_package_paths"]

canonical_root = summary["source_before"]["root"].rsplit("/", 1)[0] + "/cherri-ai-acceptance-44977459353-1/producer/canonical-missing-originals"
assert canonical["command"][1:] == ["-E", "-s", "-B", summary["source_before"]["root"] + "/tools/language-ai-eval/evaluation_intake.py", "--bundle", canonical_root + "/bundle", "--trusted-asana-response", canonical_root + "/before.original.json", "--output", canonical_root + "/actual-intake/ai-measurement-before-intake.json"]
assert re.fullmatch(r"/opt/hostedtoolcache/Python/3\.12\.\d+/x64/bin/python3\.12", canonical["command"][0])
assert canonical["required_tests"] is canonical["discovered_tests"] is None and canonical["elapsed_seconds"] < 120
assert (canonical_path.parent / "ai-measurement-before-go.jsonl").read_bytes() == b""
assert (canonical_path.parent / "ai-measurement-before-stderr.log").read_bytes() == b"EVALUATION_INTAKE_REJECTED\n"
for name in ("before.original.json", "after.original.json"):
    assert (canonical_path.parent.parent / name).read_bytes() == b"{}\n"
assert not (canonical_path.parent / "ai-measurement-before-intake.json").exists()

records_path = ORIGINALS / "producer/rp50-control/original-control-records.json"
records = read(records_path)
assert records["implementation_sha"] == SUBJECT and records["scope"] == "control-flow-only" and records["ai_quality_measured"] is False
assert set(records["results"]) == {"AI01", "RP50"} and len(records["records"]) == 1
assert records["results"]["AI01"]["status"] == "AI_EVAL_NOT_RUN" and records["results"]["AI01"]["passed"] is False
assert not records["results"]["AI01"].get("executed_levels")
assert records["results"]["RP50"]["status"] == "PENDING_EXTERNAL" and records["results"]["RP50"]["passed"] is False
assert records["results"]["RP50"]["executed_levels"] == ["harness-unit"]
record = records["records"][0]
assert record["requirements"] == ["RP50"] and record["tier"] == "harness-unit" and record["implementation_sha"] == SUBJECT
assert record["test_id"] == PACKAGE + ":TestP15RP50AIHarnessControlFlow" and record["command"] == rp50_command
assert type(record["exit_code"]) is int and record["exit_code"] == 0 and record["result"] == "passed"
assert record["assertions"]["ai_quality_measured"] == "false" and record["assertions"]["external_evaluation"] == "AI_EVAL_NOT_RUN"
assert record["assertions"]["harness_scope"] == "control-flow-only"
assert record["assertions"]["required_python_tests"].splitlines() == fixed["python_control_ids"]
expected_artifacts = {name: sha((rp50_path.parent / name).read_bytes()) for name in ("ai-harness-process.json", "ai-harness-go.jsonl", "ai-harness-stderr.log")}
assert len(record["artifacts"]) == 3
for artifact in record["artifacts"]:
    name = Path(artifact["path"]).name
    assert name in expected_artifacts and artifact["sha256"] == expected_artifacts.pop(name)
    expected_prefix = canonical_root.rsplit("/", 1)[0] + "/rp50-control/" + rp50_path.parent.name + "/"
    assert artifact["path"] == expected_prefix + name
assert not expected_artifacts

report = {"schema": "cherri.ai-component-original-reconciliation/v1", "audited_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "run": 44977459353, "subject": SUBJECT, "workflow": WORKFLOW,
          "artifact_bytes": len(archive), "artifact_sha256": sha(archive), "original_files_verified": 114,
          "metadata_original_processes_verified": metadata_count,
          "tracked_tree_entries": {role: len(tree) for role, tree in trees.items()},
          "source_witnesses": 47, "production_source_witnesses": 46,
          "source_and_workflow_unchanged": True, "all_witness_actual_bytes_match_git_blobs": True,
          "outer": outer_ledger, "outer_elapsed_seconds": outer["elapsed_seconds"],
          "RP50": {"go": rp50_ledger, "elapsed_seconds": rp50["elapsed_seconds"], "python_passed": 15,
                   "status": "PENDING_EXTERNAL", "executed_levels": ["harness-unit"]},
          "BRG32_installed": {"package_files": 15, "python_passed": 15, "complete_formal_scenario_executed": False},
          "canonical_missing_originals": {"exit_code": 1, "elapsed_seconds": canonical["elapsed_seconds"],
                    "stderr_sha256": canonical["stderr_sha256"], "expected_rejection_observed": True,
                    "synthetic_inputs_are_authenticated_Asana": False},
          "retained_producer_originals": 9, "AI01": "AI_EVAL_NOT_RUN",
          "outer_owned_process_group_active": False, "nested_process_terminal_receipts_complete": True,
          "nested_cleanup_proved": False, "new_test_or_compiler_execution": False,
          "ai_quality_measured": False, "formal_acceptance_granted": False, "apple_runtime_proved": False}
out = HERE / "acceptance-original-intake.json"
assert not out.exists(), "preserve earlier reconciliation"
out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(report, indent=2))
