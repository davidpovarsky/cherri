"""Independent, read-only source/process/event reconciliation. No test execution."""
import collections
import datetime
import hashlib
import json
import math
import pathlib
import re

HERE = pathlib.Path(__file__).resolve().parent
ORIGINALS = HERE / "originals"

def pairs(items):
    out = {}
    for key, value in items:
        assert key not in out, ("duplicate JSON key", key)
        out[key] = value
    return out

def parse(raw):
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def read(path):
    return parse(path.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def timestamp(value):
    match = re.fullmatch(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?(Z|\+00:00)", value)
    assert match, value
    seconds = int(datetime.datetime.fromisoformat(match[1] + "+00:00").timestamp())
    return seconds * 10**9 + int((match[2] or "").ljust(9, "0"))

def ledger(path, expected, package, began, ended):
    expected = set(expected)
    rows = [parse(line) for line in path.read_bytes().splitlines() if line]
    started, terminal, active = {}, {}, set()
    package_started = 0
    package_terminal = []
    previous = -1
    for row in rows:
        tick = timestamp(row["Time"])
        assert began <= tick <= ended and tick >= previous, row
        previous = tick
        assert row.get("Package") == package, row
        action, test = row["Action"], row.get("Test")
        if not test:
            if action == "start":
                package_started += 1
            elif action in ("pass", "fail", "skip"):
                assert not active, active
                package_terminal.append(action)
                assert type(row.get("Elapsed")) in (int, float) and math.isfinite(row["Elapsed"]) and row["Elapsed"] >= 0
            continue
        assert test in expected, test
        if action == "run":
            assert test not in started and package_started == 1 and not package_terminal, test
            ancestors = [name for name in expected if test.startswith(name + "/")]
            if ancestors:
                assert max(ancestors, key=len) in active, test
            started[test] = tick
            active.add(test)
        elif action in ("pass", "fail", "skip"):
            assert test in active and test not in terminal
            assert not any(name.startswith(test + "/") for name in active)
            assert type(row.get("Elapsed")) in (int, float) and math.isfinite(row["Elapsed"]) and row["Elapsed"] >= 0
            terminal[test] = action
            active.remove(test)
        elif action == "output":
            assert test in active, ("inactive test output", test)
        else:
            raise AssertionError(("unexpected action", action))
    assert package_started == 1 and len(package_terminal) == 1
    counts = collections.Counter(terminal.values())
    return {
        "expected": len(expected), "started": len(started), "passed": counts["pass"],
        "failed": counts["fail"], "skipped": counts["skip"],
        "unstarted": sorted(expected - started.keys()), "unterminated": sorted(active),
        "failed_tests": sorted(test for test, result in terminal.items() if result == "fail"),
        "package_terminal": package_terminal[0], "raw_sha256": sha(path.read_bytes()),
    }

summary = read(ORIGINALS / "summary.json")
assert summary["source"] == "1dcc7b3f97da992200fdf6b627f2c67090ea5298"
assert summary["workflow_source"] == "5ef9d581b4ea09832c6b9bfd927a4a06cbbe9057"
assert summary["actual_go_started"] is True and summary["passed_all"] is False
assert summary["errors"] == [] and summary["formal_acceptance_granted"] is False
assert summary["apple_runtime_proved"] is False
inventory_raw = (ORIGINALS / "metadata/inventory-blob.stdout.original").read_bytes()
inventory = parse(inventory_raw)
assert len(inventory["source_paths"]) == len(set(inventory["source_paths"])) == 109
assert {key: len(value) for key, value in inventory["events"].items()} == {"RP21": 232, "BRG16": 213}

trees = {}
for role, label, expected_tree in (
    ("subject", "source", "8d1f6dbfc636d9bba651532338d29f66fd0a4f35"),
    ("workflow", "workflow", "9ca44b1949b02e427780aa3fd5fa996cbb1cc506"),
):
    api = read(HERE / (role + "-tree.github.original.json"))
    assert api["sha"] == expected_tree and api["truncated"] is False
    entries = {item["path"]: (item["mode"], item["sha"]) for item in api["tree"] if item["type"] != "tree"}
    trees[role] = entries
    before = summary[label + "_before"]
    assert before == summary[label + "_after"]
    assert before["status"] == "" and before["ignored_checked"] is True
    assert before["tracked_files"] == len(entries)
    for phase in ("before", "after"):
        prefix = ORIGINALS / "metadata" / (phase + "-" + role)
        assert pathlib.Path(str(prefix) + "-head.stdout.original").read_text().strip() == before["head"]
        assert pathlib.Path(str(prefix) + "-status.stdout.original").read_bytes() == b""
        assert pathlib.Path(str(prefix) + "-origin.stdout.original").read_text().strip() == before["origin"]
        tree_raw = pathlib.Path(str(prefix) + "-tree.stdout.original").read_bytes()
        assert sha(tree_raw) == before["git_tree_sha256"]
        observed = {}
        for line in tree_raw.split(b"\0"):
            if not line:
                continue
            meta, path = line.split(b"\t", 1)
            mode, kind, blob = meta.decode().split()
            assert path.decode() not in observed
            observed[path.decode()] = (mode, blob)
        assert observed == entries
        staged = pathlib.Path(str(prefix) + "-index.stdout.original").read_bytes()
        assert sha(staged) == before["index_stage_sha256"]
        observed_index = {}
        for line in staged.split(b"\0"):
            if not line:
                continue
            meta, path = line.split(b"\t", 1)
            mode, blob, stage = meta.decode().split()
            assert stage == "0" and path.decode() not in observed_index
            observed_index[path.decode()] = (mode, blob)
        assert observed_index == entries
        flags = pathlib.Path(str(prefix) + "-flags.stdout.original").read_bytes()
        assert sha(flags) == before["index_flags_sha256"]
        flags_list = [line for line in flags.split(b"\0") if line]
        assert len(flags_list) == len(entries) and all(line.startswith(b"H ") for line in flags_list)
        assert {line[2:].decode() for line in flags_list} == set(entries)
    for item in before["source_files"]:
        assert entries[item["path"]] == (item["git_mode"], item["git_blob"])
assert sorted(item["path"] for item in summary["source_before"]["source_files"]) == sorted(inventory["source_paths"])
inventory_path = "tools/language-acceptance/combined_index_arithmetic_inventory.json"
assert hashlib.sha1(b"blob " + str(len(inventory_raw)).encode() + b"\0" + inventory_raw).hexdigest() == trees["subject"][inventory_path][1]

metadata_count = 0
for path in sorted((ORIGINALS / "metadata").glob("*.process.json")):
    process = read(path)
    assert process["exit_code"] == 0 and process["timed_out"] is False and process["error"] is None
    assert process["cleanup"]["complete"] is True and process["cleanup"]["final_members"] == []
    prefix = str(path)[:-len(".process.json")]
    for stream in ("stdout", "stderr"):
        raw = pathlib.Path(prefix + "." + stream + ".original").read_bytes()
        assert sha(raw) == process[stream]["sha256"] and len(raw) == process[stream]["bytes"]
    metadata_count += 1

outer = read(ORIGINALS / "outer-go.process.json")
assert outer == summary["process"] and outer["budget_seconds"] == 570
assert outer["exit_code"] == 1 and outer["timed_out"] is False and outer["error"] is None
assert outer["cleanup"]["complete"] is True and outer["cleanup"]["final_members"] == []
assert outer["cleanup"]["signals"] == [] and outer["cleanup"]["orphaned_live_group"] is False
parents = ["TestCombinedIndexArithmeticInventoryAndUnprovedRuntime", "TestCombinedIndexArithmeticActualProductionEvidence"]
outer_names = parents + [parents[0] + "/" + name for name in ("source_count_before_launch", "required_source_before_launch")]
faults = ("missing_child", "skipped_child", "foreign_package", "wrong_source_digest", "missing_source_file", "missing_artifact", "partial_command", "dirty_source", "wrong_requirement", "wrong_tier", "cross_tier_producer")
outer_names += [parents[1] + "/" + requirement + "/" + fault for requirement in ("RP21", "BRG16") for fault in faults]
outer_ledger = ledger(ORIGINALS / "outer-go.stdout.original", outer_names,
    "github.com/electrikmilk/cherri/tools/language-acceptance", timestamp(outer["started_at"]), timestamp(outer["finished_at"]))
for stream in ("stdout", "stderr"):
    raw = (ORIGINALS / ("outer-go." + stream + ".original")).read_bytes()
    assert sha(raw) == outer[stream]["sha256"] and len(raw) == outer[stream]["bytes"]
for field in ("started", "passed", "failed", "skipped", "unstarted", "unterminated"):
    assert outer_ledger[field] == summary[field]

components = {}
source_digests = {item["path"]: item["sha256"] for item in summary["source_before"]["source_files"]}
for path in sorted((ORIGINALS / "producer").glob("*/*-process.json")):
    process = read(path)
    requirement = process["requirement"]
    assert process["source_commit"] == summary["source"]
    assert process["source_clean_before"] is process["source_clean_after"] is True
    assert {item["path"]: item["sha256"] for item in process["source_files"]} == source_digests
    assert process["required_tests"] == inventory["events"][requirement]
    assert process["timed_out"] is False
    prefix = str(path)[:-len("-process.json")]
    raw_path = pathlib.Path(prefix + "-go.jsonl")
    raw = raw_path.read_bytes()
    stderr = pathlib.Path(prefix + "-stderr.log").read_bytes()
    assert sha(raw) == process["raw_sha256"] and len(raw) == process["raw_bytes"]
    assert sha(stderr) == process["stderr_sha256"] and len(stderr) == process["stderr_bytes"]
    assert process["command"][process["command"].index("-timeout") + 1] == "3m0s"
    result = ledger(raw_path, inventory["events"][requirement], "github.com/electrikmilk/cherri",
        timestamp(process["started_utc"]), timestamp(process["finished_utc"]))
    result.update({"elapsed_seconds": process["elapsed_seconds"], "exit_code": process["exit_code"], "timed_out": process["timed_out"]})
    components[requirement] = result
assert (components["RP21"]["started"], components["RP21"]["passed"], components["RP21"]["failed"], len(components["RP21"]["unstarted"])) == (121, 112, 9, 111)
assert (components["BRG16"]["started"], components["BRG16"]["passed"], components["BRG16"]["failed"], len(components["BRG16"]["unstarted"])) == (213, 213, 0, 0)
report = {"audited_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": summary["source"], "workflow_source": summary["workflow_source"],
    "run": 44973222943, "artifact_sha256": sha((HERE / "artifact.original.zip").read_bytes()),
    "tracked_tree_entries": {key: len(value) for key, value in trees.items()},
    "source_witnesses": len(source_digests), "source_and_workflow_unchanged": True,
    "metadata_original_processes_verified": metadata_count,
    "outer": outer_ledger, "outer_elapsed_seconds": outer["elapsed_seconds"],
    "owned_process_group_active": False, "components": components,
    "new_execution": False, "formal_acceptance_granted": False, "apple_runtime_proved": False}
out = HERE / "root-independent-intake.json"
assert not out.exists(), "preserve any previous intake"
out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({key: value for key, value in report.items() if key not in ("outer", "components")}))
print(json.dumps({key: {field: (len(value) if isinstance(value, list) else value) for field, value in result.items()} for key, result in {"outer": outer_ledger, **components}.items()}))
