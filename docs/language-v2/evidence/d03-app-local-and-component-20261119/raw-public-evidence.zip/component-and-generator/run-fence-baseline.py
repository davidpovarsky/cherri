import importlib.util,sys,unittest,pathlib
base=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location("build_documentation_index",base/"generator-fence-baseline.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
sys.modules["build_documentation_index"]=module
spec=importlib.util.spec_from_file_location("docs_tests",sys.argv[1])
tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
suite=unittest.TestSuite([tests.DocumentationIndexTests("testLegacyFenceInfoCannotBypassMigrationPolicy")])
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
