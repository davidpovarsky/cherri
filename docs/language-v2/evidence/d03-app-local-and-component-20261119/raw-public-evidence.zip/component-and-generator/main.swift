import Foundation

let raw = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
let index = try DocumentationIndex.decode(raw)
var observed: [String] = []
func require(_ ok: Bool, _ name: String) {
    if !ok { fatalError("Actual documentation model check failed: \(name)") }
    observed.append(name)
}
require(index.sections.count > 500, "complete current index")
require(index.search("show").first?.title == "show", "exact action ranks first")
require(index.search("SHOW").first?.title == "show", "case insensitive search")
require(index.search("show").first?.blocks.contains { $0.kind == "code" && $0.text.contains("show(") } ?? false,
        "actual action signature retained")
require(index.search("ZZZ_MISSING_DOCUMENTATION_937").isEmpty, "missing query stays empty")
require(!index.search("").contains { $0.migrationOnly }, "migration excluded by default")
require(index.search("", includeMigration: true).contains { $0.migrationOnly }, "migration explicit opt in")
for mutation in ["historicalPath", "floatingCommit", "duplicateSection", "legacyFenceMetadata"] {
    var object = try JSONSerialization.jsonObject(with: raw) as! [String: Any]
    var sections = object["sections"] as! [[String: Any]]
    switch mutation {
    case "historicalPath": sections[0]["sourcePath"] = "language/obsolete.md"
    case "floatingCommit": object["docsCommit"] = "main"
    case "duplicateSection": sections.append(sections[0])
    default:
        sections[0]["blocks"] = [["kind": "code", "language": "cherri-legacy title=example", "text": "@old = 1"]]
    }
    object["sections"] = sections
    var rejected = false
    do { _ = try DocumentationIndex.decode(JSONSerialization.data(withJSONObject: object)) }
    catch { rejected = true }
    require(rejected, "reject " + mutation)
}
let report: [String: Any] = ["passed": observed.count, "checks": observed,
                             "docsCommit": index.docsCommit, "sections": index.sections.count,
                             "scope": "ACTUAL_WINDOWS_FOUNDATION_MODEL_NOT_SWIFTUI_OR_IOS"]
let output = try JSONSerialization.data(withJSONObject: report, options: [.sortedKeys])
print(String(decoding: output, as: UTF8.self))
