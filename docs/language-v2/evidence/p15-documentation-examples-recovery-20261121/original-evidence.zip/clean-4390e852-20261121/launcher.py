from pathlib import Path
import importlib.util,sys,subprocess,json,hashlib,collections,time
sys.dont_write_bytecode=True
base=Path(r'C:\Users\DAVID\Code')
C=base/'cherri-p10r15-docs-acceptance-r5-20261120'
R=base/'cherri-p10r15-docs-actual-source-f05a6221'
D=base/'cherrilang-p10r15-docs-r5-20261120'
E=base/'cherri-p10r15-parity-evidence-20261119'/'r5-documentation-examples-20261120'/'clean-4390e852-20261121'
E.mkdir()
(E/'launcher.py').write_bytes(Path(__file__).read_bytes())
spec=importlib.util.spec_from_file_location('docs_examples',C/'tools/p10r15/documentation_recovery_examples.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
S='f05a6221b44582cb04bb085d254df9ff25cf64a8'
K='4390e85261e49e3cda5891b133746083dbf72b6c'
DS='7c67bef8cf061b24498cf2a5f4717949ce10c79f'
for root,sha,role in [(R,S,'compiler'),(C,K,'consumer'),(D,DS,'docs')]: m.checkout(root,sha,role)
test,_,err=m.process(E,'collector-controls',[sys.executable,'-B','-m','unittest','discover','-s','tools/p10r15','-p','test_documentation_recovery_examples.py','-v'],C,60)
m.require(m.succeeded(test),'COLLECTOR_CONTROLS')
binary=base/'cherri-p10r15-continuation-evidence-20261119'/'r5-docs-actual-baseline-f05a6221-clone'/'compiler.exe'
m.require(m.digest(binary.read_bytes())=='ce23370cc3d0a8e34dca44c632eaba75edb75047a944de152c0b60b437b8da7f','COMPILER_HASH')
capsP,capsB,_=m.process(E,'observed-capabilities',[str(binary),'--capabilities-json'],E)
m.require(m.succeeded(capsP),'CAPABILITIES')
caps=m.load_json(capsB)
identity=m.compiler_identity(binary,S,caps,E)
sources=[];cases=[];inline=[]
sets=[(R,S,'compiler',m.COMPILER_GUIDES),(D,DS,'docs',m.DOCS_GUIDES),(C,K,'consumer',m.SKILL_GUIDES)]
for root,sha,role,files in sets:
 for path in files:
  raw=m.bound_bytes(root,sha,path)
  sources.append({'repository':role,'commit':sha,'path':path,'sha256':m.digest(raw),'bytes':len(raw)})
  cases+=m.fence_examples(raw.decode('utf-8'),role,path)
  if role=='consumer':
   extra,tokens=m.skill_examples(raw.decode('utf-8'),path);cases+=extra;inline+=tokens
m.require(len(cases)==88,'EXPECTED_COMPLETE_88_INVENTORY')
prior=m.load_json((base/'cherri-p10r15-continuation-evidence-20261119'/'r5-docs-legacy-repair'/'clean-replay-7c67bef8'/'report.json').read_bytes())
def key(c): return (c['path'],c['mode'],c['source'].strip(),tuple(c['expectedErrors']))
old=collections.Counter(key(c) for c in prior['actualCases'])
new=collections.Counter(key(c) for c in cases)
m.require(not(old-new),'PRIOR_EXAMPLES_DROPPED')
(E/'inventory.json').write_bytes((json.dumps({'sources':sources,'cases':cases,'inline':inline,'prior73Preserved':True},indent=2,ensure_ascii=False)+'\n').encode())
results=[m.execute_example(binary,c,E/('example-%04d'%i)) for i,c in enumerate(cases)]
for root,sha,role,files in sets:
 m.checkout(root,sha,role)
 for path in files:
  found=next(x for x in sources if x['repository']==role and x['path']==path)
  m.require(m.digest(m.bound_bytes(root,sha,path))==found['sha256'],'SOURCE_CHANGED')
m.require(m.digest(binary.read_bytes())==identity['sha256'],'BINARY_CHANGED')
summary={'executed':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results),'byRepository':dict(collections.Counter(x['repository'] for x in results)),'collectorControls':12}
report={'implementationSha':K,'compilerCommit':S,'docsCommit':DS,'summary':summary,'compiler':identity,'sources':sources,'examples':results,'prior73Preserved':True,'formalAcceptanceGranted':False,'coherentConsumerTuple':False,'nativeExecution':'NOT_RUN','scope':'COMPONENT actual documentation check and unsigned compile; no manifest pins changed; final collect still requires coherent manifest'}
(E/'component-report.json').write_bytes((json.dumps(report,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps({'summary':summary,'reportSHA256':m.digest((E/'component-report.json').read_bytes()),'failures':[{'path':x['path'],'snippet':x['originalSnippet'],'failures':x['failures']}for x in results if not x['passed']]},ensure_ascii=False))
raise SystemExit(0 if not summary['failed'] else 1)
