import json, re, sys

cb_path, expected_nonce, expected_trace_run_id, expected_out, trace_out_path, manifest_path, expected_sha = sys.argv[1:8]
if expected_trace_run_id in ("qa-nested-list-control-v2", "qa-nested-list-candidate-v2"):
    from pathlib import Path
    assert len(sys.argv) == 9
    sys.path.insert(0, str(Path(sys.argv[8]) / "tools/shortcuts-simulator-qa"))
    from nested_list_runtime import emit
    emit(sys.argv[8], *sys.argv[1:8])
    sys.exit(0)
profile = "UNKNOWN"
trace_expectation = "REQUIRED_NDJSON"
release_build_verified = False
source_sha256 = ""
unsigned_sha256 = ""

def result(run_gate, trace_gate, reason):
    print(json.dumps({
        "runGate": run_gate, "traceGate": trace_gate, "reason": reason,
        "targetFixtureId": expected_trace_run_id, "compilerCommitSha": expected_sha,
        "buildProfile": profile, "traceExpectation": trace_expectation,
        "releaseBuildVerified": release_build_verified,
        "sourceSha256": source_sha256, "unsignedPlistSha256": unsigned_sha256,
    }))

try:
    manifest = json.load(open(manifest_path, encoding="utf-8"))
    assert re.fullmatch(r"[0-9a-f]{40}", expected_sha) and expected_nonce
    assert manifest.get("syntheticOnly") is True and manifest.get("compilerCommitSha") == expected_sha
    fixtures = manifest.get("fixtures")
    assert isinstance(fixtures, list) and all(isinstance(f, dict) for f in fixtures)
    entries = [f for f in fixtures if f.get("fixtureId") == expected_trace_run_id]
    assert len(entries) == 1
    fixture = entries[0]
    source_sha256 = fixture.get("sourceSha256", "")
    unsigned_sha256 = fixture.get("unsignedPlistSha256", "")
    assert isinstance(source_sha256, str) and re.fullmatch(r"[0-9a-f]{64}", source_sha256)
    assert isinstance(unsigned_sha256, str) and re.fullmatch(r"[0-9a-f]{64}", unsigned_sha256)
    profile = fixture.get("buildProfile")
    trace_expectation = fixture.get("runtimeTraceExpectation")
    if expected_trace_run_id == "qa-measure-release-v2":
        assert expected_out == "CHERRI_QA_MEASURE_RELEASE_RESULT:P15_MEASURE_RELEASE_OK"
        assert profile == "release" and trace_expectation == "ABSENT_RELEASE"
        assert fixture.get("releaseDiagnosticActionsAbsent") is True
        assert fixture.get("releaseBodyShapeVerified") is True
        release_build_verified = True
    else:
        assert profile == "debug" and trace_expectation == "REQUIRED_NDJSON"
    if expected_trace_run_id == "qa-optional-forwarding-diagnostic-v2":
        assert source_sha256 == "e6f195aadcd2d46f25c6fe1de5165798c18a40f4c1942785b9e39171b1cc2139"
        reviewed_source = {
            "status": "PASS_REVIEWED_PUBLIC_SOURCE_ONLY", "sourceSha256": source_sha256,
            "expectedContractSha256": "da1335a22389cbe97e72a706192cb6b93ece8eff380080fa0541dcb5cbc50cef",
            "observedFields": 11, "appleRuntime": "NOT_RUN", "formalAcceptanceGranted": False,
        }
        observed_source = fixture.get("optionalForwardingSource")
        assert isinstance(observed_source, dict) and set(observed_source) == set(reviewed_source)
        assert all(type(observed_source[key]) is type(value) and observed_source[key] == value
                   for key, value in reviewed_source.items())
        reviewed_graph = {
            "schemaVersion": "1.0", "fixtureId": expected_trace_run_id,
            "status": "PASS_NATIVE_STRUCTURE_ONLY", "sourceSha256": source_sha256,
            "expectedContractSha256": reviewed_source["expectedContractSha256"],
            "unsignedPlistSha256": unsigned_sha256, "nativeActionCount": 402,
            "appleRuntime": "NOT_RUN", "formalAcceptanceGranted": False,
        }
        observed_graph = fixture.get("optionalForwardingGraph")
        assert isinstance(observed_graph, dict) and set(observed_graph) == set(reviewed_graph) | {"testStdoutSha256", "testStderrSha256"}
        assert all(type(observed_graph[key]) is type(value) and observed_graph[key] == value
                   for key, value in reviewed_graph.items())
        assert all(isinstance(observed_graph[key], str) and re.fullmatch(r"[0-9a-f]{64}", observed_graph[key])
                   for key in ("testStdoutSha256", "testStderrSha256"))
except (OSError, ValueError, TypeError, AttributeError, AssertionError) as exc:
    result("FAIL_RUNTIME", "FAIL_RUNTIME", f"compiler manifest/runtime profile contract rejected: {type(exc).__name__}")
    sys.exit(0)
try:
    events = json.load(open(cb_path, encoding="utf-8"))
except Exception as exc:
    result("FAIL_RUNTIME", "FAIL_RUNTIME", f"failed to read callback-events.json: {exc}")
    sys.exit(0)

if not isinstance(events, list) or not all(isinstance(e, dict) for e in events):
    result("FAIL_RUNTIME", "FAIL_RUNTIME", "callback store is not an array of event objects")
    sys.exit(0)

matched = [e for e in events if not e.get("receiverSelfTest") and e.get("runId") == expected_nonce]
if len(matched) == 0:
    result("FAIL_RUNTIME", "FAIL_RUNTIME", f"no non-self-test callback for runId {expected_nonce}")
    sys.exit(0)
if len(matched) > 1:
    result("FAIL_RUNTIME", "FAIL_RUNTIME", f"duplicate callback replay ({len(matched)}) for runId {expected_nonce}")
    sys.exit(0)

ev = matched[0]
if ev.get("receiverSelfTest") is not False or ev.get("eventSource") != "shortcuts-x-callback" or ev.get("fixtureId") != expected_trace_run_id or ev.get("expectedShortcutName") != expected_trace_run_id:
    result("FAIL_RUNTIME", "FAIL_RUNTIME", "callback source or fixture identity mismatch")
    sys.exit(0)
if ev.get("status") != "SUCCESS":
    result("FAIL_RUNTIME", "FAIL_RUNTIME", f"callback status={ev.get('status')} error={ev.get('errorMessage')}")
    sys.exit(0)

summary_text = ev.get("resultSummary")
trace_text = ev.get("tracePayload")
# Codable omits nil optional tracePayload when no trace was returned. False,
# zero, lists and dictionaries are not accepted as an absent trace.
if trace_text is None:
    trace_text = ""
if not isinstance(summary_text, str) or not isinstance(trace_text, str):
    result("FAIL_RUNTIME", "FAIL_RUNTIME", "callback result/trace must be text")
    sys.exit(0)
if expected_out and summary_text.strip() != expected_out:
    result("FAIL_RUNTIME", "FAIL_RUNTIME", "callback result does not exactly match expected output")
    sys.exit(0)

if release_build_verified:
    if trace_text != "":
        result("FAIL_RUNTIME", "FAIL_RUNTIME", "unexpected trace in the explicit Release fixture")
    else:
        # An empty file is absence evidence, never a fabricated collector event.
        open(trace_out_path, "w", encoding="utf-8").close()
        result("PASS", "NOT_APPLICABLE_RELEASE", "verified Release build, exact fresh body/result callback and absent trace")
    sys.exit(0)

# Validate NDJSON trace lines
raw_lines = [l.strip() for l in trace_text.splitlines() if l.strip() and l.strip() != "===CHERRI_QA_TRACE_NDJSON_V14==="]
valid_records = []
has_begin = False
has_end = False
inline_count = 0
last_step_sequence = -1
trace_err = None

for idx, line in enumerate(raw_lines):
    try:
        rec = json.loads(line)
    except (ValueError, TypeError):
        trace_err = f"line {idx+1} invalid JSON"
        break
    if not isinstance(rec, dict) or rec.get("schemaVersion") != "1.4":
        trace_err = f"line {idx+1} invalid trace schema"
        break
    if has_end:
        trace_err = f"line {idx+1} occurs after collector_end"
        break
    kind = rec.get("kind")
    stage = rec.get("stage")
    if kind == "COLLECTOR_EVENT":
        if rec.get("runId") != expected_trace_run_id:
            trace_err = f"collector runId missing or mismatched at line {idx+1}"
            break
        if stage == "collector_begin" and idx == 0 and not has_begin:
            has_begin = True
        elif stage == "collector_end" and has_begin and inline_count > 0:
            has_end = True
        else:
            trace_err = f"invalid collector order/stage at line {idx+1}"
            break
        valid_records.append(rec)
    elif kind == "INLINE_DEBUG_ACTION":
        step = rec.get("stepSequence")
        stamp = rec.get("timestamp")
        aid = rec.get("actionIdentifier")
        value_type = rec.get("valueType")
        if (not has_begin or stage not in ("before", "after", "error", "end")
                or not isinstance(stamp, str) or not stamp.strip()
                or type(step) is not int or step < 0
                or not isinstance(aid, str) or not aid.startswith("is.workflow.actions.")
                or not isinstance(value_type, str) or not value_type):
            trace_err = f"invalid INLINE_DEBUG_ACTION record at line {idx+1}"
            break
        # The fixture stream is linear. Duplicate/regressing records indicate
        # replay or misordered export, not evidence of an additional action.
        if step <= last_step_sequence:
            trace_err = f"duplicate or regressing stepSequence at line {idx+1}"
            break
        last_step_sequence = step
        inline_count += 1
        valid_records.append(rec)
    else:
        trace_err = f"unknown trace record kind at line {idx+1}"
        break

if not trace_err and (not has_begin or not has_end or inline_count == 0):
    trace_err = f"incomplete trace stream (begin={has_begin}, end={has_end}, inlineCount={inline_count})"

if trace_err:
    result("PASS", "FAIL_RUNTIME", trace_err)
else:
    with open(trace_out_path, "w", encoding="utf-8") as tf:
        for r in valid_records:
            tf.write(json.dumps(r, ensure_ascii=False) + "\n")
    result("PASS", "PASS", "verified correlated callback output and NDJSON trace")