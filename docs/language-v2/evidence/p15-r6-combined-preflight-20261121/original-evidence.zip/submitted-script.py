import pathlib,subprocess,json,hashlib,collections,datetime,os,re,time,sys
base=pathlib.Path(r"C:\Users\DAVID\Code"); original=base/"cherri-p10r15-completion-r4-20261120"; evidence=base/"cherri-p10r15-continuation-evidence-20261119/r6-combined-preflight-c46902bb-20261121";repo=evidence/"source"
evidence.mkdir(parents=True,exist_ok=False)
source="c46902bbe6cf7d0d8a6f5acd2d776eb1f77c7262"
def git(*args):
 r=subprocess.run(["git","--no-replace-objects",*args],capture_output=True,timeout=120)
 if r.returncode: raise RuntimeError(r.stderr.decode("utf-8",errors="replace"))
 return r.stdout.decode("utf-8").strip()
git("clone","--no-hardlinks","--no-checkout",str(original),str(repo))
git("-C",str(repo),"checkout","--detach",source)
assert git("-C",str(repo),"rev-parse","HEAD")==source and not git("-C",str(repo),"status","--porcelain")
names=[]
for f in repo.glob("*_test.go"):
 for n in re.findall(r"^func (Test\w+)\(",f.read_text(encoding="utf-8"),re.M):
  if re.match(r"^TestP15(M02|Paginate|C03|LegacyInline|Setter|E06|Editor|Mobile)",n): names.append(n)
names=sorted(set(names));assert len(names)>25
command=["go","test","-count=1","-json","-timeout=15m","-run","^("+"|".join(names)+")$","."]
env=os.environ.copy();env["CHERRI_TEST_BASH"]=r"C:\Program Files\Git\bin\bash.exe";env["PYTHONDONTWRITEBYTECODE"]="1"
receipt={"source":source,"sourceCleanBefore":True,"expectedParents":names,"command":command,"startedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"combined integration preflight, not formal179/Apple"}
(evidence/"started.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
(evidence/"submitted-script.py").write_bytes(pathlib.Path(__file__).read_bytes())
started=time.monotonic();timedout=False
with (evidence/"stdout.jsonl").open("wb") as out,(evidence/"stderr.txt").open("wb") as err:
 child=subprocess.Popen(command,cwd=repo,stdout=out,stderr=err,env=env)
 try: code=child.wait(timeout=960)
 except subprocess.TimeoutExpired:
  timedout=True; subprocess.run(["taskkill","/PID",str(child.pid),"/T","/F"],capture_output=True,timeout=15);code=child.wait(timeout=15)
events=[]
for line in (evidence/"stdout.jsonl").read_bytes().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
counts=dict(collections.Counter(e.get("Action") for e in events if e.get("Test")))
startednames={e["Test"] for e in events if e.get("Action")=="run" and e.get("Test")}
receipt.update(exitCode=code,timedOut=timedout,durationSeconds=round(time.monotonic()-started,3),counts=counts,failed=[e.get("Test",e.get("Package")) for e in events if e.get("Action")=="fail"],unstartedParents=[n for n in names if n not in startednames],sourceCleanAfter=not git("-C",str(repo),"status","--porcelain"),headAfter=git("-C",str(repo),"rev-parse","HEAD"),stdoutSHA256=hashlib.sha256((evidence/"stdout.jsonl").read_bytes()).hexdigest(),stderrSHA256=hashlib.sha256((evidence/"stderr.txt").read_bytes()).hexdigest(),finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(evidence/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(receipt))
