import pathlib,subprocess,os,time,json,collections,hashlib,datetime
r=pathlib.Path(r'C:\Users\DAVID\Code\cherri-p10r15-local-contracts-20261119')
e=pathlib.Path(r'C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\local-contracts-ddc6c02')
env=os.environ.copy();env.update({'GOMAXPROCS':'2','GOFLAGS':'-p=1','CHERRI_P10R10_CORPUS':'0','PYTHONDONTWRITEBYTECODE':'1'})
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert sha=='4065c3549b5fdde2e0a1aa94f2bcae2f7f4b1a05'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
commands=[
('declaration-clean-root',[r'C:\Program Files\Go\bin\go.exe','test','-count=1','-json','-timeout=5m','-p=1','.','-run','^(TestP15ActionDeclaration.*|TestP15C02.*|TestP15C05.*|TestP15Custom.*|TestP15Registry.*|TestLANG001_.*|TestEnum_.*)$']),
('declaration-clean-packages',[r'C:\Program Files\Go\bin\go.exe','test','-count=1','-json','-timeout=5m','-p=1','./internal/language/analysis','./internal/language/backend','./internal/language/syntax','./internal/language/service','./tools/language-schema'])
]
for name,cmd in commands:
 start=time.time();log=e/(name+'.jsonl')
 with log.open('wb') as output:
  p=subprocess.run(cmd,cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=360)
 raw=log.read_bytes();events=[];unparsed=[]
 for line in raw.decode('utf-8',errors='replace').splitlines():
  try:events.append(json.loads(line))
  except ValueError:unparsed.append(line)
 counts=collections.Counter(x['Action'] for x in events if x.get('Test') and x.get('Action') in ['run','pass','fail','skip'])
 status=subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)
 s={'phase':'CLEAN_SOURCE_VALIDATION','source_sha':sha,'command':cmd,'exit_code':p.returncode,'elapsed':time.time()-start,'events':dict(counts),'failed':[x['Test'] for x in events if x.get('Test') and x.get('Action')=='fail'],'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'unparsed':unparsed,'source_clean_before':True,'source_clean_after':not bool(status),'source_status':status,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (e/(name+'-summary.json')).write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print(json.dumps(s),flush=True)
 if p.returncode!=0:break
