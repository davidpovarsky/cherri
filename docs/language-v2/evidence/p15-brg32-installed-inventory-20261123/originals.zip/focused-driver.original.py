import pathlib,subprocess,json,datetime,hashlib,os,signal,time
repo=pathlib.Path("/mnt/development/projects/worktrees/cherri-p10r15-ai-integration-20261123")
sha="d5b82e3a4e21416556d4a6c81ed12b05b1365b2f"
base=pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-brg32-installed-inventory-20261123")
ev=base/"focused-attempt-01";ev.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(["git","-C",str(repo),*args],text=True).strip()
assert git("rev-parse","HEAD")==sha and git("status","--porcelain=v1")==""
godir=pathlib.Path("/mnt/development/tooling/cherri-go/mod/golang.org/toolchain@v0.0.1-go1.24.13.linux-arm64/bin")
argv=[str(godir/"go"),"test","-p=1","-count=1","-json","-timeout=5m","./tools/language-acceptance","-run","^TestSupplementalObligationHarnessProductionEvidence$"]
env=os.environ.copy()
for k in list(env):
 if k.startswith(("CHERRI_AI_","CHERRI_S4_","CHERRI_PRIVATE_")) or k in {"ANTHROPIC_API_KEY","OPENAI_API_KEY"}:env.pop(k)
tmp=ev/"tmp";tmp.mkdir()
env.update(PATH=str(godir)+":"+env.get("PATH",""),GOTOOLCHAIN="go1.24.13",GOMODCACHE="/mnt/development/tooling/cherri-go/mod",GOCACHE="/mnt/development/tooling/cherri-go/build",GOTMPDIR=str(tmp),TMPDIR=str(tmp),GOMAXPROCS="2",PYTHONDONTWRITEBYTECODE="1",CHERRI_ACCEPTANCE_PYTHON="/usr/bin/python3")
receipt={"schema":"cherri-focused-producer-process/1","implementation":sha,"tree":git("rev-parse","HEAD^{tree}"),"sourceCleanBefore":True,"argv":argv,"cwd":str(repo),"goVersion":subprocess.check_output([str(godir/"go"),"version"],env=env,text=True).strip(),"startedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"nestedOriginalBudgetSeconds":180,"outerGoBudgetSeconds":300,"supervisorBudgetSeconds":330,"providerCredentialsInChildEnvironment":False,"liveGenerationConfigured":False}
(ev/"intent.original.json").write_text(json.dumps(receipt,indent=2)+"\n")
start=time.monotonic();timed=False
with (ev/"stdout.original.jsonl").open("wb") as out,(ev/"stderr.original.log").open("wb") as err:
 p=subprocess.Popen(argv,cwd=repo,env=env,stdout=out,stderr=err,start_new_session=True)
 receipt["pid"]=p.pid;(ev/"started.original.json").write_text(json.dumps(receipt,indent=2)+"\n")
 try:code=p.wait(timeout=330)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
receipt.update(finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,6),exitCode=code,timedOut=timed,headAfter=git("rev-parse","HEAD"),sourceCleanAfter=git("status","--porcelain=v1")=="")
events=[];parseerrors=0
for line in (ev/"stdout.original.jsonl").read_text().splitlines():
 try:events.append(json.loads(line))
 except Exception:parseerrors+=1
receipt["goEvents"]={"pass":[e["Test"] for e in events if e.get("Action")=="pass" and e.get("Test")],"fail":[e.get("Test",e.get("Package")) for e in events if e.get("Action")=="fail"],"skip":[e.get("Test",e.get("Package")) for e in events if e.get("Action")=="skip"],"parseErrors":parseerrors}
for name in ["stdout.original.jsonl","stderr.original.log"]:
 raw=(ev/name).read_bytes();receipt[name]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
derived=[]
marker="P15_BRG32_OBLIGATION_HARNESS_RECEIPT:"
for e in events:
 line=e.get("Output","")
 if marker in line:
  try:derived.append(json.loads(line.split(marker,1)[1].strip()))
  except Exception:pass
receipt["actualHarnessReceiptCount"]=len(derived)
if len(derived)==1:
 obj=derived[0];(ev/"harness-receipt-derived.json").write_text(json.dumps(obj,indent=2)+"\n")
 receipt["actualRecordCount"]=len(obj.get("records",[]));receipt["receiptSource"]=obj.get("implementation_sha");receipt["scope"]=obj.get("scope");receipt["aiQualityMeasured"]=obj.get("ai_quality_measured")
receipt["status"]="PASS" if code==0 and not timed and receipt["sourceCleanAfter"] and receipt["headAfter"]==sha and not receipt["goEvents"]["fail"] and not receipt["goEvents"]["skip"] and len(receipt["goEvents"]["pass"])==9 and len(derived)==1 else "FAILED_OR_INCOMPLETE"
result=ev/"result.original.json";result.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"receipt":receipt,"resultSHA256":hashlib.sha256(result.read_bytes()).hexdigest()}))
raise SystemExit(0 if receipt["status"]=="PASS" else 1)
