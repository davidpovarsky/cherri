from pathlib import Path
import ctypes,subprocess,json,os,time,hashlib,sys
class Memory(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ['total_phys','avail_phys','total_page','avail_page','total_virtual','avail_virtual','avail_extended']]
m=Memory();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
assert m.avail_phys>1800000000,m.avail_phys
root=Path(r'C:\Users\DAVID\Code\cherri-p10r15-custom-codec-20261119')
out=Path(r'C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\custom-codec-a432646')
out.mkdir(exist_ok=True)
prefix=sys.argv[1]
log=out/(prefix+'.jsonl'); summary=out/(prefix+'-summary.json')
assert not log.exists() and not summary.exists()
env=os.environ.copy();env.update(GOMAXPROCS='1',GOFLAGS='-p=1')
go=r'C:\Program Files\Go\bin\go.exe'
mode=sys.argv[2]
if mode=='related':
 args=[go,'test','-p=1','-count=1','-json','-timeout=4m','-run','^(TestP15Custom.*Codec.*|TestP15C01.*|TestP15C02.*|TestP15T03.*|TestP15Registry.*|TestCompilerEndToEndParityMatrix|TestArchitecture_D_SharedCodecMaintenance)$','.']
elif mode=='packages':
 args=[go,'test','-p=1','-count=1','-json','-timeout=4m','./internal/language/lower','./internal/language/backend']
else:raise RuntimeError(mode)
before=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True,encoding='utf-8')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert before=='',before
start=time.time()
with log.open('wb') as f:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=0x00004000)
 try: code=p.wait(timeout=270);timed=False
 except subprocess.TimeoutExpired:
  timed=True
  subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
  code=p.wait(timeout=15)
raw=log.read_bytes();counts={};failed=[];skipped=[];bad=[];events=[]
for i,line in enumerate(raw.splitlines(),1):
 try:e=json.loads(line);events.append(e)
 except Exception:bad.append({'line':i,'text':line.decode('utf-8','replace')});continue
 if e.get('Test') and e.get('Action') in ('pass','fail','skip'):
  action=e['Action'];counts[action]=counts.get(action,0)+1
  if action=='fail':failed.append(e['Test'])
  if action=='skip':skipped.append(e['Test'])
after=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True,encoding='utf-8')
result={'source_sha':head,'source_status_before':before,'source_status_after':after,'command':args,'exit_code':code,'timed_out':timed,'seconds':round(time.time()-start,3),'named_tests':counts,'failed':failed,'skipped':skipped,'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest(),'invalid_json':bad,'available_bytes_before':m.avail_phys}
summary.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result))
if code:
 for e in events:
  if e.get('Output') and (not e.get('Test') or any(e['Test'].startswith(n) or n.startswith(e['Test']) for n in failed)):print(e['Output'],end='')
sys.exit(code if code>=0 else 1)
