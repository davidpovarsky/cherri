from pathlib import Path
import subprocess,json,hashlib
R=Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-editor-independent")
def run(*a):return subprocess.run(["git","--no-replace-objects",*a],cwd=R,capture_output=True)
def git(*a):
 p=run(*a);assert p.returncode==0,p.stderr.decode(errors="replace");return p.stdout
base="f05a6221b44582cb04bb085d254df9ff25cf64a8"
assert git("rev-parse","HEAD").decode().strip()==base and not git("status","--porcelain").strip()
receipt=(E/"receipt.json").read_bytes()
assert hashlib.sha256(receipt).hexdigest()=="8c8253e0570b2ec8f3e1335a5a827c11a9697710355414a6b0e954bedc06d1f0"
j=json.loads(receipt);assert len(j["components"])==3 and j["formalAcceptanceGranted"] is False
(E/"merge-launcher.py").write_bytes(Path(__file__).read_bytes())
p=run("merge","--no-ff","1720ccd8f9272cfcc379ad5c5bea0e4720a55aa8","-m","merge: verified editor context diagnostics and symbol ownership repairs")
(E/"merge.stdout").write_bytes(p.stdout);(E/"merge.stderr").write_bytes(p.stderr)
if p.returncode:print(json.dumps({"mergeExit":p.returncode,"status":git("status","--porcelain").decode(),"stdout":p.stdout.decode(errors="replace"),"stderr":p.stderr.decode(errors="replace")}));raise SystemExit(1)
merge=git("rev-parse","HEAD").decode().strip()
assert not git("status","--porcelain").strip()
dest=R/"docs/language-v2/evidence/p15-editor-independent-intake-20261120";dest.mkdir(exist_ok=False)
for n in ["receipt.json","e01-receipt.json","e02-receipt.json","e03-receipt.json","intake-launcher.py"]:
 (dest/n).write_bytes((E/n).read_bytes())
paths=[str((dest/n).relative_to(R)).replace("\\","/") for n in ["receipt.json","e01-receipt.json","e02-receipt.json","e03-receipt.json","intake-launcher.py"]]
git("-c","core.autocrlf=false","add","-f","--",*paths)
git("diff","--cached","--check")
p=run("commit","-m","docs: retain independent editor source and execution intake")
(E/"intake-commit.stdout").write_bytes(p.stdout);(E/"intake-commit.stderr").write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode(errors="replace")
result={"previousRoot":base,"merge":merge,"rootHead":git("rev-parse","HEAD").decode().strip(),"clean":not git("status","--porcelain").strip(),"formalAcceptanceGranted":False}
(E/"merge-receipt.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
