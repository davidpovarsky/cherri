from pathlib import Path
import subprocess,json,hashlib,zipfile
R=Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-editor-independent")
D=R/"docs/language-v2/evidence/p15-editor-independent-intake-20261120"
def g(*a):return subprocess.check_output(["git","--no-replace-objects",*a],cwd=R)
assert g("rev-parse","HEAD").decode().strip()=="f2170366e888c56719c0e9d11516f61c0215eff4"
names=["receipt.json","e01-receipt.json","e02-receipt.json","e03-receipt.json","intake-launcher.py"]
status=g("status","--porcelain").decode().splitlines()
assert len(status)==5 and all(line.startswith("A  docs/language-v2/evidence/p15-editor-independent-intake-20261120/") for line in status)
check=subprocess.run(["git","--no-replace-objects","diff","--cached","--check"],cwd=R,capture_output=True)
(E/"initial-proof-diff-check.stdout").write_bytes(check.stdout);(E/"initial-proof-diff-check.stderr").write_bytes(check.stderr)
(E/"proof-newline-launcher.py").write_bytes(Path(__file__).read_bytes())
manifest=[]
with zipfile.ZipFile(D/"intake-originals.zip","x",compression=zipfile.ZIP_DEFLATED) as z:
 for n in names+["merge-launcher.py","merge.stdout","merge.stderr","initial-proof-diff-check.stdout","initial-proof-diff-check.stderr","proof-newline-launcher.py"]:
  b=(E/n).read_bytes();z.writestr(n,b)
  manifest.append({"path":n,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
for n in names:
 b=(E/n).read_bytes();(D/n).write_bytes(b.replace(b"\r\n",b"\n"))
archive=(D/"intake-originals.zip").read_bytes()
m={"originals":manifest,"archive":{"path":"intake-originals.zip","bytes":len(archive),"sha256":hashlib.sha256(archive).hexdigest()},"readableCopies":"LF newline normalization only; exact original bytes remain in the archive","formalAcceptanceGranted":False}
(D/"originals-manifest.json").write_bytes((json.dumps(m,indent=2)+"\n").encode())
paths=[str(p.relative_to(R)).replace("\\","/") for p in D.iterdir()]
g("-c","core.autocrlf=false","add","-f","--",*paths)
g("diff","--cached","--check")
g("commit","-m","docs: retain independent editor source and execution intake")
result={"previousRoot":"f05a6221b44582cb04bb085d254df9ff25cf64a8","merge":"f2170366e888c56719c0e9d11516f61c0215eff4","rootHead":g("rev-parse","HEAD").decode().strip(),"clean":not g("status","--porcelain").strip(),"independentReceiptSHA256":hashlib.sha256((D/"receipt.json").read_bytes()).hexdigest(),"originalArchiveSHA256":m["archive"]["sha256"],"formalAcceptanceGranted":False}
(E/"merge-receipt.json").write_bytes((json.dumps(result,indent=2)+"\n").encode());print(json.dumps(result))
