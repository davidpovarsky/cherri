# Native File archive experiment — prepared, not executed

Compiler: exact source 5bc62d057e4bfa8bdd895e7228ca59eedac20b40; binary SHA256 278834c032c2ec3a246b2909b607b907b79d33ce5c19be05dfc853299464278a. The existing executable compiled all three authored V2 probes with --skip-sign, --derive-uuids and --no-toolkit. No Go build or native run occurred in this preparation.

## Inputs and independent expectations

- witnesses: 13 actions; separate one-byte binary, Text and Dictionary witnesses, observed types, bytes and counts.
- baseline: 10 actions; original Text → Base64 Encode → Decode → Set Name, then native count/type/bytes/Name/File Extension consumers.
- candidate: 14 actions; original Text → Make Archive → Extract Archive → Count == 1 guard → first item → Set Name, then the same consumers.

expected/json-original.utf8 is the independently fixed 83-byte UTF-8 witness (SHA256 539a079afd9ef25a7e6c893494300f86f9f8db22c9dc4b58bbb433d4e492c365). Its Base64, full filename cherri-debug.json, stem, extension and singleton expectations are in expected/expectations.original.json. Whitespace, numeric spelling, escaped Unicode/newline, Hebrew combining characters, emoji and trailing newline make reserialization observable.

graph-contract.original.json binds every role to the actual compiler-emitted action index/UUID and source/plist hashes. Candidate extracted is index2, item index5, named index6 (UUID 0C87A7E3-B627-5038-A531-AB7CBD6BEBDA); its byte consumer is index9, Name index10, File Extension index11. Inspect named/item nativeClass before any later conversion. Original File failure observations remain unchanged.

## Unchanged native machinery

source/probe.original.js is the exact retained ShortcutKit prelude plus the unchanged original observer, SHA256 9cb1d58914a8d262cd48fef48207ef74c0def7f89674afc3e75de69eb04959d5. The original observer reads compiler bytes, constructs a transient save-disabled workflow and records action/native-value observations. It does not import into Shortcuts, control UI/Simulator, access clipboard or contact a provider. Graph auditing enforces the exact allowed local actions; archive extraction can create native temporary files.

owner.py only provides new owned paths around unchanged load_primitives(...,None), capture and envelope. It retains the existing 16-action/2-MiB input, 8-second engine, 20-second command, 60-second owner and 1-MiB stream limits; the original 4-MiB incremental + 64-MiB free-space margin; new process session; parent reaping and ABSENT group requirement. Native TMPDIR/cwd are inside each owned case directory. All receipts use exclusive creation; sources are hashed and checked before/after.

## Root-owned admission and execution

Fixed stage: /Users/m1/sentinelx/uploads/cherri-debug-export-archive-20261127-01

Root must freshly admit CPU/memory/disk capacity and existing ownership before each case. Copy that original receipt verbatim to admissions/<case>.original.json, without imposing a new receipt schema. Pass its exact SHA256 and the separately supplied package-manifest SHA256:

    /opt/homebrew/opt/python@3.12/libexec/bin/python3 -I -B <stage>/owner.py --case <witnesses|baseline|candidate> --manifest-sha256 <frozen-manifest-SHA256> --admission-sha256 <fresh-root-receipt-SHA256>

Run cases serially, retaining original stdout, stderr, event JSONL, process start/finish, source snapshots and result receipts under runs/<case>/. No automatic retry or overwriting occurs. Use an outer owned command budget greater than the 60-second owner budget so its terminal receipt can finish.

A retained observation is not a semantic pass. Inspect the exact original native classes, singleton count, bytes, name/extension and independent witness parity. The prepared pure intake draft is deliberately excluded from this minimal package; root can inspect the bounded originals and apply the existing original-stream validator. Baseline failure remains evidence. Any candidate success is macOS-only carrier evidence; production debugExport, signed/iPad acceptance and primary FN04/RP39 gates remain separate and unchanged.
