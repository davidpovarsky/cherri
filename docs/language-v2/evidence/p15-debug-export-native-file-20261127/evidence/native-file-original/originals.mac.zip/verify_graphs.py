#!/usr/bin/env python3
"""Read-only audit of the separately authored probes; never emits or rewrites plist."""
import sys
sys.dont_write_bytecode = True
import argparse, base64, hashlib, json, plistlib, re, stat
from pathlib import Path

SOURCE = "5bc62d057e4bfa8bdd895e7228ca59eedac20b40"
PREFIX = "is.workflow.actions."
OBSERVER_SHA = "c1239494a12ebe7bb9f3efb4067b4203baaacf700ee9c626283e90ebbfc0480b"
PRELUDE_SHA = "d6fbcaad5104562b04004b39ca098486449399c15c83176c49b2ac28f47a3461"
JOINED_SHA = "9cb1d58914a8d262cd48fef48207ef74c0def7f89674afc3e75de69eb04959d5"
UUID = re.compile(r"[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}")
CASES = ("witnesses", "baseline", "candidate")
SPECS = {
 "baseline": [("original","gettext"),("encoded","base64encode"),("decoded","base64encode"),
              ("named","setitemname"),("namedCount","count"),("namedType","getitemtype"),
              ("namedBytes64","base64encode"),("namedStem","getitemname"),
              ("namedExtension","properties.files"),("terminal","nothing")],
 "candidate": [("original","gettext"),("archive","makezip"),("extracted","unzip"),
               ("extractedCount","count"),("countGuardStart","conditional"),("item","getitemfromlist"),
               ("named","setitemname"),("namedCount","count"),("namedType","getitemtype"),
               ("namedBytes64","base64encode"),("namedStem","getitemname"),
               ("namedExtension","properties.files"),("countGuardEnd","conditional"),
               ("terminal","nothing")],
 "witnesses": [("binaryInput","gettext"),("binaryWitness","base64encode"),("binaryType","getitemtype"),
               ("binaryBytes64","base64encode"),("binaryCount","count"),
               ("textWitness","gettext"),("textType","getitemtype"),("textBytes64","base64encode"),
               ("textCount","count"),("dictionaryWitness","dictionary"),
               ("dictionaryType","getitemtype"),("dictionaryCount","count"),("terminal","nothing")]
}

def require(value, code):
 if not value: raise ValueError(code)

def pin(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}

def read_regular(root, relative, limit=2*1024**2):
 path=Path(relative)
 require(not path.is_absolute() and ".." not in path.parts, "RELATIVE_PATH")
 full=root/path
 current=root
 require(not root.is_symlink() and root.is_dir(), "ROOT_DIRECTORY")
 for part in path.parts:
  current=current/part
  require(not current.is_symlink(), "SYMLINK")
 before=full.stat()
 require(stat.S_ISREG(before.st_mode) and before.st_size<=limit, "REGULAR_BOUNDED_INPUT")
 raw=full.read_bytes()
 after=full.stat()
 require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==
         (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), "INPUT_CHANGED_DURING_READ")
 return raw

def load_json(raw):
 def pairs(rows):
  result={}
  for key,value in rows:
   require(key not in result, "DUPLICATE_JSON_KEY")
   result[key]=value
  return result
 return json.loads(raw,object_pairs_hook=pairs)

def verify_manifest(root, expected_sha):
 raw=read_regular(root,"manifest.original.json")
 require(pin(raw)["sha256"]==expected_sha, "PACKAGE_MANIFEST_SHA")
 manifest=load_json(raw)
 require(manifest["schema"]=="cherri-native-file-archive-package/1" and
         manifest["sourceCommit"]==SOURCE, "PACKAGE_IDENTITY")
 rows=manifest["files"]
 require(type(rows) is dict and 1<=len(rows)<=128, "PACKAGE_FILE_BOUND")
 for relative,expected in rows.items():
  require(pin(read_regular(root,relative))==expected, "PACKAGE_FILE_HASH:"+relative)
 return manifest

def audit(root):
 root=Path(root).resolve()
 expected=load_json(read_regular(root,"expected/expectations.original.json"))
 require(expected["schema"]=="cherri-native-file-archive-expectations/1" and
         expected["sourceCommit"]==SOURCE, "EXPECTED_IDENTITY")
 original=read_regular(root,expected["json"]["file"])
 require(pin(original)=={k:expected["json"][k] for k in ("bytes","sha256")} and
         base64.b64encode(original).decode()==expected["json"]["base64"], "INDEPENDENT_UTF8")
 require(expected["requiredFileClass"]=="WFGenericFileContentItem" and
         expected["requiredCount"]==1 and expected["fullName"]=="cherri-debug.json" and
         expected["stem"]=="cherri-debug" and expected["extension"]=="json", "ORIGINAL_FILE_CRITERIA")
 source_pins=load_json(read_regular(root,"source/source-pins.original.json"))
 require(source_pins["commit"]==SOURCE and source_pins["unchangedCopies"] is True, "SOURCE_IDENTITY")
 for relative,expected_pin in source_pins["files"].items():
  require(pin(read_regular(root,"source/"+relative))==expected_pin, "UNCHANGED_SOURCE:"+relative)
 observer=read_regular(root,"source/tools/shortcut-runtime/jxa/observe_original_action_values.js")
 prelude=read_regular(root,"source/jxa-prelude.original.js")
 joined=read_regular(root,"source/probe.original.js")
 require(pin(observer)["sha256"]==OBSERVER_SHA and pin(prelude)["sha256"]==PRELUDE_SHA and
         pin(joined)["sha256"]==JOINED_SHA and joined==prelude+b"\n"+observer, "EXACT_OBSERVER_PRELUDE")
 results={}
 for case in CASES:
  source_path="fixtures/qa-file-archive-"+case+"-v2.cherri"
  plist_path="compiled/qa-file-archive-"+case+"-v2.shortcut"
  source=read_regular(root,source_path)
  raw=read_regular(root,plist_path)
  document=plistlib.loads(raw)
  actions=document["WFWorkflowActions"]
  require(type(actions) is list and 1<=len(actions)<=16 and len(actions)==len(SPECS[case]), "ACTION_BOUND")
  require(document.get("WFWorkflowHasOutputFallback") is False and
          document.get("WFWorkflowHasShortcutInputVariables") is False and
          document.get("WFWorkflowImportQuestions")==[], "NO_EXTERNAL_INPUT_OR_IMPORT_QUESTION")
  roles={};params={};seen=set()
  for index,((role,identifier),action) in enumerate(zip(SPECS[case],actions)):
   require(set(action)=={"WFWorkflowActionIdentifier","WFWorkflowActionParameters"} or
           (identifier=="nothing" and set(action)=={"WFWorkflowActionIdentifier"}), "ACTION_FIELDS")
   require(action["WFWorkflowActionIdentifier"]==PREFIX+identifier, "EXACT_ACTION_ORDER")
   p=action.get("WFWorkflowActionParameters",{})
   require(type(p) is dict, "PARAMETER_OBJECT")
   if identifier not in ("conditional","nothing"):
    require(p.get("CustomOutputName")==("Text" if role=="binaryInput" else role), "NAMED_ROLE")
    require(type(p.get("UUID")) is str and UUID.fullmatch(p["UUID"]) and p["UUID"] not in seen, "UNIQUE_UUID")
    seen.add(p["UUID"])
   else:
    require("UUID" not in p and "CustomOutputName" not in p, "ORIGINAL_UUID_ABSENCE")
   roles[role]={"index":index,"identifier":PREFIX+identifier,"uuid":p.get("UUID")}
   params[role]=p

  def keys(role,extra):
   require(set(params[role])==set(extra)|{"CustomOutputName","UUID"}, "EXACT_KEYS:"+role)
  def ref(raw,target,coercion=False,wrapped=False):
   if wrapped:
    require(type(raw) is dict and set(raw)=={"Type","Variable"} and raw["Type"]=="Variable", "CONDITION_WRAPPER")
    raw=raw["Variable"]
   require(type(raw) is dict and set(raw)=={"Value","WFSerializationType"} and
           raw["WFSerializationType"]=="WFTextTokenAttachment", "REFERENCE_TOKEN")
   value=raw["Value"];allowed={"Type","OutputName","OutputUUID"}
   if coercion: allowed.add("Aggrandizements")
   require(type(value) is dict and set(value)==allowed and value["Type"]=="ActionOutput" and
           value["OutputUUID"]==roles[target]["uuid"] and
           value["OutputName"]==("Text" if target=="binaryInput" else target), "EXACT_REFERENCE:"+target)
   if coercion:
    require(value["Aggrandizements"]==[{"CoercionItemClass":"WFNumberContentItem","Type":"WFCoercionVariableAggrandizement"}],
            "EXACT_NUMBER_COERCION")
  def simple(role,identifier,target,key="WFInput",extra=None):
   extra=extra or {}
   require(roles[role]["identifier"]==PREFIX+identifier, "ROLE_IDENTIFIER")
   keys(role,{key,*extra})
   ref(params[role][key],target)
   for key,value in extra.items(): require(params[role][key]==value, "PARAMETER_VALUE:"+role)
  def encode(role,target):
   simple(role,"base64encode",target,extra={"WFEncodeMode":"Encode","WFBase64LineBreakMode":"None","input":"Encode"})
  def count(role,target):
   simple(role,"count",target,key="Input",extra={"WFCountType":"Items"})
  def decode(role,target):
   simple(role,"base64encode",target,extra={"WFEncodeMode":"Decode"})
  def text(role,value):
   keys(role,{"WFTextActionText"});require(params[role]["WFTextActionText"]==value,"EXACT_LITERAL_TEXT:"+role)

  require(params["terminal"]=={}, "TERMINAL_NOTHING")
  if case in ("baseline","candidate"):
   text("original",original.decode("utf-8"))
   if case=="baseline":
    encode("encoded","original");decode("decoded","encoded");input_role="decoded"
   else:
    simple("archive","makezip","original",extra={"WFArchiveFormat":".zip","WFZIPName":"cherri-file-probe"})
    simple("extracted","unzip","archive",key="WFArchive")
    count("extractedCount","extracted")
    start=params["countGuardStart"];end=params["countGuardEnd"]
    require(set(start)=={"GroupingIdentifier","WFCondition","WFConditionalLegacyComparisonBehavior",
            "WFControlFlowMode","WFInput","WFNumberValue"} and
            start["WFControlFlowMode"]==0 and start["WFCondition"]==4 and
            start["WFConditionalLegacyComparisonBehavior"] is True and
            type(start["WFNumberValue"]) is float and start["WFNumberValue"]==1.0 and
            type(start["GroupingIdentifier"]) is str and UUID.fullmatch(start["GroupingIdentifier"]), "COUNT_GUARD")
    ref(start["WFInput"],"extractedCount",True,True)
    require(end=={"GroupingIdentifier":start["GroupingIdentifier"],"WFControlFlowMode":2}, "COUNT_GUARD_END")
    simple("item","getitemfromlist","extracted",extra={"WFItemSpecifier":"First Item"})
    require(roles["countGuardStart"]["index"]<roles["item"]["index"]<roles["named"]["index"]<
            roles["namedBytes64"]["index"]<roles["namedStem"]["index"]<roles["countGuardEnd"]["index"],
            "GUARDED_PRODUCER_ORDER")
    input_role="item"
   simple("named","setitemname",input_role,extra={"WFName":expected["fullName"],"WFDontIncludeFileExtension":False})
   require(params["named"]["WFDontIncludeFileExtension"] is False, "NAME_FLAG_BOOLEAN")
   count("namedCount","named");simple("namedType","getitemtype","named");encode("namedBytes64","named")
   simple("namedStem","getitemname","named")
   simple("namedExtension","properties.files","named",extra={"WFContentItemPropertyName":"File Extension"})
  else:
   text("binaryInput","AQ==");decode("binaryWitness","binaryInput")
   simple("binaryType","getitemtype","binaryWitness");encode("binaryBytes64","binaryWitness");count("binaryCount","binaryWitness")
   text("textWitness",expected["witnesses"]["text"]["value"])
   simple("textType","getitemtype","textWitness");encode("textBytes64","textWitness");count("textCount","textWitness")
   keys("dictionaryWitness",{"WFItems"})
   field=params["dictionaryWitness"]["WFItems"]
   require(set(field)=={"Value","WFSerializationType"} and field["WFSerializationType"]=="WFDictionaryFieldValue" and
           set(field["Value"])=={"WFDictionaryFieldValueItems"}, "DICTIONARY_WRAPPER")
   fields=field["Value"]["WFDictionaryFieldValueItems"]
   require(type(fields) is list and len(fields)==1 and set(fields[0])=={"WFItemType","WFKey","WFValue"} and
           type(fields[0]["WFItemType"]) is int and fields[0]["WFItemType"]==0, "DICTIONARY_SINGLE_TEXT_FIELD")
   for key,value in [("WFKey","probe"),("WFValue",expected["witnesses"]["dictionary"]["probe"])]:
    wrapped=fields[0][key]
    require(wrapped=={"Value":{"string":value},"WFSerializationType":"WFTextTokenString"}, "DICTIONARY_LITERAL")
   simple("dictionaryType","getitemtype","dictionaryWitness");count("dictionaryCount","dictionaryWitness")
  results[case]={"sourcePath":source_path,"sourcePin":pin(source),"plistPath":plist_path,"plistPin":pin(raw),
                 "actionCount":len(actions),"roles":roles,"noNonlocalAction":True}
 return {"schema":"cherri-native-file-archive-graph-contract/1","sourceCommit":SOURCE,
         "sourceAuditPassed":True,"nativeExecuted":False,"formalAcceptanceGranted":False,
         "cases":results}

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument("--root",required=True)
 parser.add_argument("--manifest-sha256")
 args=parser.parse_args()
 root=Path(args.root)
 if args.manifest_sha256: verify_manifest(root,args.manifest_sha256)
 result=audit(root)
 contract=root/"graph-contract.original.json"
 if contract.exists(): require(load_json(read_regular(root,"graph-contract.original.json"))==result,"FROZEN_GRAPH_CONTRACT")
 print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))
if __name__=="__main__": main()
