# Construction-only identity diagnostic — prepared, not executed

Fresh Mac stage: /Users/m1/sentinelx/uploads/cherri-debug-export-identity-20261127-01

The original candidate source/plist bytes, original observer/prelude, graph contract, and failed native candidate receipts remain byte-identical. This package changes no compiler or production behavior and recompiles nothing.

The diagnostic observer has exactly two additive insertions (diagnostic/two-insertions.original.diff): an identity observation immediately before the unchanged ORIGINAL_ACTION_IDENTITY guard, and an unconditional IDENTITY_DIAGNOSTIC_STOP_NO_ENGINE throw before controller registration/construction. The UUID guard remains byte-identical. All paths forbid engine execution; a successful identity comparison still stops before registration. Existing original pilot/error/event protocol and limits remain.

New identity rows contain original/actual index, identifier, UUID and actual native class. They reuse values already read by the original observer; no alias normalization or private getter was added. Earlier failures remain preserved in reference/failed-candidate/. A zero-run diagnostic supplies no archive/File semantic verdict.

Owner changes are limited to the fresh ROOT, candidate-only case selection, diagnostic probe binding, and operation label; see diagnostic/owner-binding-only.original.diff. Existing load_primitives(...,None), capture, envelope, deadlines, streams, source snapshots, create-only receipts and owned-group cleanup are unchanged.

Root must freshly admit capacity/ownership and retain its opaque original receipt at admissions/candidate.original.json. Invoke the existing Python3.12 isolated owner with --case candidate, the frozen manifest SHA256, and the fresh admission receipt SHA256. No new admission schema is imposed.

The osascript process may exit0 because the existing JXA catch records its error. Owner exit1 is expected for the construction-only hard stop or retained mismatch; inspect pilot.error and confirm engineRunInvocations0, no engine-run-invoked event, no action callbacks, unchanged sources and closed process group. This is not a candidate semantic failure or a native File pass.
