#!/usr/bin/env python3
"""Fresh paths around the unchanged original JXA observer/capture; root admits each execution."""
import sys
sys.dont_write_bytecode=True
import argparse,datetime,hashlib,json,os,platform,stat,time,traceback,types
from pathlib import Path

ROOT=Path("/Users/m1/sentinelx/uploads/cherri-debug-export-identity-20261127-01")
SOURCE="5bc62d057e4bfa8bdd895e7228ca59eedac20b40"
WHOLE_SECONDS,COMMAND_SECONDS,STREAM_BYTES=60,20,1024**2
INCREMENTAL_BYTES,OS_MARGIN_BYTES=4*1024**2,64*1024**2

def require(value,code):
 if not value: raise ValueError(code)
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def load_exact(name,path,raw):
 module=types.ModuleType(name);module.__file__=str(path);module.__package__=""
 exec(compile(raw,str(path),"exec"),module.__dict__);return module
def record(folder,name,value):
 raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+"\n").encode()
 with (folder/name).open("xb") as stream:
  stream.write(raw);stream.flush();os.fsync(stream.fileno())
 return {"path":str((folder/name).relative_to(ROOT)),**pin(raw)}
def snapshot(graphs,manifest):
 rows={}
 for relative,expected in manifest["files"].items():
  path=ROOT/relative;before=path.lstat();raw=graphs.read_regular(ROOT,relative);after=path.lstat()
  identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  require(identity(before)==identity(after) and pin(raw)==expected,"SOURCE_CHANGED:"+relative)
  rows[relative]={"identity":list(identity(after)),**pin(raw)}
 return rows

def main():
 start=time.monotonic();hard=start+WHOLE_SECONDS
 parser=argparse.ArgumentParser()
 parser.add_argument("--case",choices=("candidate",),required=True)
 parser.add_argument("--manifest-sha256",required=True)
 parser.add_argument("--admission-sha256",required=True)
 args=parser.parse_args()
 # The existing root owner supplies a fresh original capacity/ownership receipt.
 # This adapter does not define another CPU/memory admission policy or protocol.
 try:
  require(platform.system()=="Darwin" and platform.machine()=="arm64" and os.getuid()==501,"MAC_OWNER_IDENTITY")
  require(sys.version_info[:2]==(3,12) and sys.flags.isolated and sys.dont_write_bytecode,"PYTHON_312_ISOLATED")
  require(Path(__file__).resolve().parent==ROOT and not ROOT.is_symlink() and
          ROOT.stat().st_uid==501 and ROOT.stat().st_mode & 0o022==0,"FRESH_OWNED_STAGE")
  manifest_raw=(ROOT/"manifest.original.json").read_bytes()
  require(len(manifest_raw)<=2*1024**2 and pin(manifest_raw)["sha256"]==args.manifest_sha256,"MANIFEST_SHA")
  manifest=json.loads(manifest_raw)
  graph_path=ROOT/"verify_graphs.py";graph_raw=graph_path.read_bytes()
  require(pin(graph_raw)==manifest["files"]["verify_graphs.py"],"GRAPH_AUDITOR_HASH")
  graphs=load_exact("archive_graph_audit",graph_path,graph_raw)
  graphs.verify_manifest(ROOT,args.manifest_sha256)
  contract=graphs.audit(ROOT)
  require(contract==graphs.load_json(graphs.read_regular(ROOT,"graph-contract.original.json")),"FROZEN_GRAPH_CONTRACT")
  admission=graphs.read_regular(ROOT,"admissions/"+args.case+".original.json",64*1024)
  require(pin(admission)["sha256"]==args.admission_sha256,"ROOT_ADMISSION_RECEIPT_SHA")
  require(not (ROOT/"runs"/args.case).exists(),"ORIGINAL_CASE_RECEIPTS_ALREADY_EXIST")
  free=os.statvfs("/System/Volumes/Data").f_bavail*os.statvfs("/System/Volumes/Data").f_frsize
  require(free>=INCREMENTAL_BYTES+OS_MARGIN_BYTES,"ORIGINAL_OWNER_FREE_SPACE_THRESHOLD")
 except BaseException as error:
  print(json.dumps({"status":"NOT_ADMITTED","case":args.case,"reason":str(error),
                    "engineRunInvocations":0,"nativeAcceptanceGranted":False}))
  return 78

 folder=ROOT/"runs"/args.case
 folder.parent.mkdir(mode=0o700,exist_ok=True);folder.mkdir(mode=0o700)
 result={"schema":"cherri-workflowkit-original-action-pilot-owner/1","status":"INCOMPLETE","case":args.case,
   "startedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourceCommit":SOURCE,
   "packageManifestSHA256":args.manifest_sha256,"rootAdmissionSHA256":args.admission_sha256,
   "wholeOwnerSeconds":WHOLE_SECONDS,"commandSeconds":COMMAND_SECONDS,"engineSeconds":8,
   "streamLimitBytes":STREAM_BYTES,"freeDataBefore":free,"estimatedIncrementalBytes":INCREMENTAL_BYTES,
   "osMarginBytes":OS_MARGIN_BYTES,"shortcutImports":0,"engineRunInvocations":None,
   "nativeAcceptanceGranted":False,"signedImportExercised":False,"iOSDeviceExercised":False}
 observed=details=None;last_journal={};process_started=False
 original_cwd=Path.cwd();original_tmp=os.environ.get("TMPDIR")
 try:
  record(folder,"admission.original.json",admission)
  base_path=ROOT/"source/ios/scripts/collect_ios_xcresult_summary.py"
  base=load_exact("original_capture_base",base_path,
                  graphs.read_regular(ROOT,str(base_path.relative_to(ROOT))))
  with base.envelope(max(0.001,hard-time.monotonic())):
   helper=base.load_primitives(ROOT/"source",None)
   before=snapshot(graphs,manifest);record(folder,"source-before.original.json",before)
   case=contract["cases"][args.case]
   events=folder/"events.original.jsonl"
   with events.open("xb"):pass
   temporary=folder/"native-tmp";temporary.mkdir(mode=0o700)
   os.environ["TMPDIR"]=str(temporary)+"/";os.chdir(temporary)
   argv=["/usr/bin/osascript","-l","JavaScript",str(ROOT/"diagnostic/probe.identity.original.js"),
         str(ROOT/case["plistPath"]),str(events)]
   record(folder,"intent.original.json",{"argv":argv,"seconds":COMMAND_SECONDS,
        "hardDeadlineMonotonic":hard-15,"operation":"construction-only-original-identity-"+args.case,
        "sourcePin":case["sourcePin"],"plistPin":case["plistPin"],
        "workingDirectory":str(temporary),"TMPDIR":str(temporary)+"/"})
   def journal(phase,row):
    nonlocal process_started
    last_journal.clear();last_journal.update(row)
    if phase=="started":process_started=True
    record(folder,"process."+phase+".original.json",row)
   with (folder/"stdout.original").open("xb") as stdout,(folder/"stderr.original").open("xb") as stderr:
    observed,details=helper.capture(argv,COMMAND_SECONDS,output=stdout,error_output=stderr,
        hard_deadline=hard-15,stream_limit=STREAM_BYTES,journal=journal)
   record(folder,"process.original.json",{"observed":observed,"capture":details})
   result["process"]={"observed":observed,"capture":details}
   require(details["cleanupParentReaped"] is True and details["groupAfterCleanup"]["state"]=="ABSENT","OWNED_PROCESS_GROUP_REMAINED")
   after=snapshot(graphs,manifest);record(folder,"source-after.original.json",after)
   require(after==before,"SOURCE_CHANGED_AFTER_NATIVE_PROCESS")
   result["sourceBeforeAfterEqual"]=True
   require(observed["result"]=="PASS" and observed["exitCode"]==0,"NATIVE_PROCESS_"+observed["result"])
   raw=graphs.read_regular(ROOT,str((folder/"stdout.original").relative_to(ROOT)),STREAM_BYTES)
   pilot=graphs.load_json(raw)
   require(pilot.get("schema")=="cherri-workflowkit-original-action-pilot/1" and
           type(pilot.get("engineRunInvocations")) is int and pilot["engineRunInvocations"] in (0,1)
           and type(pilot.get("events")) is list and len(pilot["events"])<=64,"ORIGINAL_PILOT_SHAPE")
   require(all(pilot.get(key) is False for key in
          ("sourceProgramsChanged","signedImportExercised","iOSDeviceExercised","formalAcceptanceGranted")),
          "ORIGINAL_PILOT_SCOPE")
   record(folder,"pilot.original.json",raw)
   result.update(status=pilot["status"],engineRunInvocations=pilot["engineRunInvocations"],
                 pilot=pin(raw),pilotError=pilot.get("error"))
 except BaseException as error:
  result["status"]="OWNER_OR_OBSERVATION_FAILURE"
  result["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
  if last_journal and "process" not in result:
   result["process"]={"observed":observed,"capture":last_journal}
 finally:
  os.chdir(original_cwd)
  if original_tmp is None:os.environ.pop("TMPDIR",None)
  else:os.environ["TMPDIR"]=original_tmp
  if not process_started and result["engineRunInvocations"] is None:result["engineRunInvocations"]=0
  result["processStarted"]=process_started
  result["elapsedMs"]=round((time.monotonic()-start)*1000)
  result["freeDataAfter"]=os.statvfs("/System/Volumes/Data").f_bavail*os.statvfs("/System/Volumes/Data").f_frsize
  receipt=record(folder,"result.original.json",result)
  print(json.dumps({"status":result["status"],"case":args.case,"receipt":receipt,
                   "engineRunInvocations":result["engineRunInvocations"],"nativeAcceptanceGranted":False}))
 return 0 if result["status"]=="ENGINE_CALLBACKS_RETAINED_VALIDATION_PENDING" else 1
if __name__=="__main__":raise SystemExit(main())
