# Unexecuted bounded NSError observation

Case: zip. Original source/plist: qa-file-archive-zip-v2. Original Asana task: 1220544665232213.

This package changes only observation of an error from the already compiled zip program. It preserves its 743-byte source and 9,648-byte plist exactly. There is no compiler invocation, source-program edit, production edit, hand-edited plist, new action, changed execution context or permission/entitlement change. Prior raw-source comparison and compile receipts are retained as original evidence, not rerun.

## Existing evidence and helper check

The acquired zip pilot SHA256 238be38769fbb5a5a84686d8b33074f2ecc8fc7f5c3cac5eeab33bdb71b985aa records only nativeClass, domain and code at its two error events. Its stderr is empty. Omitted descriptions cannot be reconstructed from those originals. The bounded nativeValue helper leaves NSError UNOBSERVED. The separate Swift Vision error helper is for OCR and cannot read omitted WorkflowKit details.

## Exact observation-only delta

The original observer, prelude and joined probe remain under their original paths and hashes. The separate observe_nserror_details.diagnostic.js adds error-details.insertion.js before actionIdentity and replaces the error expression at exactly two callback sites. observer-error-diagnostic.diff records every change.

The static auditor verifies that deleting the inserted helper and reversing both substitutions restores the original observer byte for byte. All identity/UUID guards, class bindings, controller construction, action input/output observations, callback sequence, engine invocation and deadlines remain unchanged. Original nativeClass/domain/code fields retain the exact original property access and conversions. Extra getter failures become fixed status values and do not erase original error fields or change callback control.

source/probe.error-diagnostic.js joins the unchanged original prelude, one newline and the diagnostic observer. Node --check validated syntax without executing it. No native execution occurred during preparation.

## Data and hard bounds

Only localizedDescription, localizedFailureReason and localizedRecoverySuggestion are read from NSError. NSString checks precede conversion. Text is omitted beyond 512 UTF-16 code units, 2,048 UTF-8 bytes per field or 4,096 total collected text bytes per error record. Underlying class/domain strings have a stricter 128-code-unit limit. Recognizable credential assignments, bearer values, private-key markers and credential-like URLs are omitted with a fixed status. No environment, credential store or provider information is queried.

Only the NSUnderlyingError dictionary key is read, after checking userInfo is NSDictionary. No keys are enumerated and userInfo is never serialized. The underlying value must be NSError; only its class, domain, safe-integer code and the same three text fields are observed. No second underlying error or underlying userInfo is read. Added metadata is limited to 8,192 serialized UTF-8 bytes. Nil, unsupported types, bounds and getter failures produce fixed statuses. Existing event/stream bounds remain active.

## Fresh owner and original limits

owner.py changes only ROOT and observer filename from the reviewed zip owner; case remains zip. owner-binding.diff records both changes. Original load_primitives/capture/envelope and seven helper copies remain exact. Limits remain 16 actions, 2 MiB plist, 8-second engine, 20-second command, 60-second owner, 15-second cleanup reserve and 1 MiB per stream. Root must freshly admit the owned run and retain parent-reaped, process-group ABSENT and unchanged-source receipts.

Fresh stage:
/Users/m1/sentinelx/uploads/cherri-debug-export-archive-error-20261127-01

Root alone uses its new admissions/zip.original.json receipt and:
python3 -I -B STAGE/owner.py --case zip --manifest-sha256 MANIFEST_SHA --admission-sha256 ADMISSION_SHA

No existing Mac GUI, Simulator, clipboard or unrelated process is controlled. The fixed program has no network, provider-save, UI or import action; local archive temporary files remain possible.

Both direct and zip original failures remain unchanged: Make Archive returned VCVoiceShortcutsErrorDomain 1011, null callback UUID and empty output, with no later completion. This package does not interpret that code or relax ACTION_MODEL_BINDING rejection. It is diagnostic only, even if a future outcome changes, and grants no File, canonical-action, full-debugExport, signed-import or iPad acceptance.
