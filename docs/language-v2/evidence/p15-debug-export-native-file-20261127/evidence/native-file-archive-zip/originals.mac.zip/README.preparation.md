# Unexecuted native archive wire-format diagnostic

Case: zip. Source: qa-file-archive-zip-v2. Original Asana task: 1220544665232213.

This is a separately authored source diagnostic using the existing native.action/native.ref language constructs and the unchanged canonical compiler. It does not modify production makeArchive or hand-edit compiler output. The ordinary makeArchive literal enum allows .zip and rejects zip; committed Apple metadata instead distinguishes wire id zip from display title .zip. native-format-evidence.original.json retains exact5bc source pins and metadata extracts. The metadata snapshot is build26A434; the prior actual runtime was26A428. No NSError code meaning is inferred.

## Exact change and comparison

Only the original Make Archive source line was replaced with:
let archive = native.action("is.workflow.actions.makezip", parameters: {"WFInput": native.ref(original), "WFArchiveFormat": "zip", "WFZIPName": "cherri-file-probe"})

Every other source byte is unchanged from direct. source-from-direct.diff and plist-from-direct.diff preserve the actual changes. The single existing5bc compiler invocation passed in56ms, producing11actions. No Go build, signing, other case replay, or native execution occurred during preparation.

normalized-graph-comparison.original.json maps each of the10 actual named producer UUIDs bijectively by exact index, identifier and unchanged output name; it also enumerates all9 ActionOutput reference edges. Normalization changes only those producer UUID fields and their exact WFTextTokenAttachment ActionOutput OutputUUID fields. It does not remove UUID-like strings, names, headers, unrelated keys, or parameters. The complete workflows compare equal except WFWorkflowActions[1].WFWorkflowActionParameters.WFArchiveFormat: direct=.zip, zip=zip. Both source/plist hashes and actual identities remain distinct. There are no additional actions, selectors, filters or coercions.

## Unchanged native route

source/probe.original.js is the exact original prelude plus newline plus original observer, with unchanged action-index/identifier/UUID guards and callback fields. All7 copied original helper files remain byte-exact. owner.py differs from the reviewed direct owner only in its fixed ROOT and sole permitted case. owner-binding.diff preserves both binding changes. load_primitives/capture/envelope remain unchanged.

Bounds remain16actions,2MiB plist,8secondengine,20secondcommand,60secondowner with15secondcleanupreserve,1MiB perstream. Root supplies a fresh opaque admission receipt. The owned parent must be reaped, its process group ABSENT, and source snapshots equal. Receipt and run paths are create-only. Archive temporary files are expected; no UI/import/clipboard/network/provider-save action is present, and existing GUI/Simulator/unrelated processes are not controlled.

Fixed stage:
/Users/m1/sentinelx/uploads/cherri-debug-export-archive-zip-20261127-01

Root alone stages/admit/runs:
python3 -I -B STAGE/owner.py --case zip --manifest-sha256 MANIFEST_SHA --admission-sha256 ADMISSION_SHA

Use the fresh admissions/zip.original.json hash. No prior admission or run path is reused.

## Runtime criteria and limits

The entire Extract Archive output is passed directly to Set Name, with Counts before and after; there is no If or First Item. Both actual collections must have exactly1File and both Count outputs must be1. Extra extracted or named entries reject carrier evidence even if a consumer silently collapses them. Observe the actual named WFGenericFileContentItem before Type/Base64/Name/Extension consumers, require the extracted item also be a File, and retain original identity/error events unchanged. The independent83byte UTF8 oracle, SHA256539a079afd9ef25a7e6c893494300f86f9f8db22c9dc4b58bbb433d4e492c365, literal Base64, stem cherri-debug, extension json and full name cherri-debug.json remain exact. Missing or truncated evidence cannot pass.

Prior outcomes remain separate: baseline produced WFDictionaryContentItem; guarded candidate never ran because construction identity failed; direct ran once and MakeArchive returned VCVoiceShortcutsErrorDomain1011 with null callback UUID and empty output, with no later action completion. This diagnostic does not replace or relabel any original result. Reuse existing binary/Text/Dictionary witness observations; do not replay them. A positive result would support only this macOS raw-source carrier experiment; full debugExport, canonical makeArchive, signed import and iPad gates require their own evidence. Owner status ENGINE_CALLBACKS_RETAINED_VALIDATION_PENDING is not semantic acceptance.
