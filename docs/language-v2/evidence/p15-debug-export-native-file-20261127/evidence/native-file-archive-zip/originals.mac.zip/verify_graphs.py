#!/usr/bin/env python3
"""Read-only audit of the separately authored probes; never emits or rewrites plist."""
import sys
sys.dont_write_bytecode = True
import argparse, base64, hashlib, json, plistlib, re, stat
from pathlib import Path

SOURCE = "5bc62d057e4bfa8bdd895e7228ca59eedac20b40"
PREFIX = "is.workflow.actions."
OBSERVER_SHA = "c1239494a12ebe7bb9f3efb4067b4203baaacf700ee9c626283e90ebbfc0480b"
PRELUDE_SHA = "d6fbcaad5104562b04004b39ca098486449399c15c83176c49b2ac28f47a3461"
JOINED_SHA = "9cb1d58914a8d262cd48fef48207ef74c0def7f89674afc3e75de69eb04959d5"
UUID = re.compile(r"[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}")
CASES = ("zip",)
SPECS = {
 "zip": [("original","gettext"),("archive","makezip"),("extracted","unzip"),
            ("extractedCount","count"),("named","setitemname"),("namedCount","count"),
            ("namedType","getitemtype"),("namedBytes64","base64encode"),
            ("namedStem","getitemname"),("namedExtension","properties.files"),("terminal","nothing")]
}

def require(value, code):
 if not value: raise ValueError(code)

def pin(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}

def read_regular(root, relative, limit=2*1024**2):
 path=Path(relative)
 require(not path.is_absolute() and ".." not in path.parts, "RELATIVE_PATH")
 full=root/path
 current=root
 require(not root.is_symlink() and root.is_dir(), "ROOT_DIRECTORY")
 for part in path.parts:
  current=current/part
  require(not current.is_symlink(), "SYMLINK")
 before=full.stat()
 require(stat.S_ISREG(before.st_mode) and before.st_size<=limit, "REGULAR_BOUNDED_INPUT")
 raw=full.read_bytes()
 after=full.stat()
 require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==
         (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), "INPUT_CHANGED_DURING_READ")
 return raw

def load_json(raw):
 def pairs(rows):
  result={}
  for key,value in rows:
   require(key not in result, "DUPLICATE_JSON_KEY")
   result[key]=value
  return result
 return json.loads(raw,object_pairs_hook=pairs)

def verify_manifest(root, expected_sha):
 raw=read_regular(root,"manifest.original.json")
 require(pin(raw)["sha256"]==expected_sha, "PACKAGE_MANIFEST_SHA")
 manifest=load_json(raw)
 require(manifest["schema"]=="cherri-native-file-archive-package/1" and
         manifest["sourceCommit"]==SOURCE, "PACKAGE_IDENTITY")
 rows=manifest["files"]
 require(type(rows) is dict and 1<=len(rows)<=128, "PACKAGE_FILE_BOUND")
 for relative,expected in rows.items():
  require(pin(read_regular(root,relative))==expected, "PACKAGE_FILE_HASH:"+relative)
 return manifest

def compare_direct(root):
 import copy
 old_source=read_regular(root,"reference/direct/fixtures/qa-file-archive-direct-v2.cherri")
 new_source=read_regular(root,"fixtures/qa-file-archive-zip-v2.cherri")
 before=b'let archive = makeArchive(original, ".zip", "cherri-file-probe")'
 after=b'let archive = native.action("is.workflow.actions.makezip", parameters: {"WFInput": native.ref(original), "WFArchiveFormat": "zip", "WFZIPName": "cherri-file-probe"})'
 require(old_source.count(before)==1 and new_source==old_source.replace(before,after),"ONLY_SOURCE_PRODUCER_REPLACEMENT")
 old_raw=read_regular(root,"reference/direct/compiled/qa-file-archive-direct-v2.shortcut")
 new_raw=read_regular(root,"compiled/qa-file-archive-zip-v2.shortcut")
 require(pin(old_raw)=={"bytes":9649,"sha256":"e0f08e38a88be8dfc1ca307368e679fedf750fabb82994dbc2e30e817c3af487"},"EXACT_DIRECT_PLIST")
 documents=[plistlib.loads(old_raw),plistlib.loads(new_raw)]
 specs=SPECS["zip"];mappings=[];by_side=[{},{}]
 require(all(len(d["WFWorkflowActions"])==len(specs) for d in documents),"COMPARISON_ACTION_COUNT")
 for index,(role,identifier) in enumerate(specs):
  actions=[d["WFWorkflowActions"][index] for d in documents]
  require(all(a["WFWorkflowActionIdentifier"]==PREFIX+identifier for a in actions),"COMPARISON_IDENTIFIER_ORDER")
  parameters=[a.get("WFWorkflowActionParameters",{}) for a in actions]
  if role=="terminal":
   require(parameters==[{},{}],"COMPARISON_TERMINAL")
   continue
  names=[p.get("CustomOutputName") for p in parameters]
  uuids=[p.get("UUID") for p in parameters]
  require(names==[role,role],"UNCHANGED_PRODUCER_NAMES")
  require(all(type(u) is str and UUID.fullmatch(u) for u in uuids),"COMPARISON_UUID_SHAPE")
  row={"index":index,"role":role,"identifier":PREFIX+identifier,"directUUID":uuids[0],"zipUUID":uuids[1],
       "directOutputName":names[0],"zipOutputName":names[1]}
  mappings.append(row)
  for side,uuid in enumerate(uuids):
   require(uuid not in by_side[side],"BIJECTIVE_PRODUCER_UUID")
   by_side[side][uuid]=row
 reference_paths=[[],[]]
 def normalize_references(value,side,path):
  if type(value) is list:return [normalize_references(v,side,path+[i]) for i,v in enumerate(value)]
  if type(value) is not dict:return value
  normalized={k:normalize_references(v,side,path+[k]) for k,v in value.items()}
  if value.get("WFSerializationType")=="WFTextTokenAttachment" and type(value.get("Value")) is dict and value["Value"].get("Type")=="ActionOutput":
   v=value["Value"]
   require(set(value)=={"Value","WFSerializationType"} and set(v)=={"Type","OutputName","OutputUUID"},"EXACT_COMPARISON_REFERENCE_SHAPE")
   require(v["OutputUUID"] in by_side[side],"COMPARISON_REFERENCE_BINDING")
   row=by_side[side][v["OutputUUID"]]
   require(v["OutputName"]==row["role"],"UNCHANGED_REFERENCE_OUTPUT_NAME")
   normalized["Value"]["OutputUUID"]="producer:"+row["role"]
   reference_paths[side].append({"path":path+["Value","OutputUUID"],"role":row["role"],"outputName":v["OutputName"]})
  return normalized
 normalized=[]
 for side,document in enumerate(documents):
  d=normalize_references(copy.deepcopy(document),side,[])
  for row in mappings:d["WFWorkflowActions"][row["index"]]["WFWorkflowActionParameters"]["UUID"]="producer:"+row["role"]
  normalized.append(d)
 require(reference_paths[0]==reference_paths[1],"IDENTICAL_REFERENCE_EDGES")
 differences=[]
 def diff(a,b,path):
  if type(a) is not type(b):differences.append({"path":path,"direct":a,"zip":b});return
  if type(a) is dict:
   require(set(a)==set(b),"COMPARISON_FIELD_SET:"+str(path))
   for key in sorted(a):diff(a[key],b[key],path+[key])
  elif type(a) is list:
   require(len(a)==len(b),"COMPARISON_LIST_LENGTH:"+str(path))
   for i,(left,right) in enumerate(zip(a,b)):diff(left,right,path+[i])
  elif a!=b:differences.append({"path":path,"direct":a,"zip":b})
 diff(normalized[0],normalized[1],[])
 expected=[{"path":["WFWorkflowActions",1,"WFWorkflowActionParameters","WFArchiveFormat"],"direct":".zip","zip":"zip"}]
 require(differences==expected,"ONLY_FORMAT_SEMANTIC_DIFFERENCE")
 def canonical(value):return (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+"\n").encode()
 return {"status":"ONLY_WFArchiveFormat_CHANGED_AFTER_EXPLICIT_UUID_MAPPING","directSourcePin":pin(old_source),
         "zipSourcePin":pin(new_source),"directPlistPin":pin(old_raw),"zipPlistPin":pin(new_raw),
         "sameOriginalSource":False,"sameOriginalPlist":False,"sourceChange":"makeArchive call replaced by existing native.action/native.ref",
         "producerMappings":mappings,"referenceEdges":reference_paths[0],"outputNamesChanged":False,
         "extraActions":0,"extraCoercions":0,"differences":differences,
         "normalizationScope":"Only each declared producer UUID and its exact WFTextTokenAttachment ActionOutput OutputUUID; no names, literal strings, header fields or other parameters ignored.",
         "normalizedDirectPin":pin(canonical(normalized[0])),"normalizedZipPin":pin(canonical(normalized[1])),
         "nativeExecuted":False}

def audit(root):
 root=Path(root).resolve()
 expected=load_json(read_regular(root,"expected/expectations.original.json"))
 require(expected["schema"]=="cherri-native-file-archive-expectations/1" and
         expected["sourceCommit"]==SOURCE, "EXPECTED_IDENTITY")
 original=read_regular(root,expected["json"]["file"])
 require(pin(original)=={k:expected["json"][k] for k in ("bytes","sha256")} and
         base64.b64encode(original).decode()==expected["json"]["base64"], "INDEPENDENT_UTF8")
 require(expected["requiredFileClass"]=="WFGenericFileContentItem" and
         expected["requiredCount"]==1 and expected["fullName"]=="cherri-debug.json" and
         expected["stem"]=="cherri-debug" and expected["extension"]=="json", "ORIGINAL_FILE_CRITERIA")
 source_pins=load_json(read_regular(root,"source/source-pins.original.json"))
 require(source_pins["commit"]==SOURCE and source_pins["unchangedCopies"] is True, "SOURCE_IDENTITY")
 for relative,expected_pin in source_pins["files"].items():
  require(pin(read_regular(root,"source/"+relative))==expected_pin, "UNCHANGED_SOURCE:"+relative)
 observer=read_regular(root,"source/tools/shortcut-runtime/jxa/observe_original_action_values.js")
 prelude=read_regular(root,"source/jxa-prelude.original.js")
 joined=read_regular(root,"source/probe.original.js")
 require(pin(observer)["sha256"]==OBSERVER_SHA and pin(prelude)["sha256"]==PRELUDE_SHA and
         pin(joined)["sha256"]==JOINED_SHA and joined==prelude+b"\n"+observer, "EXACT_OBSERVER_PRELUDE")
 results={}
 for case in CASES:
  source_path="fixtures/qa-file-archive-"+case+"-v2.cherri"
  plist_path="compiled/qa-file-archive-"+case+"-v2.shortcut"
  source=read_regular(root,source_path)
  raw=read_regular(root,plist_path)
  document=plistlib.loads(raw)
  actions=document["WFWorkflowActions"]
  require(type(actions) is list and 1<=len(actions)<=16 and len(actions)==len(SPECS[case]), "ACTION_BOUND")
  require(document.get("WFWorkflowHasOutputFallback") is False and
          document.get("WFWorkflowHasShortcutInputVariables") is False and
          document.get("WFWorkflowImportQuestions")==[], "NO_EXTERNAL_INPUT_OR_IMPORT_QUESTION")
  roles={};params={};seen=set()
  for index,((role,identifier),action) in enumerate(zip(SPECS[case],actions)):
   require(set(action)=={"WFWorkflowActionIdentifier","WFWorkflowActionParameters"} or
           (identifier=="nothing" and set(action)=={"WFWorkflowActionIdentifier"}), "ACTION_FIELDS")
   require(action["WFWorkflowActionIdentifier"]==PREFIX+identifier, "EXACT_ACTION_ORDER")
   p=action.get("WFWorkflowActionParameters",{})
   require(type(p) is dict, "PARAMETER_OBJECT")
   if identifier not in ("conditional","nothing"):
    require(p.get("CustomOutputName")==("Text" if role=="binaryInput" else role), "NAMED_ROLE")
    require(type(p.get("UUID")) is str and UUID.fullmatch(p["UUID"]) and p["UUID"] not in seen, "UNIQUE_UUID")
    seen.add(p["UUID"])
   else:
    require("UUID" not in p and "CustomOutputName" not in p, "ORIGINAL_UUID_ABSENCE")
   roles[role]={"index":index,"identifier":PREFIX+identifier,"uuid":p.get("UUID")}
   params[role]=p

  def keys(role,extra):
   require(set(params[role])==set(extra)|{"CustomOutputName","UUID"}, "EXACT_KEYS:"+role)
  def ref(raw,target,coercion=False,wrapped=False):
   if wrapped:
    require(type(raw) is dict and set(raw)=={"Type","Variable"} and raw["Type"]=="Variable", "CONDITION_WRAPPER")
    raw=raw["Variable"]
   require(type(raw) is dict and set(raw)=={"Value","WFSerializationType"} and
           raw["WFSerializationType"]=="WFTextTokenAttachment", "REFERENCE_TOKEN")
   value=raw["Value"];allowed={"Type","OutputName","OutputUUID"}
   if coercion: allowed.add("Aggrandizements")
   require(type(value) is dict and set(value)==allowed and value["Type"]=="ActionOutput" and
           value["OutputUUID"]==roles[target]["uuid"] and
           value["OutputName"]==("Text" if target=="binaryInput" else target), "EXACT_REFERENCE:"+target)
   if coercion:
    require(value["Aggrandizements"]==[{"CoercionItemClass":"WFNumberContentItem","Type":"WFCoercionVariableAggrandizement"}],
            "EXACT_NUMBER_COERCION")
  def simple(role,identifier,target,key="WFInput",extra=None):
   extra=extra or {}
   require(roles[role]["identifier"]==PREFIX+identifier, "ROLE_IDENTIFIER")
   keys(role,{key,*extra})
   ref(params[role][key],target)
   for key,value in extra.items(): require(params[role][key]==value, "PARAMETER_VALUE:"+role)
  def encode(role,target):
   simple(role,"base64encode",target,extra={"WFEncodeMode":"Encode","WFBase64LineBreakMode":"None","input":"Encode"})
  def count(role,target):
   simple(role,"count",target,key="Input",extra={"WFCountType":"Items"})
  def decode(role,target):
   simple(role,"base64encode",target,extra={"WFEncodeMode":"Decode"})
  def text(role,value):
   keys(role,{"WFTextActionText"});require(params[role]["WFTextActionText"]==value,"EXACT_LITERAL_TEXT:"+role)

  require(params["terminal"]=={}, "TERMINAL_NOTHING")
  require(pin(source)=={"bytes":743,"sha256":"73fb0b7b090d7a404e4c58124997d6fbd26699cca99aa03c281cb7aaf80ff6d0"} and
          pin(raw)=={"bytes":9648,"sha256":"5b6b8f92736dc77ef865a26322592cfa436a224572cff2d962d2cacb24481168"},
          "EXACT_SINGLE_COMPILED_ZIP_SOURCE")
  text("original",original.decode("utf-8"))
  simple("archive","makezip","original",extra={"WFArchiveFormat":"zip","WFZIPName":"cherri-file-probe"})
  simple("extracted","unzip","archive",key="WFArchive")
  count("extractedCount","extracted")
  simple("named","setitemname","extracted",extra={"WFName":expected["fullName"],"WFDontIncludeFileExtension":False})
  require(params["named"]["WFDontIncludeFileExtension"] is False,"NAME_FLAG_BOOLEAN")
  count("namedCount","named")
  simple("namedType","getitemtype","named")
  encode("namedBytes64","named")
  simple("namedStem","getitemname","named")
  simple("namedExtension","properties.files","named",extra={"WFContentItemPropertyName":"File Extension"})
  require(roles["extracted"]["index"]<roles["extractedCount"]["index"]<roles["named"]["index"]<
          roles["namedCount"]["index"]<roles["namedType"]["index"]<roles["namedBytes64"]["index"]<
          roles["namedStem"]["index"]<roles["namedExtension"]["index"],"WHOLE_COLLECTION_OBSERVATION_ORDER")
  results[case]={"sourcePath":source_path,"sourcePin":pin(source),"plistPath":plist_path,"plistPin":pin(raw),
                 "actionCount":len(actions),"roles":roles,"noNonlocalAction":True,
                 "wholeExtractedCollectionPassedToName":True,"requiredExtractedCount":1,"requiredNamedCount":1,
                 "extraItemsRejectCarrierEvidence":True,"conditionalOrItemSelectionActions":0}
 return {"schema":"cherri-native-file-archive-graph-contract/1","sourceCommit":SOURCE,
         "sourceAuditPassed":True,"nativeExecuted":False,"formalAcceptanceGranted":False,
         "cases":results,"comparisonWithDirect":compare_direct(root)}

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument("--root",required=True)
 parser.add_argument("--manifest-sha256")
 args=parser.parse_args()
 root=Path(args.root)
 if args.manifest_sha256: verify_manifest(root,args.manifest_sha256)
 result=audit(root)
 contract=root/"graph-contract.original.json"
 if contract.exists(): require(load_json(read_regular(root,"graph-contract.original.json"))==result,"FROZEN_GRAPH_CONTRACT")
 print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))
if __name__=="__main__": main()
