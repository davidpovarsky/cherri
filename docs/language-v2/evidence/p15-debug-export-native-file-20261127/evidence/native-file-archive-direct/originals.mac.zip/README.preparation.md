# Unexecuted direct archive carrier probe

Case: direct. Program: qa-file-archive-direct-v2. Original Asana task: 1220544665232213.

This separately named program passes the complete Extract Archive output directly into Set Name. It has 11 actions, including counts of both extracted and named collections and a terminal Nothing. There is no If, First Item, filter, coercion, provider save, network, clipboard, UI, or import action. The preserved 5bc compiler was invoked once for this source; its original compile receipt reports exit 0, 37 ms, stable source, parent reaped and group ABSENT. No compiler rebuild or other case replay occurred.

## Immutable runtime route

Use only the original observer/prelude and seven copied helper files. source/source-pins.original.json binds the exact 5bc source files. source/probe.original.js is the original prelude plus newline plus unchanged original observer. Its action index, identifier and UUID guards remain byte-exact. owner.py differs from the previously reviewed archive owner only in fixed Mac ROOT and allowed case; owner-binding.diff records those two binding changes. It reuses unchanged load_primitives, capture and envelope primitives. No new native executor or acceptance protocol is introduced.

The original limits remain: at most 16 actions, at most 2 MiB input plist, 8-second engine limit, 20-second command, 60-second owner with 15-second cleanup reserve, and 1 MiB per captured stream. Parent reaping, owned process-group ABSENT, and equal source snapshots are required. Receipt and run paths are create-only. Native archive temporary files are expected within the owned execution environment. Existing Shortcuts GUI, Simulator, clipboard and unrelated processes are not controlled.

The root owner must freshly admit and stage at:
/Users/m1/sentinelx/uploads/cherri-debug-export-archive-direct-20261127-01

With its fresh admissions/direct.original.json, execute exactly the existing owner interface using the actual manifest and admission hashes:
python3 -I -B STAGE/owner.py --case direct --manifest-sha256 MANIFEST_SHA --admission-sha256 ADMISSION_SHA

The root owns transfer, capacity checks and all Mac execution. No Mac run occurred during preparation.

## Required original-stream observations

The independent original UTF-8 payload is exactly 83 bytes, SHA256 539a079afd9ef25a7e6c893494300f86f9f8db22c9dc4b58bbb433d4e492c365; its literal Base64 and filename expectations are in unchanged expected/expectations.original.json. Never derive an expected value from native output.

For carrier-only evidence, both actual extracted and named collections must contain exactly one item, and both Count action results must be 1. The named item must already be WFGenericFileContentItem in its original action event before Type/Base64/Name/Extension consumers; the extracted item must also be a File. Require Type File, exact original bytes/Base64, name cherri-debug, extension json, and full name cherri-debug.json where the observer reports it. Missing/truncated observations do not pass. Any extra extracted or named item rejects carrier evidence, even if a later action implicitly collapses it. No First Item selection hides entries. Join observations by the graph contract's exact action indices and UUIDs.

Reuse the separately acquired original binary/Text/Dictionary witness observations; do not rerun them or the baseline. The baseline remains a negative File result: decoded and named output was WFDictionaryContentItem despite exact bytes/name/count. The guarded 14-action candidate remains NOT_RUN with engine count zero. Its construction-only diagnostic found original index 5 at native index 6 with the same identifier and UUID; the cause is unobserved. This distinct direct source does not relax that guard or retroactively pass that case.

Even if this probe succeeds, it establishes only this macOS carrier experiment. It does not change production behavior or close the original signed-import, full debugExport, or iPad gates. Owner status ENGINE_CALLBACKS_RETAINED_VALIDATION_PENDING alone is not semantic acceptance.
