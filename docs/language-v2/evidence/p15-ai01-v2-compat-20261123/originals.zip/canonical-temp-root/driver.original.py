import pathlib,sys,json,subprocess,tempfile,hashlib,ast,datetime,os
root=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-505-refresh-20261123')
evidence=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-ai01-compat-20261123')
sys.path.insert(0,str(root/'tools/language-ai-eval'))
import evaluation_bundle as eb
source=(root/'tools/language-ai-eval/evaluation_bundle.py').read_text()
baseline=subprocess.check_output(['git','show','HEAD:tools/language-ai-eval/evaluation_bundle.py'],cwd=root,text=True)
def function(text,name):
 return ast.get_source_segment(text,next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name))
unchanged={n:function(source,n)==function(baseline,n) for n in ['read_regular','_stat_is_link','derive','generate_suite']}
assert all(unchanged.values())
workflow=(root/'.github/workflows/build-test.yml').read_text()
snippet='set -euo pipefail\nTMPDIR="$(cd -- "${RUNNER_TEMP:?}" && pwd -P)"\nexport TMPDIR\n'
assert workflow.count('        TMPDIR="$(cd -- "${RUNNER_TEMP:?}" && pwd -P)"')==2
subprocess.run(['bash','-n'],input=snippet,text=True,check=True,timeout=10)
rows=[]
with tempfile.TemporaryDirectory(prefix='ai01-canonical-root-',dir=evidence) as owned:
 parent=pathlib.Path(owned)
 physical=parent/'physical';physical.mkdir()
 alias=parent/'alias';alias.symlink_to(physical,target_is_directory=True)
 alias_file=alias/'original.bin';alias_file.write_bytes(b'causal temporary-root control\n')
 try:eb.read_regular(alias_file)
 except eb.BundleError as error:
  assert str(error)=='INPUT_PARENT_SYMLINK'
  rows.append({'case':'alias_original_rejected','result':'PASS','observed':str(error)})
 else:raise AssertionError('Alias evidence unexpectedly accepted')
 environment={'RUNNER_TEMP':str(alias),'PATH':'/usr/bin:/bin'}
 command=snippet+'printf "%s\\n" "$TMPDIR"\n'
 result=subprocess.run(['bash','-c',command],env=environment,text=True,capture_output=True,check=True,timeout=10)
 canonical=result.stdout.strip()
 assert canonical==str(physical)
 with tempfile.TemporaryDirectory(prefix='new-fixture-',dir=canonical) as created:
  path=pathlib.Path(created)/'original.bin';path.write_bytes(b'causal temporary-root control\n')
  assert eb.read_regular(path)==b'causal temporary-root control\n'
  rows.append({'case':'new_fixture_under_workflow_resolved_root','result':'PASS'})
 try:eb.read_regular(alias_file)
 except eb.BundleError as error:
  assert str(error)=='INPUT_PARENT_SYMLINK'
  rows.append({'case':'arbitrary_alias_still_rejected_after_environment_fix','result':'PASS','observed':str(error)})
 else:raise AssertionError('Production policy was weakened')
 original=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-r8-frozen-ci-20261123/build-test/macos-job-137425839467.original.log')
 log=original.read_bytes()
 report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'read_regular_source_sha256':hashlib.sha256(function(source,'read_regular').encode()).hexdigest(),'unchanged_functions':unchanged,'workflow_sha256':hashlib.sha256(workflow.encode()).hexdigest(),'original_macos_log':str(original),'original_macos_log_sha256':hashlib.sha256(log).hexdigest(),'original_INPUT_PARENT_SYMLINK_count':log.count(b'INPUT_PARENT_SYMLINK'),'workflow_shell_prefix':snippet,'causal_controls':rows,'actual_platform':sys.platform,'macos_rerun':False,'provider_calls':0,'compiler_calls':0}
 (evidence/'canonical-temp-root-control.original.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))

