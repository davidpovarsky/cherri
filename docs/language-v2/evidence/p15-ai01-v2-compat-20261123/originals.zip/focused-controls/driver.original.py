import pathlib,json,subprocess,hashlib,datetime,time,sys,re
root=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-505-refresh-20261123')
out=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-ai01-compat-20261123/focused-controls-initial')
out.mkdir(mode=0o700,exist_ok=False)
paths=['.github/workflows/build-test.yml','tools/language-ai-eval/fresh-instance-protocol-v2.md']+[str(p.relative_to(root)) for p in sorted((root/'tools/language-ai-eval').glob('*.py'))]+['tools/language-ai-eval/tasks.json','tests/language-v2/acceptance-contract.json','tests/language-v2/repair-regression-plan.json','tests/language-v2/backend-recovery-gates.json']
def bindings():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in paths}
before=bindings()
command=[sys.executable,'-B','-m','unittest','-v','test_evaluation_bundle','test_anthropic_adapter','test_evaluation_intake','test_graph_validator','test_sealed_runner']
plan={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip(),'command':command,'cwd':str(root/'tools/language-ai-eval'),'timeout_seconds':150,'source_sha256':before,'provider_calls_allowed':False,'compiler_execution_allowed':False,'scope':'affected five Python modules; historical runner module unchanged and not repeated'}
(out/'plan.original.json').write_text(json.dumps(plan,indent=2)+'\n')
(out/'source.diff.original.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
start=time.monotonic();timed_out=False
with (out/'stdout.original.log').open('wb') as stdout,(out/'stderr.original.log').open('wb') as stderr:
 try:p=subprocess.run(command,cwd=root/'tools/language-ai-eval',stdout=stdout,stderr=stderr,timeout=150,check=False)
 except subprocess.TimeoutExpired:timed_out=True;p=None
after=bindings();raw=(out/'stderr.original.log').read_text();m=re.search(r'Ran (\d+) tests in ([0-9.]+)s',raw)
receipt={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-start,6),'returncode':None if p is None else p.returncode,'timed_out':timed_out,'source_unchanged':before==after,'test_parents':int(m.group(1)) if m else None,'unittest_seconds':float(m.group(2)) if m else None,'stdout_sha256':hashlib.sha256((out/'stdout.original.log').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/'stderr.original.log').read_bytes()).hexdigest(),'stderr_bytes':len((out/'stderr.original.log').read_bytes())}
(out/'receipt.original.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'evidence':str(out),**receipt}))
print(raw[-9000:])

