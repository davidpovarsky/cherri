from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,sys,zipfile
root=Path(r'C:\Users\DAVID\Code\cherri-p10r15-publication-k11-20261123\attempt-02')
evidence=root/'evidence';incoming=root/'incoming'
repo=Path(r'C:\Users\DAVID\Code\cherri-p10r15-publication-k10-20261123\repo.git')
primary=Path(r'C:\Users\DAVID\Code\cherri')
git=r'C:\Program Files\Git\cmd\git.exe';gh=r'C:\Program Files\GitHub CLI\gh.exe'
scp=r'C:\WINDOWS\System32\OpenSSH\scp.exe'
k8='2c54ebd50fa30597cbdd6337e6ecc6b65274a903'
base='4feadab9db4d351628f78593304373631693869a'
source='9b4135e705b08f765b7304e01212d3b9658806fb';tree='d3688f219f7454e80778cbcb3013967b6d339aad'
ref='refs/heads/agent/cherri-p10r15-k11-verification-20261123';prior_ref='refs/heads/agent/cherri-p10r15-k10-verification-20261123'
canonical='https://github.com/davidpovarsky/cherri.git'
remote_dir='/mnt/development/projects/evidence/cherri-p10r15-k11-frozen-ci-20261123/publication'
bundle=incoming/'cherri-k11.bundle';handoff=incoming/'bundle-handoff.json'
bundle_sha='2b7523dba10e8c4a3043b89e28404282259b366ab4fe1fe7b98d2db7bd42e319';handoff_sha='1efd864efd077cfe8655ea705535627d44e89a813f9e7c4a1a0a31c35a726a65'
safe_names=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','USERPROFILE','HOMEDRIVE','HOMEPATH','PATH','TEMP','TMP','APPDATA','LOCALAPPDATA','ProgramData','ALLUSERSPROFILE','ProgramFiles','ProgramFiles(x86)')
env={n:os.environ[n] for n in safe_names if n in os.environ}
env.update(GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',GH_PROMPT_DISABLED='1')
env['PATH']=r'C:\Program Files\GitHub CLI'+os.pathsep+env.get('PATH','')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write_new(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
assert not bundle.exists() and not handoff.exists()
assert repo.is_dir() and not (repo/'objects/info/alternates').exists()
incoming.mkdir(exist_ok=False)
start={'operation':'EXACT_K11_CREATE_ONLY_PUBLICATION','startedAtUtc':now(),'sourceCommit':source,'sourceTree':tree,'ref':ref,'bundleSHA256':bundle_sha,'bundleBytes':312997,'prerequisites':[base],'repo':str(repo),'destinationMustBeAbsent':True,'pushAttemptLimit':1,'primaryMutationAuthorized':False}
write_new(evidence/'publication.start.json',start)
write_new(evidence/'preflight-reconciliation.original.json',{'observedAtUtc':now(),'priorResultSHA256':'33ca5bfebf8c1df31f80258e32883c910e9bf0eea172f1cb8bc921158070603f','priorPushAttempted':False,'priorIncomingFiles':[],'correction':'Include exact pre-existing K10 remote-tracking ref; preserve observed primary untracked test fixture by exact hash and before/after status instead of assuming a clean primary. No primary file is edited or transferred.','fixtureModifiedUTC':'2026-11-10T09:51:17.884655+00:00','totalAllowedPushAttempts':1})
steps=[];attempted=False;push_result=None;result=dict(start);publication_error=None
def run(name,argv,timeout=30,allowed=(0,),cwd=None):
    op=evidence/(name+'.stdout.original');ep=evidence/(name+'.stderr.original')
    started=now();tick=time.monotonic();timed=False;killcode=None
    with op.open('xb') as of,ep.open('xb') as ef:
        p=subprocess.Popen(argv,cwd=cwd,stdout=of,stderr=ef,env=env,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        try:rc=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed=True
            killed=subprocess.run(['taskkill.exe','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env,timeout=15)
            killcode=killed.returncode
            try:rc=p.wait(timeout=10)
            except subprocess.TimeoutExpired:rc=None
        of.flush();ef.flush();os.fsync(of.fileno());os.fsync(ef.fileno())
    row={'name':name,'argv':argv,'cwd':str(cwd) if cwd else None,'startedAtUtc':started,'finishedAtUtc':now(),'seconds':round(time.monotonic()-tick,3),'exitCode':rc,'timeoutSeconds':timeout,'timedOut':timed,'ownedTreeKillExit':killcode,'stdoutSHA256':sha(op),'stderrSHA256':sha(ep),'stdoutBytes':op.stat().st_size,'stderrBytes':ep.stat().st_size}
    steps.append(row);write_new(evidence/(name+'.receipt.json'),row)
    if allowed is not None and (timed or rc not in allowed):raise RuntimeError(name+' failed; exit='+str(rc)+' timeout='+str(timed))
    return {'code':rc,'stdout':op.read_text(encoding='utf-8',errors='replace').strip(),'timedOut':timed}
try:
    origin=run('01-origin',[git,'-C',str(repo),'remote','get-url','origin'])['stdout']
    refs=run('02-base-refs',[git,'-C',str(repo),'for-each-ref','--format=%(refname) %(objectname)'])['stdout'].splitlines()
    assert origin==canonical and set(refs)=={'refs/preparation/k8 '+k8,prior_ref+' '+base,'refs/remotes/origin/agent/cherri-p10r15-k10-verification-20261123 '+base}
    assert (repo/'shallow').read_text().splitlines()==[k8]
    primary_before={'head':run('03-primary-head-before',[git,'-C',str(primary),'rev-parse','HEAD'])['stdout'],'status':run('04-primary-status-before',[git,'-C',str(primary),'status','--porcelain=v1'])['stdout']}
    primary_before['preservedFixtureSHA256']=sha(primary/'tests/decomp-me.cherri')
    assert primary_before=={'head':'3fdf58c53f9a5acbe09cfbc58ad5770701d5bb3b','status':'?? tests/decomp-me.cherri','preservedFixtureSHA256':'8df55a3ffdd76ca7fa9b360e0e7ec8c2d88bf7d807141517ad05a759c1212503'}
    run('05-transfer',[scp,'-B','-o','BatchMode=yes','-o','ConnectTimeout=12','torah-dev:'+remote_dir+'/cherri-k11.bundle','torah-dev:'+remote_dir+'/bundle-handoff.json','.'],120,cwd=incoming)
    assert bundle.stat().st_size==312997 and sha(bundle)==bundle_sha
    assert handoff.stat().st_size==833 and sha(handoff)==handoff_sha
    h=json.loads(handoff.read_text())
    assert h['sourceCommit']==source and h['sourceTree']==tree and h['ref']==ref and h['prerequisites']==[base] and h['advertisedHeads']==[source+' '+ref] and h['destinationMustBeAbsent'] is True
    with bundle.open('rb') as f:
        version=f.readline().rstrip(b'\r\n')
        assert version in (b'# v2 git bundle',b'# v3 git bundle')
        prereq=[];heads=[];caps=[]
        while True:
            line=f.readline()
            if line in (b'\n',b'\r\n'):break
            if not line:raise RuntimeError('Unterminated bundle header')
            line=line.rstrip(b'\r\n')
            if line.startswith(b'-'):prereq.append(line[1:].split(b' ',1)[0].decode('ascii'))
            elif line.startswith(b'@'):caps.append(line.decode('ascii'))
            else:heads.append(line.decode('utf-8').split(' ',1))
    assert prereq==[base] and heads==[[source,ref]]
    assert all(c=='@object-format=sha1' for c in caps)
    assert run('06-bundle-heads',[git,'-C',str(repo),'bundle','list-heads',str(bundle)])['stdout']==source+' '+ref
    run('07-bundle-verify',[git,'-C',str(repo),'bundle','verify',str(bundle)])
    run('08-import',[git,'-C',str(repo),'fetch','--no-tags','--no-recurse-submodules',str(bundle),ref+':'+ref],60)
    actual=run('09-commit',[git,'-C',str(repo),'rev-parse',ref])['stdout']
    actual_tree=run('10-tree',[git,'-C',str(repo),'rev-parse',ref+'^{tree}'])['stdout']
    assert actual==source and actual_tree==tree
    run('11-ancestry',[git,'-C',str(repo),'merge-base','--is-ancestor',base,source])
    run('12-connectivity',[git,'-C',str(repo),'fsck','--connectivity-only','--no-reflogs',ref],60)
    actual_refs=run('13-imported-refs',[git,'-C',str(repo),'for-each-ref','--format=%(refname) %(objectname)'])['stdout'].splitlines()
    assert set(actual_refs)=={ref+' '+source,prior_ref+' '+base,'refs/preparation/k8 '+k8,'refs/remotes/origin/agent/cherri-p10r15-k10-verification-20261123 '+base}
    before=run('14-remote-before',[git,'-C',str(repo),'ls-remote','--exit-code','--refs','origin',ref],30,allowed=(0,2))
    assert before['code']==2 and before['stdout']=='','Remote destination not absent; do not push'
    validation={'validatedAtUtc':now(),'bundleSHA256':sha(bundle),'bundleBytes':bundle.stat().st_size,'handoffSHA256':sha(handoff),'prerequisites':prereq,'heads':heads,'importedCommit':actual,'importedTree':actual_tree,'remoteRefAbsent':True,'localRefs':actual_refs,'primaryBefore':primary_before}
    write_new(evidence/'publication.validation.json',validation);result['validation']=validation
    push_argv=[git,'-C',str(repo),'push','--porcelain','--force-with-lease='+ref+':','origin',source+':'+ref]
    write_new(evidence/'publication.push-attempt.json',{'startedAtUtc':now(),'argv':push_argv,'attemptNumber':1,'allowedAttempts':1,'expectedRemoteValue':'ABSENT'})
    attempted=True
    push_result=run('15-push',push_argv,120,allowed=None)
    result['pushExitCode']=push_result['code'];result['pushTimedOut']=push_result['timedOut']
except Exception as error:
    publication_error=type(error).__name__+': '+str(error)
result['pushAttempted']=attempted
if attempted:
    try:
        after=run('16-remote-after',[git,'-C',str(repo),'ls-remote','--exit-code','--refs','origin',ref],30,allowed=(0,2))
        result['remoteRefReadback']=after
        assert after['code']==0 and after['stdout'].split()==[source,ref]
        remote_ref=json.loads(run('17-api-ref',[gh,'api','-H','Cache-Control: no-cache','repos/davidpovarsky/cherri/git/ref/heads/'+ref[len('refs/heads/'):],'--jq','{ref: .ref, sha: .object.sha, type: .object.type}'])['stdout'])
        remote_commit=json.loads(run('18-api-commit',[gh,'api','-H','Cache-Control: no-cache','repos/davidpovarsky/cherri/git/commits/'+source,'--jq','{sha: .sha, tree: .tree.sha, parents: [.parents[].sha]}'])['stdout'])
        assert remote_ref=={'ref':ref,'sha':source,'type':'commit'}
        assert remote_commit['sha']==source and remote_commit['tree']==tree
        result['remoteBinding']={'ref':remote_ref,'commit':remote_commit,'verifiedAtUtc':now()}
        result['status']='PUBLISHED_REMOTE_VERIFIED' if push_result and push_result['code']==0 and not push_result['timedOut'] else 'PUBLISHED_REMOTE_VERIFIED_WITH_TRANSPORT_ERROR'
    except Exception as error:
        result['status']='PUSH_ATTEMPTED_REMOTE_OUTCOME_UNVERIFIED'
        result['remoteVerificationError']=type(error).__name__+': '+str(error)
else:result['status']='FAILED_BEFORE_PUSH'
if publication_error:result['error']=publication_error
try:
    result['primaryAfter']={'head':run('19-primary-head-after',[git,'-C',str(primary),'rev-parse','HEAD'])['stdout'],'status':run('20-primary-status-after',[git,'-C',str(primary),'status','--porcelain=v1'])['stdout']}
    result['primaryAfter']['preservedFixtureSHA256']=sha(primary/'tests/decomp-me.cherri')
    result['primaryUnchanged']=result['primaryAfter']==primary_before
except Exception as error:result['primaryReadbackError']=type(error).__name__
result['steps']=steps;result['finishedAtUtc']=now();result['liveRemoteBuilderTouched']=False;result['actionsDispatches']=0
write_new(evidence/'publication.result.json',result)
with zipfile.ZipFile(evidence/'publication.originals.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(evidence.iterdir()):
        if p.is_file() and p.name!='publication.originals.zip':z.write(p,p.name)
summary={'status':result['status'],'sourceCommit':source,'sourceTree':tree,'ref':ref,'pushAttempted':attempted,'pushExitCode':result.get('pushExitCode'),'remoteVerified':'remoteBinding' in result,'resultPath':str(evidence/'publication.result.json'),'resultSHA256':sha(evidence/'publication.result.json'),'archiveSHA256':sha(evidence/'publication.originals.zip'),'archiveBytes':(evidence/'publication.originals.zip').stat().st_size,'primaryUnchanged':result.get('primaryUnchanged'),'error':result.get('error'),'remoteVerificationError':result.get('remoteVerificationError')}
write_new(evidence/'publication.summary.json',summary)
print(json.dumps(summary),flush=True)
sys.exit(0 if result['status'].startswith('PUBLISHED_REMOTE_VERIFIED') and result.get('primaryUnchanged') else 1)
