import pathlib,json,hashlib,subprocess,zipfile,re,datetime
repo=pathlib.Path("/mnt/development/projects/worktrees/cherri-p10r15-505-refresh-20261123")
root=pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-rp50-discovery-repair-20261123")
source="9a9e44798fde521b4869497166969728dedb5e0e"
assert subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()==source
assert not subprocess.check_output(["git","-C",str(repo),"status","--porcelain"])
checks=[]
def check(name,value):
    checks.append({"check":name,"pass":bool(value)})
    assert value,name
def sha(b):return hashlib.sha256(b).hexdigest()
result=json.loads((root/"focused-attempt-02/result.original.json").read_text())
first=json.loads((root/"focused-attempt-01/result.original.json").read_text())
check("actual second parent succeeded on clean exact source",result["passed"] and result["source_sha"]==source and result["source_clean_after"] and result["source_bytes_unchanged"])
check("one parent and nine existing corruption controls",len(result["passed_parents"])==1 and len(result["passed_subcases"])==9 and not result["failures_or_skips"])
for name,meta in result["streams"].items():
    b=(root/"focused-attempt-02"/name).read_bytes()
    check("outer original "+name,len(b)==meta["bytes"] and sha(b)==meta["sha256"])
base=root/"focused-attempt-02/original-control-artifacts/rp50-control"
control=json.loads((base/"original-control-records.json").read_text())
check("partial RP50 and unmeasured AI01 retained",control["results"]["RP50"]["status"]=="PENDING_EXTERNAL" and control["results"]["AI01"]["status"]=="AI_EVAL_NOT_RUN" and control["ai_quality_measured"] is False)
record=control["records"][0]
check("detail contains actual producer identity",record["result"]=="passed" and "TestP15RP50AIHarnessControlFlow" in record["detail"])
check("only control tier claimed",record["tier"]=="harness-unit" and record["assertions"]["ai_quality_measured"]=="false" and record["assertions"]["external_evaluation"]=="AI_EVAL_NOT_RUN")
for artifact in record["artifacts"]:
    check("original artifact "+pathlib.Path(artifact["path"]).name,sha(pathlib.Path(artifact["path"]).read_bytes())==artifact["sha256"])
process_path=next(base.rglob("ai-harness-process.json"));process=json.loads(process_path.read_text())
check("child completed cleanly within original bound",process["source_commit"]==source and process["source_clean_before"] and process["source_clean_after"] and process["exit_code"]==0 and not process["timed_out"] and process["elapsed_seconds"]<240)
check("required and discovered child identity exact",process["required_tests"]==process["discovered_tests"]==["TestP15RP50AIHarnessControlFlow"])
check("forty-eight reviewed source bindings",len(process["source_files"])==48)
for binding in process["source_files"]:
    raw=subprocess.check_output(["git","-C",str(repo),"show",source+":"+binding["path"]])
    check("source binding "+binding["path"],sha(raw)==binding["sha256"])
go=next(base.rglob("ai-harness-go.jsonl")).read_bytes()
events=[json.loads(s) for s in go.splitlines()]
test="TestP15RP50AIHarnessControlFlow"
check("one child start and one child pass",sum(e.get("Test")==test and e.get("Action")=="run" for e in events)==1 and sum(e.get("Test")==test and e.get("Action")=="pass" for e in events)==1)
marker="P15_RP50_HARNESS_CONTROL_DISCOVERY:"
lines="".join(e.get("Output","") for e in events if e.get("Test")==test).splitlines()
reports=[json.loads(s.split(marker,1)[1]) for s in lines if marker in s]
check("one original Python discovery receipt",len(reports)==1)
d=reports[0];required=record["assertions"]["required_python_tests"].splitlines()
check("complete original fifteen Python discoveries and passes",d["selection_complete"] and d["found"]==d["passed"]==required and d["tests_run"]==15 and all(d[k]==0 for k in ("failures","errors","skipped","expected_failures","unexpected_successes")))
check("original return-time lock assertion executed","test_runner.EvaluationHarnessTests.test_timeout_stops_a_spawned_worker" in d["passed"])
check("first failed replay preserved",not first["passed"] and first["source_sha"]=="c331645657768f08e7854e7f4f8f0eb7ea8ce489" and "TestAIBoundHarnessDetailRequiresObservedEvents" in first["passed_parents"])
boundaries=json.loads((root/"cleanup-preserved-boundaries.json").read_text())
for name,digest in boundaries["unchanged_files_sha256"].items():
    check("preserved boundary "+name,sha((repo/name).read_bytes())==digest)
offline=json.loads((root/"cleanup-controls-working-source/result.original.json").read_text())
check("five controls preserve working-source provenance",offline["exit_code"]==0 and not offline["source_tree_clean"] and offline["source_unchanged"])
for name,digest in offline["source_sha256"].items():
    check("offline tested bytes match commit "+name,sha((repo/name).read_bytes())==digest)
audit={"schema":"rp50-discovery-repair-independent-intake/v1","observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
       "implementation_source":source,"second_replay_seconds":result["elapsed_seconds"],"first_replay_seconds":first["elapsed_seconds"],
       "python_parents":15,"original_go_parent":test,"corruption_subcases":9,"new_extraction_controls_reused":3,
       "new_cleanup_control_parents":5,"checks":checks,"passed":True,"provider_requests":0,"actual_model_quality_measured":False,
       "full_supplemental_parent_rerun":False,"native_or_apple_runtime_claim":False}
audit_bytes=(json.dumps(audit,indent=2,sort_keys=True)+"\n").encode()
(root/"independent-intake.original.json").write_bytes(audit_bytes)
public=repo/"docs/language-v2/evidence/p15-rp50-discovery-cleanup-20261123"
public.mkdir(parents=True,exist_ok=False)
rows=[]
for p in sorted(root.rglob("*")):
    if not p.is_file():continue
    b=p.read_bytes()
    assert len(b)<2000000
    assert not re.search(rb"sk-ant-[A-Za-z0-9_-]{20,}",b),"credential-shaped bytes"
    rows.append({"path":str(p.relative_to(root)),"bytes":len(b),"sha256":sha(b)})
with zipfile.ZipFile(public/"originals.zip","w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for row in rows:z.write(root/row["path"],row["path"])
with zipfile.ZipFile(public/"originals.zip") as z:
    assert len(z.namelist())==len(rows)
    assert all(sha(z.read(row["path"]))==row["sha256"] for row in rows)
manifest={"schema":"rp50-discovery-cleanup-originals/v1","implementation_source":source,
          "original_failure_source":"2c54ebd50fa30597cbdd6337e6ecc6b65274a903",
          "first_replay_source":"c331645657768f08e7854e7f4f8f0eb7ea8ce489","zip_sha256":sha((public/"originals.zip").read_bytes()),
          "members":rows,"all_archived_original_bytes_verified":True,"private_corpus_files_included":False,
          "provider_credentials_included":False,"provider_requests":0}
(public/"original-manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
(public/"independent-intake.json").write_bytes(audit_bytes)
readme="""# RP50 discovery detail and cancellation evidence

The actual focused RP50 producer passed at clean source
`9a9e44798fde521b4869497166969728dedb5e0e` in **34.136746 seconds**.
Its original Go child actually discovered and passed all **15 original Python
controls**, including the unchanged assertion that a timed-out descendant's
process lock is already released at return. The narrow parent and its **9
existing corruption subcases** passed. RP50 still reports `PENDING_EXTERNAL`;
AI01 remains `AI_EVAL_NOT_RUN`. No provider, seed or model-quality measurement
is claimed.

## Original failures remain visible

K8 Linux job137425839599 failed the generic supplemental assertion because
RP50's Detail omitted `TestP15RP50AIHarnessControlFlow`, although the exact
Go child and all15 Python controls had passed. The original10MB CI log remains
at its recorded server path, SHA256
`f7a60ff605f70704845cddd7aa3aa7651241e96e25f3a07a4d831a49d88cd459`.
This packet includes its precise intake receipt, not a relabeled CI success.

Commit `c331645657768f08e7854e7f4f8f0eb7ea8ce489` derives Detail from actual
pass identities extracted only after strict validation of the original Go
JSONL and Python discovery receipt. It does not populate a claimed test list.
The new extraction parent and3 causal controls passed, including exclusion
of an invented identity in free-form output.

The first actual narrow replay then failed in **26.422059 seconds**:14 of15
Python controls passed. The original timeout test saw the worker lock still
held at return, then an absent worker and a released lock. POSIX group SIGKILL
delivery is asynchronous; waiting only for the direct child did not establish
that its descendants had finished. The complete failure, raw streams and
source witnesses remain unchanged in `focused-attempt-01`.

## Production repair and retained boundaries

Commit `9a9e44798fde521b4869497166969728dedb5e0e` adds an actual process-group
quiescence barrier after cancellation. Direct-child waiting and observation
share a five-second cleanup bound, each observer at most one second. The
original request timeout is unchanged. Observations contain only PGID/state
from portable `ps -A -o pgid=,stat=`; no process arguments, environment values,
credential or arbitrary diagnostic is collected or published.

The barrier waits for observed nonexecution. It adds no grace sleep or
adapter/test retry. True zombies have terminated, while Linux's `Zl` case
with remaining live threads stays active. Uncertain, malformed, failed or
over-budget observation fails closed. Only established quiescence permits the
original TimeoutExpired to be raised. Other cleanup failure retains streams
and yields a distinct safe failure. Windows cancellation behavior is unchanged.

Five new focused offline controls passed in **0.281771 seconds**. Their
receipt explicitly records working-source status; the tested bytes were
verified against the subsequent commit, not restamped as a clean execution.
They occupy a separate new test file, preserving RP50's fixed15 inventory.

The original `test_runner.py`, all15 methods and their timeout/lock assertions,
generic supplemental test, strict Go-event parser, three immutable179
contracts, model settings and provider deadlines are unchanged. The Go source
witness additively binds the new control file.

## Actual second replay and independent verification

`focused-attempt-02` contains the clean-source command, outer streams, actual
child process receipt, all48 source bindings, original child JSONL and sole
Python discovery receipt, plus the RP50 record. Independent mechanical
verification checked CHECK_COUNT conditions without rerunning the child,
compiler, provider or full supplemental parent. Every archive member was
checked byte-for-byte after ZIP creation.

The outer command selected only
`TestAIEvaluationHarnessEvidenceRetainsExternalRequirement`; its original
child kept the three-minute Go timeout and original Python bounds. All9
existing corruption cases passed. The Detail contains the observed child
identity and satisfies the unchanged generic assertion. The next full CI
will exercise the complete supplemental parent; no extra231-second parent
replay is claimed here.

`original-manifest.json` binds every archived original by size and SHA256.
The packet contains public harness/source evidence, no private corpus or live
outcome. An initial mechanical intake script used the wrong casing for the
JSON `status` key and stopped before writing proof; its diagnostic is
retained separately. Correcting that reader did not rerun or alter the tests.

Because `runner.py` is a v2 producer dependency, the final implementation
requires a new final-source public calibration and seal before live evaluation.
The historical752 calibration and original packets remain untouched.

## Primary process-state references

- Apple ps options, header suppression and state definitions:
  https://github.com/apple-oss-distributions/adv_cmds/blob/main/ps/ps.1
- Procps live-thread zombie-leader exception:
  https://gitlab.com/procps-ng/procps/-/merge_requests/306
""".replace("CHECK_COUNT",str(len(checks)))
(public/"README.md").write_text(readme)
print(json.dumps({"packet":str(public),"members":len(rows),"checks":len(checks),"zip_sha256":manifest["zip_sha256"],
                 "manifest_sha256":sha((public/"original-manifest.json").read_bytes()),
                 "intake_sha256":sha(audit_bytes),"child_process_sha256":sha(process_path.read_bytes())}))
