#!/usr/bin/env python3
import datetime, hashlib, json, os, pathlib, subprocess, time
ROOT = pathlib.Path("/mnt/development/projects/worktrees/cherri-p10r15-505-refresh-20261123")
SOURCE = "c331645657768f08e7854e7f4f8f0eb7ea8ce489"
OUT = pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-rp50-discovery-repair-20261123/focused-attempt-01")
EXPECTED = ["TestAIBoundHarnessDetailRequiresObservedEvents", "TestAIEvaluationHarnessEvidenceRetainsExternalRequirement"]
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(["git", "-C", str(ROOT), *a], text=True).strip()
def write(name, data):
    (OUT/name).write_text(json.dumps(data, sort_keys=True, indent=2)+"\n")
assert git("rev-parse","HEAD") == SOURCE and not git("status","--porcelain")
OUT.mkdir(mode=0o700, exist_ok=False)
(OUT/"original-control-artifacts").mkdir(mode=0o700)
environment = {key: os.environ[key] for key in ("PATH","HOME","USER","LOGNAME","SHELL") if key in os.environ}
environment.update({
    "LANG":"C.UTF-8", "LC_ALL":"C.UTF-8", "GOTOOLCHAIN":"go1.24.13",
    "GOMODCACHE":"/mnt/development/tooling/cherri-go/mod",
    "GOCACHE":"/mnt/development/tooling/cherri-go/build",
    "GOTMPDIR":"/mnt/development/tooling/cherri-go/tmp",
    "TMPDIR":"/mnt/development/tooling/cherri-go/tmp",
    "CHERRI_AI_EVAL_ALLOW_GENERATION":"0",
    "CHERRI_AI_ACCEPTANCE_EVIDENCE_OUTPUT":str(OUT/"original-control-artifacts"),
})
command = ["go","test","-count=1","-json","-timeout=6m","./tools/language-acceptance","-run","^("+"|".join(EXPECTED)+")$"]
tracked = ["tools/language-acceptance/"+n for n in ("ai_evaluation_execution_test.go","ai_measurement_execution.go","ai_measurement_execution_test.go","supplemental_execution_test.go","strict_go_events.go")]
tracked += ["tests/language-v2/"+n for n in ("acceptance-contract.json","repair-regression-plan.json","backend-recovery-gates.json")]
before = {name:digest(ROOT/name) for name in tracked}
start = {"source_sha":SOURCE,"source_clean_before":True,"command":command,"cwd":str(ROOT),"started_utc":utc(),
    "source_sha256":before,"expected_parents":EXPECTED,"outer_supervisor_seconds":390,
    "actual_source_bound_child_deadlines_unchanged":True,"provider_requests":0,"real_evaluation_seed_created":False,
    "go_version":subprocess.check_output(["go","version"],env=environment,text=True).strip(),
    "cache_environment":{k:environment[k] for k in ("GOTOOLCHAIN","GOMODCACHE","GOCACHE","GOTMPDIR","TMPDIR")}}
write("start.original.json",start)
started=time.monotonic()
timed_out=False
with (OUT/"go.stdout.original.jsonl").open("wb") as stdout, (OUT/"go.stderr.original.log").open("wb") as stderr:
    try:
        process = subprocess.run(command,cwd=ROOT,env=environment,stdout=stdout,stderr=stderr,timeout=390,check=False,start_new_session=True)
        exit_code=process.returncode
    except subprocess.TimeoutExpired:
        timed_out=True
        exit_code=124
elapsed=time.monotonic()-started
events=[json.loads(line) for line in (OUT/"go.stdout.original.jsonl").read_bytes().splitlines() if line.strip()]
passes=[e["Test"] for e in events if e.get("Action")=="pass" and e.get("Test")]
failures=[e.get("Test","<package>") for e in events if e.get("Action") in ("fail","skip")]
after={name:digest(ROOT/name) for name in tracked}
status=git("status","--porcelain")
result={"source_sha":SOURCE,"finished_utc":utc(),"elapsed_seconds":round(elapsed,6),"exit_code":exit_code,
        "timed_out":timed_out,"passed_parents":[n for n in EXPECTED if n in passes],
        "passed_subcases":[n for n in passes if "/" in n],"failures_or_skips":failures,
        "source_head_after":git("rev-parse","HEAD"),"source_clean_after":not status,
        "source_bytes_unchanged":before==after,"streams":{name:{"bytes":(OUT/name).stat().st_size,"sha256":digest(OUT/name)} for name in ("go.stdout.original.jsonl","go.stderr.original.log")},
        "provider_requests":0,"actual_quality_measurement":False}
result["passed"]=exit_code==0 and not timed_out and not failures and result["passed_parents"]==EXPECTED and not status and before==after and result["source_head_after"]==SOURCE
write("result.original.json",result)
print(json.dumps(result,sort_keys=True))
raise SystemExit(0 if result["passed"] else 1)
