from pathlib import Path
import subprocess,json,os,time,hashlib,signal,shutil,sys
root=Path('/home/chatgpt-agent/workspaces/cherri-p10r15-local-scenarios-20261119')
out=Path('/home/chatgpt-agent/workspaces/cherri-p10r15-local-scenarios-evidence-20261119')
out.mkdir(exist_ok=True)
go='/home/chatgpt-agent/workspaces/cherri-remote/tools/go/bin/go'
env=os.environ.copy()
env.update(GOMAXPROCS='1',GOFLAGS='-p=1',PATH=str(Path(go).parent)+os.pathsep+env['PATH'])
gate=sys.argv[1]
if gate=='root':
 args=[go,'test','-p=1','-count=1','-json','-timeout=6m','-run','^(TestP15RP05LiteralPublicRoutes|TestP15RP09StaticVariantNativeDifferential|TestP15CanonicalCallbackCausality|TestP15RP32SevenTriggerMigrationAndNativeRoundTrip|TestP15RP30HeaderAbsenceAndNameRoundTrip)$','.']
 deadline=420
elif gate=='producer':
 args=[go,'test','-p=1','-count=1','-json','-timeout=10m','-run','^(TestSupplementalLocalContractsProductionEvidence|TestSupplementalProduction.*)$','./tools/language-acceptance']
 deadline=660
else: raise RuntimeError(gate)
prefix=sys.argv[2]
log=out/(prefix+'-'+gate+'.jsonl')
receipt=out/(prefix+'-'+gate+'-summary.json')
assert not log.exists() and not receipt.exists()
before=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert before=='',before
start=time.time()
print(json.dumps({'event':'start','head':head,'command':args,'free_bytes':shutil.disk_usage(root).free,'log':str(log)}),flush=True)
with log.open('wb') as f:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try: code=p.wait(timeout=deadline); timed=False
 except subprocess.TimeoutExpired:
  timed=True; os.killpg(p.pid,signal.SIGTERM)
  try: code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL); code=p.wait(timeout=5)
raw=log.read_bytes(); actions={}; failed=[]; skipped=[]; bad=[]; events=[]
for i,line in enumerate(raw.splitlines(),1):
 try: e=json.loads(line); events.append(e)
 except Exception: bad.append({'line':i,'text':line.decode('utf-8','replace')}); continue
 if e.get('Test') and e.get('Action') in ('pass','fail','skip'):
  actions[e['Action']]=actions.get(e['Action'],0)+1
  if e['Action']=='fail': failed.append(e['Test'])
  if e['Action']=='skip': skipped.append(e['Test'])
after=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
result={'source_sha':head,'source_clean_before':not before,'source_clean_after':not after,'command':args,'exit_code':code,'timed_out':timed,'seconds':round(time.time()-start,3),'named_tests':actions,'failed':failed,'skipped':skipped,'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest(),'invalid_json':bad,'free_bytes_after':shutil.disk_usage(root).free}
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
if code:
 for e in events:
  if e.get('Output') and (not e.get('Test') or any(e['Test'].startswith(n) or n.startswith(e['Test']) for n in failed)): print(e['Output'],end='')
sys.exit(code if code>=0 else 1)
