import pathlib,json,subprocess,hashlib,re,datetime,collections
w=pathlib.Path(r'C:\Users\DAVID\Code\cherri-p10r15-upstream-boundary-20261120')
e=pathlib.Path(r'C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r4-u01')
source='6bdddd6d5ea3012b806ae82239cd7a7fe49e2138'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args,input=None):
 r=subprocess.run(['git',*args],cwd=w,input=input,capture_output=True,check=True);return r.stdout
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def events(p):return [json.loads(s) for s in p.read_bytes().splitlines() if s]
def marker(ev,test,name):
 text=''.join(v.get('Output','') for v in ev if v.get('Test')==test)
 found=[json.loads(line.split(name,1)[1].strip()) for line in text.splitlines() if name in line]
 assert len(found)==1,(test,len(found));return found[0]
def inspect(p,expected_sha,expected_count):
 proc=load(p/'process-original.json'); raw=(p/'stdout-original.jsonl').read_bytes(); ev=events(p/'stdout-original.jsonl')
 assert proc['source_sha']==expected_sha==proc['source_sha_after'] and proc['source_clean_before'] and proc['source_clean_after']
 assert proc['exit_code']==0 and proc['raw_sha256']==sha(raw) and proc['raw_bytes']==len(raw)
 passed=[x['Test'] for x in ev if x.get('Action')=='pass' and x.get('Test')]
 assert len(passed)==expected_count==len(set(passed))==proc['named_passes']
 assert not [x for x in ev if x.get('Action') in ['fail','skip']]
 assert len([x for x in ev if x.get('Action')=='pass' and not x.get('Test')])==1
 return ev,{'source':expected_sha,'named_passes':len(passed),'raw_bytes':len(raw),'raw_sha256':sha(raw)}
component,component_summary=inspect(e/'component-dc32dbb6','dc32dbb68b34078cefd3941415febc0d468c5390',14)
outer,outer_summary=inspect(e/'producer-6bdddd6d',source,135)
receipt=marker(outer,'TestUpstreamBoundaryActualProductionEvidence','P15_U01_PRODUCTION_RECEIPT:')
assert receipt['source_sha']==source and len(receipt['records'])==1
report=receipt['report']
assert report['total_cases']==1 and report['passed_cases']==1 and report['failed_cases']==0 and report['skipped_cases']==0 and report['phase']=='local' and report['closure_complete'] is False
assert report['results'][0]['id']=='U01' and report['results'][0]['status']=='PASSED' and report['results'][0]['executed_levels']==['repository']
record=receipt['records'][0]
assert record['requirements']==['U01'] and record['tier']=='repository' and record['implementation_sha']==source and record['exit_code']==0 and record['result']=='passed'
assert record['test_id']=='github.com/electrikmilk/cherri:TestP15U01ActualDeclarationBoundary'
artifacts={}
for a in record['artifacts']:
 p=pathlib.Path(a['path']);assert p.is_relative_to(e);b=p.read_bytes();assert sha(b)==a['sha256'];artifacts[p.name]=p
assert set(artifacts)=={'u01-go.jsonl','u01-process.json','u01-stderr.log'}
child=load(artifacts['u01-process.json']);raw=artifacts['u01-go.jsonl'].read_bytes();stderr=artifacts['u01-stderr.log'].read_bytes()
assert child['format_version']==1 and child['requirement']=='U01' and child['source_commit']==source
assert child['source_clean_before'] and child['source_clean_after'] and child['exit_code']==0 and child['timed_out'] is False
assert child['command']==record['command'] and child['raw_sha256']==sha(raw) and child['raw_bytes']==len(raw)
assert child['stderr_sha256']==sha(stderr) and child['stderr_bytes']==len(stderr)==0
inner=events(artifacts['u01-go.jsonl'])
passed=[x['Test'] for x in inner if x.get('Action')=='pass' and x.get('Test')]
assert len(passed)==len(set(passed))==14 and set(passed)==set(child['required_tests'])==set(child['discovered_tests'])
assert not [x for x in inner if x.get('Action') in ['fail','skip']]
assert len([x for x in inner if x.get('Action')=='pass' and not x.get('Test')])==1
assert record['assertions']['required_go_events'].splitlines()==child['required_tests']
start=datetime.datetime.fromisoformat(child['started_utc'].replace('Z','+00:00'))
finish=datetime.datetime.fromisoformat(child['finished_utc'].replace('Z','+00:00'))
assert 0<(finish-start).total_seconds()<240 and abs((finish-start).total_seconds()-child['elapsed_seconds'])<0.05
for x in inner:
 if 'Time' in x:
  t=datetime.datetime.fromisoformat(x['Time'].replace('Z','+00:00'));assert start<=t<=finish
def batch(requests):
 raw=git('cat-file','--batch',input=('\n'.join(requests)+'\n').encode());result={};offset=0
 for request in requests:
  lineend=raw.index(b'\n',offset);header=raw[offset:lineend].split();assert len(header)==3 and header[1]==b'blob'
  size=int(header[2]);offset=lineend+1;data=raw[offset:offset+size];assert len(data)==size and raw[offset+size:offset+size+1]==b'\n'
  result[request]=data;offset+=size+1
 assert offset==len(raw);return result
producer=git('show',source+':tools/language-acceptance/upstream_boundary_execution.go').decode()
block=re.search(r'var upstreamBoundaryProductionPaths = \[\]string\{(.*?)\n\}',producer,re.S).group(1)
expected_paths=re.findall(r'"([^"]+)"',block)
assert len(expected_paths)==len(set(expected_paths))==50
sources=child['source_files'];assert len(sources)==50 and set(x['path'] for x in sources)==set(expected_paths)
source_blobs=batch([source+':'+p for p in expected_paths])
for x in sources:assert sha(source_blobs[source+':'+x['path']])==x['sha256']
manifest=json.loads(source_blobs[source+':docs/language-v2/upstream-preservation-boundary.json'])
baselines={'upstream':'a66db15b7f247f3121726c2a2b72becfeef3d96b','language':'559abceadda1dbf0cd7d7deb1a26315b8ac44c3f','continuation':'d7052f4568db26dba169bdefc72623e48c04968a','recorded_source':'8e66254d56ea3e4ac70f6cda6ef9d31217e0937c'}
assert manifest['baselines']==baselines and manifest['requirement_id']=='U01' and manifest['action_file_count']==25 and manifest['additional_preserved_file']=='stdfunc.cherri'
paths=sorted([x for x in git('ls-tree','-r','--name-only',source,'--','actions').decode().splitlines() if x.endswith('.cherri')]+['stdfunc.cherri'])
assert len(paths)==26 and set(paths)==set(x['path'] for x in manifest['files'])
historical=batch([commit+':'+p for commit in baselines.values() for p in paths])
allow={'actions/device.cherri':(b"text ?startTime: 'endTime'",b"text ?endTime: 'endTime'"),'actions/location.cherri':(b"text addressLine2: 'WFAddressLine1'",b"text addressLine1: 'WFAddressLine1'")}
counts=collections.Counter(); verified=[]
for entry in manifest['files']:
 p=entry['path'];current=source_blobs[source+':'+p]
 assert (w/p).read_bytes()==current==historical[baselines['recorded_source']+':'+p]
 assert set(entry['versions'])==set(baselines)
 for role,commit in baselines.items():
  b=historical[commit+':'+p];assert entry['versions'][role]=={'bytes':len(b),'sha256':sha(b)}
 old=historical[baselines['continuation']+':'+p]
 for role,key in [('upstream','upstream_identical'),('language','language_baseline_identical')]:
  same=current==historical[baselines[role]+':'+p];assert entry[key] is same
  if same:counts[role+'_identical']+=1
 if p in allow:
  before,after=allow[p];assert old.count(before)==1 and old.replace(before,after,1)==current
  assert entry['continuation_class']=='parameter-label-correction' and entry['implementation_commit']=='dc86a87de5cd6b2f2e795236ac1fa25e28853ade'
  assert entry['reviewed_patch']['before']==before.decode() and entry['reviewed_patch']['after']==after.decode()
  counts['reviewed_corrections']+=1
 else:
  assert current==old and entry['continuation_class']=='unchanged' and 'reviewed_patch' not in entry;counts['unchanged_since_continuation']+=1
 verified.append({'path':p,'bytes':len(current),'sha256':sha(current)})
observed=marker(inner,'TestP15U01ActualDeclarationBoundary','P15_U01_REPOSITORY_BOUNDARY:')
assert observed['source_sha']==source and observed['source_clean'] and observed['baselines']==baselines and observed['tracked_files']==manifest['files']
numstat=git('diff','--numstat',baselines['continuation'],source,'--','actions','stdfunc.cherri').decode()
assert numstat==observed['actual_numstat']=='1\t1\tactions/device.cherri\n1\t1\tactions/location.cherri\n'
contracts={'tests/language-v2/acceptance-contract.json':'9fdfa8910b09824dc61395d8ddf4aa8fe8914619af0fdde59c63b67ab10b895e','tests/language-v2/repair-regression-plan.json':'eba070df0e1ff229a94e52d977a09c2a0c125a31b1a69caf32787d41600074f5','tests/language-v2/backend-recovery-gates.json':'e7fbb3ad177c5142935f71a46ca7e89b84822061bfc0919eec59708811ab7e7c'}
for p,h in contracts.items(): assert sha(source_blobs[source+':'+p])==h,(p,sha(source_blobs[source+':'+p]))
assert git('rev-parse','HEAD').decode().strip()==source and git('status','--porcelain')==b''
result={'status':'VERIFIED_U01_COMPONENT_ONLY','audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha':source,'component':component_summary,'outer':outer_summary,'inner':{'named_passes':14,'raw_bytes':len(raw),'raw_sha256':sha(raw),'source_files_verified':50,'artifact_references_verified':3},'matrix':dict(counts),'declarations':verified,'local_report':report,'immutable_contracts':contracts,'closure_complete':False,'scope':'U01 repository-only actual component; no inherited B01/BRG01, native or final release credit.'}
out=e/'independent-audit-6bdddd6d.json';out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['declarations','local_report','immutable_contracts']},ensure_ascii=False))
