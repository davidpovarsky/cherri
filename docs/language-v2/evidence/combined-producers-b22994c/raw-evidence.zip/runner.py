import pathlib,subprocess,json,os,hashlib,time,datetime
base=pathlib.Path(r"C:\Users\DAVID\Code");primary=base/"cherri-p10r15-project-closure-20261118";repo=base/"cherri-p10r15-combined-check-b22994c"
source="b22994c88141f8a49e02ba687ef3e3615a58d28c"
out=base/"cherri-p10r15-evidence-20261119"/"combined-producers-b22994c";out.mkdir(exist_ok=True)
assert not repo.exists()
subprocess.run(["git","worktree","add","--detach",str(repo),source],cwd=primary,check=True,capture_output=True,text=True,timeout=45)
def snap():return {"source":subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip(),"status":subprocess.check_output(["git","status","--porcelain"],cwd=repo,text=True)}
before=snap();assert before=={"source":source,"status":""}
names=["TestFormatterProductionEvidence","TestFormatterEvidenceRejectsCrossTierAndTruncatedScenario","TestWorkspaceResourceProductionEvidence","TestWorkspaceEvidenceRejectsUnrelatedCommands","TestDeclarationTriggerProductionEvidence","TestSupplementalLocalContractsProductionEvidence","TestRequiredEncodingLocalScopeRemainsUnverified","TestRequiredEncodingMappingHasDedicatedProducerAndAssertions","TestRequiredEncodingIntakeRejectsIncompleteOrGenericEvidence","TestRequiredEncodingPhaseArtifactReconciliation","TestRequiredEncodingStrictJSONRejectsAmbiguity","TestRequiredEncodingRecomputesDiagnosticFromActualStderr"]
cmd=[r"C:\Program Files\Go\bin\go.exe","test","./tools/language-acceptance","-count=1","-json","-timeout=300s","-run","^("+"|".join(names)+")$"]
env={k:v for k,v in os.environ.items() if not k.startswith("CHERRI")};env.update({"GOMAXPROCS":"1","GOFLAGS":"-p=1"})
log=out/"clean-production-gates.jsonl";start=time.monotonic();timed=False
(out/"runner.py").write_bytes(pathlib.Path(__file__).read_bytes())
with log.open("wb") as f:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 (out/"launch.json").write_bytes(json.dumps({"source":source,"command":cmd,"pid":p.pid,"started":datetime.datetime.now(datetime.timezone.utc).isoformat()}).encode())
 try:code=p.wait(timeout=360)
 except subprocess.TimeoutExpired:
  timed=True;subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30);code=p.wait(timeout=30)
events=[]
for line in log.read_text(encoding="utf-8",errors="replace").splitlines():
 try:events.append(json.loads(line))
 except json.JSONDecodeError:pass
counts={a:sum(1 for e in events if e.get("Action")==a and e.get("Test")) for a in ["run","pass","fail","skip"]}
passed={e.get("Test") for e in events if e.get("Action")=="pass"}
result={"source":source,"before":before,"after":snap(),"seconds":round(time.monotonic()-start,3),"exit":code,"timedOut":timed,"counts":counts,"allRequiredPassed":set(names)<=passed,"requiredTests":names,"sha256":hashlib.sha256(log.read_bytes()).hexdigest(),"bytes":log.stat().st_size}
(out/"summary.json").write_bytes((json.dumps(result,indent=2)+"\n").encode());print(json.dumps(result))
assert code==0 and not timed and result["before"]==result["after"] and result["allRequiredPassed"] and counts["fail"]==0 and counts["skip"]==0
