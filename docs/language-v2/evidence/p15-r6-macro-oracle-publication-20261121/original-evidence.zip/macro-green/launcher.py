from pathlib import Path
import os,subprocess,json,datetime,time,sys,hashlib
repo=Path(r"C:\Users\DAVID\Code\cherri-p10r15-docs-acceptance-r5-20261120")
base=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-c46902bb-20261121")
source="0be0a15db9c74a26131fecb5a9f055a87c867bb6"
assert subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=repo).decode().strip()==source
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=repo)
out=base/"macro-oracle-0be0a15d";out.mkdir()
(out/"launcher.py").write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1")
commands=[
 ("refresh",[sys.executable,"tools/p10r15/generate_macro_contract_coverage.py","--refresh","--out-dir",str(out/"ledger")],420),
 ("verify",[sys.executable,"tools/p10r15/generate_macro_contract_coverage.py","--verify","--out-dir",str(out/"ledger")],60),
 ("faults",[sys.executable,"tools/p10r15/verify_macro_ledger_evidence.py","--repo",".","--ledger-dir",str(out/"ledger"),"--report",str(out/"verifier-audit.json")],120)]
for name,cmd,budget in commands:
 started=datetime.datetime.now(datetime.timezone.utc);clock=time.monotonic();timed=False
 with(out/(name+".stdout")).open("xb")as stdout,(out/(name+".stderr")).open("xb")as stderr:
  try:p=subprocess.run(cmd,cwd=repo,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=budget);code=p.returncode
  except subprocess.TimeoutExpired:timed=True;code=-1
 receipt={"command":cmd,"source":source,"cwd":str(repo),"startedUTC":started.isoformat(),"finishedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsedSeconds":time.monotonic()-clock,"budgetSeconds":budget,"exitCode":code,"timedOut":timed}
 (out/(name+".process.json")).write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf8")
 print(name,json.dumps(receipt),flush=True)
 if code:print((out/(name+".stderr")).read_text(encoding="utf8")[-3000:]);raise SystemExit(code)
report=json.loads((out/"ledger/macro-contract-coverage.json").read_text(encoding="utf8"))
audit=json.loads((out/"verifier-audit.json").read_text(encoding="utf8"))
assert report["sourceSha"]==source and report["worktreeDirtyBeforeExecution"]is False
assert report["summary"]["structuralExecutionVerdict"]=="PASS"
assert audit["summary"]["failed"]==0
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=repo)
print("SUMMARY",json.dumps(report["summary"]),json.dumps(audit["summary"]))
