import pathlib,json,hashlib,zipfile,subprocess,datetime
e=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-parity-evidence-20261119\r4-consumer-refresh-20261120")
o=e/"d03-44714729238-original";a=o/"artifact-members"; c=a/"consumer"
C="b09f48564adf8d317911a0d552785426a43d4a18";S="fd691b96fb661697a1cbaddab92476d457636ba9";D="35543290124f00f216f6f4b638a890542c8e8783"
repo=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-parity-20261119");docs=pathlib.Path(r"C:\Users\DAVID\Code\cherrilang-p10r15-completion-20261119")
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def blob(r,s,p):
 x=subprocess.run(["git","--no-replace-objects","show",s+":"+p],cwd=r,stdin=subprocess.DEVNULL,capture_output=True,timeout=20)
 assert x.returncode==0,(s,p,x.stderr);return x.stdout
run=read(o/"run.json");assert run["id"]==44714729238 and run["head_sha"]==C and run["workflow_id"]==424463918 and run["run_attempt"]==1 and run["event"]=="workflow_dispatch" and run["conclusion"]=="success"
jobs=read(o/"jobs.json")["jobs"];assert len(jobs)==1 and jobs[0]["id"]==136215091373 and jobs[0]["head_sha"]==C and jobs[0]["conclusion"]=="success"
assert all(x["conclusion"] in ("success","skipped") for x in jobs[0]["steps"])
ars=read(o/"artifacts.json")["artifacts"];assert len(ars)==1;ar=ars[0];zraw=(o/"14618374213.zip").read_bytes()
assert ar["id"]==14618374213 and ar["workflow_run"]["head_sha"]==C and len(zraw)==ar["size_in_bytes"]==250063 and sha(zraw)=="794b94d9b9505d5ababc270a0eca8fe40788e11be70fb1e382c0695f9fdd2126"
inv=read(o/"member-inventory.json")
with zipfile.ZipFile(o/"14618374213.zip") as z:
 names=[x.filename for x in z.infolist() if not x.is_dir()]
 assert len(names)==len(set(names))==len(inv)==50
 for m in inv:
  b=(a/m["path"]).read_bytes()
  assert b==z.read(m["path"]) and len(b)==m["bytes"] and sha(b)==m["sha256"]
r=read(a/"intake-receipt.json");pub=read(a/"publication-input-receipt.json");v=read(c/"documentation-consumers.json")
records=read(c/"documentation-consumer-evidence.json")["records"];assert len(records)==1;record=records[0]
assert record["requirements"]==["D03"] and record["tier"]=="docs" and record["result"]=="passed" and record["exit_code"]==0 and record["implementation_sha"]==C
assert record["test_id"]=="tools/p10r15:verify_documentation_consumers" and record["assertions"]=={"published_current_docs":"true","installed_skill_current_docs":"true","historical_docs_explicit_only":"true"}
for item in record["artifacts"]:
 p=pathlib.PurePosixPath(item["path"]);b=(c/p.name).read_bytes();assert sha(b)==item["sha256"]
assert r["collector_evidence_sha256"]==sha((c/"documentation-consumer-evidence.json").read_bytes())
assert r["implementation_sha"]==C and r["documentation_record_accepted"] is True and r["original_references_unchanged"] is True
assert all(r[k] is False for k in ["d03_complete","app_integration_executed","closure_complete"])
assert r["report"]["results"][0]["executed_levels"]==["docs"] and r["report"]["results"][0]["status"]=="FAILED"
assert r["report"]["passed_cases"]==0 and r["report"]["closure_complete"] is False
assert pub["implementationSha"]==C and pub["docsCommit"]==D and pub["consumerCompilerPin"]==S
assert pub["deploymentRunId"]=="44711839370" and pub["deploymentAttempt"]==1 and pub["artifactId"]==14617636818
pbytes=(a/"original-publication-evidence.zip").read_bytes()
assert pbytes==(e/"docs-pages-44711839370-original"/"14617636818.zip").read_bytes()
assert len(pbytes)==pub["originalArchiveBytes"]==1538 and sha(pbytes)==pub["originalArchiveSha256"]=="22f54e80efb982db39db8402451c4e947292f2ab344ebda558e4bbc9f9ffa652"
assert pub["formalAcceptanceGranted"] is False and pub["appIntegrationExecuted"] is False
for name,digest in pub["metadata"].items():assert sha((a/name).read_bytes())==digest
assert v["mode"]=="actual-installed-public-site" and v["implementationSha"]==C and v["compilerCommit"]==S and v["docsCommit"]==D and v["sourceClean"] is True and v["docsClean"] is True
assert v["before"]==v["after"] and len(v["before"])==7
source_witness=[]
for item in v["sourceFiles"]:
 b=blob(docs,D,item["path"]);assert sha(b)==item["sha256"];source_witness.append({"repository":"docs","commit":D,**item})
for item in v["skillFiles"]:
 b=blob(repo,C,"skills/cherri-shortcuts/"+item["path"]);assert sha(b)==item["sha256"];source_witness.append({"repository":"compiler","commit":C,**item})
manifest=read(c/"documentation-compatibility-manifest.json")
for k in ["compilerCommit","docsCommit","schemaFingerprint","codecFingerprint","macroFingerprint"]:assert manifest[k]==v[k]
expected={"active-empty":0,"active-show":0,"legacy-empty":0,"legacy-query":0,"absent-query":0,"invalid-regex":2,"missing-current":1,"restored-active":0}
assert [x["name"] for x in v["searchCases"]]==list(expected)
for x in v["searchCases"]:
 assert x["exitCode"]==expected[x["name"]] and x["timedOut"] is False
 for stream in ["stdout","stderr"]:assert sha((c/(x["name"]+"."+stream+".log")).read_bytes())==x[stream+"SHA256"]
assert (c/"active-show.stdout.log").read_bytes()==(c/"restored-active.stdout.log").read_bytes()
site=e/"docs-pages-44711839370-original"/"published-site"
paths={"":"index.html","fork-language/":"fork-language/index.html","fork-language/guide":"fork-language/guide.html","fork-language/actions":"fork-language/actions.html","fork-language/migration":"fork-language/migration.html","assets/js/search-data.json":"assets/js/search-data.json","assets/preview.js":"assets/preview.js"}
assert [x["route"] for x in v["httpObservations"]]==list(paths)
for h in v["httpObservations"]:
 b=(c/h["artifact"]).read_bytes();assert h["status"]==200 and len(b)==h["bytes"] and sha(b)==h["sha256"]
 assert b==(site/paths[h["route"]]).read_bytes(),h["route"]
events=[json.loads(line) for line in (a/"intake-test.jsonl").read_bytes().splitlines() if line.strip()]
name="TestDocumentationConsumerCIActualIntake"
assert sum(x.get("Test")==name and x.get("Action")=="run" for x in events)==1
assert sum(x.get("Test")==name and x.get("Action")=="pass" for x in events)==1
assert not any(x.get("Action") in ["fail","skip"] for x in events)
for f in ["skill-source-create.json","skill-source-verify.json"]:
 q=read(a/f);assert q["skillCommit"]==C and q["compilerCommit"]==S and q["docsCommit"]==D and q["status"]=="PASS_PACKAGE_INTEGRITY";assert q["archiveSha256"]==sha((a/"skill-source.zip").read_bytes())
out={"status":"PASS_INDEPENDENT_D03_DOCS_ONLY_AUDIT","runId":run["id"],"jobId":jobs[0]["id"],"implementationSha":C,"compilerCommit":S,"docsCommit":D,"artifactId":ar["id"],"archiveBytes":len(zraw),"archiveSha256":sha(zraw),"originalArchiveMembersVerified":len(inv),"recordArtifactsVerified":len(record["artifacts"]),"immutableSourceFilesVerified":source_witness,"actualInstalledSearchCases":len(expected),"actualPublishedBytesComparedWithOriginalPagesArtifact":len(paths),"actualGoIntakeTest":name,"actualGoIntakePassed":True,"documentationTierAccepted":True,"appIntegrationExecuted":False,"d03Complete":False,"closureComplete":False,"originalReferencesUnchanged":True,"auditedAtUTC":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(o/"independent-audit.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
print(json.dumps(out))
