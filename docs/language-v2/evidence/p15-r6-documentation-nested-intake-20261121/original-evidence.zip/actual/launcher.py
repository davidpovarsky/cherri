from pathlib import Path
import subprocess,os,json,datetime,time,sys,hashlib
repo=Path(r"C:\Users\DAVID\Code\cherri-p10r15-docs-acceptance-r5-20261120")
root=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-c46902bb-20261121")
source=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=repo).decode().strip()
assert source=="a7d4f8eba56eedeeddd44627de9dde679447ae30"
assert subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=repo)==b""
out=root/("registrar-"+source[:8]);out.mkdir()
(out/"launcher.py").write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",
 CHERRI_TEST_BASH=r"C:\Program Files\Git\bin\bash.exe",
 CHERRI_DOCS_PYTHON=r"C:\ProgramData\SentinelX\.venv\Scripts\python.exe",
 CHERRI_DOCUMENTATION_SOURCE_ROOT=r"C:\Users\DAVID\Code\cherri-p10r15-source-c46902bb-exact-20261121",
 CHERRI_D03_DOCS_REPO=r"C:\Users\DAVID\Code\cherrilang-p10r15-docs-r5-20261120",
 CHERRI_DOCUMENTATION_COMPILER=str(root/"compiler-exact.exe"),
 CHERRI_DOCS_RECOVERY_ACCEPTANCE_OUTPUT=str(out/"originals"))
command=["go","test","./tools/language-acceptance","-count=1","-json","-timeout=8m","-run","^TestDocumentationRecoveryActualProductionEvidence$"]
started=datetime.datetime.now(datetime.timezone.utc);clock=time.monotonic()
timedout=False
with (out/"go.jsonl").open("xb") as stdout,(out/"stderr.log").open("xb") as stderr:
 try:p=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr,timeout=540);code=p.returncode
 except subprocess.TimeoutExpired:timedout=True;code=-1
receipt={"command":command,"cwd":str(repo),"source":source,"startedUTC":started.isoformat(),
 "finishedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsedSeconds":time.monotonic()-clock,
 "exitCode":code,"timedOut":timedout,
 "sourceCleanAfter":not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=repo),
 "rawSHA256":hashlib.sha256((out/"go.jsonl").read_bytes()).hexdigest()}
(out/"launcher-report.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf8")
for line in (out/"go.jsonl").read_text(encoding="utf8").splitlines():
 event=json.loads(line)
 if event.get("Action") in ("fail","pass") or "P15_DOCUMENTATION_RECOVERY_ACCEPTANCE:" in event.get("Output",""):
  if "P15_DOCUMENTATION_RECOVERY_ACCEPTANCE:" in event.get("Output",""):
   value=json.loads(event["Output"].split("P15_DOCUMENTATION_RECOVERY_ACCEPTANCE:",1)[1])
   (out/"derived-intake-receipt.json").write_text(json.dumps(value,indent=2)+"\n",encoding="utf8")
  elif event.get("Action")=="fail":print(event)
print(json.dumps(receipt))
print("EVIDENCE",str(out))
raise SystemExit(code)
