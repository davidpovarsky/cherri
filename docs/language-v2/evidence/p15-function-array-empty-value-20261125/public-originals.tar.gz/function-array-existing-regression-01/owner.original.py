import os,json,hashlib,subprocess,datetime,time,shutil,signal,sys
from pathlib import Path
OWNER_STARTED=time.monotonic()
CONFIG=Path(sys.argv[1]); configBytes=CONFIG.read_bytes(); C=json.loads(configBytes)
W=Path(C['worktree']);O=Path(C['output'])
GO='/mnt/development/tooling/cherri-go/runtime-persistent-20261123/owned-mod-cache-restored-20261125/golang.org/toolchain@v0.0.1-go1.24.13.linux-arm64/bin/go'
OBSERVER=Path('/mnt/development/projects/evidence/cherri-p10r15-ci-release-20261125/rp20-joined-repair-qualification-preparation-02/observe-go-owners.py')
assert hashlib.sha256(OBSERVER.read_bytes()).hexdigest()=='8b900628658ca9bba5861a0a3eb61410dfd8466e32003cb3ff854fa873a356c6'
assert C['goSeconds']>0 and C['outerSeconds']>C['goSeconds'] and C['outerSeconds']<=600
assert 0<len(C['parents'])<=128 and C['parents']==sorted(set(C['parents']))
assert all(n.startswith('Test') and '/' not in n and n.isidentifier() for n in C['parents'])
assert C['packages'] and all(p=='.' or (p.startswith('./') and '..' not in p) for p in C['packages'])
assert not O.exists();O.mkdir(mode=0o755)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):
 b=v if isinstance(v,bytes) else (json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
 with (O/n).open('xb') as f:f.write(b)
 return pin(O/n)
def git(*a):
 r=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],capture_output=True,timeout=30)
 assert r.returncode==0,r.stderr
 return r.stdout
def snapshot():
 rows=git('ls-tree','-rz','--full-tree','HEAD').split(b'\0'); physical={}
 for row in rows:
  if not row:continue
  metadata,name=row.split(b'\t',1);mode,kind,blob=metadata.decode().split();name=name.decode();p=W/name
  assert mode in ('100644','100755') and kind=='blob' and p.is_file() and not p.is_symlink()
  raw=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob,name
  physical[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'blob':blob,'mode':mode}
 return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status':git('status','--porcelain=v1','--untracked-files=all').decode(),'trackedPhysicalInputs':physical}
write('owner.original.py',Path(__file__).read_bytes());write('config.original.json',configBytes)
before=snapshot();assert before['head']==C['head'] and before['branch']==C['branch'] and not before['status']
write('source-before.original.json',before)
remote=git('-c','credential.helper=','-c','credential.helper=!gh auth git-credential','ls-remote','--heads','origin').decode()
write('remote-heads-before-build.original.txt',remote.encode())
remoteRefs={line.split()[1]:line.split()[0] for line in remote.splitlines()}
assert remoteRefs['refs/heads/'+C['branch']]==before['head']
BUILDCACHE=Path('/mnt/development/tooling/cherri-go/runtime-persistent-20261123/build-cache-restored-20261125')
assert BUILDCACHE.is_dir() and not BUILDCACHE.is_symlink()
admission={'root':939524096,'development':1073741824,'shm':402653184,'memoryAvailable':3221225472}
liveFloor={'root':805306368,'development':805306368,'shm':201326592,'memoryAvailable':2147483648}
def free():
 memory={k:int(v.strip().split()[0])*1024 for k,v in (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())}
 return {'root':shutil.disk_usage('/').free,'development':shutil.disk_usage('/mnt/development').free,'shm':shutil.disk_usage('/dev/shm').free,'memoryAvailable':memory['MemAvailable']}
initial=free();write('preflight.original.json',{'utc':now(),'freeBytes':initial,'admission':admission,'liveStopFloors':liveFloor,'GOCACHE':str(BUILDCACHE),'GOMODCACHE':'/mnt/development/tooling/cherri-go/runtime-persistent-20261123/owned-mod-cache-restored-20261125'})
observed=subprocess.run(['/usr/bin/python3','-I','-B',str(OBSERVER)],capture_output=True,timeout=25)
write('concurrent-owner-observation.original.json',observed.stdout);write('concurrent-owner-observation.original.stderr',observed.stderr)
decision=json.loads(observed.stdout) if observed.stdout else {}
ownerAllowed=observed.returncode==0 and not observed.stderr and decision.get('schema')=='cherri-distinct-go-owner-observation/v1' and decision.get('admitted') is True and decision.get('blockedPids')==[]
if any(initial[k]<limit for k,limit in admission.items()) or not ownerAllowed:
 r=write('result.original.json',{'status':'NOT_RUN','reason':'CAPACITY_OR_CONCURRENT_GO_ADMISSION','freeBytes':initial,'ownerAdmitted':ownerAllowed,'source':before['head'],'testInputsUnchanged':True})
 print(json.dumps({'result':{'path':str(O/'result.original.json'),**r},'status':'NOT_RUN','freeBytes':initial,'ownerAdmitted':ownerAllowed}));raise SystemExit(0)
env=dict(os.environ);env.update(GOPROXY='off',GOSUMDB='off',PATH=str(Path(GO).parent)+':/usr/local/bin:/usr/bin:/bin',GOTOOLCHAIN='local',GOMAXPROCS='2',GOFLAGS='-p=2 -mod=readonly',GOMODCACHE='/mnt/development/tooling/cherri-go/runtime-persistent-20261123/owned-mod-cache-restored-20261125',GOCACHE=str(BUILDCACHE),GOTMPDIR='/mnt/development/tooling/cherri-go/runtime-persistent-20261123/tmp-ubuntu',TMPDIR='/mnt/development/tooling/cherri-go/runtime-persistent-20261123/tmp-ubuntu')
for key,relative in C.get('artifactEnvs',{}).items():
 assert key in ('CHERRI_STRUCTURED_VALUE_ARTIFACTS','CHERRI_STRUCTURED_ACCEPTANCE_ARTIFACTS','CHERRI_RP20_ARTIFACTS','CHERRI_EXPLICIT_SIGNING_EVIDENCE_OUTPUT')
 assert relative and '/' not in relative and relative not in ('.','..')
 destination=O/relative;destination.mkdir();os.chown(destination,1001,1001);env[key]=str(destination)
args=['/usr/sbin/runuser','-u','ubuntu','--',GO,'test','-count=1','-json','-timeout='+str(C['goSeconds'])+'s','-run','^(?:'+'|'.join(C['parents'])+')$']+C['packages']
started=now();tick=time.monotonic();minimum=dict(initial);timed=False;capacity=False;signals=[];p=None
assert time.monotonic()-OWNER_STARTED < C['outerSeconds']-30

try:
 with (O/'go-test.original.jsonl').open('xb') as so,(O/'go-test.original.stderr').open('xb') as se:
  p=subprocess.Popen(args,cwd=W,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,start_new_session=True)
  write('process-start.original.json',{'utc':started,'pid':p.pid,'argv':args,'outerSeconds':C['outerSeconds']})
  while p.poll() is None:
   f=free()
   for k in minimum:minimum[k]=min(minimum[k],f[k])
   capacity=any(f[k]<limit for k,limit in liveFloor.items());timed=time.monotonic()-OWNER_STARTED>=C['outerSeconds']-20
   if capacity or timed:break
   try:p.wait(timeout=.25)
   except subprocess.TimeoutExpired:pass
finally:
 if p is not None and p.poll() is None:
  for sig in (signal.SIGTERM,signal.SIGKILL):
   try:os.killpg(p.pid,sig);signals.append(signal.Signals(sig).name)
   except ProcessLookupError:pass
   try:p.wait(timeout=5);break
   except subprocess.TimeoutExpired:pass
after=snapshot();write('source-after.original.json',after)
raw=(O/'go-test.original.jsonl').read_bytes();events=[];parseErrors=[]
for i,line in enumerate(raw.splitlines(),1):
 try:events.append(json.loads(line))
 except (json.JSONDecodeError,UnicodeDecodeError) as e:parseErrors.append({'line':i,'error':str(e)})
passed=[{'package':e['Package'],'test':e['Test']} for e in events if e.get('Action')=='pass' and 'Test' in e]
failed=[{'package':e.get('Package'),'test':e.get('Test')} for e in events if e.get('Action')=='fail']
skipped=[{'package':e.get('Package'),'test':e.get('Test')} for e in events if e.get('Action')=='skip']
pairs=[(e['package'],e['test']) for e in passed]
parentsPassed={e['test'] for e in passed if '/' not in e['test']}
actualPackages={e['Package'] for e in events if e.get('Action')=='pass' and 'Test' not in e}
expectedPackages={'github.com/electrikmilk/cherri'+(p[1:] if p!='.' else '') for p in C['packages']}
actualNamed=sorted(e['test'] for e in passed)
expectedNamed=C['expectedNamedEvents']
okay=actualNamed==expectedNamed and p.returncode==0 and before==after and not skipped and not failed and not timed and not capacity and not parseErrors and raw.endswith(b'\n') and parentsPassed==set(C['parents']) and len(pairs)==len(set(pairs)) and actualPackages==expectedPackages
result={'schema':'cherri-root-source-bound-go/2','status':'PASSED' if okay else 'FAILED','scope':C['scope'],'head':before['head'],'branch':before['branch'],'command':args,'startedAt':started,'finishedAt':now(),'elapsedSeconds':time.monotonic()-tick,'wholeOwnerElapsedSeconds':time.monotonic()-OWNER_STARTED,'wholeOwnerSeconds':C['outerSeconds'],'postProcessReserveSeconds':20,'exitCode':p.returncode,'timedOut':timed,'capacityFloorStopped':capacity,'signals':signals,'minimumFree':minimum,'sourceUnchanged':before==after,'passedTests':passed,'failed':failed,'skipped':skipped,'parseErrors':parseErrors,'expectedParents':C['parents'],'expectedNamedEvents':expectedNamed,'actualNamedEvents':actualNamed,'actualPackages':sorted(actualPackages),'formalAcceptance':False,'artifacts':{f:pin(O/f) for f in ['owner.original.py','config.original.json','source-before.original.json','source-after.original.json','go-test.original.jsonl','go-test.original.stderr','preflight.original.json','concurrent-owner-observation.original.json','concurrent-owner-observation.original.stderr','process-start.original.json','remote-heads-before-build.original.txt']}}
r=write('result.original.json',result)
print(json.dumps({'result':{'path':str(O/'result.original.json'),**r},'status':result['status'],'exitCode':p.returncode,'passed':len(passed),'failed':failed,'skipped':skipped,'timedOut':timed,'capacityFloorStopped':capacity,'sourceUnchanged':before==after}))
