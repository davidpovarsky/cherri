import hashlib,json,pathlib,sys,time,unittest
q=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(q))
events=[]
class Recorded(unittest.TextTestResult):
    def startTest(self,test):
        events.append({"kind":"parent","action":"run","id":test.id()});super().startTest(test)
    def addSuccess(self,test):
        events.append({"kind":"parent","action":"pass","id":test.id()});super().addSuccess(test)
    def addFailure(self,test,err):
        events.append({"kind":"parent","action":"fail","id":test.id(),"error":self._exc_info_to_string(err,test)});super().addFailure(test,err)
    def addError(self,test,err):
        events.append({"kind":"parent","action":"error","id":test.id(),"error":self._exc_info_to_string(err,test)});super().addError(test,err)
    def addSkip(self,test,reason):
        events.append({"kind":"parent","action":"skip","id":test.id(),"reason":reason});super().addSkip(test,reason)
    def addSubTest(self,test,subtest,err):
        record={"kind":"subtest","action":"pass" if err is None else "fail","parent":test.id(),"id":str(subtest)}
        if err is not None:record["error"]=self._exc_info_to_string(err,test)
        events.append(record);super().addSubTest(test,subtest,err)
start=time.monotonic()
suite=unittest.defaultTestLoader.loadTestsFromName("test_function_envelope_r2_graph")
result=unittest.TextTestRunner(stream=sys.stderr,verbosity=2,resultclass=Recorded).run(suite)
record={"schema":"cherri-python-original-control-results/1","passed":result.wasSuccessful(),"parentTestsRun":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skips":len(result.skipped),"subtests":sum(e["kind"]=="subtest" for e in events),"elapsedSeconds":time.monotonic()-start,"nativeExecution":False}
for name,data in [("events.original.json",events),("controls.result.original.json",record)]:
 with (out/name).open("x") as f:f.write(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+"\n")
if result.wasSuccessful():
 import function_envelope_r2_graph as graph
 proof=graph.validate_compiled((q/"fixtures/qa-function-envelope-presence-v2-r2.cherri").read_bytes(),(q/"fixtures/qa-function-envelope-presence-v2-r2.expected.json").read_bytes(),(q/"testdata/function-envelope-presence-r2-compiled.original.plist").read_bytes())
 proof["compilerCommitSha"]="9b350816f27cf06bf7194e19a1dcc5a97c94f42b"
 with (out/"r2-graph-validation.original.json").open("x") as f:f.write(json.dumps(proof,sort_keys=True,indent=2)+"\n")
print(json.dumps(record))
raise SystemExit(0 if result.wasSuccessful() else 1)
