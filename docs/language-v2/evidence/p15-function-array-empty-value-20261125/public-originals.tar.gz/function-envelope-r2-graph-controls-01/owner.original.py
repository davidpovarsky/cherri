import ast,collections,datetime,hashlib,json,os,pathlib,signal,subprocess,sys,time
config_path=pathlib.Path(sys.argv[1]);config=json.loads(config_path.read_bytes());w=pathlib.Path(config["worktree"]);out=pathlib.Path(config["output"]);q=w/"tools/shortcuts-simulator-qa"
out.mkdir(mode=0o700);start=time.monotonic();deadline=start+120
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 raw=(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
 with (out/name).open("xb") as f:f.write(raw)
 return {"bytes":len(raw),"sha256":sha(raw)}
def git(*a):
 remaining=deadline-time.monotonic();assert remaining>0,"owner deadline"
 return subprocess.run(["git","--no-replace-objects","-C",str(w),*a],capture_output=True,check=True,timeout=min(10,remaining)).stdout
def snapshot():
 head=git("rev-parse","HEAD").decode().strip();assert head==config["head"]
 status=git("status","--porcelain=v1").decode();assert status==""
 tree={}
 for item in git("ls-tree","-r","-z","HEAD").split(b"\0"):
  if item:
   meta,path=item.split(b"\t",1);mode,kind,blob=meta.decode().split()
   tree[path.decode()]={"mode":mode,"kind":kind,"blob":blob}
 pins={}
 for rel in config["sourcePaths"]:
  p=w/rel;assert not p.is_symlink() and tree[rel]["kind"]=="blob"
  b=p.read_bytes();assert hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==tree[rel]["blob"]
  pins[rel]=tree[rel]|{"bytes":len(b),"sha256":sha(b)}
 return {"head":head,"tree":git("rev-parse","HEAD^{tree}").decode().strip(),"status":status,"sourceFiles":pins}
def interrupted(sig,frame):raise TimeoutError("OWNED_PYTHON_CONTROL_SIGNAL_"+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,interrupted)
write("config.original.json",config)
with (out/"owner.original.py").open("xb") as f:f.write(pathlib.Path(__file__).read_bytes())
with (out/"runner.original.py").open("xb") as f:f.write(pathlib.Path(config["runner"]).read_bytes())
assert sha(pathlib.Path(config["runner"]).read_bytes())==config["runnerSHA256"]
before=after=observation=detail=None;error=None
try:
 before=snapshot();write("source-before.original.json",before)
 sys.path.insert(0,str(q));import project_prerequisite_observation as process
 os.chdir(q)
 command=[sys.executable,"-I","-B",config["runner"],str(q),str(out)]
 def journal(stage,value):write("process-"+stage+".original.json",value)
 with (out/"stdout.original").open("xb") as stdout,(out/"stderr.original").open("xb") as stderr:
  observation,detail=process.capture(command,90,output=stdout,error_output=stderr,hard_deadline=deadline-10,stream_limit=1024*1024,journal=journal)
 write("process.original.json",{"actualArgv":command,"observation":observation,"process":detail})
except BaseException as exc:
 error={"type":type(exc).__name__,"message":str(exc)}
finally:
 try:after=snapshot();write("source-after.original.json",after)
 except BaseException as exc:
  error=error or {"type":type(exc).__name__,"message":str(exc)}
ok=False;counts={};control=None
try:
 control=json.loads((out/"controls.result.original.json").read_bytes());events=json.loads((out/"events.original.json").read_bytes())
 runs=collections.Counter(e["id"] for e in events if e["kind"]=="parent" and e["action"]=="run")
 passes=collections.Counter(e["id"] for e in events if e["kind"]=="parent" and e["action"]=="pass")
 expected=collections.Counter(config["parentIDs"]);bad=[e for e in events if e["action"] in ["fail","error","skip"]]
 counts={"parentsRun":sum(runs.values()),"parentsPassed":sum(passes.values()),"subtests":sum(e["kind"]=="subtest" for e in events),"badEvents":len(bad),"missingParents":sorted(set(expected)-set(runs)),"extraParents":sorted(set(runs)-set(expected))}
 ok=error is None and observation["result"]=="PASS" and observation["exitCode"]==0 and before==after and runs==passes==expected and not bad and control["passed"] is True and detail["cleanupParentReaped"] is True and detail["groupAfterCleanup"]["state"]=="ABSENT"
except BaseException as exc:error=error or {"type":type(exc).__name__,"message":str(exc)}
artifacts={str(p.relative_to(out)):{"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in out.iterdir() if p.is_file()}
result={"schema":"cherri-r2-source-bound-python-qualification/1","status":"PASS" if ok else "FAILED","head":config["head"],"sourceUnchanged":before is not None and before==after,"counts":counts,"error":error,"process":observation,"wholeOwnerElapsedSeconds":time.monotonic()-start,"pythonSeconds":90,"wholeOwnerSeconds":120,"artifacts":artifacts,"nativeExecution":False,"formalAcceptance":False}
pin=write("result.original.json",result);print(json.dumps({"result":pin,"path":str(out/"result.original.json"),"status":result["status"],"counts":counts,"error":error}))
