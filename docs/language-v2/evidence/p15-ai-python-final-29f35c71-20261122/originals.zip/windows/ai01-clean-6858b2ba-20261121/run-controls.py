from pathlib import Path
import sys,json,unittest,time
root=Path(sys.argv[1]);evidence=Path(sys.argv[2])
sys.path.insert(0,str(root/'tools/language-ai-eval'))
modules=['test_runner','test_evaluation_bundle','test_graph_validator','test_evaluation_intake','test_sealed_runner','test_anthropic_adapter']
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
def flatten(s):
 for item in s:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item
ids=[x.id() for x in flatten(suite)]
assert len(ids)==129 and len(set(ids))==129,(len(ids),len(set(ids)))
(evidence/'inventory.json').write_bytes((json.dumps({'modules':modules,'testIds':ids,'count':len(ids)},indent=2)+'\n').encode())
events=(evidence/'test-events.jsonl').open('x',encoding='utf-8')
class Result(unittest.TextTestResult):
 def emit(self,event,test,detail=None):
  events.write(json.dumps({'event':event,'test':test.id(),'detail':detail,'monotonic':time.monotonic()})+'\n');events.flush()
 def startTest(self,test):self.emit('START',test);super().startTest(test)
 def addSuccess(self,test):self.emit('PASS',test);super().addSuccess(test)
 def addFailure(self,test,err):self.emit('FAIL',test);super().addFailure(test,err)
 def addError(self,test,err):self.emit('ERROR',test);super().addError(test,err)
 def addSkip(self,test,reason):self.emit('SKIP',test,reason);super().addSkip(test,reason)
 def addSubTest(self,test,subtest,err):self.emit('SUBCASE_PASS' if err is None else 'SUBCASE_FAIL',test,str(subtest));super().addSubTest(test,subtest,err)
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
events.close()
(evidence/'test-result.json').write_bytes((json.dumps({'testsRun':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':[[x.id(),reason] for x,reason in r.skipped],'successful':r.wasSuccessful()},indent=2)+'\n').encode())
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
