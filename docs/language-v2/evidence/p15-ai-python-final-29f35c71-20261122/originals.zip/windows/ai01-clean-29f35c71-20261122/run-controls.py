from pathlib import Path
import sys,json,unittest,time,traceback
root=Path(sys.argv[1]); evidence=Path(sys.argv[2])
sys.path.insert(0,str(root/'tools/language-ai-eval'))
selectors=json.loads(sys.argv[3]);expected=int(sys.argv[4])
suite=unittest.defaultTestLoader.loadTestsFromNames(selectors)
def flatten(s):
 for item in s:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item
ids=[x.id() for x in flatten(suite)]
assert len(ids)==expected and len(set(ids))==expected,(len(ids),len(set(ids)))
(evidence/'inventory.json').write_text(json.dumps({'selectors':selectors,'testIds':ids,'count':len(ids)},indent=2)+'\n',encoding='utf-8')
events=(evidence/'test-events.jsonl').open('x',encoding='utf-8')
class Result(unittest.TextTestResult):
 def emit(self,event,test,detail=None):
  events.write(json.dumps({'event':event,'test':test.id(),'detail':detail,'monotonic':time.monotonic()})+'\n');events.flush()
 def immediate(self,test,err):
  sys.stderr.write('\nIMMEDIATE ORIGINAL EXCEPTION: '+test.id()+'\n')
  traceback.print_exception(*err,file=sys.stderr);sys.stderr.flush()
 def startTest(self,test):self.emit('START',test);super().startTest(test)
 def addSuccess(self,test):self.emit('PASS',test);super().addSuccess(test)
 def addFailure(self,test,err):self.emit('FAIL',test);self.immediate(test,err);super().addFailure(test,err)
 def addError(self,test,err):self.emit('ERROR',test);self.immediate(test,err);super().addError(test,err)
 def addSkip(self,test,reason):self.emit('SKIP',test,reason);super().addSkip(test,reason)
 def addSubTest(self,test,subtest,err):
  self.emit('SUBCASE_PASS' if err is None else 'SUBCASE_FAIL',test,str(subtest))
  if err is not None:self.immediate(test,err)
  super().addSubTest(test,subtest,err)
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
events.close()
(evidence/'test-result.json').write_text(json.dumps({'testsRun':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':[[x.id(),reason] for x,reason in r.skipped],'successful':r.wasSuccessful()},indent=2)+'\n')
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
