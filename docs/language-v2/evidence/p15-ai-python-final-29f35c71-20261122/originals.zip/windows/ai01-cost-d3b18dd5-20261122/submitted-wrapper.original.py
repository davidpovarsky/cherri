
from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time,re,ctypes,ctypes.wintypes as w
repo=Path(r'C:\Users\DAVID\Code\cherri-p10r15-ai-evaluation-20261121')
out=Path(r'C:\Users\DAVID\Code\cherri-p10r15-apple-analysis-20261119\ai01-cost-d3b18dd5-20261122')
out.mkdir(exist_ok=False)
(out/'submitted-wrapper.original.py').write_bytes(Path(__file__).read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,timeout=15)
head=git('rev-parse','HEAD').decode().strip()
assert head=='d3b18dd5ec6933d8605c9d37943d062915b068d0' and git('status','--porcelain')==b''
(out/'source-before.json').write_text(json.dumps({'source_sha':head,'clean':True})+'\n')
rows=[]
for line in git('ls-tree','-r','HEAD','--','tools/language-ai-eval').decode().splitlines():
 meta,path=line.split('\t');blob=meta.split()[2];raw=(repo/path).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
 rows.append({'path':path,'git_blob':blob,'sha256':sha(raw),'bytes':len(raw)})
(out/'source-bindings.json').write_text(json.dumps(rows,indent=2)+'\n')
driver="\"\"\"One instrumented existing synthetic parent; never canonical proof.\"\"\"\nimport functools\nimport hashlib\nimport json\nimport os\nfrom pathlib import Path\nimport sys\nimport subprocess\nimport time\nimport unittest\n\nrepo, output = map(Path, sys.argv[1:])\nsys.path.insert(0, str(repo / \"tools/language-ai-eval\"))\nimport evaluation_bundle as eb\nimport evaluation_intake as intake\nimport test_evaluation_intake as cases\n\ntrace = open(output / \"cost-events.jsonl\", \"x\", encoding=\"utf-8\", buffering=1)\naggregates = {}\nsequence = 0\n\ndef event(kind, **fields):\n    global sequence\n    sequence += 1\n    trace.write(json.dumps({\"sequence\": sequence, \"event\": kind,\n        \"monotonic\": time.perf_counter(), **fields}, sort_keys=True)+\"\\n\")\n    trace.flush()\n\ndef measured(label, function, emit=False):\n    @functools.wraps(function)\n    def call(*args, **kwargs):\n        before = time.perf_counter()\n        status = \"RETURNED\"\n        if emit:\n            event(\"ENTER\", operation=label)\n        try:\n            return function(*args, **kwargs)\n        except BaseException as error:\n            status = type(error).__name__\n            raise\n        finally:\n            elapsed = time.perf_counter()-before\n            row = aggregates.setdefault(label, {\"calls\": 0, \"inclusive_seconds\": 0.0,\n                \"max_seconds\": 0.0, \"errors\": 0})\n            row[\"calls\"] += 1\n            row[\"inclusive_seconds\"] += elapsed\n            row[\"max_seconds\"] = max(row[\"max_seconds\"], elapsed)\n            row[\"errors\"] += status != \"RETURNED\"\n            if emit:\n                event(\"LEAVE\", operation=label, elapsed_seconds=elapsed,\n                    status=status, aggregates=aggregates)\n    return call\n\noriginal_crypto = eb.crypto\noriginal_run = subprocess.run\nprocess_number = 0\ndef recorded_run(argv, *args, **kwargs):\n    global process_number\n    if Path(argv[0]).name.lower() not in (\"openssl\", \"openssl.exe\"):\n        return original_run(argv, *args, **kwargs)\n    process_number += 1\n    number = process_number\n    before = time.perf_counter()\n    result = None\n    error_name = None\n    stdout = stderr = b\"\"\n    try:\n        result = original_run(argv, *args, **kwargs)\n        stdout, stderr = result.stdout, result.stderr\n        return result\n    except BaseException as error:\n        error_name = type(error).__name__\n        stdout, stderr = getattr(error, \"stdout\", b\"\") or b\"\", getattr(error, \"stderr\", b\"\") or b\"\"\n        raise\n    finally:\n        elapsed = time.perf_counter()-before\n        originals = {}\n        for stream, raw in ((\"stdout\", stdout), (\"stderr\", stderr)):\n            name = f\"crypto-{number:02d}.{stream}.original\"\n            with open(output / name, \"xb\") as handle:\n                handle.write(raw)\n            originals[name] = {\"bytes\": len(raw), \"sha256\": hashlib.sha256(raw).hexdigest()}\n        event(\"CRYPTO_PROCESS\", argv=list(map(str, argv)),\n            timeout_seconds=kwargs.get(\"timeout\"), elapsed_seconds=elapsed,\n            returncode=None if result is None else result.returncode,\n            error_type=error_name, originals=originals)\nsubprocess.run = recorded_run\n\ndef crypto(*args):\n    label = \"crypto.\"+str(args[0])\n    if \"-sign\" in args:\n        label += \".sign\"\n    elif \"-verify\" in args:\n        label += \".verify\"\n    elif \"-pubin\" in args:\n        label += \".algorithm\"\n    elif \"-pubout\" in args:\n        label += \".public-export\"\n    return measured(label, original_crypto, emit=True)(*args)\neb.crypto = crypto\nfor module, name, label in (\n        (eb, \"read_regular\", \"bundle.read_regular\"),\n        (intake, \"read_regular\", \"intake.read_regular\"),\n        (eb, \"write_new\", \"bundle.write_new\"),\n        (eb, \"verify_signature\", \"bundle.verify_signature\"),\n        (os, \"fstat\", \"filesystem.fstat\")):\n    setattr(module, name, measured(label, getattr(module, name)))\nfor name in (\"resolve\", \"stat\", \"lstat\", \"open\", \"read_bytes\", \"write_bytes\", \"mkdir\"):\n    setattr(Path, name, measured(\"filesystem.Path.\"+name, getattr(Path, name)))\nfor name in (\"setUp\", \"provider\", \"validator\", \"complete\", \"run_intake\"):\n    setattr(cases.IntakeTamperControls, name,\n        measured(\"fixture.\"+name, getattr(cases.IntakeTamperControls, name), emit=True))\neb.seal_outcome = measured(\"bundle.seal_outcome\", eb.seal_outcome, emit=True)\n\nevent(\"DIAGNOSTIC_START\", scope=\"one existing synthetic twelve-outcome parent\",\n    canonical_regression_credit=False, model_calls=0, compiler_calls=0,\n    aggregate_semantics=\"Inclusive categories overlap; do not sum nested timings.\")\nsuite = unittest.TestSuite([cases.IntakeTamperControls(\n    \"test_mock_provider_and_graph_receipts_join_all_twelve_outcomes\")])\nresult = unittest.TextTestRunner(verbosity=2, stream=sys.stderr).run(suite)\nevent(\"DIAGNOSTIC_END\", tests_run=result.testsRun, failures=len(result.failures),\n    errors=len(result.errors), skipped=len(result.skipped), aggregates=aggregates,\n    canonical_regression_credit=False)\ntrace.close()\nraise SystemExit(0 if result.wasSuccessful() else 1)\n"
(out/'diagnostic-driver.py').write_bytes(driver.encode())
argv=[sys.executable,str(out/'diagnostic-driver.py'),str(repo),str(out)]
intent={'source_sha':head,'argv':argv,'driver_sha256':sha(driver.encode()),'budget_seconds':70,'canonical_regression_credit':False,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
start=time.monotonic();timed=False;killraw=b''
with (out/'stdout.original').open('xb') as stdout,(out/'stderr.original').open('xb') as stderr:
 p=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
 (out/'process-start.json').write_text(json.dumps({'pid':p.pid,'argv':argv})+'\n')
 try:p.wait(timeout=70)
 except subprocess.TimeoutExpired:
  timed=True;k=subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=5)
  killraw=k.stdout;(out/'taskkill.stdout.original').write_bytes(k.stdout);(out/'taskkill.stderr.original').write_bytes(k.stderr)
  p.kill();p.wait(timeout=5)
elapsed=time.monotonic()-start
after={'source_sha':git('rev-parse','HEAD').decode().strip(),'clean':git('status','--porcelain')==b''}
(out/'source-after.json').write_text(json.dumps(after)+'\n')
receipt={**intent,'pid':p.pid,'returncode':p.returncode,'timed_out':timed,'elapsed_seconds':elapsed,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':sha((out/'stdout.original').read_bytes()),'stderr_sha256':sha((out/'stderr.original').read_bytes()),'source_clean_after':after=={'source_sha':head,'clean':True}}
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
pids=sorted({p.pid}|{int(n) for n in re.findall(rb'process with PID\s+(\d+)',killraw)})
k32=ctypes.WinDLL('kernel32',use_last_error=True);k32.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k32.OpenProcess.restype=w.HANDLE;k32.GetExitCodeProcess.argtypes=[w.HANDLE,ctypes.POINTER(w.DWORD)];k32.GetExitCodeProcess.restype=w.BOOL;k32.CloseHandle.argtypes=[w.HANDLE]
observed=[]
for pid in pids:
 h=k32.OpenProcess(0x1000,False,pid)
 if not h:
  error=ctypes.get_last_error();observed.append({'pid':pid,'open_error':error,'status':'NOT_PRESENT' if error==87 else 'UNRESOLVED'})
 else:
  code=w.DWORD();ok=k32.GetExitCodeProcess(h,ctypes.byref(code));error=ctypes.get_last_error();k32.CloseHandle(h)
  observed.append({'pid':pid,'status':'ACTIVE' if ok and code.value==259 else 'EXITED' if ok else 'UNRESOLVED','exit_code':code.value if ok else None,'error':0 if ok else error})
reconcile={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owned_processes':observed,'no_owned_process_active':all(x['status'] in ['NOT_PRESENT','EXITED'] for x in observed)}
(out/'process-reconciliation.json').write_text(json.dumps(reconcile,indent=2)+'\n')
print(json.dumps(receipt));print(json.dumps(reconcile))
events=[json.loads(x) for x in (out/'cost-events.jsonl').read_text().splitlines()]
print(json.dumps({'event_count':len(events),'last_event':events[-1]}))
print((out/'stderr.original').read_text()[-6000:])
