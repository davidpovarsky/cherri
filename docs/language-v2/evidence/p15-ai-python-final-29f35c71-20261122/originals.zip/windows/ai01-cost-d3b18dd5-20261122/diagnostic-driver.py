"""One instrumented existing synthetic parent; never canonical proof."""
import functools
import hashlib
import json
import os
from pathlib import Path
import sys
import subprocess
import time
import unittest

repo, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(repo / "tools/language-ai-eval"))
import evaluation_bundle as eb
import evaluation_intake as intake
import test_evaluation_intake as cases

trace = open(output / "cost-events.jsonl", "x", encoding="utf-8", buffering=1)
aggregates = {}
sequence = 0

def event(kind, **fields):
    global sequence
    sequence += 1
    trace.write(json.dumps({"sequence": sequence, "event": kind,
        "monotonic": time.perf_counter(), **fields}, sort_keys=True)+"\n")
    trace.flush()

def measured(label, function, emit=False):
    @functools.wraps(function)
    def call(*args, **kwargs):
        before = time.perf_counter()
        status = "RETURNED"
        if emit:
            event("ENTER", operation=label)
        try:
            return function(*args, **kwargs)
        except BaseException as error:
            status = type(error).__name__
            raise
        finally:
            elapsed = time.perf_counter()-before
            row = aggregates.setdefault(label, {"calls": 0, "inclusive_seconds": 0.0,
                "max_seconds": 0.0, "errors": 0})
            row["calls"] += 1
            row["inclusive_seconds"] += elapsed
            row["max_seconds"] = max(row["max_seconds"], elapsed)
            row["errors"] += status != "RETURNED"
            if emit:
                event("LEAVE", operation=label, elapsed_seconds=elapsed,
                    status=status, aggregates=aggregates)
    return call

original_crypto = eb.crypto
original_run = subprocess.run
process_number = 0
def recorded_run(argv, *args, **kwargs):
    global process_number
    if Path(argv[0]).name.lower() not in ("openssl", "openssl.exe"):
        return original_run(argv, *args, **kwargs)
    process_number += 1
    number = process_number
    before = time.perf_counter()
    result = None
    error_name = None
    stdout = stderr = b""
    try:
        result = original_run(argv, *args, **kwargs)
        stdout, stderr = result.stdout, result.stderr
        return result
    except BaseException as error:
        error_name = type(error).__name__
        stdout, stderr = getattr(error, "stdout", b"") or b"", getattr(error, "stderr", b"") or b""
        raise
    finally:
        elapsed = time.perf_counter()-before
        originals = {}
        for stream, raw in (("stdout", stdout), ("stderr", stderr)):
            name = f"crypto-{number:02d}.{stream}.original"
            with open(output / name, "xb") as handle:
                handle.write(raw)
            originals[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        event("CRYPTO_PROCESS", argv=list(map(str, argv)),
            timeout_seconds=kwargs.get("timeout"), elapsed_seconds=elapsed,
            returncode=None if result is None else result.returncode,
            error_type=error_name, originals=originals)
subprocess.run = recorded_run

def crypto(*args):
    label = "crypto."+str(args[0])
    if "-sign" in args:
        label += ".sign"
    elif "-verify" in args:
        label += ".verify"
    elif "-pubin" in args:
        label += ".algorithm"
    elif "-pubout" in args:
        label += ".public-export"
    return measured(label, original_crypto, emit=True)(*args)
eb.crypto = crypto
for module, name, label in (
        (eb, "read_regular", "bundle.read_regular"),
        (intake, "read_regular", "intake.read_regular"),
        (eb, "write_new", "bundle.write_new"),
        (eb, "verify_signature", "bundle.verify_signature"),
        (os, "fstat", "filesystem.fstat")):
    setattr(module, name, measured(label, getattr(module, name)))
for name in ("resolve", "stat", "lstat", "open", "read_bytes", "write_bytes", "mkdir"):
    setattr(Path, name, measured("filesystem.Path."+name, getattr(Path, name)))
for name in ("setUp", "provider", "validator", "complete", "run_intake"):
    setattr(cases.IntakeTamperControls, name,
        measured("fixture."+name, getattr(cases.IntakeTamperControls, name), emit=True))
eb.seal_outcome = measured("bundle.seal_outcome", eb.seal_outcome, emit=True)

event("DIAGNOSTIC_START", scope="one existing synthetic twelve-outcome parent",
    canonical_regression_credit=False, model_calls=0, compiler_calls=0,
    aggregate_semantics="Inclusive categories overlap; do not sum nested timings.")
suite = unittest.TestSuite([cases.IntakeTamperControls(
    "test_mock_provider_and_graph_receipts_join_all_twelve_outcomes")])
result = unittest.TextTestRunner(verbosity=2, stream=sys.stderr).run(suite)
event("DIAGNOSTIC_END", tests_run=result.testsRun, failures=len(result.failures),
    errors=len(result.errors), skipped=len(result.skipped), aggregates=aggregates,
    canonical_regression_credit=False)
trace.close()
raise SystemExit(0 if result.wasSuccessful() else 1)
