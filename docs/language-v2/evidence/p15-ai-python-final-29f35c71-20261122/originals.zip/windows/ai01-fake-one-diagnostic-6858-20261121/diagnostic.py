import sys,unittest,json,time,traceback
from pathlib import Path
sys.path.insert(0,sys.argv[1]);out=Path(sys.argv[2])
name='test_runner.EvaluationHarnessTests.test_fake_subprocess_covers_both_arms_without_quality_score'
events=(out/'events.jsonl').open('x',encoding='utf-8')
class Result(unittest.TextTestResult):
 def emit(self,kind,test,err=None):
  detail=''.join(traceback.format_exception(*err)) if err else None
  events.write(json.dumps({'event':kind,'test':test.id(),'monotonic':time.monotonic(),'traceback':detail})+'\n');events.flush()
  if detail:sys.stderr.write(detail);sys.stderr.flush()
 def startTest(self,test):self.emit('START',test);super().startTest(test)
 def addSuccess(self,test):self.emit('PASS',test);super().addSuccess(test)
 def addError(self,test,err):self.emit('ERROR',test,err);super().addError(test,err)
 def addFailure(self,test,err):self.emit('FAIL',test,err);super().addFailure(test,err)
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(unittest.defaultTestLoader.loadTestsFromName(name))
events.close();sys.exit(0 if r.wasSuccessful() else 1)
