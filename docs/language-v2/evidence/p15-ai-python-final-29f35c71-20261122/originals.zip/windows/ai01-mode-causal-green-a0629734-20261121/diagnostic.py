import sys,unittest,json,time,traceback
from pathlib import Path
sys.path.insert(0,sys.argv[1]);out=Path(sys.argv[2])
ids=['test_evaluation_bundle.ProvenanceControls.test_windows_exe_execute_bits_do_not_confuse_file_identity','test_evaluation_bundle.ProvenanceControls.test_windows_same_handle_mode_change_still_rejects_after_read','test_evaluation_bundle.ProvenanceControls.test_other_cross_api_mode_changes_are_not_normalized','test_graph_validator.SixTaskGraphControls.test_oversized_original_remains_unadjudicated_and_is_not_read_or_deleted','test_graph_validator.SixTaskGraphControls.test_receipt_inventory_never_uses_unbounded_reads']
(out/'inventory.json').write_bytes((json.dumps(ids,indent=2)+'\n').encode())
events=(out/'events.jsonl').open('x',encoding='utf-8')
class Result(unittest.TextTestResult):
 def emit(self,kind,test,err=None):
  detail=''.join(traceback.format_exception(*err)) if err else None
  events.write(json.dumps({'event':kind,'test':test.id(),'monotonic':time.monotonic(),'traceback':detail})+'\n');events.flush()
  if detail:sys.stderr.write(detail);sys.stderr.flush()
 def startTest(self,test):self.emit('START',test);super().startTest(test)
 def addSuccess(self,test):self.emit('PASS',test);super().addSuccess(test)
 def addError(self,test,err):self.emit('ERROR',test,err);super().addError(test,err)
 def addFailure(self,test,err):self.emit('FAIL',test,err);super().addFailure(test,err)
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(unittest.defaultTestLoader.loadTestsFromNames(ids))
events.close();sys.exit(0 if r.wasSuccessful() else 1)
