from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time,re,ctypes,ctypes.wintypes as w
repo=Path(r'C:\Users\DAVID\Code\cherri-p10r15-ai-evaluation-20261121')
out=Path(r'C:\Users\DAVID\Code\cherri-p10r15-apple-analysis-20261119\ai01-clean-d3b18dd5-20261122')
out.mkdir(exist_ok=False)
(out/'submitted-wrapper.original.py').write_bytes(Path(__file__).read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,timeout=15)
head=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain=v1')
assert head=='d3b18dd5ec6933d8605c9d37943d062915b068d0' and status==b''
(out/'git-before.json').write_text(json.dumps({'head':head,'status':status.decode()})+'\n')
rows=[]
for line in git('ls-tree','-r','HEAD','--','tools/language-ai-eval').decode().splitlines():
 meta,path=line.split('\t');kind=meta.split();raw=(repo/path).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==kind[2],path
 rows.append({'path':path,'git_blob':kind[2],'sha256':sha(raw),'bytes':len(raw)})
(out/'source-bindings.json').write_text(json.dumps({'source_sha':head,'bindings':rows},indent=2)+'\n')
old=Path(r'C:\Users\DAVID\Code\cherri-p10r15-apple-analysis-20261119\ai01-clean-7481060a-20261121\run-controls.py')
driver=old.read_bytes();assert sha(driver)=='f12fc917ed3c1f1aefccdd0bc7eb5dc1d6a548290ef5105a9af36f26d351ecd0'
(out/'run-controls.py').write_bytes(driver)
selectors=['test_runner','test_evaluation_bundle','test_graph_validator','test_evaluation_intake','test_sealed_runner','test_anthropic_adapter']
argv=[sys.executable,str(out/'run-controls.py'),str(repo),str(out),json.dumps(selectors),'132']
intent={'source_sha':head,'argv':argv,'driver_sha256':sha(driver),'outer_budget_seconds':150,'unchanged_test_cli_budget_seconds':15,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
start=time.monotonic();timed=False;killraw=b''
with (out/'stdout.original').open('xb') as stdout,(out/'stderr.original').open('xb') as stderr:
 p=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
 (out/'process-start.json').write_text(json.dumps({'pid':p.pid,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv})+'\n')
 try:p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  timed=True
  k=subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=5)
  killraw=k.stdout;(out/'taskkill.stdout').write_bytes(k.stdout);(out/'taskkill.stderr').write_bytes(k.stderr)
  p.kill();p.wait(timeout=5)
elapsed=time.monotonic()-start
after={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain=v1').decode()}
(out/'git-after.json').write_text(json.dumps(after)+'\n')
events=[json.loads(x) for x in (out/'test-events.jsonl').read_text().splitlines()]
counts={key:sum(x['event']==key for x in events) for key in ['START','PASS','FAIL','ERROR','SKIP','SUBCASE_PASS','SUBCASE_FAIL']}
receipt={**intent,'pid':p.pid,'returncode':p.returncode,'timed_out':timed,'elapsed_seconds':elapsed,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'stderr_sha256':sha((out/'stderr.original').read_bytes()),'stdout_sha256':sha((out/'stdout.original').read_bytes()),'source_clean_after':after=={'head':head,'status':''}}
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
pids=sorted({p.pid}|{int(n) for n in re.findall(rb'process with PID\s+(\d+)',killraw)})
k32=ctypes.WinDLL('kernel32',use_last_error=True);k32.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k32.OpenProcess.restype=w.HANDLE;k32.GetExitCodeProcess.argtypes=[w.HANDLE,ctypes.POINTER(w.DWORD)];k32.GetExitCodeProcess.restype=w.BOOL;k32.CloseHandle.argtypes=[w.HANDLE]
observed=[]
for pid in pids:
 h=k32.OpenProcess(0x1000,False,pid)
 if not h:
  error=ctypes.get_last_error();observed.append({'pid':pid,'open_error':error,'status':'NOT_PRESENT' if error==87 else 'UNRESOLVED'})
 else:
  code=w.DWORD();ok=k32.GetExitCodeProcess(h,ctypes.byref(code));error=ctypes.get_last_error();k32.CloseHandle(h)
  observed.append({'pid':pid,'status':'ACTIVE' if ok and code.value==259 else 'EXITED' if ok else 'UNRESOLVED','exit_code':code.value if ok else None,'error':0 if ok else error})
reconciliation={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Win32 owned PID query only','owned_processes':observed,'no_owned_process_active':all(x['status'] in ['NOT_PRESENT','EXITED'] for x in observed)}
(out/'process-reconciliation.json').write_text(json.dumps(reconciliation,indent=2)+'\n')
print(json.dumps(receipt));print(json.dumps(reconciliation))
if p.returncode:print((out/'stderr.original').read_text(encoding='utf-8')[-18000:])
