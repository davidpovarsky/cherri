from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time,ast
repo=Path(r'C:\Users\DAVID\Code\cherri-p10r15-ai-evaluation-20261121')
out=Path(r'C:\Users\DAVID\Code\cherri-p10r15-apple-analysis-20261119\ai01-clean-7481060a-20261121')
out.mkdir(exist_ok=False)
(out/'submitted-wrapper.original.py').write_bytes(Path(__file__).read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,timeout=15)
head=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain=v1')
assert head=='7481060a0c3225f558f7a8205d3c5b29596f1640' and status==b''
(out/'git-before.json').write_text(json.dumps({'head':head,'status':status.decode()})+'\n')
rows=[]
for line in git('ls-tree','-r','HEAD','--','tools/language-ai-eval').decode().splitlines():
 meta,path=line.split('\t');kind=meta.split()
 raw=(repo/path).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==kind[2],path
 rows.append({'path':path,'git_blob':kind[2],'sha256':sha(raw),'bytes':len(raw)})
(out/'source-bindings.json').write_text(json.dumps({'source_sha':head,'bindings':rows},indent=2)+'\n')
driver=r'''from pathlib import Path
import sys,json,unittest,time,traceback
root=Path(sys.argv[1]); evidence=Path(sys.argv[2])
sys.path.insert(0,str(root/'tools/language-ai-eval'))
selectors=json.loads(sys.argv[3]);expected=int(sys.argv[4])
suite=unittest.defaultTestLoader.loadTestsFromNames(selectors)
def flatten(s):
 for item in s:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item
ids=[x.id() for x in flatten(suite)]
assert len(ids)==expected and len(set(ids))==expected,(len(ids),len(set(ids)))
(evidence/'inventory.json').write_text(json.dumps({'selectors':selectors,'testIds':ids,'count':len(ids)},indent=2)+'\n',encoding='utf-8')
events=(evidence/'test-events.jsonl').open('x',encoding='utf-8')
class Result(unittest.TextTestResult):
 def emit(self,event,test,detail=None):
  events.write(json.dumps({'event':event,'test':test.id(),'detail':detail,'monotonic':time.monotonic()})+'\n');events.flush()
 def immediate(self,test,err):
  sys.stderr.write('\nIMMEDIATE ORIGINAL EXCEPTION: '+test.id()+'\n')
  traceback.print_exception(*err,file=sys.stderr);sys.stderr.flush()
 def startTest(self,test):self.emit('START',test);super().startTest(test)
 def addSuccess(self,test):self.emit('PASS',test);super().addSuccess(test)
 def addFailure(self,test,err):self.emit('FAIL',test);self.immediate(test,err);super().addFailure(test,err)
 def addError(self,test,err):self.emit('ERROR',test);self.immediate(test,err);super().addError(test,err)
 def addSkip(self,test,reason):self.emit('SKIP',test,reason);super().addSkip(test,reason)
 def addSubTest(self,test,subtest,err):
  self.emit('SUBCASE_PASS' if err is None else 'SUBCASE_FAIL',test,str(subtest))
  if err is not None:self.immediate(test,err)
  super().addSubTest(test,subtest,err)
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
events.close()
(evidence/'test-result.json').write_text(json.dumps({'testsRun':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':[[x.id(),reason] for x,reason in r.skipped],'successful':r.wasSuccessful()},indent=2)+'\n')
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
'''
(out/'run-controls.py').write_text(driver,encoding='utf-8',newline='\n')
selector=['test_runner','test_evaluation_bundle','test_graph_validator','test_evaluation_intake','test_sealed_runner','test_anthropic_adapter']
argv=[sys.executable,str(out/'run-controls.py'),str(repo),str(out),json.dumps(selector),'132']
intent={'source_sha':head,'argv':argv,'driver_sha256':sha(driver.encode()),'outer_budget_seconds':150,'unchanged_test_cli_budget_seconds':15,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
start=time.monotonic();timed=False
with (out/'stdout.original').open('xb') as stdout,(out/'stderr.original').open('xb') as stderr:
 p=subprocess.Popen(argv,cwd=repo,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
 try:p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  timed=True
  k=subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=5)
  (out/'taskkill.stdout').write_bytes(k.stdout);(out/'taskkill.stderr').write_bytes(k.stderr)
  p.kill();p.wait(timeout=5)
elapsed=time.monotonic()-start
after={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain=v1').decode()}
(out/'git-after.json').write_text(json.dumps(after)+'\n')
events=[json.loads(x) for x in (out/'test-events.jsonl').read_text().splitlines()]
counts={key:sum(x['event']==key for x in events) for key in ['START','PASS','FAIL','ERROR','SKIP','SUBCASE_PASS','SUBCASE_FAIL']}
receipt={**intent,'returncode':p.returncode,'timed_out':timed,'elapsed_seconds':elapsed,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'stderr_sha256':sha((out/'stderr.original').read_bytes()),'source_clean_after':after=={'head':head,'status':''}}
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
if p.returncode:print((out/'stderr.original').read_text(encoding='utf-8')[:16000])
