import sys,unittest,json
from pathlib import Path
sys.path.insert(0,sys.argv[1])
root=Path(sys.argv[2])
suite=unittest.defaultTestLoader.loadTestsFromName('test_evaluation_intake')
def cases(s):
 for item in s:
  if isinstance(item,unittest.TestSuite):yield from cases(item)
  else:yield item
inventory=[t.id() for t in cases(suite)]
assert len(inventory)==11 and len(set(inventory))==11
(root/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):events.append({'id':test.id(),'event':'START'});super().startTest(test)
 def addSuccess(self,test):events.append({'id':test.id(),'event':'PASS'});super().addSuccess(test)
 def addError(self,test,error):events.append({'id':test.id(),'event':'ERROR'});super().addError(test,error)
 def addFailure(self,test,error):events.append({'id':test.id(),'event':'FAIL'});super().addFailure(test,error)
 def addSkip(self,test,reason):events.append({'id':test.id(),'event':'SKIP'});super().addSkip(test,reason)
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
(root/'events.json').write_text(json.dumps(events,indent=2),encoding='utf-8')
assert r.testsRun==11
sys.exit(0 if r.wasSuccessful() and not r.skipped else 1)
