import sys,json,time,importlib.util
from pathlib import Path
source=Path(sys.argv[1]);out=Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('exact_runner_diagnostic',source);runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
events=(out/'timings.jsonl').open('x',encoding='utf-8')
def emit(event,**fields):
 events.write(json.dumps({'event':event,'monotonic':time.monotonic(),**fields})+'\n');events.flush()
original_run=runner.run_process
def measured_run(command,request,timeout,originals=None):
 started=time.monotonic();emit('PROCESS_START',kind=command[-1],request_id=request['request_id'],timeout=timeout)
 try:return original_run(command,request,timeout,originals)
 finally:emit('PROCESS_END',kind=command[-1],request_id=request['request_id'],elapsed_seconds=time.monotonic()-started)
original_atomic=runner.atomic_json
def measured_atomic(path,value):
 started=time.monotonic();emit('ATOMIC_START',name=Path(path).name)
 try:return original_atomic(path,value)
 finally:emit('ATOMIC_END',name=Path(path).name,elapsed_seconds=time.monotonic()-started)
original_fsync=runner.os.fsync
def measured_fsync(fd):
 started=time.monotonic();emit('FSYNC_START')
 try:return original_fsync(fd)
 finally:emit('FSYNC_END',elapsed_seconds=time.monotonic()-started)
runner.run_process=measured_run;runner.atomic_json=measured_atomic;runner.os.fsync=measured_fsync
arguments=['--output',str(out/'report.json'),'--fake','--model','control-model','--legacy-guide',str(out/'guide.md'),'--v2-guide',str(out/'guide.md')]
emit('MAIN_START',argv=arguments)
try:status=runner.main(arguments)
finally:emit('MAIN_END');events.close()
raise SystemExit(status)
