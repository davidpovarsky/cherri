from pathlib import Path
import json,subprocess,hashlib,os,time,shutil
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-remaining-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-remaining-oracles")
assert subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()=="a497430c36e131c74b42383cf79c9fdbfe8a07ce"
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
p=W/"p15_hybrid_native_loop_result_test.go";s=p.read_text(encoding="utf-8")
old='''\t\t\t\t\tif plan.NaturalVerifiedCount != len(doc.Actions)-body.fallback {
\t\t\t\t\t\tt.Fatalf("unexpected native fixture classification: %+v", plan.Decisions)
\t\t\t\t\t}'''
new='''\t\t\t\t\t// The preserved parameter-free Nothing also requires an exact
\t\t\t\t\t// native escape. Assert its position and every other decision.
\t\t\t\t\tif plan.NaturalVerifiedCount != len(doc.Actions)-body.fallback-1 ||
\t\t\t\t\t\tplan.ExactNativeCount != body.fallback+1 || len(plan.Decisions) != len(doc.Actions) {
\t\t\t\t\t\tt.Fatalf("unexpected native fixture classification: %+v", plan.Decisions)
\t\t\t\t\t}
\t\t\t\t\tfor i, decision := range plan.Decisions {
\t\t\t\t\t\twant := "NATURAL_VERIFIED"
\t\t\t\t\t\tif i == len(doc.Actions)-2 || body.name == "empty_list" && i == 1 {
\t\t\t\t\t\t\twant = "EXACT_NATIVE_FALLBACK"
\t\t\t\t\t\t}
\t\t\t\t\t\tif decision.ActionIndex != i || string(decision.Classification) != want {
\t\t\t\t\t\t\tt.Fatalf("native action %d classification changed: %+v, want %s", i, decision, want)
\t\t\t\t\t\t}
\t\t\t\t\t}'''
assert s.count(old)==1
(E/"hybrid-classification.original").write_bytes(p.read_bytes());p.write_text(s.replace(old,new),encoding="utf-8",newline="\n")
control=W/"p15_main_output_oracle_controls_test.go"
assert not control.exists()
control.write_text('''package main

import "testing"

func TestP15M02MainVoidBoundaryRejectsMalformedFinalActions(t *testing.T) {
\tactual := p15CompiledActions(t, "text(\\\"M02_COMPLETE_GRAPH_CONTROL\\\")")
\tif err := p15M02MainVoidBoundaryError(actual); err != nil {
\t\tt.Fatal(err)
\t}
\tfor _, fault := range []string{"missing", "wrong_identifier", "implicit_input", "malformed_parameters", "null_parameters", "extra_envelope"} {
\t\tt.Run(fault, func(t *testing.T) {
\t\t\tchanged := p15C01Clone(t, actual)
\t\t\tlast := changed[len(changed)-1]
\t\t\tswitch fault {
\t\t\tcase "missing":
\t\t\t\tchanged = changed[:len(changed)-1]
\t\t\tcase "wrong_identifier":
\t\t\t\tlast["WFWorkflowActionIdentifier"] = "is.workflow.actions.getvariable"
\t\t\tcase "implicit_input":
\t\t\t\tlast["WFWorkflowActionParameters"] = map[string]any{"WFInput": "unowned"}
\t\t\tcase "malformed_parameters":
\t\t\t\tlast["WFWorkflowActionParameters"] = []any{}
\t\t\tcase "null_parameters":
\t\t\t\tlast["WFWorkflowActionParameters"] = nil
\t\t\tcase "extra_envelope":
\t\t\t\tlast["P15UnexpectedResult"] = true
\t\t\t}
\t\t\tif p15M02MainVoidBoundaryError(changed) == nil {
\t\t\t\tt.Fatal("malformed terminal action passed the complete-main boundary", fault)
\t\t\t}
\t\t})
\t}
}
''',encoding="utf-8",newline="\n")
subprocess.run(["gofmt","-w",p.name,control.name],cwd=W,check=True,capture_output=True)
subprocess.run(["git","--no-replace-objects","diff","--check"],cwd=W,check=True,capture_output=True)
subprocess.run(["git","--no-replace-objects","-c","core.autocrlf=false","add","--",p.name,control.name],cwd=W,check=True,capture_output=True)
q=subprocess.run(["git","--no-replace-objects","commit","-m","test: verify preserved empty-result classification and malformed boundaries"],cwd=W,capture_output=True)
(E/"classification-commit.stdout").write_bytes(q.stdout);(E/"classification-commit.stderr").write_bytes(q.stderr);assert q.returncode==0
head=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
T=E/"focused-clean";T.mkdir(exist_ok=False);(T/"launcher.py").write_bytes(Path(__file__).read_bytes())
assert shutil.disk_usage(W).free>=2*1024**3
pattern="^(TestP15(HybridNative.*|L02IndexBoundaryWire|L04.*|F02Loop.*|RP22Loop.*|RP33.*|Native.*|T03NumberString.*|N01.*|M02.*|V02.*|EmptyList.*|C04.*|Filter.*)|TestBackendRecovery12Loop.*)$"
command=["go","test","-count=1","-json","-timeout=15m","-run",pattern,"."]
env=os.environ.copy();env["CHERRI_TEST_BASH"]=r"C:\Program Files\Git\bin\bash.exe"
meta={"source":head,"command":command,"sourceCleanBefore":True,"formalAcceptanceGranted":False,"productionChanged":False}
(T/"started.json").write_text(json.dumps(meta,indent=2)+"\n",encoding="utf-8")
start=time.monotonic()
with (T/"stdout.jsonl").open("wb") as out,(T/"stderr.log").open("wb") as err:
 child=subprocess.Popen(command,cwd=W,env=env,stdout=out,stderr=err)
 timed=False
 try:code=child.wait(timeout=975)
 except subprocess.TimeoutExpired:
  timed=True
  kill=subprocess.run(["taskkill","/PID",str(child.pid),"/T","/F"],capture_output=True,timeout=30)
  (T/"taskkill.stdout").write_bytes(kill.stdout);(T/"taskkill.stderr").write_bytes(kill.stderr)
  child.wait(timeout=30);code=child.returncode
events=[json.loads(x) for x in (T/"stdout.jsonl").read_text(encoding="utf-8").splitlines()]
result={**meta,"exitCode":code,"timedOut":timed,"durationSeconds":round(time.monotonic()-start,3),"counts":{a:sum(e.get("Action")==a and bool(e.get("Test")) for e in events) for a in ["run","pass","fail","skip"]},"failures":[e["Test"] for e in events if e.get("Action")=="fail" and e.get("Test")],"stdoutSHA256":hashlib.sha256((T/"stdout.jsonl").read_bytes()).hexdigest(),"sourceCleanAfter":not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip(),"headAfter":subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()}
(T/"summary.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
