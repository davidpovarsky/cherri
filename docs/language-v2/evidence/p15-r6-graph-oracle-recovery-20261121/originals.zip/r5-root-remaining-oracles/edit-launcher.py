from pathlib import Path
import subprocess,json,hashlib
BASE=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-regressions-r5-20261120")
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-remaining-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-remaining-oracles")
assert not W.exists() and not E.exists()
base=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=BASE).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=BASE).strip()
subprocess.run(["git","--no-replace-objects","worktree","add","-b","audit/cherri-p10r15-root-remaining-r5-20261120",str(W),base],cwd=BASE,check=True,capture_output=True)
E.mkdir();(E/"edit-launcher.py").write_bytes(Path(__file__).read_bytes())
sources={};originals={}
def edit(name,old,new,count=1):
 s=sources.get(name)
 if s is None:s=(W/name).read_text(encoding="utf-8");originals[name]=(W/name).read_bytes()
 assert s.count(old)==count,(name,s.count(old),old[:90])
 sources[name]=s.replace(old,new)
edit("p15_main_void_return_test.go",'''\tif last["WFWorkflowActionIdentifier"] != "is.workflow.actions.nothing" || len(p15Param(last)) != 0 {
\t\treturn fmt.Errorf("main fallthrough does not clear unused native output: final=%#v", last)
\t}''','''\tif last["WFWorkflowActionIdentifier"] != "is.workflow.actions.nothing" {
\t\treturn fmt.Errorf("main fallthrough does not clear unused native output: final=%#v", last)
\t}
\tfor key := range last {
\t\tif key != "WFWorkflowActionIdentifier" && key != "WFWorkflowActionParameters" {
\t\t\treturn fmt.Errorf("main empty result acquired an unexpected envelope field %s", key)
\t\t}
\t}
\tif raw, present := last["WFWorkflowActionParameters"]; present {
\t\tparameters, okay := raw.(map[string]any)
\t\tif !okay || len(parameters) != 0 {
\t\t\treturn fmt.Errorf("main empty result has nonempty or malformed parameters: %#v", raw)
\t\t}
\t}''')
edit("p15_main_output_oracle_test.go","import \"fmt\"","import \"fmt\"")
sources["p15_main_output_oracle_test.go"]+='''

// Preserve the entire decoded action sequence; this checks only its explicit
// authored-main boundary. Each caller also asserts its complete scenario.
func p15M02MainVoidDebugError(actions []ShortcutAction) error {
\tif len(actions) == 0 {
\t\treturn fmt.Errorf("main fallthrough has no explicit empty result")
\t}
\tlast := actions[len(actions)-1]
\tif last.WFWorkflowActionIdentifier != "is.workflow.actions.nothing" || len(last.WFWorkflowActionParameters) != 0 {
\t\treturn fmt.Errorf("main fallthrough has no exact empty terminal action")
\t}
\tif last.rawNativeEnvelope != nil {
\t\treturn p15M02MainVoidBoundaryError([]map[string]any{last.rawNativeEnvelope})
\t}
\treturn nil
}
'''
edit("p15_hybrid_output_name_presence_test.go",'''\tif !ok || len(actions) != 2 {
\t\tt.Fatal("synthetic output-name fixture must contain two actions")
\t}''','''\tif !ok || len(actions) != 3 {
\t\tt.Fatal("synthetic output-name fixture must contain the producer, consumer, and empty main result")
\t}
\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\tif actions[0].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.number" ||
\t\tactions[1].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" {
\t\tt.Fatal("synthetic output-name producer or consumer order changed")
\t}''')
edit("p15_indexing_acceptance_test.go",'''\t\t\tnothing := -1
\t\t\tfor i, a := range actions {''','''\t\t\tif err := p15M02MainVoidBoundaryError(actions); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tnothing, emptyValues := -1, 0
\t\t\tfor i, a := range actions {''')
edit("p15_indexing_acceptance_test.go",'''\t\t\t\tif a["WFWorkflowActionIdentifier"] == "is.workflow.actions.nothing" {
\t\t\t\t\tnothing = i
\t\t\t\t}''','''\t\t\t\tif a["WFWorkflowActionIdentifier"] == "is.workflow.actions.nothing" && i != len(actions)-1 {
\t\t\t\t\tnothing = i
\t\t\t\t\temptyValues++
\t\t\t\t}''')
edit("p15_indexing_acceptance_test.go",'''\t\t\tif nothing < 0 || !p15IndexOutput(p15Param(actions[len(actions)-1])["WFVariable"], p15Param(actions[nothing])["UUID"]) {''','''\t\t\tif emptyValues != 1 || nothing != len(actions)-3 ||
\t\t\t\tactions[len(actions)-2]["WFWorkflowActionIdentifier"] != "is.workflow.actions.getvariable" ||
\t\t\t\t!p15IndexOutput(p15Param(actions[len(actions)-2])["WFVariable"], p15Param(actions[nothing])["UUID"]) {''')
edit("p15_loop_identity_native_oracle_test.go",'''\tif c.at != len(actions) || len(c.stack) != 0 {''','''\tif err := p15M02MainVoidBoundaryError(actions); err != nil {
\t\treturn err
\t}
\tif c.at != len(actions)-1 || len(c.stack) != 0 {''')
edit("p15_migration_native_literal_test.go",'''\t\t\tbefore, err := CompileSourceToPlist("rp33-before.cherri", fixture.source)''','''\t\t\t// Migration preserves the original program's Legacy output policy.
\t\t\t// Give this canonical native snippet that explicit policy before
\t\t\t// comparing complete workflow bytes, including its final action.
\t\t\tbefore, err := CompileSourceToPlist("rp33-before.cherri", "shortcut \\\"\\\" { outputMode: \\\"legacy\\\" }\\n"+fixture.source)''')
edit("p15_migration_reference_wire_test.go",'''\t\t\tif len(actions) != 2 || actions[0].WFWorkflowActionIdentifier''','''\t\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tif len(actions) != 3 || actions[0].WFWorkflowActionIdentifier''')
edit("p15_migration_structure_test.go",'''\tif len(program.Declarations) != 1 || len(program.Statements) != 2 {
\t\tt.Fatal("reference source structure changed", converted)
\t}
\tfunction := program.Declarations[0].(*syntax.FunctionDecl)''','''\tparts := p15RP33Parts(program)
\tif len(program.Declarations) != 2 || len(program.Statements) != 2 ||
\t\tparts.shortcut == nil || parts.function == nil || parts.shortcut.Name != "" ||
\t\tparts.shortcut.Metadata == nil || len(parts.shortcut.Metadata.Fields) != 1 {
\t\tt.Fatal("reference source structure changed", converted)
\t}
\tpolicy := parts.shortcut.Metadata.Fields[0]
\tvalue, okay := policy.Value.(*syntax.LiteralExpr)
\tif policy.Name != "outputMode" || !okay || value.Type != syntax.TokenString || value.Value != "legacy" {
\t\tt.Fatal("reference migration lost its explicit original output policy", converted)
\t}
\tfunction := parts.function''')
edit("p15_native_condition_operands_test.go",'''\tif len(actions) != 5 {''','''\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\treturn err
\t}
\tif len(actions) != 6 {''')
edit("p15_native_envelope_test.go",'''\t\t\t\twant := p15NormalizedNativeActions(t, []any{envelope})''','''\t\t\t\twantRows := []any{envelope}
\t\t\t\tif !legacy {
\t\t\t\t\twantRows = append(wantRows, map[string]any{"WFWorkflowActionIdentifier": "is.workflow.actions.nothing"})
\t\t\t\t}
\t\t\t\twant := p15NormalizedNativeActions(t, wantRows)''')
edit("p15_native_envelope_test.go",'''\t\t\texpected := p15NormalizedNativeActions(t, []any{p15AcceptanceAction("com.example.p15.old-params", params)})''','''\t\t\twantRows := []any{p15AcceptanceAction("com.example.p15.old-params", params)}
\t\t\tif !legacy {
\t\t\t\twantRows = append(wantRows, map[string]any{"WFWorkflowActionIdentifier": "is.workflow.actions.nothing"})
\t\t\t}
\t\t\texpected := p15NormalizedNativeActions(t, wantRows)''')
edit("p15_native_envelope_test.go",'''\t\tif !plistValuesStrictlyEqual(p15NormalizedNativeActions(t, []any{edited}), actual["WFWorkflowActions"]) {''','''\t\twantRows := []any{edited}
\t\tif !legacy {
\t\t\twantRows = append(wantRows, map[string]any{"WFWorkflowActionIdentifier": "is.workflow.actions.nothing"})
\t\t}
\t\tif !plistValuesStrictlyEqual(p15NormalizedNativeActions(t, wantRows), actual["WFWorkflowActions"]) {''')
edit("p15_native_metadata_test.go",'''\tif len(actions) != 1 {
\t\tt.Fatalf("raw metadata materialized %d runtime actions instead of exactly one explicit native action", len(actions))
\t}''','''\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\tif len(actions) != 2 {
\t\tt.Fatalf("raw metadata must retain exactly one explicit native action and the empty main result, got %d actions", len(actions))
\t}''')
edit("p15_native_output_name_test.go",'''\t\t\tif len(doc.Actions) != 1 {
\t\t\t\tt.Fatalf("expected one native Text action, got %d", len(doc.Actions))
\t\t\t}''','''\t\t\tif err := p15M02MainVoidRowsError(doc.RawRoot["WFWorkflowActions"].([]any)); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tif len(doc.Actions) != 2 || doc.RawRoot["WFWorkflowActions"].([]any)[0].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" {
\t\t\t\tt.Fatalf("expected the native Text action and empty main result, got %d", len(doc.Actions))
\t\t\t}''')
edit("p15_number_text_acceptance_test.go",'''func p15T03LiteralWire(actions []ShortcutAction, nativeID, nativeKey, literal string) error {
\tif len(actions) != 2''','''func p15T03LiteralWire(actions []ShortcutAction, nativeID, nativeKey, literal string, legacy bool) error {
\tcount := 2
\tif !legacy {
\t\tcount++
\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\treturn err
\t\t}
\t}
\tif len(actions) != count''')
edit("p15_number_text_acceptance_test.go","p15T03LiteralWire(actions, nativeID, nativeKey, literal)","p15T03LiteralWire(actions, nativeID, nativeKey, literal, legacy)")
edit("p15_number_text_acceptance_test.go","p15T03LiteralWire(broken, nativeID, nativeKey, literal)","p15T03LiteralWire(broken, nativeID, nativeKey, literal, legacy)")
edit("p15_number_text_acceptance_test.go",'''\t\tif len(actions) != 1 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.round"''','''\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\tt.Fatal(err)
\t\t}
\t\tif len(actions) != 2 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.round"''')
edit("p15_number_text_acceptance_test.go",'''\tif len(actions) != 3 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.gettext"''','''\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\tif len(actions) != 4 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.gettext"''')
edit("p15_numeric_fraction_acceptance_test.go",'''func p15N01GraphResult(actions []map[string]any) (float64, error) {
\tvar outputs''','''func p15N01GraphResult(actions []map[string]any) (float64, error) {
\tif err := p15M02MainVoidBoundaryError(actions); err != nil {
\t\treturn 0, err
\t}
\tvar outputs''')
edit("p15_numeric_fraction_acceptance_test.go",'''\t\t"setclipboard": {"WFInput"},''','''\t\t"setclipboard": {"WFInput"},
\t\t"nothing":      {},''')
edit("p15_numeric_fraction_acceptance_test.go",'''\t\tcase "number":
\t\t\tnumber, err''','''\t\tcase "nothing":
\t\t\tif index != len(actions)-1 {
\t\t\t\treturn 0, fmt.Errorf("unexpected empty result inside numeric dataflow")
\t\t\t}
\t\t\tcontinue
\t\tcase "number":
\t\t\tnumber, err''')
edit("p15_numeric_fraction_acceptance_test.go","err != nil || index != len(actions)-1","err != nil || index != len(actions)-2")
edit("p15_numeric_fraction_acceptance_test.go",'''"rounding", "missing_observation"''','''"rounding", "missing_observation", "missing_main_result", "nonempty_main_result"''')
edit("p15_numeric_fraction_acceptance_test.go",'p15C01Params(broken[len(broken)-1])["WFInput"]','p15C01Params(broken[len(broken)-2])["WFInput"]')
edit("p15_numeric_fraction_acceptance_test.go",'''\t\t\tcase "missing_observation":
\t\t\t\tbroken = broken[:len(broken)-1]''','''\t\t\tcase "missing_observation":
\t\t\t\tbroken = append(broken[:len(broken)-2], broken[len(broken)-1])
\t\t\tcase "missing_main_result":
\t\t\t\tbroken = broken[:len(broken)-1]
\t\t\tcase "nonempty_main_result":
\t\t\t\tbroken[len(broken)-1]["WFWorkflowActionParameters"] = map[string]any{"WFInput": "incidental-value"}''')
for name,s in sources.items():
 (E/(name+".original")).write_bytes(originals[name]);(W/name).write_text(s,encoding="utf-8",newline="\n")
subprocess.run(["gofmt","-w",*sources],cwd=W,check=True,capture_output=True)
subprocess.run(["git","--no-replace-objects","diff","--check"],cwd=W,check=True,capture_output=True)
diff=subprocess.check_output(["git","--no-replace-objects","diff"],cwd=W);(E/"changes.diff").write_bytes(diff)
subprocess.run(["git","--no-replace-objects","-c","core.autocrlf=false","add","--",*sources],cwd=W,check=True,capture_output=True)
q=subprocess.run(["git","--no-replace-objects","commit","-m","test: preserve full native graphs and explicit source output policies"],cwd=W,capture_output=True)
(E/"commit.stdout").write_bytes(q.stdout);(E/"commit.stderr").write_bytes(q.stderr);assert q.returncode==0
head=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
result={"base":base,"source":head,"changed":list(sources),"productionChanged":False,"clean":True,"diffSHA256":hashlib.sha256(diff).hexdigest()}
(E/"source.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
