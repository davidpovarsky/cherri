from pathlib import Path
import subprocess,json,hashlib
B=Path(r"C:\Users\DAVID\Code");Eroot=B/"cherri-p10r15-continuation-evidence-20261119"
def g(w,*a):return subprocess.check_output(["git","--no-replace-objects",*a],cwd=w)
def seal(w,e,paths,message):
 subprocess.run(["gofmt","-w",*paths],cwd=w,capture_output=True,check=True);g(w,"diff","--check")
 (e/"changes.diff").write_bytes(g(w,"diff"));g(w,"-c","core.autocrlf=false","add","--",*paths)
 q=subprocess.run(["git","--no-replace-objects","commit","-m",message],cwd=w,capture_output=True)
 (e/"commit.stdout").write_bytes(q.stdout);(e/"commit.stderr").write_bytes(q.stderr);assert q.returncode==0
 assert not g(w,"status","--porcelain").strip()
 return g(w,"rev-parse","HEAD").decode().strip()

W=B/"cherri-p10r15-root-final-oracles-r5-20261120";E=Eroot/"r5-root-final-oracles"
assert g(W,"rev-parse","HEAD").decode().strip()=="e335e5cc2068e95944861799535a4d4806059507" and not g(W,"status","--porcelain").strip()
failed=json.loads((E/"focused-clean-callers/summary.json").read_bytes());assert failed["counts"]["fail"]==12 and failed["exitCode"]==1
D=E/"explicit-legacy-snapshot-and-literal-setter";D.mkdir(exist_ok=False);(D/"launcher.py").write_bytes(Path(__file__).read_bytes())
files=["p15_variadic_structure_test.go","p15_legacy_inline_test.go","p15_setter_mode_roundtrip_test.go"]
sources={}
for n in files:
 raw=(W/n).read_bytes();(D/(n+".original")).write_bytes(raw);sources[n]=raw.decode()
def edit(n,a,b,count=1):
 assert sources[n].count(a)==count,(n,a,sources[n].count(a))
 sources[n]=sources[n].replace(a,b)
edit("p15_variadic_structure_test.go",'''func p15C03SnapshotOracle(actions []ShortcutAction) error {
\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\treturn err
\t}''','''func p15C03SnapshotOracle(actions []ShortcutAction, mainLegacy bool) error {
\tif !mainLegacy {
\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\treturn err
\t\t}
\t}''')
edit("p15_variadic_structure_test.go","p15C03SnapshotOracle(actions)","p15C03SnapshotOracle(actions, false)")
edit("p15_variadic_structure_test.go","p15C03SnapshotOracle(broken)","p15C03SnapshotOracle(broken, false)")
n="p15_legacy_inline_test.go"
for expr in ["actions","broken"]:
 needle="p15C03SnapshotOracle("+expr+")";count=sources[n].count(needle)
 assert count>0,(needle,count)
 edit(n,needle,"p15C03SnapshotOracle("+expr+", true)",count)
n="p15_setter_mode_roundtrip_test.go"
edit(n,'''\t\t\t\t\tif len(actions) != 3 {
\t\t\t\t\t\tt.Fatal("literal input, setter, and main result changed cardinality")
\t\t\t\t\t}''','''\t\t\t\t\twant := 3
\t\t\t\t\tif action == "editEvent" {
\t\t\t\t\t\t// Calendar's native variable codec materializes the literal;
\t\t\t\t\t\t// Reminder's Text field retains the direct scalar.
\t\t\t\t\t\twant++
\t\t\t\t\t}
\t\t\t\t\tif len(actions) != want || actions[0]["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" ||
\t\t\t\t\t\tp15Param(actions[0])["WFTextActionText"] != "PUBLIC_SYNTHETIC_TARGET" {
\t\t\t\t\t\tt.Fatal("literal input, setter, and main result changed cardinality or identity")
\t\t\t\t\t}
\t\t\t\t\tif action == "editEvent" && (actions[1]["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" ||
\t\t\t\t\t\tp15Param(actions[1])["WFTextActionText"] != value) {
\t\t\t\t\t\tt.Fatal("Calendar lost the exact literal value producer")
\t\t\t\t\t}''')
edit(n,'''\t\t\t\t\tp := p15Param(last)
\t\t\t\t\tif last["WFWorkflowActionIdentifier"]''','''\t\t\t\t\tp := p15Param(last)
\t\t\t\t\ttarget, okay := p15Param(actions[0])["UUID"].(string)
\t\t\t\t\tif !okay || target == "" || requireOutputUUID(p["WFInput"]) != target {
\t\t\t\t\t\tt.Fatal("setter lost the actual target producer")
\t\t\t\t\t}
\t\t\t\t\tif last["WFWorkflowActionIdentifier"]''')
for n,s in sources.items():(W/n).write_bytes(s.encode())
head=seal(W,D,files,"test: retain explicit Legacy snapshots and literal setter codecs")
meta=json.loads((E/"source.json").read_bytes());(D/"previous-source.json").write_bytes((E/"source.json").read_bytes());meta["source"]=head
(E/"source.json").write_bytes((json.dumps(meta,indent=2)+"\n").encode());print(json.dumps({"component":"W4","source":head,"productionChanged":False}))

W=B/"cherri-p10r15-root-boundaries-r5-20261120";E=Eroot/"r5-root-boundary-oracles"
assert g(W,"rev-parse","HEAD").decode().strip()=="6d9881c69352474c5cad392768aa712d07ba9d1c" and not g(W,"status","--porcelain").strip()
red=json.loads((E/"paginate-input-peer-red/summary.json").read_bytes());assert red["exitCode"]==1 and red["counts"]=={"run":6,"pass":3,"fail":3,"skip":0}
D=E/"paginate-input-peer-repair";D.mkdir(exist_ok=False);(D/"launcher.py").write_bytes(Path(__file__).read_bytes())
name="p15_paginate_result_oracle_test.go";p=W/name;raw=p.read_bytes();s=raw.decode();(D/"original.go").write_bytes(raw)
s=s.replace('\t"fmt"\n','\t"fmt"\n\t"reflect"\n',1)
marker='''\tuuid, okay := actions[consumer-1].WFWorkflowActionParameters["UUID"].(string)
'''
assert s.count(marker)==1
addition='''\t// Bind the result read to the actual empty List initializer and the
\t// native item append in this fixture. An arbitrary existing variable
\t// (including the separate seen-URL list) is not its result aggregate.
\tattachment := func(raw any, kind string) (map[string]any, error) {
\t\touter, okay := raw.(map[string]any)
\t\tif !okay || len(outer) != 2 || outer["WFSerializationType"] != "WFTextTokenAttachment" {
\t\t\treturn nil, fmt.Errorf("pagination aggregate lost native attachment")
\t\t}
\t\tvalue, okay := outer["Value"].(map[string]any)
\t\tif !okay || value["Type"] != kind {
\t\t\treturn nil, fmt.Errorf("pagination aggregate attachment kind changed")
\t\t}
\t\tkey := "OutputUUID"
\t\tif kind == "Variable" {
\t\t\tkey = "VariableName"
\t\t}
\t\tid, okay := value[key].(string)
\t\tif !okay || id == "" {
\t\t\treturn nil, fmt.Errorf("pagination aggregate attachment has no concrete identity")
\t\t}
\t\tfor field := range value {
\t\t\tif field != "Type" && field != key && !(kind == "ActionOutput" && field == "OutputName") {
\t\t\t\treturn nil, fmt.Errorf("pagination aggregate attachment gained a transformation")
\t\t\t}
\t\t}
\t\treturn value, nil
\t}
\tif consumer < 3 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.list" ||
\t\tactions[1].WFWorkflowActionIdentifier != "is.workflow.actions.setvariable" {
\t\treturn fmt.Errorf("pagination aggregate initialization order changed")
\t}
\titems := reflect.ValueOf(actions[0].WFWorkflowActionParameters["WFItems"])
\tif !items.IsValid() || items.Kind() != reflect.Slice || items.IsNil() || items.Len() != 0 {
\t\treturn fmt.Errorf("pagination aggregate must start as an actual empty List")
\t}
\temptyID, okay := actions[0].WFWorkflowActionParameters["UUID"].(string)
\tname, named := actions[1].WFWorkflowActionParameters["WFVariableName"].(string)
\tif !okay || emptyID == "" || !named || name == "" {
\t\treturn fmt.Errorf("pagination aggregate initializer lost identity")
\t}
\tinitial, err := attachment(actions[1].WFWorkflowActionParameters["WFInput"], "ActionOutput")
\tif err != nil || initial["OutputUUID"] != emptyID {
\t\treturn fmt.Errorf("pagination aggregate does not store its original empty List")
\t}
\tread, err := attachment(actions[consumer-1].WFWorkflowActionParameters["WFVariable"], "Variable")
\tif err != nil || read["VariableName"] != name {
\t\treturn fmt.Errorf("pagination result reads another aggregate")
\t}
\tstores, appends, emptyOwners := 0, 0, 0
\tfor index, action := range actions[:consumer-1] {
\t\tparams := action.WFWorkflowActionParameters
\t\tif params["UUID"] == emptyID {
\t\t\temptyOwners++
\t\t}
\t\tif params["WFVariableName"] != name {
\t\t\tcontinue
\t\t}
\t\tif action.WFWorkflowActionIdentifier == "is.workflow.actions.setvariable" {
\t\t\tstores++
\t\t}
\t\tif action.WFWorkflowActionIdentifier != "is.workflow.actions.appendvariable" {
\t\t\tcontinue
\t\t}
\t\tappends++
\t\titem, err := attachment(params["WFInput"], "ActionOutput")
\t\tif err != nil {
\t\t\treturn err
\t\t}
\t\titemOwners := 0
\t\tfor _, prior := range actions[:index] {
\t\t\tif prior.WFWorkflowActionParameters["UUID"] != item["OutputUUID"] {
\t\t\t\tcontinue
\t\t\t}
\t\t\titemOwners++
\t\t\tinput, err := attachment(prior.WFWorkflowActionParameters["WFVariable"], "Variable")
\t\t\tif prior.WFWorkflowActionIdentifier != "is.workflow.actions.getvariable" || err != nil ||
\t\t\t\tinput["VariableName"] != "Repeat Item" {
\t\t\t\treturn fmt.Errorf("pagination aggregate append lost the original native item")
\t\t\t}
\t\t}
\t\tif itemOwners != 1 {
\t\t\treturn fmt.Errorf("pagination aggregate append has %d prior item owners", itemOwners)
\t\t}
\t}
\tif stores != 1 || appends != 1 || emptyOwners != 1 {
\t\treturn fmt.Errorf("pagination aggregate ownership changed: stores=%d appends=%d initializerOwners=%d", stores, appends, emptyOwners)
\t}
'''
s=s.replace(marker,addition+marker);p.write_bytes(s.encode())
head=seal(W,D,[name],"test: bind paginate result to initialized and populated aggregate")
(D/"source.json").write_bytes((json.dumps({"source":head,"redSource":red["source"],"productionChanged":False},indent=2)+"\n").encode())
print(json.dumps({"component":"paginate-peer-repair","source":head,"productionChanged":False}))
