from pathlib import Path
import subprocess,json,hashlib
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-boundaries-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-boundary-oracles")
red=json.loads((E/"paginate-oracle-red/summary.json").read_bytes())
assert red["source"]=="f000f393e6a57960100c8110c826cd876065e182" and red["exitCode"]==1 and red["counts"]=={"run":4,"pass":0,"fail":4,"skip":0}
assert subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()==red["source"]
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
(E/"edit-launcher-retry1.py").write_bytes(Path(__file__).read_bytes())
sources={};originals={}
def edit(name,old,new,count=1):
 s=sources.get(name)
 if s is None:s=(W/name).read_text(encoding="utf-8");originals[name]=(W/name).read_bytes()
 assert s.count(old)==count,(name,s.count(old),old[:110])
 sources[name]=s.replace(old,new)
edit("p15_optional_presence_acceptance_test.go",'''func p15T05FlatWire(actions []ShortcutAction, tc p15T05PresenceCase) error {
\tif len(actions) != 1''','''func p15T05FlatWire(actions []ShortcutAction, tc p15T05PresenceCase) error {
\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\treturn err
\t}
\tif len(actions) != 2''')
edit("p15_optional_presence_acceptance_test.go",'''func p15T05EmptyContainerWire(actions []ShortcutAction) error {
\tif len(actions) != 2''','''func p15T05EmptyContainerWire(actions []ShortcutAction) error {
\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\treturn err
\t}
\tif len(actions) != 3''')
edit("p15_optional_presence_acceptance_test.go",'''\tif len(actions) != 2 || actions[0].WFWorkflowActionParameters["WFTextActionText"]''','''\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\tif len(actions) != 3 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.gettext" ||
\t\tactions[1].WFWorkflowActionIdentifier != "is.workflow.actions.showresult" ||
\t\tactions[0].WFWorkflowActionParameters["WFTextActionText"]''')
edit("p15_optional_presence_acceptance_test.go",'''\tif len(actions) != 1 || !reflect.DeepEqual(actions[0].WFWorkflowActionParameters''','''\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\tif len(actions) != 2 || actions[0].WFWorkflowActionIdentifier != "com.example.p15.presence" ||
\t\t!reflect.DeepEqual(actions[0].WFWorkflowActionParameters''')
edit("p15_optional_transport_boundary_test.go",'''func p15LazyKeyError(actions []map[string]any, nested bool) error {
\tif len(actions) != 3''','''func p15LazyKeyError(actions []map[string]any, nested bool) error {
\tif err := p15M02MainVoidBoundaryError(actions); err != nil {
\t\treturn err
\t}
\tif len(actions) != 4''')
edit("p15_output_signing_contract_test.go","func p15RP43AssertNativeOutput(t *testing.T, data []byte) {","func p15RP43AssertNativeOutput(t *testing.T, data []byte, legacy bool) {")
edit("p15_output_signing_contract_test.go",'''\tif !ok || len(actions) != 1 {
\t\tt.Fatalf("one source action must produce one native action: %#v", document["WFWorkflowActions"])
\t}''','''\tcount := 1
\tif !legacy {
\t\tcount++
\t\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\t\tt.Fatal(err)
\t\t}
\t}
\tif !ok || len(actions) != count {
\t\tt.Fatalf("source mode changed the complete output graph: legacy=%t actions=%#v", legacy, document["WFWorkflowActions"])
\t}''')
edit("p15_output_signing_contract_test.go","p15RP43AssertNativeOutput(t, actual)","p15RP43AssertNativeOutput(t, actual, strings.HasSuffix(route, \"_legacy\"))")
edit("p15_output_signing_contract_test.go","p15RP43AssertNativeOutput(t, data)","p15RP43AssertNativeOutput(t, data, strings.HasSuffix(route, \"_legacy\"))")
edit("p15_output_signing_security_test.go",'''\t\t\tp15RP43AssertNativeOutput(t, data)
\t\t})
\t}
}

func TestP15RP43PublicSignerFailureBoundaries''','''\t\t\tp15RP43AssertNativeOutput(t, data, false)
\t\t})
\t}
}

func TestP15RP43PublicSignerFailureBoundaries''')
edit("p15_output_signing_security_test.go","p15RP43AssertNativeOutput(t, unsigned)","p15RP43AssertNativeOutput(t, unsigned, false)")
edit("p15_output_signing_security_test.go","p15RP43AssertNativeOutput(t, observed[0].data)","p15RP43AssertNativeOutput(t, observed[0].data, strings.HasSuffix(route, \"_legacy\"))")
edit("p15_output_signing_security_test.go","p15RP43AssertNativeOutput(t, data)","p15RP43AssertNativeOutput(t, data, strings.HasSuffix(route, \"_legacy\"))")
edit("p15_platform_version_acceptance_test.go",'''\t\t\tif len(actions) != 1 {
\t\t\t\tt.Fatalf("version checking changed native action count: %d", len(actions))
\t\t\t}''','''\t\t\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tif len(actions) != 2 {
\t\t\t\tt.Fatalf("version checking changed native action count: %d", len(actions))
\t\t\t}''')
edit("p15_prompt_number_evidence_test.go",'''func p15PromptNumberWire(actions []ShortcutAction) error {
\tif len(actions) != 4''','''func p15PromptNumberWire(actions []ShortcutAction) error {
\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\treturn err
\t}
\tif len(actions) != 5''')
edit("p15_raw_native_result_test.go",'''\t\t\tif len(actions) != 1 {
\t\t\t\tt.Fatalf("Release changed raw producer side effects or retained the removed consumer: %d actions", len(actions))
\t\t\t}''','''\t\t\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tif len(actions) != 2 || actions[0].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" {
\t\t\t\tt.Fatalf("Release changed raw producer side effects or retained the removed consumer: %d actions", len(actions))
\t\t\t}''')
edit("p15_raw_null_boundary_test.go",'''\t\tif len(actions) != 1 || actions[0]["WFWorkflowActionIdentifier"]''','''\t\tif err := p15M02MainVoidBoundaryError(actions); err != nil {
\t\t\tt.Fatal(err)
\t\t}
\t\tif len(actions) != 2 || actions[0]["WFWorkflowActionIdentifier"]''')
edit("p15_registry_lifetime_test.go","} else if err != nil || len(actions) != 1 ||","} else if err != nil || p15M02MainVoidDebugError(actions) != nil || len(actions) != 2 ||")
edit("p15_registry_lifetime_test.go",'''\t\t\tif len(actions) != 1 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.url"''','''\t\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tif len(actions) != 2 || actions[0].WFWorkflowActionIdentifier != "is.workflow.actions.url"''')
edit("p15_registry_lifetime_test.go",'''\t\tif len(actions) != 2 || actions[0].WFWorkflowActionIdentifier != id''','''\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\tt.Fatal(err)
\t\t}
\t\tif len(actions) != 3 || actions[0].WFWorkflowActionIdentifier != id''')
edit("p15_schema_labels_recovery_test.go",'''\t\t\tif len(actions) != 1 || actions[0].WFWorkflowActionIdentifier != tc.identifier''','''\t\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\t\tt.Fatal(err)
\t\t\t}
\t\t\tif len(actions) != 2 || actions[0].WFWorkflowActionIdentifier != tc.identifier''')
edit("p15_schema_optional_propagation_test.go",'''\tif !ok || len(actions) != 1 {
\t\tt.Fatalf("actual CLI emitted the wrong action cardinality: %+v", workflow)
\t}''','''\tif !ok || len(actions) != 2 {
\t\tt.Fatalf("actual CLI emitted the wrong action cardinality: %+v", workflow)
\t}
\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\tt.Fatal(err)
\t}''')
edit("p15_rp11_parameter_wire_test.go","len(actions) != 3","len(actions) != 4")
edit("p15_rp11_parameter_wire_test.go","len(actions) != 2","len(actions) != 3")
edit("p15_rp11_parameter_wire_test.go",'''\tif len(actions) == 0 || actions[len(actions)-1].WFWorkflowActionIdentifier != fixture.action''','''\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\treturn err
\t}
\tif len(actions) < 2 || actions[len(actions)-2].WFWorkflowActionIdentifier != fixture.action''')
edit("p15_rp11_parameter_wire_test.go",'fixture.reference == "" && len(actions) != 1','fixture.reference == "" && len(actions) != 2')
edit("p15_rp11_parameter_wire_test.go","actions[len(actions)-1].WFWorkflowActionParameters[fixture.key]","actions[len(actions)-2].WFWorkflowActionParameters[fixture.key]")
edit("p15_rp11_parameter_wire_test.go","last := &broken[len(broken)-1]","last := &broken[len(broken)-2]")
edit("p15_rp11_parameter_wire_test.go","len(broken) != 3","len(broken) != 4",3)
edit("p15_rp11_parameter_wire_test.go","mutable fixture changed its independent three-action setup","mutable fixture changed its initializer/store/consumer/empty-result setup",2)
edit("p15_scoped_blocks_test.go",'''\tif err != nil {
\t\tt.Fatal(err)
\t}
\treturn actions''','''\tif err != nil {
\t\tt.Fatal(err)
\t}
\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\treturn actions''')
edit("p15_scoped_blocks_test.go","last := actions[len(actions)-1]","last := actions[len(actions)-2]",2)
edit("p15_scoped_blocks_test.go","restore := actions[len(actions)-2]","restore := actions[len(actions)-3]")
edit("p15_scoped_blocks_test.go",'outerRead := p15OutputReference(actions[len(actions)-2].WFWorkflowActionParameters["WFVariable"])','outerRead := p15OutputReference(actions[len(actions)-3].WFWorkflowActionParameters["WFVariable"])')
edit("p15_scoped_blocks_test.go",'last := p15OutputReference(actions[len(actions)-1].WFWorkflowActionParameters["WFVariable"])','last := p15OutputReference(actions[len(actions)-2].WFWorkflowActionParameters["WFVariable"])',3)
edit("p15_scoped_blocks_test.go",'''\t\tfor _, timer := range p15ActionsNamed(actions, "gettimebetweendates") {''','''\t\tif uuid, okay := last["OutputUUID"].(string); last["Type"] != "ActionOutput" || !okay || uuid == "" {
\t\t\tt.Fatal("measure result consumer has no actual body producer", last)
\t\t}
\t\tfor _, timer := range p15ActionsNamed(actions, "gettimebetweendates") {''')
edit("p15_scoped_blocks_test.go",'''\t\tif len(actions[end+1:]) != 1 {''','''\t\tif len(actions[end+1:]) != 2 || actions[end+1].WFWorkflowActionIdentifier != "is.workflow.actions.getvariable" {''')
edit("p15_scoped_blocks_test.go","repeatRegion=%d resultConsumer=%d","repeatRegion=%d postLoopActions=%d")
edit("p15_semantic_typed_list_test.go",'''\t\tnumbers := map[string]string{}''','''\t\tif err := p15M02MainVoidRowsError(actions); err != nil {
\t\t\tt.Fatal(err)
\t\t}
\t\tnumbers := map[string]string{}''')
edit("p15_semantic_typed_list_test.go",'''\t\tfor _, value := range actions {
\t\t\taction := value.(map[string]any)
\t\t\tparameters := action["WFWorkflowActionParameters"].(map[string]any)''','''\t\tfor index, value := range actions {
\t\t\taction := value.(map[string]any)
\t\t\tif index == len(actions)-1 {
\t\t\t\t// The exact original empty-result action was checked above.
\t\t\t\tcontinue
\t\t\t}
\t\t\tparameters, okay := action["WFWorkflowActionParameters"].(map[string]any)
\t\t\tif !okay {
\t\t\t\tt.Fatal("typed List producer lost its parameter dictionary", action)
\t\t\t}''')
edit("p15_paginate_test.go",'''\t\t\t\treturned := actions[len(actions)-2].WFWorkflowActionParameters["UUID"]
\t\t\t\ttail := debugParamMap(debugParamMap(actions[len(actions)-1].WFWorkflowActionParameters["WFVariable"])["Value"])
\t\t\t\tif tail["OutputUUID"] != returned {
\t\t\t\t\tt.Fatal("consumer lost original typed aggregate result")
\t\t\t\t}''','''\t\t\t\tif err := p15PaginateResultError(actions, legacy); err != nil {
\t\t\t\t\tt.Fatal(err)
\t\t\t\t}''')
edit("p15_paginate_test.go",'''\t\t\tif got := actionSuffixes(actions); !reflect.DeepEqual(got, []string{"list", "setvariable", "getvariable"}) {''','''\t\t\twant := []string{"list", "setvariable", "getvariable"}
\t\t\tif !legacy {
\t\t\t\twant = append(want, "nothing")
\t\t\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\t\t\tt.Fatal(err)
\t\t\t\t}
\t\t\t}
\t\t\tif got := actionSuffixes(actions); !reflect.DeepEqual(got, want) {''')
name="p15_paginate_result_oracle_test.go"
old=(W/name).read_text(encoding="utf-8")
start=old.index("// Initial checkpoint:")
end=old.index("\nfunc TestP15PaginateResultOracleRejectsDetachedGraph")
replacement='''// Follow the actual authored consumer and its prior native aggregate producer.
// Keep the main empty result in the graph and require a concrete owned UUID;
// two absent fields can never establish a producer-consumer relationship.
func p15PaginateResultError(actions []ShortcutAction, legacy bool) error {
\tconsumer := len(actions)-1
\tif !legacy {
\t\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\t\treturn err
\t\t}
\t\tconsumer--
\t}
\tif consumer < 1 || actions[consumer].WFWorkflowActionIdentifier != "is.workflow.actions.getvariable" ||
\t\tactions[consumer-1].WFWorkflowActionIdentifier != "is.workflow.actions.getvariable" {
\t\treturn fmt.Errorf("pagination result producer/consumer order changed")
\t}
\tuuid, okay := actions[consumer-1].WFWorkflowActionParameters["UUID"].(string)
\tif !okay || uuid == "" {
\t\treturn fmt.Errorf("pagination aggregate producer has no concrete UUID")
\t}
\towners := 0
\tfor _, action := range actions {
\t\tif action.WFWorkflowActionParameters["UUID"] == uuid {
\t\t\towners++
\t\t}
\t}
\tif owners != 1 {
\t\treturn fmt.Errorf("pagination aggregate UUID has %d owners", owners)
\t}
\tinput, okay := actions[consumer].WFWorkflowActionParameters["WFVariable"].(map[string]any)
\tif !okay || len(input) != 2 || input["WFSerializationType"] != "WFTextTokenAttachment" {
\t\treturn fmt.Errorf("pagination consumer lost its exact native attachment")
\t}
\tvalue, okay := input["Value"].(map[string]any)
\tif !okay || value["Type"] != "ActionOutput" || value["OutputUUID"] != uuid {
\t\treturn fmt.Errorf("pagination consumer is detached from its actual aggregate")
\t}
\tfor key := range value {
\t\tif key != "Type" && key != "OutputUUID" && key != "OutputName" {
\t\t\treturn fmt.Errorf("pagination result gained an unmodeled transformation")
\t\t}
\t}
\treturn nil
}
'''
edit(name,old[start:end],replacement)
for n,s in sources.items():
 (E/(n+".original")).write_bytes(originals[n]);(W/n).write_text(s,encoding="utf-8",newline="\n")
subprocess.run(["gofmt","-w",*sources],cwd=W,capture_output=True,check=True)
subprocess.run(["git","--no-replace-objects","diff","--check"],cwd=W,capture_output=True,check=True)
diff=subprocess.check_output(["git","--no-replace-objects","diff"],cwd=W);(E/"changes.diff").write_bytes(diff)
subprocess.run(["git","--no-replace-objects","-c","core.autocrlf=false","add","--",*sources],cwd=W,capture_output=True,check=True)
q=subprocess.run(["git","--no-replace-objects","commit","-m","test: bind complete source-mode outputs and reject detached macro results"],cwd=W,capture_output=True)
(E/"commit.stdout").write_bytes(q.stdout);(E/"commit.stderr").write_bytes(q.stderr);assert q.returncode==0
head=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
result={"base":red["source"],"source":head,"changed":list(sources),"productionChanged":False,"clean":True,"diffSHA256":hashlib.sha256(diff).hexdigest()}
(E/"source.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
