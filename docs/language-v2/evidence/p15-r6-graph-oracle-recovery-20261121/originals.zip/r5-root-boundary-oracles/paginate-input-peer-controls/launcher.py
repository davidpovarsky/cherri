from pathlib import Path
import subprocess,json,hashlib
B=Path(r"C:\Users\DAVID\Code")
Eroot=B/"cherri-p10r15-continuation-evidence-20261119"
def git(w,*a):return subprocess.check_output(["git","--no-replace-objects",*a],cwd=w)
def commit(w,e,message,paths):
 subprocess.run(["gofmt","-w",*paths],cwd=w,capture_output=True,check=True)
 git(w,"diff","--check");git(w,"-c","core.autocrlf=false","add","--",*paths)
 q=subprocess.run(["git","--no-replace-objects","commit","-m",message],cwd=w,capture_output=True)
 (e/"commit.stdout").write_bytes(q.stdout);(e/"commit.stderr").write_bytes(q.stderr);assert q.returncode==0,q.stderr.decode(errors="replace")
 assert not git(w,"status","--porcelain").strip()
 return git(w,"rev-parse","HEAD").decode().strip()
W=B/"cherri-p10r15-root-final-oracles-r5-20261120";E=Eroot/"r5-root-final-oracles"
assert git(W,"rev-parse","HEAD").decode().strip()=="9daaadad4ae99e15b43a6a22d6f8533b3f55bef3" and not git(W,"status","--porcelain").strip()
failure=json.loads((E/"focused-clean/summary.json").read_bytes());assert failure["exitCode"]==1 and failure["counts"]["run"]==0
D=E/"legacy-helper-call-repair";D.mkdir(exist_ok=False);(D/"launcher.py").write_bytes(Path(__file__).read_bytes())
name="p15_legacy_inline_test.go";p=W/name;raw=p.read_bytes();s=raw.decode()
assert s.count("p15C03EffectOracle(actions)")==2 and s.count("p15C03EffectOracle(broken)")==1
(D/"original.go").write_bytes(raw)
s=s.replace("p15C03EffectOracle(actions)","p15C03EffectOracle(actions, true)").replace("p15C03EffectOracle(broken)","p15C03EffectOracle(broken, true)")
p.write_bytes(s.encode())
head=commit(W,D,"test: declare Legacy mode at existing inline variadic oracle callers",[name])
meta=json.loads((E/"source.json").read_bytes());(D/"previous-source.json").write_bytes((E/"source.json").read_bytes());meta["source"]=head;meta["changed"].append(name);meta["signatureRepairOnly"]=True
(E/"source.json").write_bytes((json.dumps(meta,indent=2)+"\n").encode())
print(json.dumps({"component":"W4","source":head,"changed":name,"originalBuildFailureRetained":True,"testsRun":False}))

W=B/"cherri-p10r15-root-boundaries-r5-20261120";E=Eroot/"r5-root-boundary-oracles"
assert git(W,"rev-parse","HEAD").decode().strip()=="0e3a803718d9f40a61d32b64f12ea68a2fcae9f3" and not git(W,"status","--porcelain").strip()
D=E/"paginate-input-peer-controls";D.mkdir(exist_ok=False);(D/"launcher.py").write_bytes(Path(__file__).read_bytes())
name="p15_paginate_result_oracle_test.go";p=W/name;raw=p.read_bytes();s=raw.decode();(D/"original.go").write_bytes(raw)
old='"detached_consumer", "missing_consumer_input", "missing_producer_uuid"'
assert s.count(old)==1;s=s.replace(old,old+', "missing_aggregate_input", "foreign_aggregate_input"')
old='''\t\t\tcase "missing_producer_uuid":
\t\t\t\tdelete(broken[len(broken)-3].WFWorkflowActionParameters, "UUID")
'''
new=old+'''\t\t\tcase "missing_aggregate_input":
\t\t\t\tdelete(broken[len(broken)-3].WFWorkflowActionParameters, "WFVariable")
\t\t\tcase "foreign_aggregate_input":
\t\t\t\tinput, okay := broken[len(broken)-3].WFWorkflowActionParameters["WFVariable"].(map[string]any)
\t\t\t\tif !okay {
\t\t\t\t\tt.Fatal("actual aggregate read has no native input")
\t\t\t\t}
\t\t\t\tvalue, okay := input["Value"].(map[string]any)
\t\t\t\tif !okay || value["Type"] != "Variable" {
\t\t\t\t\tt.Fatal("actual aggregate read has no variable attachment")
\t\t\t\t}
\t\t\t\tvalue["VariableName"] = "UNRELATED_PAGINATION_AGGREGATE"
'''
assert s.count(old)==1;s=s.replace(old,new);p.write_bytes(s.encode())
head=commit(W,D,"test: reproduce unbound paginate aggregate input acceptance",[name])
print(json.dumps({"component":"paginate-peer-RED-controls","source":head,"productionChanged":False,"oracleChanged":False}))
(D/"source.json").write_bytes((json.dumps({"source":head,"base":"0e3a803718d9f40a61d32b64f12ea68a2fcae9f3","productionChanged":False,"oracleChanged":False},indent=2)+"\n").encode())
