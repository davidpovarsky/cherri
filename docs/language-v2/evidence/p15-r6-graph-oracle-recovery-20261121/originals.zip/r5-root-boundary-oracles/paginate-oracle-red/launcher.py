from pathlib import Path
import json,subprocess,time,hashlib,os
B=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-remaining-r5-20261120")
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-boundaries-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-boundary-oracles")
assert not W.exists() and not E.exists()
subprocess.run(["git","--no-replace-objects","worktree","add","-b","audit/cherri-p10r15-root-boundaries-r5-20261120",str(W),"08e34e294fd06097529ddaf8aa06ba7123d6b975"],cwd=B,capture_output=True,check=True)
E.mkdir();T=E/"paginate-oracle-red";T.mkdir();(T/"launcher.py").write_bytes(Path(__file__).read_bytes())
p=W/"p15_paginate_result_oracle_test.go"
assert not p.exists()
p.write_text('''package main

import (
\t"encoding/json"
\t"fmt"
\t"testing"
)

// Initial checkpoint: the previous inline consumer check, extracted without
// changing its predicate so the actual detached-graph controls can expose it.
func p15PaginateResultError(actions []ShortcutAction, legacy bool) error {
\tif len(actions) < 2 {
\t\treturn fmt.Errorf("missing pagination result")
\t}
\treturned := actions[len(actions)-2].WFWorkflowActionParameters["UUID"]
\ttail := debugParamMap(debugParamMap(actions[len(actions)-1].WFWorkflowActionParameters["WFVariable"])["Value"])
\tif tail["OutputUUID"] != returned {
\t\treturn fmt.Errorf("consumer lost original typed aggregate result")
\t}
\treturn nil
}

func TestP15PaginateResultOracleRejectsDetachedGraph(t *testing.T) {
\tsource := "let rows = paginate(\\\"https://example.invalid/pages/one.json\\\", \\\"rows\\\", \\\"following\\\", 3, 6)\\ngetVariable(rows)\\n"
\tactions, err := compileBuildProfileFixture(t, source, false, BuildProfileDebug)
\tif err != nil {
\t\tt.Fatal(err)
\t}
\tif err := p15M02MainVoidDebugError(actions); err != nil {
\t\tt.Fatal(err)
\t}
\tif len(actions) < 3 || actions[len(actions)-2].WFWorkflowActionIdentifier != "is.workflow.actions.getvariable" {
\t\tt.Fatal("actual pagination consumer missing")
\t}
\tif uuid, okay := actions[len(actions)-3].WFWorkflowActionParameters["UUID"].(string); !okay || uuid == "" {
\t\tt.Fatal("actual aggregate result has no concrete producer UUID")
\t}
\tif err := p15PaginateResultError(actions, false); err != nil {
\t\tt.Fatal("healthy actual graph", err)
\t}
\tfor _, fault := range []string{"detached_consumer", "missing_consumer_input", "missing_producer_uuid"} {
\t\tt.Run(fault, func(t *testing.T) {
\t\t\traw, err := json.Marshal(actions)
\t\t\tif err != nil { t.Fatal(err) }
\t\t\tvar broken []ShortcutAction
\t\t\tif err := json.Unmarshal(raw, &broken); err != nil { t.Fatal(err) }
\t\t\tswitch fault {
\t\t\tcase "detached_consumer":
\t\t\t\tbroken[len(broken)-2].WFWorkflowActionParameters["WFVariable"] = p13TokenAttachment("unrelated-pagination-output", "List")
\t\t\tcase "missing_consumer_input":
\t\t\t\tdelete(broken[len(broken)-2].WFWorkflowActionParameters, "WFVariable")
\t\t\tcase "missing_producer_uuid":
\t\t\t\tdelete(broken[len(broken)-3].WFWorkflowActionParameters, "UUID")
\t\t\t}
\t\t\tif p15PaginateResultError(broken, false) == nil {
\t\t\t\tt.Fatal("detached actual pagination graph accepted", fault)
\t\t\t}
\t\t})
\t}
}
''',encoding="utf-8",newline="\n")
subprocess.run(["gofmt","-w",p.name],cwd=W,capture_output=True,check=True)
subprocess.run(["git","--no-replace-objects","-c","core.autocrlf=false","add","--",p.name],cwd=W,capture_output=True,check=True)
q=subprocess.run(["git","--no-replace-objects","commit","-m","test: expose nil pagination producer and consumer false acceptance"],cwd=W,capture_output=True)
(T/"commit.stdout").write_bytes(q.stdout);(T/"commit.stderr").write_bytes(q.stderr);assert q.returncode==0
head=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
command=["go","test","-count=1","-json","-timeout=3m","-run","^TestP15PaginateResultOracleRejectsDetachedGraph$","."]
env=os.environ.copy();env["CHERRI_TEST_BASH"]=r"C:\Program Files\Git\bin\bash.exe"
start=time.monotonic()
with (T/"stdout.jsonl").open("wb") as out,(T/"stderr.log").open("wb") as err:
 q=subprocess.run(command,cwd=W,stdout=out,stderr=err,env=env,timeout=210)
events=[json.loads(l) for l in (T/"stdout.jsonl").read_text(encoding="utf-8").splitlines()]
result={"source":head,"command":command,"exitCode":q.returncode,"durationSeconds":round(time.monotonic()-start,3),"counts":{a:sum(e.get("Action")==a and bool(e.get("Test")) for e in events) for a in ["run","pass","fail","skip"]},"failures":[e["Test"] for e in events if e.get("Action")=="fail" and e.get("Test")],"stdoutSHA256":hashlib.sha256((T/"stdout.jsonl").read_bytes()).hexdigest(),"sourceCleanAfter":not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip(),"formalAcceptanceGranted":False}
(T/"summary.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
