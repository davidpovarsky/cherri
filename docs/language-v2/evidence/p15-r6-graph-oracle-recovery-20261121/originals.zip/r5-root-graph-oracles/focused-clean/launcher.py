from pathlib import Path
import subprocess,json,hashlib,os,time,shutil
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-regressions-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-graph-oracles")
assert subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()=="413b8200de1f08b1c5861715bdcb2d33aa856c94"
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
p=W/"p15_hybrid_native_loop_result_test.go";s=p.read_text(encoding="utf-8")
old='''\tend, ok := endAction["WFWorkflowActionParameters"].(map[string]any)
\tstartAction, startOK := actions[0].(map[string]any)
\tstart := p15Param(startAction)
\tif !ok || !startOK || p15Int(end["WFControlFlowMode"]) != 2 ||
\t\tend["GroupingIdentifier"] == "" || end["GroupingIdentifier"] != start["GroupingIdentifier"] ||
\t\tendAction["WFWorkflowActionIdentifier"] != startAction["WFWorkflowActionIdentifier"] {
\t\tt.Fatal("native outer loop closure identity changed")
\t}'''
new='''\tend, ok := endAction["WFWorkflowActionParameters"].(map[string]any)
\tstartAction, startOK := actions[0].(map[string]any)
\tif !ok || !startOK {
\t\tt.Fatal("native outer loop endpoints lost their parameter maps")
\t}
\tstart := p15Param(startAction)
\tgroup, groupOK := end["GroupingIdentifier"].(string)
\tif !groupOK || group == "" || group != start["GroupingIdentifier"] ||
\t\tp15Int(start["WFControlFlowMode"]) != 0 || p15Int(end["WFControlFlowMode"]) != 2 ||
\t\tendAction["WFWorkflowActionIdentifier"] != startAction["WFWorkflowActionIdentifier"] {
\t\tt.Fatal("native outer loop closure identity changed")
\t}'''
assert s.count(old)==1
(E/"loop-endpoint-review.original").write_bytes(p.read_bytes())
p.write_text(s.replace(old,new),encoding="utf-8",newline="\n")
subprocess.run(["gofmt","-w",p.name],cwd=W,check=True)
subprocess.run(["git","--no-replace-objects","diff","--check"],cwd=W,check=True)
subprocess.run(["git","--no-replace-objects","-c","core.autocrlf=false","add","--",p.name],cwd=W,check=True)
q=subprocess.run(["git","--no-replace-objects","commit","-m","test: require explicit nonempty native loop endpoint identity"],cwd=W,capture_output=True)
(E/"loop-endpoint-commit.stdout").write_bytes(q.stdout);(E/"loop-endpoint-commit.stderr").write_bytes(q.stderr);assert q.returncode==0
head=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
T=E/"focused-clean";T.mkdir(exist_ok=False);(T/"launcher.py").write_bytes(Path(__file__).read_bytes())
assert shutil.disk_usage(W).free>=2*1024**3
command=["go","test","-count=1","-json","-timeout=15m","-run","^(TestP15V02.*|TestP15CanonicalBehaviorSourcePropagation|TestP15EmptyList.*|TestP15C04.*|TestP15Filter.*|TestP15HybridNativeLoop.*|TestP15M02.*)$","."]
env=os.environ.copy();env["CHERRI_TEST_BASH"]=r"C:\Program Files\Git\bin\bash.exe"
meta={"source":head,"command":command,"sourceCleanBefore":True,"formalAcceptanceGranted":False,"productionChanged":False}
(T/"started.json").write_text(json.dumps(meta,indent=2)+"\n",encoding="utf-8")
start=time.monotonic()
with (T/"stdout.jsonl").open("wb") as out,(T/"stderr.log").open("wb") as err:
 child=subprocess.Popen(command,cwd=W,env=env,stdout=out,stderr=err)
 timed=False
 try:code=child.wait(timeout=975)
 except subprocess.TimeoutExpired:
  timed=True
  kill=subprocess.run(["taskkill","/PID",str(child.pid),"/T","/F"],capture_output=True,timeout=30)
  (T/"taskkill.stdout").write_bytes(kill.stdout);(T/"taskkill.stderr").write_bytes(kill.stderr)
  child.wait(timeout=30);code=child.returncode
events=[json.loads(x) for x in (T/"stdout.jsonl").read_text(encoding="utf-8").splitlines()]
result={**meta,"exitCode":code,"timedOut":timed,"durationSeconds":round(time.monotonic()-start,3),"counts":{a:sum(e.get("Action")==a and bool(e.get("Test")) for e in events) for a in ["run","pass","fail","skip"]},"failures":[e["Test"] for e in events if e.get("Action")=="fail" and e.get("Test")],"stdoutSHA256":hashlib.sha256((T/"stdout.jsonl").read_bytes()).hexdigest(),"sourceCleanAfter":not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip(),"headAfter":subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()}
(T/"summary.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result))
