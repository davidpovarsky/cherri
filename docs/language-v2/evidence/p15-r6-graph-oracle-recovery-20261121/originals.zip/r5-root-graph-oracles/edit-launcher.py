from pathlib import Path
import subprocess,json,hashlib,re
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-regressions-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-graph-oracles")
E.mkdir(parents=True,exist_ok=False);(E/"edit-launcher.py").write_bytes(Path(__file__).read_bytes())
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
changed=[]
def edit(name,old,new):
 p=W/name;s=p.read_text(encoding="utf-8");assert s.count(old)==1,(name,s.count(old),old[:90])
 if name not in changed:
  (E/(name+".original")).write_bytes(p.read_bytes());changed.append(name)
 p.write_text(s.replace(old,new),encoding="utf-8",newline="\n")
edit("p15_binding_scope_wire_test.go",'''func p15V02OuterReference(actions []map[string]any, outer string, mutable bool) error {
	if err := p15M02MainVoidBoundaryError(actions); err != nil {
		return err
	}
	if len(actions) < 2 {
		return fmt.Errorf("missing final authored scope consumer")
	}
	outputs, variables := p15V02NativeReferences(actions[len(actions)-2])''','''func p15V02OuterReference(actions []map[string]any, outer string, mutable, mainFallthrough bool) error {
	consumerIndex := len(actions) - 1
	if mainFallthrough {
		if err := p15M02MainVoidBoundaryError(actions); err != nil {
			return err
		}
		consumerIndex--
	}
	if consumerIndex < 0 {
		return fmt.Errorf("missing final authored scope consumer")
	}
	if !mainFallthrough && actions[consumerIndex]["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" {
		return fmt.Errorf("imported output contract lost the final authored Text consumer")
	}
	outputs, variables := p15V02NativeReferences(actions[consumerIndex])''')
for old,new in [
("p15V02OuterReference(actions, outer, tc.mutable)","p15V02OuterReference(actions, outer, tc.mutable, true)"),
("p15V02OuterReference(mutated, outer, tc.mutable)","p15V02OuterReference(mutated, outer, tc.mutable, true)"),
('p15V02OuterReference(actions, "value", true)','p15V02OuterReference(actions, "value", true, true)'),
('p15V02OuterReference(actions, outer, kind == "variable")','p15V02OuterReference(actions, outer, kind == "variable", false)'),
('p15V02OuterReference(boolActions, outer, kind == "variable")','p15V02OuterReference(boolActions, outer, kind == "variable", false)')]:
 edit("p15_binding_scope_wire_test.go",old,new)
for actual in ["actions","boolActions"]:
 anchor='''			if err := p15V02OuterReference('''+actual+''', outer, kind == "variable", false); err != nil {
				t.Fatal(err)
			}'''
 new=anchor+'''
			// The imported main retains its native output mode. Corrupt the
			// actual final consumer without inventing a V2 fallthrough action.
			if p15V02OuterReference(p15V02CorruptLastReference(t, '''+actual+''', kind == "variable", false),
				outer, kind == "variable", false) == nil {
				t.Fatal("imported final consumer accepted a detached native identity")
			}'''
 edit("p15_binding_scope_wire_test.go",anchor,new)
edit("p15_empty_list_test.go",'''	if len(raw) != 1 || !reflect.DeepEqual(p15EmptyParams(raw[0]), want) {''','''	if err := p15M02MainVoidBoundaryError(raw); err != nil {
		t.Fatal(err)
	}
	if len(raw) != 2 || raw[0]["WFWorkflowActionIdentifier"] != "com.example.p15.opaque.empty" ||
		!reflect.DeepEqual(p15EmptyParams(raw[0]), want) {''')
edit("p15_enum_registry_test.go",'''		if err != nil || workflow == nil || len(workflow.Actions) != 1 {''','''		if err != nil || workflow == nil || len(workflow.Actions) != 2 {''')
edit("p15_enum_registry_test.go",'''		if got := workflow.Actions[0].Parameters["NativeMode"]; got != tc.want {''','''		if workflow.Actions[1].AppleIdentifier != "is.workflow.actions.nothing" ||
			len(workflow.Actions[1].Parameters) != 0 {
			t.Fatal("provided-registry main does not end with an explicit empty result")
		}
		if got := workflow.Actions[0].Parameters["NativeMode"]; got != tc.want {''')
edit("p15_filter_metadata_test.go",'''	if len(raw) != 2 || raw[0].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" {''','''	if err := p15M02MainVoidRowsError(raw); err != nil {
		return err
	}
	if len(raw) != 3 || raw[0].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.gettext" ||
		raw[1].(map[string]any)["WFWorkflowActionIdentifier"] != "is.workflow.actions.filter.files" {''')
edit("p15_hybrid_native_loop_result_test.go",'''	end := actions[len(actions)-1].(map[string]any)["WFWorkflowActionParameters"].(map[string]any)''','''	if err := p15M02MainVoidRowsError(actions); err != nil {
		t.Fatal(err)
	}
	// Preserve the complete freshly compiled graph, including the explicit
	// empty main result. The existing outer loop closes immediately before it.
	endAction, ok := actions[len(actions)-2].(map[string]any)
	if !ok {
		t.Fatal("native outer loop closure is not an action")
	}
	end, ok := endAction["WFWorkflowActionParameters"].(map[string]any)
	startAction, startOK := actions[0].(map[string]any)
	start := p15Param(startAction)
	if !ok || !startOK || p15Int(end["WFControlFlowMode"]) != 2 ||
		end["GroupingIdentifier"] == "" || end["GroupingIdentifier"] != start["GroupingIdentifier"] ||
		endAction["WFWorkflowActionIdentifier"] != startAction["WFWorkflowActionIdentifier"] {
		t.Fatal("native outer loop closure identity changed")
	}''')
# The rebuilt probe is a Go source string. Decode it, change the full-graph
# assertion, and encode it back; its source/parameter mutation oracle is unchanged.
p=W/"p15_canonical_source_propagation_test.go";s=p.read_text(encoding="utf-8")
m=re.search(r"const p15CanonicalRebuildProbe = (\"(?:[^\"\\]|\\.)*\")",s)
assert m
probe=json.loads(m[1])
old='''   if len(acts)!=1 || acts[0].WFWorkflowActionIdentifier!=tc.identifier {
    t.Fatalf("%s/%s action identity or cardinality changed: %+v",tc.name,route,acts)
   }'''
new='''   count:=1
   if !legacy { count=2 }
   if len(acts)!=count || acts[0].WFWorkflowActionIdentifier!=tc.identifier {
    t.Fatalf("%s/%s action identity or cardinality changed: %+v",tc.name,route,acts)
   }
   if !legacy && (acts[1].WFWorkflowActionIdentifier!="is.workflow.actions.nothing" || len(acts[1].WFWorkflowActionParameters)!=0) {
    t.Fatalf("%s/%s missing exact empty main completion: %+v",tc.name,route,acts)
   }'''
assert probe.count(old)==1
probe=probe.replace(old,new)
edit(p.name,m[0],"const p15CanonicalRebuildProbe = "+json.dumps(probe))
result=subprocess.run(["gofmt","-w",*changed],cwd=W,capture_output=True)
assert result.returncode==0,result.stderr.decode()
diff=subprocess.check_output(["git","--no-replace-objects","diff","--",*changed],cwd=W);(E/"changes.diff").write_bytes(diff)
subprocess.run(["git","--no-replace-objects","diff","--check"],cwd=W,check=True)
subprocess.run(["git","--no-replace-objects","-c","core.autocrlf=false","add","--",*changed],cwd=W,check=True)
p=subprocess.run(["git","--no-replace-objects","commit","-m","test: verify complete main and imported output graphs in remaining oracles"],cwd=W,capture_output=True)
(E/"commit.stdout").write_bytes(p.stdout);(E/"commit.stderr").write_bytes(p.stderr);assert p.returncode==0
head=subprocess.check_output(["git","--no-replace-objects","rev-parse","HEAD"],cwd=W).decode().strip()
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
receipt={"source":head,"base":"f05a6221b44582cb04bb085d254df9ff25cf64a8","changed":changed,"diffSHA256":hashlib.sha256(diff).hexdigest(),"productionChanged":False,"clean":True}
(E/"source.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8");print(json.dumps(receipt))
