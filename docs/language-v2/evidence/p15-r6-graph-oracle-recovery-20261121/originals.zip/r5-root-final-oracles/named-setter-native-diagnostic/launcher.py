from pathlib import Path
import subprocess,json,hashlib,plistlib,time
R=Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-final-oracles-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-final-oracles\named-setter-native-diagnostic")
E.mkdir(exist_ok=False);(E/"launcher.py").write_bytes(Path(__file__).read_bytes())
binary=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-docs-actual-baseline-f05a6221-clone\compiler.exe")
assert hashlib.sha256(binary.read_bytes()).hexdigest()=="ce23370cc3d0a8e34dca44c632eaba75edb75047a944de152c0b60b437b8da7f"
for name in ["editEvent","editReminder"]:
 D=E/name;D.mkdir()
 source='let target = "PUBLIC_SYNTHETIC_TARGET"\n'+name+'(target, detail: "URL", newValue: "Remove", mode: "Set")\n'
 p=D/"source.cherri";p.write_bytes(source.encode());out=D/"compiled.shortcut"
 cmd=[str(binary),"compile",str(p),"--skip-sign","--no-ansi","--output="+str(out)]
 start=time.monotonic();q=subprocess.run(cmd,cwd=D,capture_output=True,timeout=30)
 (D/"stdout").write_bytes(q.stdout);(D/"stderr").write_bytes(q.stderr)
 receipt={"compilerSource":"f05a6221b44582cb04bb085d254df9ff25cf64a8","command":cmd,"exit":q.returncode,"seconds":time.monotonic()-start,"scope":"Actual unchanged production compiler diagnostic only; not W4 test execution"}
 (D/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
 assert q.returncode==0,q.stderr.decode(errors="replace")
 doc=plistlib.loads(out.read_bytes());print(json.dumps({"case":name,"actions":doc["WFWorkflowActions"]}))
print(json.dumps({"paginateTail":"\n".join((W/"paginate_macro.go").read_text(encoding="utf-8").splitlines()[252:310])}))
def g(*a):return subprocess.check_output(["git","--no-replace-objects",*a],cwd=R)
for proof,path in [
("4697956e60676116565c75774548f1ed845dcbaa","docs/language-v2/evidence/p15-e05-editor-publication-20261120/provenance.json"),
("b2441a8ccbfd67c464682fec65399cf5603cdf1b","docs/language-v2/evidence/p15-qa-terminal-receipts-20261120.json")]:
 j=json.loads(g("show",proof+":"+path))
 fields={k:{"length":len(v),"first":v[:1]} if isinstance(v,list) else {"keys":list(v)} if isinstance(v,dict) else v for k,v in j.items()}
 print(json.dumps({"proof":proof,"path":path,"fields":fields}))
