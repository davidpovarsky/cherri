from pathlib import Path
import subprocess,json,shutil
R=Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-final-oracles-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-final-oracles")
assert not W.exists() and not E.exists()
assert shutil.disk_usage(R).free>2*1024**3
E.mkdir();(E/"setup-launcher.py").write_bytes(Path(__file__).read_bytes())
p=subprocess.run(["git","--no-replace-objects","worktree","add","-b","audit/cherri-p10r15-root-final-oracles-r5-20261120",str(W),"0e3a803718d9f40a61d32b64f12ea68a2fcae9f3"],cwd=R,capture_output=True)
(E/"setup.stdout").write_bytes(p.stdout);(E/"setup.stderr").write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors="replace")
assert not subprocess.check_output(["git","--no-replace-objects","status","--porcelain"],cwd=W).strip()
print(json.dumps({"checkout":str(W),"base":"0e3a803718d9f40a61d32b64f12ea68a2fcae9f3","freeBytes":shutil.disk_usage(W).free}))
