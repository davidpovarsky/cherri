from pathlib import Path
import subprocess,json,hashlib,os,time,re,collections,shutil
W=Path(r"C:\Users\DAVID\Code\cherri-p10r15-root-final-oracles-r5-20261120")
E=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r5-root-final-oracles")
source=json.loads((E/"source.json").read_bytes())
expected="ade15eea8437475be4f34062b1605d8090c7fa92"
def git(*args):return subprocess.check_output(["git","--no-replace-objects",*args],cwd=W)
assert git("rev-parse","HEAD").decode().strip()==expected and not git("status","--porcelain").strip()
assert shutil.disk_usage(W).free>2*1024**3
D=E/"focused-clean-modes";D.mkdir(exist_ok=False)
(D/"submitted-script.py").write_bytes(Path(__file__).read_bytes())
names=set()
for name in source["changed"]+["p15_main_output_oracle_controls_test.go"]:
 names.update(re.findall(r"^func (Test\w+)\(",(W/name).read_text(encoding="utf-8"),re.M))
selector="^("+"|".join(sorted(names))+")$"
cmd=["go","test","-count=1","-json","-timeout=15m","-run",selector,"."]
env=os.environ.copy();env["CHERRI_TEST_BASH"]=r"C:\Program Files\Git\bin\bash.exe"
began=time.monotonic();timed=False
with (D/"stdout.jsonl").open("wb") as out,(D/"stderr.txt").open("wb") as err:
 try:rc=subprocess.run(cmd,cwd=W,env=env,stdout=out,stderr=err,timeout=975).returncode
 except subprocess.TimeoutExpired:rc=None;timed=True
elapsed=time.monotonic()-began
events=[]
for line in (D/"stdout.jsonl").read_bytes().splitlines():
 try:events.append(json.loads(line))
 except Exception:pass
counts={a:sum(v.get("Action")==a and bool(v.get("Test")) for v in events) for a in ["run","pass","fail","skip"]}
failed=[v["Test"] for v in events if v.get("Action")=="fail" and v.get("Test")]
observed={v["Test"] for v in events if v.get("Action")=="run" and v.get("Test") and "/" not in v["Test"]}
receipt={"source":expected,"command":cmd,"environment":{"CHERRI_TEST_BASH":env["CHERRI_TEST_BASH"]},"exitCode":rc,"timedOut":timed,"durationSeconds":round(elapsed,3),"counts":counts,"failed":failed,"expectedParents":sorted(names),"unstartedParents":sorted(names-observed),"stdoutSHA256":hashlib.sha256((D/"stdout.jsonl").read_bytes()).hexdigest(),"stderrSHA256":hashlib.sha256((D/"stderr.txt").read_bytes()).hexdigest(),"sourceCleanAfter":not git("status","--porcelain").strip(),"headAfter":git("rev-parse","HEAD").decode().strip(),"productionChanged":False,"formalAcceptanceGranted":False}
(D/"summary.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps(receipt))
for name in failed:
 rows=[v.get("Output","") for v in events if v.get("Test")==name and v.get("Action")=="output"]
 print(json.dumps({"failure":name,"output":"".join(rows)[-7000:]}))
