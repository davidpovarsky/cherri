# Inactive actual56 release-gate supervisor

This is a new minimal wrapper around the original production command. It does **not** claim to be an identical recovered historical wrapper: the targeted old evidence retains execution-start.json and execution-result.json, but no standalone wrapper source.

The actual authority is /mnt/development/projects/evidence/cherri-p10r15-r8-release-gates-20261123/first-1c07e3fe:

- execution-start.json SHA256 fdfe3e5680a4fa7a4d5b3b05fdecd1867c07bd5815787d2d86d3a250fbe7a78a records the original command and1800s outer guard.
- execution-result.json SHA256 ac03c3dd8b9cf1056fb8038b21862c4363157a87ade39a3eeb99a390b65cbbce records451.427025s,actual exit1,54PASS/R23FAIL/R22BLOCKED_PLATFORM and NOT_READY.
- The active runner remains SHA256295434213219d9d50f03c00cbffa9b3b1a82d2f9e7c5c0b30429963fcbf317d5.

C1 SHA/tree/path remain null and execution is inactive. Root must review the source and supply a clean final C1 plus CPU/command handoff. No Go, gate, registry executable, generator or producer was run for this proposal. Only AST parsing/literal inspection and field comparisons against the old original report occurred.

## Preserved command and deadlines

    python3 -B tools/p10r3/run_release_gates.py --run-all --out-results <new external output>/gate-results.original.json

The1800s producer-process wait is fixed. On timeout: process-group TERM,5s wait,KILL,5s reap. No dynamic deadline, injected child selectors/flags, retries, additional gate run or standalone registry execution is added. The existing --run-all performs its original registry validation.

The new wrapper follows root's explicit TERM5/KILL5 instruction; these grace values are not invented as historical receipt fields. The original receipts independently establish1800s. Exact command authority is checked again before execution.

## Source and recording

The wrapper requires exact supplied C1 SHA/tree, clean named source, actual Git top-level and absent replacement refs. It uses the hash-verified ce809 original helper only for read-only fingerprint/capture/serialization utilities, with a sanitized environment. It never calls that helper's raw producer main.

It records source and full P10 dependency witnesses before/after, exact active runner hash, original56 definitions/status vocabulary, actual selected Go environment, invocation/PID, original stdout/stderr, immediate process terminal and final original report/result manifest. All outputs are exclusive and outside source.

The registry is read as AST literal data; the production runner is not imported for preflight. It must contain the exact original R01–R28,A01–A28 order and unchanged fixed R23 baseline76d722502e20db977e84a095444d0172442655b8.

The external report is checked against exact56 identity/order, names/tiers/status vocabulary, actual source/fingerprint, original per-gate metadata shape and independently recomputed summary/verdict. These checks require a coherent actual result, not an all-green result. The code also checks that failing-gate counts and actual child exit agree.

## Honest failure propagation

Expected policy/platform limitations are recorded as R23 FAIL and R22 BLOCKED_PLATFORM. They are context, not fabricated outcomes or a substitute for the actual report. Every real observed status is retained, including any additional failures.

A coherent actual failed run is marked ACTUAL_RESULT_RECORDED with collectionVerified=true, while the wrapper returns the actual nonzero child code. It never converts a valid failed run to exit0. Any incomplete/inconsistent capture remains rejected with original bytes retained.

The wrapper does not copy or rewrite tracked p10r3-gate-results.json, run --verify-commit, commit files, activate policy or claim aggregate readiness. Root separately intakes the completed original report and performs the already-planned metadata/adoption step.

## Runtime

Go1.24.13, existing module cache, persistent build-cache and tmp-ubuntu paths are declared explicitly. The original basic environment allowlist is retained; provider/AI/private-corpus/full-suite-marker/catalog-output variables are not forwarded. stdin is DEVNULL. Original bounded go env inspection occurs only after actual execution authorization.

Only static source/receipt work occurred. C1 and final consumer K remain unknown.
