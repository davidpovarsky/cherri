"""Inactive bounded wrapper for the original actual56-gate command.

Authority is the retained execution-start/result receipts, not an invented
historical wrapper source. Root supplies a final clean C1 SHA/tree and handoff.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

HELPER=Path("/mnt/development/projects/evidence/cherri-p10r15-505-refresh-20261123/run_catalog_producers.py")
HELPER_SHA="ce809d9839a74657d6cbf6fb685a65aef0c86e743642e1eeed31acca03143bb4"
AUTHORITY=Path("/mnt/development/projects/evidence/cherri-p10r15-r8-release-gates-20261123/first-1c07e3fe")
AUTHORITY_START_SHA="fdfe3e5680a4fa7a4d5b3b05fdecd1867c07bd5815787d2d86d3a250fbe7a78a"
AUTHORITY_RESULT_SHA="ac03c3dd8b9cf1056fb8038b21862c4363157a87ade39a3eeb99a390b65cbbce"
OUTPUT_BASE=Path("/mnt/development/projects/evidence/cherri-p10r15-release-gates-s57b6d919-20261123")
RUNNER="tools/p10r3/run_release_gates.py"
RUNNER_SHA="295434213219d9d50f03c00cbffa9b3b1a82d2f9e7c5c0b30429963fcbf317d5"
EXPECTED_IDS=[f"R{i:02d}" for i in range(1,29)]+[f"A{i:02d}" for i in range(1,29)]
GO_SELECTION={
    "GOTOOLCHAIN":"go1.24.13",
    "GOMODCACHE":"/mnt/development/tooling/cherri-go/mod",
    "GOCACHE":"/mnt/development/tooling/cherri-go/runtime-persistent-20261123/build-cache",
    "GOTMPDIR":"/mnt/development/tooling/cherri-go/runtime-persistent-20261123/tmp-ubuntu",
    "TMPDIR":"/mnt/development/tooling/cherri-go/runtime-persistent-20261123/tmp-ubuntu",
}
OWNED_OUTPUT=None
h=None


def require(value):
    if not value:
        raise ValueError("RELEASE_GATES_SUPERVISOR_REJECTED")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean_environment():
    keep=("PATH","HOME","USER","LOGNAME","LANG","LC_ALL","LC_CTYPE","TZ")
    env={k:os.environ[k] for k in keep if k in os.environ}
    env.update({"GIT_NO_REPLACE_OBJECTS":"1","GIT_OPTIONAL_LOCKS":"0",
                "GIT_TERMINAL_PROMPT":"0","PYTHONDONTWRITEBYTECODE":"1"})
    return env


def capture(argv,repo,env=None,timeout=30):
    return h.capture(argv,repo,clean_environment() if env is None else env,timeout)


def source(repo):
    def read(*args):
        return capture(["git","--no-replace-objects",*args],repo).decode().strip()
    require(Path(read("rev-parse","--show-toplevel"))==repo and not read("replace","-l"))
    return {"head":read("rev-parse","HEAD"),"tree":read("rev-parse","HEAD^{tree}"),
            "branch":read("branch","--show-current"),
            "status":capture(["git","--no-replace-objects","status","--porcelain=v1","--untracked-files=all"],repo).decode()}


def registry(repo):
    raw=(repo/RUNNER).read_bytes()
    require(hashlib.sha256(raw).hexdigest()==RUNNER_SHA)
    parsed=ast.parse(raw)
    values={}
    for node in parsed.body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id in ("GATE_DEFINITIONS","BLOCKED_STATUSES"):
                    require(target.id not in values)
                    values[target.id]=ast.literal_eval(node.value)
    definitions=values["GATE_DEFINITIONS"];blocked=values["BLOCKED_STATUSES"]
    require(list(definitions)==EXPECTED_IDS and len(definitions)==56)
    require(definitions["R23"]["upstreamBase"]=="76d722502e20db977e84a095444d0172442655b8")
    return definitions,blocked


def report_observation(path,head,fingerprint,definitions,blocked,exit_code,timed_out):
    if not path.is_file():
        return {"reportPresent":False,"reportCollectionVerified":False}
    raw=path.read_bytes()
    try:
        value=json.loads(raw)
        gates=value["gates"]
        checks={}
        checks["exact56IdentityOrder"]=(type(gates) is list and [g.get("id") for g in gates]==EXPECTED_IDS)
        checks["sourceAndFingerprint"]=value["sourceCommit"]==head and value["inputDependencyFingerprint"]==fingerprint
        checks["originalNamesAndTiers"]=all(g["name"]==definitions[g["id"]]["name"] and g["tier"]==definitions[g["id"]]["tier"] for g in gates)
        checks["statusAndReceiptShape"]=all(
            g["status"] in ({"PASS","FAIL"}|blocked) and type(g["exitCode"]) is int and
            type(g["durationSeconds"]) in (int,float) and math.isfinite(g["durationSeconds"]) and
            g["durationSeconds"]>=0 and type(g["outputSha256"]) is str and
            re.fullmatch(r"[0-9a-f]{64}",g["outputSha256"]) is not None for g in gates)
        passing=sum(g["status"]=="PASS" for g in gates)
        blocked_count=sum(g["status"] in blocked for g in gates)
        failing=sum(g["status"]!="PASS" and g["status"] not in blocked for g in gates)
        expected_summary={
            "totalGates":56,"passingGates":passing,"blockedExternalGates":blocked_count,"failingGates":failing,
            "rGatesTotal":28,"rGatesPassing":sum(g["id"].startswith("R") and g["status"]=="PASS" for g in gates),
            "rGatesBlockedExternal":sum(g["id"].startswith("R") and g["status"] in blocked for g in gates),
            "aGatesTotal":28,"aGatesPassing":sum(g["id"].startswith("A") and g["status"]=="PASS" for g in gates),
            "aGatesFailing":sum(g["id"].startswith("A") and g["status"]=="FAIL" for g in gates)}
        checks["summaryMatchesActualRows"]=value["summary"]==expected_summary
        expected_verdict="NOT_READY" if failing else ("PARTIAL_WITH_EXTERNAL_BLOCKERS" if blocked_count else "READY")
        checks["verdictMatchesActualRows"]=value["verdict"]==expected_verdict
        checks["actualExitPropagation"]=not timed_out and exit_code==(1 if failing else 0)
        return {"reportPresent":True,"reportSHA256":hashlib.sha256(raw).hexdigest(),"reportBytes":len(raw),
                "reportedSource":value["sourceCommit"],"reportedFingerprint":value["inputDependencyFingerprint"],
                "reportedSummary":value["summary"],"reportedVerdict":value["verdict"],
                "actualGateStatuses":[{"id":g["id"],"status":g["status"],"exitCode":g["exitCode"]} for g in gates],
                "checks":checks,"reportCollectionVerified":all(checks.values())}
    except (KeyError,TypeError,ValueError):
        return {"reportPresent":True,"reportSHA256":hashlib.sha256(raw).hexdigest(),
                "reportBytes":len(raw),"reportCollectionVerified":False,"reason":"REPORT_SHAPE_REJECTED"}


def main():
    global h,OWNED_OUTPUT
    parser=argparse.ArgumentParser()
    parser.add_argument("--repo",required=True)
    parser.add_argument("--expected-source",required=True)
    parser.add_argument("--expected-tree",required=True)
    parser.add_argument("--output",required=True)
    parser.add_argument("--execute-reviewed-plan",action="store_true")
    args=parser.parse_args()
    if not args.execute_reviewed_plan:
        print("RELEASE_GATES_SUPERVISOR_INACTIVE",file=sys.stderr)
        return 64
    require(os.getuid()==1001)
    require(re.fullmatch(r"[0-9a-f]{40}",args.expected_source) and re.fullmatch(r"[0-9a-f]{40}",args.expected_tree))
    require(digest(HELPER)==HELPER_SHA)
    spec=importlib.util.spec_from_file_location("reviewed_catalog_read_helpers",HELPER)
    h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
    require(digest(AUTHORITY/"execution-start.json")==AUTHORITY_START_SHA and
            digest(AUTHORITY/"execution-result.json")==AUTHORITY_RESULT_SHA)
    authority=json.loads((AUTHORITY/"execution-start.json").read_bytes())
    require(authority["outerGuardSeconds"]==1800 and
            authority["command"][:5]==["python3","-B",RUNNER,"--run-all","--out-results"])
    repo=Path(args.repo).resolve(strict=True);out=Path(args.output).absolute()
    require(out.parent.resolve()==OUTPUT_BASE and not out.exists() and
            not out.is_relative_to(repo) and not out.parent.resolve().is_relative_to(repo))
    before=source(repo)
    require(before["head"]==args.expected_source and before["tree"]==args.expected_tree and
            before["branch"] and not before["status"])
    definitions,blocked=registry(repo)
    witness_before=h.dependency_witness(repo)
    out.mkdir(mode=0o700);OWNED_OUTPUT=out
    h.original(out/"submitted-supervisor.py",Path(__file__).read_bytes())
    h.original(out/"source-before.original.json",before)
    h.original(out/"input-witness-before.original.json",witness_before)
    h.original(out/"registry-before.original.json",{"definitions":definitions,"blockedStatuses":sorted(blocked)})
    env=clean_environment();env.update(GO_SELECTION)
    for key in ("GOMODCACHE","GOCACHE","GOTMPDIR","TMPDIR"):
        p=Path(env[key]);require(p.is_dir() and os.access(p,os.R_OK|os.W_OK|os.X_OK))
    goenv=capture(["go","env","-json","GOVERSION","GOOS","GOARCH","GOROOT","GOTOOLCHAIN",
                   "GOMODCACHE","GOCACHE","GOTMPDIR"],repo,env,timeout=60)
    h.original(out/"go-env.original.json",goenv)
    require(json.loads(goenv)["GOVERSION"]=="go1.24.13")
    argv=["python3","-B",RUNNER,"--run-all","--out-results",str(out/"gate-results.original.json")]
    intent={"source":before,"argv":argv,"selected_environment":GO_SELECTION,
            "driver_sha256":digest(Path(__file__)),"read_helper_sha256":HELPER_SHA,
            "runner_sha256":RUNNER_SHA,"authority_start_sha256":AUTHORITY_START_SHA,
            "authority_result_sha256":AUTHORITY_RESULT_SHA,
            "expected_gate_ids":EXPECTED_IDS,"outerGuardSeconds":1800,
            "terminationGraceSeconds":5,"killReapWaitSeconds":5,
            "capacityFreeBefore":shutil.disk_usage("/mnt/development").free,
            "policyExpectedLimitations":{"R23":"FAIL","R22":"BLOCKED_PLATFORM"},
            "allGreenRequired":False,"consumerDataOverwriteAuthorized":False,"finalConsumerSource":None}
    require(source(repo)==before)
    h.original(out/"execution-start.original.json",intent)
    started_utc,started=h.utc(),time.monotonic();timed_out=False
    with (out/"stdout.original").open("xb") as so,(out/"stderr.original").open("xb") as se:
        process=subprocess.Popen(argv,cwd=repo,env=env,stdin=subprocess.DEVNULL,
                                 stdout=so,stderr=se,start_new_session=True)
        h.original(out/"process-start.original.json",{"pid":process.pid,"startedUTC":started_utc})
        try:
            code=process.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                code=process.wait(timeout=5)
    finished_utc,elapsed=h.utc(),time.monotonic()-started
    terminal={"source":before,"argv":argv,"pid":process.pid,"startedUTC":started_utc,
              "finishedUTC":finished_utc,"elapsedSeconds":elapsed,"exitCode":code,"timedOut":timed_out,
              "stdoutSHA256":digest(out/"stdout.original"),"stderrSHA256":digest(out/"stderr.original")}
    h.original(out/"process-terminal.original.json",terminal)
    after=source(repo);witness_after=h.dependency_witness(repo)
    h.original(out/"source-after.original.json",after)
    h.original(out/"input-witness-after.original.json",witness_after)
    observed=report_observation(out/"gate-results.original.json",args.expected_source,
                                witness_before["fingerprint"],definitions,blocked,code,timed_out)
    source_stable=after==before and witness_after==witness_before and digest(repo/RUNNER)==RUNNER_SHA
    valid=bool(source_stable and observed["reportCollectionVerified"])
    receipt={**terminal,"sourceAfter":after,"sourceUnchanged":source_stable,
             "inputFingerprintBefore":witness_before["fingerprint"],"inputFingerprintAfter":witness_after["fingerprint"],
             "reportObservation":observed,"collectionVerified":valid,
             "status":"ACTUAL_RESULT_RECORDED" if valid else "INCOMPLETE_OR_INCONSISTENT",
             "allGreenRequired":False,"actualNonzeroPreserved":code!=0,
             "capacityFreeAfter":shutil.disk_usage("/mnt/development").free,
             "consumerDataOverwritten":False,"metadataVerificationExecuted":False,"automaticRetry":False}
    h.original(out/"execution-result.original.json",receipt)
    h.original(out/"originals-manifest.json",{"files":[{"path":p.relative_to(out).as_posix(),
                "bytes":p.stat().st_size,"sha256":digest(p)} for p in sorted(out.rglob("*")) if p.is_file()]})
    print(json.dumps(receipt),flush=True)
    # A valid record of a failed gate run must retain that actual nonzero exit.
    return code if code!=0 else (0 if valid else 1)


if __name__=="__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        failure={"status":"RELEASE_GATES_SUPERVISOR_REJECTED","error_type":type(error).__name__,"automaticRetry":False}
        if OWNED_OUTPUT is not None and h is not None:
            h.original(OWNED_OUTPUT/"supervisor-rejection.original.json",failure)
        print(json.dumps(failure),file=sys.stderr)
        raise SystemExit(1)
