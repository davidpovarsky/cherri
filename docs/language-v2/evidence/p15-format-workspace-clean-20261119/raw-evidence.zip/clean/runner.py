import os,sys,json,pathlib,subprocess,time,hashlib,ctypes,datetime
base=pathlib.Path(r"C:\Users\DAVID\Code")
out=base/"cherri-p10r15-evidence-20261119"/"root-clean-e04-im04-20261119"
out.mkdir(exist_ok=True)
go=r"C:\Program Files\Go\bin\go.exe"
cases=[
 ("formatter",base/"cherri-p10r15-modules-formatter-20261119","c621786317cef4479ea34dde4f391441b5efbd34",r"^(TestFormatterProductionEvidence|TestFormatterEvidenceRejectsCrossTierAndTruncatedScenario)$"),
 ("workspace",base/"cherri-p10r15-module-resolution-20261119","8418ac2483ab0985cc9f9d8511f3fbe1098fac6f",r"^(TestWorkspaceResourceProductionEvidence|TestWorkspaceEvidenceRejectsUnrelatedCommands)$")
]
class Memory(ctypes.Structure):
 _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
def snap(p):
 return {"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=p,text=True).strip(),"status":subprocess.check_output(["git","status","--porcelain"],cwd=p,text=True)}
env={k:v for k,v in os.environ.items() if not k.startswith("CHERRI")}
env.update({"GOMAXPROCS":"1","GOFLAGS":"-p=1"})
results=[]
(out/"runner.py").write_bytes(pathlib.Path(__file__).read_bytes())
for name,repo,expected,pattern in cases:
 m=Memory();m.dwLength=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));assert m.ullAvailPhys>1800000000,m.ullAvailPhys
 before=snap(repo);assert before=={"head":expected,"status":""},before
 cmd=[go,"test","./tools/language-acceptance","-count=1","-json","-timeout=180s","-run",pattern]
 log=out/(name+".jsonl");start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();timed=False
 with log.open("wb") as f:
  p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  (out/"progress.json").write_bytes(json.dumps({"name":name,"pid":p.pid,"source":expected,"started":started}).encode())
  try: code=p.wait(timeout=240)
  except subprocess.TimeoutExpired:
   timed=True
   subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)
   code=p.wait(timeout=30)
 after=snap(repo);events=[]
 for line in log.read_text(encoding="utf-8",errors="replace").splitlines():
  try: events.append(json.loads(line))
  except json.JSONDecodeError: pass
 counts={a:sum(1 for e in events if e.get("Action")==a and e.get("Test")) for a in ["run","pass","fail","skip"]}
 result={"name":name,"source":expected,"started":started,"seconds":round(time.monotonic()-start,3),"exit":code,"timedOut":timed,"before":before,"after":after,"unchanged":before==after,"availableRAMBefore":m.ullAvailPhys,"command":cmd,"counts":counts,"sha256":hashlib.sha256(log.read_bytes()).hexdigest(),"bytes":log.stat().st_size}
 results.append(result);(out/"summary.json").write_bytes(json.dumps(results,indent=2).encode());print(json.dumps(result),flush=True)
 if code!=0 or timed or before!=after: sys.exit(1)
