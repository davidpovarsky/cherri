import os,pathlib,json,subprocess,time,hashlib,collections,datetime
r=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-modules-formatter-20261119")
out=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\formatter-31bd7aa")
log=out/"baseline-production.jsonl";assert not log.exists()
env=os.environ.copy();env["GOMAXPROCS"]="1";env["GOFLAGS"]="-p=1";env["PATH"]=r"C:\Program Files\Go\bin"+os.pathsep+env.get("PATH","")
go=r"C:\Program Files\Go\bin\go.exe";cmd=[go,"test",".","-json","-count=1","-timeout=180s","-run","^TestP15E04"]
(out/"baseline-production-runner.py").write_bytes(pathlib.Path(__file__).read_bytes())
testpaths=["internal/language/syntax/p15_formatter_preservation_test.go","internal/language/service/p15_formatter_preservation_test.go","p15_formatter_acceptance_test.go"]
before={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in testpaths}
t0=time.monotonic();timed=False
with log.open("wb") as f:
 p=subprocess.Popen(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 try:p.wait(timeout=240)
 except subprocess.TimeoutExpired:
  timed=True;subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=20);p.wait(timeout=10)
raw=log.read_bytes();events=[]
for line in raw.splitlines():
 try:events.append(json.loads(line))
 except json.JSONDecodeError:pass
summary={"source":"31bd7aa2bc4d1582adf37b22a526b690d10d8b5b","scope":"PUBLIC_FORMATTER_BASELINE_TEST_ONLY_DELTA","command":cmd,"exit":p.returncode,"timedOut":timed,"seconds":round(time.monotonic()-t0,3),"testHashes":before,"testsUnchanged":before=={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in testpaths},"counts":dict(collections.Counter(e.get("Action") for e in events if e.get("Test"))),"failures":[e["Test"] for e in events if e.get("Test") and e.get("Action")=="fail"],"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
(out/"baseline-production-summary.json").write_bytes((json.dumps(summary,indent=2)+"\n").encode())
print(json.dumps(summary))
