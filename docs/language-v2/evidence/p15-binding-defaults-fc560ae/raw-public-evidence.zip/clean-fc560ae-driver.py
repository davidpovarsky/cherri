from pathlib import Path
import os,json,subprocess,time,hashlib,ctypes
p=Path(r'C:\Users\DAVID\Code\cherri-p10r15-binding-defaults-20261119')
out=Path(r'C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\binding-defaults-7a43cb1')
out.mkdir(parents=True,exist_ok=True)
class M(ctypes.Structure):
 _fields_=[('dwLength',ctypes.c_ulong),('dwMemoryLoad',ctypes.c_ulong),('ullTotalPhys',ctypes.c_ulonglong),('ullAvailPhys',ctypes.c_ulonglong),('ullTotalPageFile',ctypes.c_ulonglong),('ullAvailPageFile',ctypes.c_ulonglong),('ullTotalVirtual',ctypes.c_ulonglong),('ullAvailVirtual',ctypes.c_ulonglong),('ullAvailExtendedVirtual',ctypes.c_ulonglong)]
m=M();m.dwLength=ctypes.sizeof(m);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
if m.ullAvailPhys<1800000000: raise SystemExit('memory below focused gate threshold: '+str(m.ullAvailPhys))
env=os.environ.copy();env['GOMAXPROCS']='1';env['GOFLAGS']='-p=1';env['PATH']=r'C:\Program Files\Go\bin'+os.pathsep+env['PATH']
status=lambda:subprocess.run(['git','status','--porcelain','--untracked-files=normal'],cwd=p,capture_output=True,text=True,encoding='utf-8',check=True).stdout
head=subprocess.run(['git','rev-parse','HEAD'],cwd=p,capture_output=True,text=True,encoding='utf-8',check=True).stdout.strip()
before=status()
if before: raise SystemExit('clean gate requires clean source')
if head!='fc560ae30cdcccd8089b1e742fba6f77a8a05720': raise SystemExit('unexpected source head')
cmd=[r'C:\Program Files\Go\bin\go.exe','test','-p=1','-count=1','-json','-timeout=180s','-run','^(TestP15V01DeclarationSnapshotProduction|TestP15V03ClipboardCapturedOnceProduction|TestP15T01FunctionPresenceEnvelope|TestP15T01DefaultsGuardedByPresence|TestP15BRG07DirectReferenceKindsRoundTrip|TestP15NativeReferenceOrderedOperandWire|TestP15T04OpaqueTypeProduction|TestP15RequireMutableAndSystemValuesCapturedOnce|TestP15C01DefaultGuardStructure|TestP15C01DefaultEffectsOnce|TestP15C01ArgumentValueSnapshot|TestP15BindingDefaultsPublicRoutes)$','.']
log=out/'clean-fc560ae-go.jsonl'
if log.exists(): raise SystemExit('candidate exists; preserve')
started=time.time(); timed=False
with log.open('wb') as f:
 proc=subprocess.Popen(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS|subprocess.CREATE_NEW_PROCESS_GROUP)
 try: rc=proc.wait(timeout=240)
 except subprocess.TimeoutExpired:
  timed=True;subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True);rc=proc.wait(timeout=20)
raw=log.read_bytes(); counts={'pass':0,'fail':0,'skip':0}; failures=[];tail=[]
for line in raw.splitlines():
 try: row=json.loads(line)
 except Exception: continue
 if row.get('Test') and row.get('Action') in counts:
  counts[row['Action']]+=1
  if row['Action']=='fail':failures.append(row['Test'])
 if row.get('Output'):tail.append(row['Output'])
if status(): raise SystemExit('source changed during clean gate')
summary={'head':head,'source_before':before,'source_after':status(),'command':cmd,'exit_code':rc,'timed_out':timed,'elapsed_seconds':round(time.time()-started,3),'available_memory_before':m.ullAvailPhys,'named_outcomes':counts,'failures':failures,'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'log':str(log)}
(out/'clean-fc560ae-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
print('DIAGNOSTICS')
for x in tail:
 if any(s in x for s in ['capture count','explicit value','presence=','CLI','production compile','slot ','undefined','cannot ','panic:','no required']):print(x.rstrip())
