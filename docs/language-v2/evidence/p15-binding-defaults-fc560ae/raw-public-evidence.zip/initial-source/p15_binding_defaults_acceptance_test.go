package main

import (
    "encoding/base64"
    "fmt"
    "os"
    "path/filepath"
    "reflect"
    "strings"
    "testing"

    "github.com/electrikmilk/cherri/internal/language/analysis"
    "github.com/electrikmilk/cherri/internal/language/service"
    "howett.net/plist"
)

func p15BindingFixture(t *testing.T, name string) string {
    t.Helper()
    var raw, err = os.ReadFile(filepath.Join("tests", "runtime_poc", name+".cherri"))
    if err != nil { t.Fatal(err) }
    return string(raw)
}

func p15BindingDescriptors(value any, kind string) []map[string]any {
    var found []map[string]any
    var visit func(any)
    visit = func(value any) {
        switch v := value.(type) {
        case map[string]any:
            if v["Type"] == kind { found = append(found, v) }
            for _, child := range v { visit(child) }
        case []any:
            for _, child := range v { visit(child) }
        }
    }
    visit(value)
    return found
}

func p15BindingTokenText(value any) (string, map[string]any, bool) {
    var outer, ok = value.(map[string]any)
    if !ok || outer["WFSerializationType"] != "WFTextTokenString" { return "", nil, false }
    var body, bodyOK = outer["Value"].(map[string]any)
    if !bodyOK { return "", nil, false }
    var text, textOK = body["string"].(string)
    var refs, refsOK = body["attachmentsByRange"].(map[string]any)
    return text, refs, textOK && refsOK
}

func p15BindingSnapshotError(actions []map[string]any, kind string) error {
    var positions = map[string]int{}
    for index, action := range actions {
        if id, ok := p15C01Params(action)["UUID"].(string); ok && id != "" {
            if _, duplicate := positions[id]; duplicate { return fmt.Errorf("duplicate producer UUID %s", id) }
            positions[id] = index
        }
    }
    var captureIndex = -1
    var captureID string
    var captures = 0
    var first, later = -1, -1
    for index, action := range actions {
        var p = p15C01Params(action)
        var refs = p15BindingDescriptors(p["WFVariable"], kind)
        if action["WFWorkflowActionIdentifier"] == "is.workflow.actions.getvariable" && len(refs) == 1 && (kind != "Variable" || refs[0]["VariableName"] == "numCaptureSrc") {
            captures++
            captureIndex = index
            captureID, _ = p["UUID"].(string)
        }
        if kind == "Variable" && action["WFWorkflowActionIdentifier"] == "is.workflow.actions.setvariable" && p["WFVariableName"] == "numCaptureSrc" {
            var inputs = p15BindingDescriptors(p["WFInput"], "ActionOutput")
            if len(inputs) != 1 { return fmt.Errorf("variable assignment lost exact Number producer") }
            var producerID, _ = inputs[0]["OutputUUID"].(string)
            var at, exists = positions[producerID]
            if !exists || at >= index || actions[at]["WFWorkflowActionIdentifier"] != "is.workflow.actions.number" { return fmt.Errorf("assignment has no preceding Number producer") }
            var number = p15C01Params(actions[at])["WFNumberActionNumber"]
            switch fmt.Sprint(number) {
            case "1": if first != -1 { return fmt.Errorf("duplicate initial assignment") }; first = index
            case "2": if later != -1 { return fmt.Errorf("duplicate later assignment") }; later = index
            default: return fmt.Errorf("assignment value changed: %v", number)
            }
        }
        if kind == "Clipboard" && action["WFWorkflowActionIdentifier"] == "is.workflow.actions.setclipboard" {
            var inputs = p15BindingDescriptors(p["WFInput"], "ActionOutput")
            if len(inputs) != 1 { return fmt.Errorf("clipboard write lost exact Text producer") }
            var producerID, _ = inputs[0]["OutputUUID"].(string)
            var at, exists = positions[producerID]
            if !exists || at >= index { return fmt.Errorf("clipboard write has no preceding producer") }
            switch p15C01Params(actions[at])["WFTextActionText"] {
            case "clip_initial": if first != -1 { return fmt.Errorf("duplicate initial clipboard write") }; first = index
            case "clip_overwritten": if later != -1 { return fmt.Errorf("duplicate later clipboard write") }; later = index
            }
        }
    }
    if captures != 1 || captureID == "" || first < 0 || later < 0 || !(first < captureIndex && captureIndex < later) {
        return fmt.Errorf("%s capture count=%d id=%q order first=%d capture=%d later=%d", kind, captures, captureID, first, captureIndex, later)
    }
    var consumed = 0
    for index, action := range actions {
        var p = p15C01Params(action)
        if kind == "Clipboard" && index != captureIndex && len(p15BindingDescriptors(p, kind)) > 0 { return fmt.Errorf("deferred clipboard read outside capture at %d", index) }
        var text, refs, ok = p15BindingTokenText(p["WFTextActionText"])
        if !ok || !strings.HasPrefix(text, "CHERRI_BINDING_CAPTURE_OK\n") { continue }
        if index <= later { return fmt.Errorf("consumer precedes later mutation") }
        for _, raw := range refs {
            var ref, ok = raw.(map[string]any)
            if !ok { return fmt.Errorf("malformed consumer reference") }
            if ref["Type"] == "ActionOutput" && ref["OutputUUID"] == captureID { consumed++ }
            if kind == "Variable" && ref["Type"] == "Variable" && ref["VariableName"] == "numCaptureSrc" { return fmt.Errorf("consumer rereads mutable variable") }
        }
    }
    if consumed != 2 { return fmt.Errorf("original %s capture consumed %d times, want exactly twice", kind, consumed) }
    return nil
}

func TestP15V01DeclarationSnapshotProduction(t *testing.T) {
    var source = p15BindingFixture(t, "CherriBindingCapturePOC")
    for _, native := range []bool{false, true} {
        t.Run(fmt.Sprint(native), func(t *testing.T) {
            var current = source
            if native { current = strings.ReplaceAll(strings.ReplaceAll(current, "= 1\n", "= number(1)\n"), "= 2\n", "= number(2)\n") }
            var actions = p15CompiledActions(t, current)
            if err := p15BindingSnapshotError(actions, "Variable"); err != nil { t.Fatal(err) }
            for _, mutation := range []string{"remove", "duplicate", "after_mutation", "wrong_source", "wrong_identity", "deferred", "wrong_initial"} {
                t.Run(mutation, func(t *testing.T) {
                    var broken = p15C01Clone(t, actions)
                    var capture = -1
                    var uuid string
                    for i, action := range broken {
                        var refs = p15BindingDescriptors(p15C01Params(action)["WFVariable"], "Variable")
                        if len(refs) == 1 && refs[0]["VariableName"] == "numCaptureSrc" { capture = i; uuid, _ = p15C01Params(action)["UUID"].(string) }
                    }
                    switch mutation {
                    case "remove": broken = append(broken[:capture], broken[capture+1:]...)
                    case "duplicate": broken = append(broken, broken[capture])
                    case "after_mutation": var saved = broken[capture]; broken = append(broken[:capture], broken[capture+1:]...); broken = append(broken, saved)
                    case "wrong_source": p15BindingDescriptors(p15C01Params(broken[capture])["WFVariable"], "Variable")[0]["VariableName"] = "another"
                    case "wrong_initial":
                        for _, action := range broken { if fmt.Sprint(p15C01Params(action)["WFNumberActionNumber"]) == "1" { p15C01Params(action)["WFNumberActionNumber"] = 9 } }
                    default:
                        for _, action := range broken {
                            for _, ref := range p15BindingDescriptors(p15C01Params(action)["WFTextActionText"], "ActionOutput") {
                                if ref["OutputUUID"] != uuid { continue }
                                if mutation == "wrong_identity" { ref["OutputUUID"] = "not-the-original" } else { ref["Type"] = "Variable"; ref["VariableName"] = "numCaptureSrc"; delete(ref,"OutputUUID") }
                            }
                        }
                    }
                    if p15BindingSnapshotError(broken, "Variable") == nil { t.Fatal("corruption escaped oracle") }
                })
            }
        })
    }
}

func TestP15V03ClipboardCapturedOnceProduction(t *testing.T) {
    var source = p15BindingFixture(t, "CherriBindingCapturePOC")
    for _, spelling := range []string{"clipboard", "Clipboard"} {
        t.Run(spelling, func(t *testing.T) {
            var actions = p15CompiledActions(t, strings.ReplaceAll(source, "= clipboard\n", "= "+spelling+"\n"))
            if err := p15BindingSnapshotError(actions, "Clipboard"); err != nil { t.Fatal(err) }
            for _, mutation := range []string{"remove", "duplicate", "after_mutation", "wrong_system", "deferred", "wrong_identity"} {
                t.Run(mutation, func(t *testing.T) {
                    var broken = p15C01Clone(t, actions)
                    var capture = -1
                    var uuid string
                    for i, action := range broken {
                        if len(p15BindingDescriptors(p15C01Params(action)["WFVariable"], "Clipboard")) == 1 { capture = i; uuid, _ = p15C01Params(action)["UUID"].(string) }
                    }
                    switch mutation {
                    case "remove": broken = append(broken[:capture], broken[capture+1:]...)
                    case "duplicate": broken = append(broken, broken[capture])
                    case "after_mutation": var saved = broken[capture]; broken = append(broken[:capture], broken[capture+1:]...); broken = append(broken, saved)
                    case "wrong_system": p15BindingDescriptors(p15C01Params(broken[capture])["WFVariable"], "Clipboard")[0]["Type"] = "CurrentDate"
                    default:
                        for _, action := range broken {
                            for _, ref := range p15BindingDescriptors(p15C01Params(action)["WFTextActionText"], "ActionOutput") {
                                if ref["OutputUUID"] != uuid { continue }
                                if mutation == "wrong_identity" { ref["OutputUUID"] = "later-write-producer" } else { ref["Type"] = "Clipboard"; delete(ref,"OutputUUID"); delete(ref,"OutputName") }
                            }
                        }
                    }
                    if p15BindingSnapshotError(broken, "Clipboard") == nil { t.Fatal("corruption escaped oracle") }
                })
            }
        })
    }
}

func TestP15T01FunctionPresenceNativeValues(t *testing.T) {
    var prefix = "function t01(flag: Bool = true, num: Number = 9, txt: Text = \"def\", items: List<Text> = [\"default\"], object: Map<Text, Text> = {\"default\": \"present\"}) -> Text { return txt }\n"
    var cases = []struct{name, call string; supplied []bool}{
        {"explicit", "t01(false,num:0,txt:\"\",items:[],object:{})", []bool{true,true,true,true,true}},
        {"omitted", "t01()", []bool{false,false,false,false,false}},
        {"mixed", "t01(items:[],flag:false)", []bool{true,false,false,true,false}},
    }
    for _, tc := range cases {
        t.Run(tc.name, func(t *testing.T) {
            var actions = p15CompiledActions(t,prefix+tc.call)
            var fields = p15C01CallFields(t,actions,false)
            for i, supplied := range tc.supplied {
                var presence, err = p15LiteralText(fields[fmt.Sprintf("has_arg_%d",i)])
                var want = "0"
                if supplied { want = "1" }
                if err != nil || presence != want { t.Fatalf("slot %d presence=%q %v",i,presence,err) }
                var value, exists = fields[fmt.Sprintf("arg_%d",i)]
                if exists != supplied { t.Fatalf("slot %d value presence=%v, supplied=%v",i,exists,supplied) }
                if !supplied { continue }
                var expected = []any{p15LiteralNumber("0"),p15LiteralNumber("0"),"",[]any{},map[string]any{}}[i]
                var row = map[string]any{"WFValue":value,"WFItemType":[]int{3,3,0,2,1}[i]}
                var actual, decodeErr = p15ReadDictionaryRow(row)
                if decodeErr != nil || !reflect.DeepEqual(actual,expected) { t.Fatalf("slot %d explicit value changed: %#v want %#v; %v",i,actual,expected,decodeErr) }
            }
        })
    }
}

func TestP15BindingDefaultsPublicRoutes(t *testing.T) {
    var binary = p15AcceptanceCLI(t)
    for _, name := range []string{"CherriBindingCapturePOC","CherriTypedDefaultsPOC"} {
        t.Run(name,func(t *testing.T) {
            var source = p15BindingFixture(t,name)
            var svc = service.NewService(nil)
            var uri = "file:///"+name+".cherri"
            svc.OpenDocument(uri,1,source)
            var diagnostics, _ = svc.Analyze(uri)
            for _, d := range diagnostics { if d.Severity == analysis.SeverityError { t.Fatal(d) } }
            var mobile = compileForMobileMode(source,name,"v2",false)
            if !mobile.OK { t.Fatal(mobile.Error) }
            var mobileRaw, err = base64.StdEncoding.DecodeString(mobile.PlistBase64)
            if err != nil { t.Fatal(err) }
            var dir = t.TempDir()
            var input, output = filepath.Join(dir,name+".cherri"),filepath.Join(dir,name+".shortcut")
            if err := os.WriteFile(input,[]byte(source),0600); err != nil { t.Fatal(err) }
            var stdout, stderr, checkErr = p15RunCLI(t,binary,dir,nil,"check",input,"--json")
            if checkErr != nil || p15DecodeOneJSON(t,stdout).(map[string]any)["valid"] != true { t.Fatalf("CLI check %v %s",checkErr,stderr) }
            stdout, stderr, err = p15RunCLI(t,binary,dir,nil,"compile",input,"--skip-sign","--output="+output)
            if err != nil { t.Fatalf("CLI compile %v %s %s",err,stdout,stderr) }
            var cliRaw, readErr = os.ReadFile(output)
            if readErr != nil { t.Fatal(readErr) }
            for route, raw := range map[string][]byte{"mobile":mobileRaw,"cli":cliRaw} {
                var doc map[string]any
                if _, err := plist.Unmarshal(raw,&doc); err != nil { t.Fatal(err) }
                var rawActions, ok = doc["WFWorkflowActions"].([]any)
                if !ok || len(rawActions)==0 { t.Fatalf("%s lost native actions",route) }
                var actions = make([]map[string]any,len(rawActions))
                for i, rawAction := range rawActions { actions[i]=rawAction.(map[string]any) }
                if name=="CherriBindingCapturePOC" {
                    for _,kind:=range []string{"Variable","Clipboard"} { if err:=p15BindingSnapshotError(actions,kind);err!=nil { t.Fatalf("%s %s: %v",route,kind,err) } }
                }
            }
        })
    }
}
