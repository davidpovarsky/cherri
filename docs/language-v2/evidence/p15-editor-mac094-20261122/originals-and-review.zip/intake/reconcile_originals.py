"""Read existing Mac originals; never launches Swift, Go, Git, or a model."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import zipfile

HERE = Path(__file__).resolve().parent
ORIGINALS = HERE.parent / "ci-failure-intake-20261122"
SOURCE = "094388d443e0f95f5d4527ab047852647d38cacb"
PREFIX = "/Users/runner/work/_temp/cherri-editor-contract-evidence/"
REPO = "/Users/runner/work/cherri/cherri"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(raw):
    def unique(rows):
        result = {}
        for key, value in rows:
            assert key not in result, "duplicate key"
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def stamp(text):
    value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    assert value.utcoffset().total_seconds() == 0
    return value


def region(text, first, last):
    assert text.count(first) == text.count(last) == 1
    start, end = text.index(first), text.index(last)
    assert start < end
    value = text[start:end].strip()
    assert not any(line.strip().startswith("#") for line in value.splitlines())
    return value


def constant(raw, name):
    tree = ast.parse(raw)
    values = [node.value for node in tree.body if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
    assert len(values) == 1
    return ast.literal_eval(values[0])


def witness(raw):
    return {"bytes": len(raw), "sha256": sha(raw)}


outer = (ORIGINALS / "14732682096.original.zip").read_bytes()
assert witness(outer) == {"bytes": 385155, "sha256": "e062c85705cba1f5e429fda447639cc2458183a25447b98c4bb4f970c41a0e5e"}
members = ORIGINALS / "14732682096.members"
inventory = load((members / "inventory.json").read_bytes())
archive = (members / "public-editor-evidence.zip").read_bytes()
assert sha(archive) == inventory["archive_sha256"]
assert inventory["ci_source_sha"] == SOURCE and inventory["ci_run_id"] == "44964931190"
assert inventory["ui_executed"] is False and inventory["formal_requirements_proved"] == []
with zipfile.ZipFile(members / "public-editor-evidence.zip") as zipped:
    assert len(zipped.namelist()) == len(set(zipped.namelist())) == 69
    files = {name: zipped.read(name) for name in zipped.namelist()}
assert set(files) == {row["path"] for row in inventory["files"]}
for row in inventory["files"]:
    assert witness(files[row["path"]]) == {k: row[k] for k in ("bytes", "sha256")}
assert sum(map(len, files.values())) == inventory["total_bytes"] == 1684448

fetches = load((HERE / "source-fetches.original.json").read_bytes())
for part in sorted(HERE.glob("source-fetches-extra-*.original.json")):
    fetches += load(part.read_bytes())
sources, source_blobs = {}, []
for row in fetches:
    original = row["result"]["structuredContent"]
    raw = original["content"].encode("utf-8")
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    assert blob == original["sha"]
    sources[row["path"]] = raw
    source_blobs.append({"path": row["path"], "git_blob": blob, **witness(raw)})
assert len(sources) == len(fetches) == 107
contract = load(sources["tools/language-acceptance/editor_contract_inventory.json"])
assert len(contract["source_paths"]) == len(set(contract["source_paths"])) == 107
assert set(sources) == set(contract["source_paths"])
ancestry_envelope = load((HERE / "source-ancestry.original.json").read_bytes())
ancestry = load(ancestry_envelope["structuredContent"]["content"])
assert ancestry["status"] == "ahead" and ancestry["behind_by"] == 0
assert ancestry["merge_base_commit"]["sha"] == "254313031edf3cad9fd78d97c265eb06a21fd392"
contract_hashes = {
    "acceptance-contract.json": "9fdfa8910b09824dc61395d8ddf4aa8fe8914619af0fdde59c63b67ab10b895e",
    "repair-regression-plan.json": "eba070df0e1ff229a94e52d977a09c2a0c125a31b1a69caf32787d41600074f5",
    "backend-recovery-gates.json": "e7fbb3ad177c5142935f71a46ca7e89b84822061bfc0919eec59708811ab7e7c",
}
immutable_contracts = []
for row in load((HERE / "contracts.original.json").read_bytes()):
    value = row["result"]["structuredContent"]
    raw = value["content"].encode()
    assert sha(raw) == contract_hashes[PurePosixPath(row["path"]).name]
    assert hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == value["sha"]
    immutable_contracts.append({"path":row["path"], "git_blob":value["sha"], **witness(raw)})
assert len(immutable_contracts) == 3
child = load((HERE / "asana-local-child.original.json").read_bytes())["structuredContent"]["data"]
assert child["gid"] == "1220738758291836" and child["completed"] is False
start = child["notes"].index("Definition of done for THIS child only:")
stop = child["notes"].index("\n\nHistorical", start)
child_dod = child["notes"][start:stop]
source_witnesses = None
process_results = []
swift_results = []

for name, raw in files.items():
    if not name.endswith("-process.json"):
        continue
    receipt = load(raw)
    assert receipt["format_version"] == 1 and receipt["source_commit"] == SOURCE
    assert receipt["source_clean_before"] is receipt["source_clean_after"] is True
    assert receipt["exit_code"] == 0 and type(receipt["exit_code"]) is int
    assert receipt["timed_out"] is False
    begun, ended = stamp(receipt["started_utc"]), stamp(receipt["finished_utc"])
    assert begun <= ended and 0 <= receipt["elapsed_seconds"] < 180
    manifest = receipt["source_files"]
    assert [row["path"] for row in manifest] == contract["source_paths"]
    if source_witnesses is None:
        source_witnesses = manifest
    assert manifest == source_witnesses
    for row in manifest:
        if row["path"] in sources:
            assert sha(sources[row["path"]]) == row["sha256"]
    stem = name.removesuffix("-process.json")
    actual, errors = files[stem + "-go.jsonl"], files[stem + "-stderr.log"]
    assert witness(actual) == {"bytes": receipt["raw_bytes"], "sha256": receipt["raw_sha256"]}
    assert witness(errors) == {"bytes": receipt["stderr_bytes"], "sha256": receipt["stderr_sha256"]}
    assert errors == b""
    rid = receipt["requirement"]
    spec = contract["scenarios"][rid]
    step_name = PurePosixPath(stem).name.split("-", 1)[1]
    if step_name == "swift":
        process_results.append({"path": name, "kind": "swift-wrapper", "requirement": rid,
                                "command": receipt["command"], "interval": [receipt["started_utc"], receipt["finished_utc"]],
                                "elapsed_seconds": receipt["elapsed_seconds"]})
        continue
    step = next(value for value in spec["steps"] if value["name"] == step_name)
    expected = step["events"]
    assert receipt["required_tests"] == receipt["discovered_tests"] == expected
    assert receipt["command"] == ["go", "test", "-count=1", "-json", "-timeout", "3m0s",
                                  step["package"], "-run", "^(" + "|".join(step["tests"]) + ")$"]
    active, passed, package_started, package_passed = set(), set(), False, False
    for line in actual.splitlines():
        event = load(line)
        assert event["Package"] == step["package_id"] and not package_passed
        assert begun <= stamp(event["Time"]) <= ended
        test, action = event.get("Test"), event["Action"]
        assert action not in ("skip", "fail")
        if test:
            assert test in expected
            if action == "run":
                assert test not in active | passed
                active.add(test)
            elif action == "pass":
                assert test in active and test not in passed
                assert not any(child.startswith(test + "/") for child in active)
                active.remove(test); passed.add(test)
            else:
                assert action == "output"
        elif action == "start":
            assert not package_started
            package_started = True
        elif action == "pass":
            assert not active and passed == set(expected)
            package_passed = True
        else:
            assert action == "output"
    assert package_started and package_passed and not active and passed == set(expected)
    process_results.append({"path": name, "kind": "go", "requirement": rid, "step": step_name,
                            "events": len(expected), "passed": len(passed), "interval": [receipt["started_utc"], receipt["finished_utc"]],
                            "elapsed_seconds": receipt["elapsed_seconds"]})

for name in files:
    if not name.endswith("swift/receipt.json"):
        continue
    receipt = load(files[name])
    directory = PurePosixPath(name).parent
    prefix = str(directory.parent)
    rid = "E05" if "e05-" in name else "E06"
    kind = contract["scenarios"][rid]["swift_probe"]
    process = load(files[prefix + "/" + rid.lower() + "-swift-process.json"])
    expected_directory = PREFIX + str(directory)
    assert process["command"][1:] == ["-B", "tools/p10r15/editor_" + ("publication" if rid == "E05" else "position") + "_probe.py",
                                       "--repo", REPO, "--output", expected_directory]
    assert receipt["schema_version"] == 1 and receipt["passed"] is True
    assert receipt["uiExecuted"] is False and receipt["formalRequirementsProved"] == []
    assert receipt["sources_unchanged"] is True
    for row in receipt["sources"]:
        assert witness(sources[row["path"]]) == {k: row[k] for k in ("bytes", "sha256")}
    item = region(sources["ios/CherriApp/Compiler/CherriCompiler.swift"].decode(), "struct CherriCompletionItem:", "\nstruct CherriWirePosition:")
    if rid == "E05":
        assert receipt["realCompilerExecuted"] is False
        template = sources["tools/p10r15/editor_publication_probe.swift"].decode()
        build = region(sources["ios/CherriApp/App/WorkspaceView.swift"].decode(), "    private func build(", "\n    @MainActor\n    private func refreshActionCatalog")
        completion = region(sources["ios/CherriApp/Editor/CherriEditorView.swift"].decode(), "    private func refreshContextualCompletions(", "\n    private func refreshDiagnostic")
        template = template.replace("__ACTUAL_BUILD_METHOD__", build.replace("private func ", "func ", 1)).replace("__ACTUAL_COMPLETION_METHOD__", completion.replace("private func ", "func ", 1))
        generated_name, binary, execute_budget, count = "editor-publication-generated.swift", "editor-publication-probe", 45, 26
        names = constant(sources["tools/p10r15/editor_publication_probe.py"], "CONTROL_NAMES")
    else:
        template = sources["tools/p10r15/editor_position_probe.swift"].decode()
        generated_name, binary, execute_budget, count = "position-generated.swift", "position-probe", 20, 17
        names = constant(sources["tools/p10r15/editor_position_probe.py"], "NAMES")
    generated = ("import Foundation\n" + item + "\n" + template).encode()
    assert generated == files[str(directory / generated_name)]
    assert receipt["generated"] == {"path": generated_name, **witness(generated)}
    expected_compile = ["/usr/bin/swiftc", "-parse-as-library", expected_directory + "/" + generated_name,
                        REPO + "/ios/CherriApp/Editor/CherriCompletionRequest.swift"]
    if rid == "E05":
        expected_compile += [REPO + "/ios/CherriApp/Editor/CherriEditorBuildRequest.swift"]
    expected_compile += ["-o", expected_directory + "/" + binary]
    assert receipt["compile"]["command"] == expected_compile
    assert receipt["execution"]["command"] == [expected_directory + "/" + binary]
    assert receipt["binary"] == witness(files[str(directory / binary)])
    for label, budget in (("compile", 90), ("execution", execute_budget)):
        stage = receipt[label]
        assert type(stage["exit_code"]) is int and stage["exit_code"] == 0
        assert stage["timed_out"] is False and stage["within_budget"] is True
        assert stage["timeout_seconds"] == budget and type(stage["duration_seconds"]) in (int, float)
        assert math.isfinite(stage["duration_seconds"]) and 0 <= stage["duration_seconds"] <= budget
        for row in stage["artifacts"]:
            assert witness(files[str(directory / row["path"])]) == {k: row[k] for k in ("bytes", "sha256")}
    controls = [load(line) for line in files[str(directory / "execute.stdout")].splitlines()]
    assert len(controls) == count + 1
    assert len({row["name"] for row in controls[:-1]}) == count
    assert {row["name"] for row in controls[:-1]} == set(names)
    assert all(row["event"] == "control" and row["result"] == "PASS" for row in controls[:-1])
    summary = controls[-1]
    assert summary["controls"] == count and summary["failed"] == 0 and summary["uiExecuted"] is False
    if rid == "E05":
        assert receipt["controls"] == controls[:-1] and receipt["summary"] == summary
        assert summary["realCompilerExecuted"] is False
    else:
        assert receipt["rows"] == controls
        expected_positions = [(1,1),(1,5),(1,7),(2,1),(2,3),(2,4),(2,6),(2,7),(2,8),
                              (None,None),(None,None),(None,None),(None,None),(1,1),(None,None),(2,1),(2,3)]
        assert [(row["observation"]["line"],row["observation"]["column"]) for row in controls[:-1]] == expected_positions
    swift_results.append({"receipt": name, "kind": kind, "controls": count, "compile_command": expected_compile,
                          "execute_command": receipt["execution"]["command"], "compile_seconds": receipt["compile"]["duration_seconds"],
                          "execution_seconds": receipt["execution"]["duration_seconds"], "generated": receipt["generated"],
                          "binary": receipt["binary"], "ui_executed": False})

record_results = []
for name in ("editor-contract-evidence.json", "canonical-swift-paths/canonical-swift-paths-evidence.json"):
    proof = load(files[name])
    assert proof["source"] == SOURCE
    for record in proof["records"]:
        rid, = record["requirements"]
        assert record["implementation_sha"] == SOURCE and record["tier"] == contract["scenarios"][rid]["tier"]
        assert record["result"] == "passed" and record["exit_code"] == 0
        for artifact in record["artifacts"]:
            assert artifact["path"].startswith(PREFIX)
            assert sha(files[artifact["path"][len(PREFIX):]]) == artifact["sha256"]
        outcome = proof["results"][rid]
        assert outcome["status"] == "PENDING_EXTERNAL" and outcome["passed"] is False
        assert outcome["executed_levels"] == [record["tier"]]
        record_results.append({"proof": name, "id": rid, "tier": record["tier"], "status": "PENDING_EXTERNAL"})
    if "report" in proof:
        assert proof["report"]["closure_complete"] is False
        assert (proof["report"]["passed_cases"],proof["report"]["failed_cases"],proof["report"]["skipped_cases"]) == (0,0,5)

log_path = ORIGINALS / "job-137031690166.decoded-original.log"
log = log_path.read_bytes()
starts, terminals = Counter(), {}
for line in log.decode().splitlines():
    match = re.search(r"=== RUN\s+(TestEditorContract(?:ActualProductionEvidence|CanonicalSwiftExecutionPaths)(?:/\S+)?)$", line)
    if match:
        starts[match[1]] += 1
    match = re.search(r"--- (PASS|FAIL|SKIP): (TestEditorContract(?:ActualProductionEvidence|CanonicalSwiftExecutionPaths)(?:/\S+)?) \(([0-9.]+)s\)$", line)
    if match:
        terminals.setdefault(match[2], []).append({"action": match[1], "seconds": float(match[3])})
faults = ["wrong_source","wrong_tier","wrong_command","missing_artifact","dirty_source","timed_out","forged_source_digest","missing_child"]
swift_faults = ["compiled_body_changed","compiled_binary_changed","missing_control","swift_timeout","native_scope_claim","duplicate_swift_key"]
production = "TestEditorContractActualProductionEvidence"
canonical = "TestEditorContractCanonicalSwiftExecutionPaths"
expected_outer = {production,canonical}
for rid in ("E01","E02","E03","E05","E06"):
    expected_outer.add(production + "/" + rid)
    expected_outer.update(production + "/" + rid + "/" + f for f in faults)
    if rid in ("E05","E06"):
        expected_outer.update(production + "/" + rid + "/" + f for f in swift_faults)
        expected_outer.add(canonical + "/" + rid)
        expected_outer.update(canonical + "/" + rid + "/" + f for f in ("original_alias","foreign_directory","foreign_repository"))
assert set(starts) == set(terminals) == expected_outer and len(expected_outer) == 67
assert all(starts[name] == 1 and len(terminals[name]) == 1 and terminals[name][0]["action"] == "PASS" for name in expected_outer)
guard = "TestEditorContractRejectsUnprovedExternalAndCrossIDRecords"
expected_guard = {guard}
for rid in ("E01","E02","E03","E05","E06"):
    step = contract["scenarios"][rid]["steps"][0]
    producer = step["package_id"] + ":" + step["tests"][0]
    for tier in ("ios-ui","ios-runtime","ios-build"):
        for identity in (producer,"CherriUITests/test" + rid + "Forged"):
            expected_guard.add(guard + "/" + rid + "/" + tier + "/" + identity)
    expected_guard.add(guard + "/" + rid + "/cross_requirement")
guard_starts, guard_terminals = Counter(), {}
for line in log.decode().splitlines():
    match = re.search(r"=== RUN\s+(" + guard + r"(?:/\S+)?)$", line)
    if match:
        guard_starts[match[1]] += 1
    match = re.search(r"--- (PASS|FAIL|SKIP): (" + guard + r"(?:/\S+)?) \(([0-9.]+)s\)$", line)
    if match:
        guard_terminals.setdefault(match[2], []).append(match[1])
assert set(guard_starts) == set(guard_terminals) == expected_guard and len(expected_guard) == 36
assert all(guard_starts[name] == 1 and guard_terminals[name] == ["PASS"] for name in expected_guard)

report = {"scope": "READ_ONLY_RECONCILIATION_OF_EXISTING_MAC_ORIGINALS", "created_utc": datetime.now(timezone.utc).isoformat(),
          "source": SOURCE, "run": 44964931190, "job": 137031690166, "artifact": 14732682096,
          "outer_archive": witness(outer), "editor_archive": witness(archive), "members": 69, "member_bytes": 1684448,
          "source_blobs_independently_fetched": source_blobs,
          "source_witnesses_consistent_across_all_process_receipts": len(source_witnesses),
          "all_107_blobs_independently_fetched": True, "source_binding_scope": "All107 fixed Swift/Go/registrar source Git blobs independently fetched at094 and byte/hash reconciled to every original process receipt; no test or compiler rerun.",
          "path_fix_ancestry": {"base": ancestry["base_commit"]["sha"], "merge_base": ancestry["merge_base_commit"]["sha"], "ahead_by": ancestry["ahead_by"], "behind_by": ancestry["behind_by"]},
          "immutable_contracts": immutable_contracts,
          "local_child_snapshot": {"id":child["gid"], "name":child["name"], "completed":False, "modified_at":child["modified_at"], "definition_of_done":child_dod, "last_comment":child["comments"][-1]["gid"]},
          "processes": process_results, "swift": swift_results, "local_records": record_results,
          "outer_log": {"path": str(log_path), **witness(log)}, "outer_fixed_events": 67, "outer_passed": 67,
          "production_parent_seconds": terminals[production][0]["seconds"], "canonical_parent_seconds": terminals[canonical][0]["seconds"],
          "external_tier_and_cross_requirement_rejection_events":36, "external_rejection_passed":36,
          "recommendation":"Local child DoD is supported by preserved historical baseline/repair proof plus this actual combined post254 source replay and strict local intake. Eligible for root-reviewed bounded completion; no child state was changed. No fresh full179 report at094 is asserted.",
          "actual_new_executions": 0, "ui_executed": False, "formal_acceptance_granted": False,
          "full_ci_status": "FAILURE preserved; this scoped intake does not override unrelated BRG32 failures or the ordinary Mac suite timeout"}
raw = (json.dumps(report,indent=2,ensure_ascii=False) + "\n").encode()
(HERE / "reconciliation.json").write_bytes(raw)
print(json.dumps({"report_sha256":sha(raw), "members":69, "source_blobs":107, "source_manifest_entries":107,
                  "outer_passed":67, "swift_controls":[row["controls"] for row in swift_results],
                  "go_process_events":[row.get("events") for row in process_results if row["kind"]=="go"],
                  "actual_new_executions":0, "formal_acceptance_granted":False}))
