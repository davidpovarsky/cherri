# Local editor child: actual macOS evidence at 094388d4

This is a read-only reconciliation of an existing CI execution. No Go, Swift,
compiler, Apple device, or model was invoked during this review. No Asana task
was marked complete.

## Decision for the bounded child

The original definition of done for child `1220738758291836` is a local
service/protocol stage. It requires preserved clean baselines and failures,
reproduced repairs, complete per-row local scenarios and causal controls,
strict source/process/test/tier binding, and separately sealed originals and
immutable Git witnesses. It explicitly withholds UI, full179, deployment and
consumer-tuple credit.

The preserved historical baseline/repair evidence was independently audited
in `e95a56353253288fc66dafe77a5104e94a8f942e`. This new packet establishes the
previously outstanding actual macOS execution of the later path correction
on combined source `094388d443e0f95f5d4527ab047852647d38cacb`. It supports
completion of the bounded local child after the root agent's independent
review. The child is still open; this packet does not perform that action.

GitHub's immutable comparison establishes that 094 contains
`254313031edf3cad9fd78d97c265eb06a21fd392`: the latter is the merge base,
094 is 183 commits ahead, and zero commits behind. All 107 exact source
witnesses from every original process receipt were fetched independently at
094. Their Git blob hashes and UTF-8 bytes match their declared SHA-256
digests. The three immutable acceptance contracts retain their original
SHA-256 values.

The 18:50 integration/fresh179 dependency was already satisfied by the
historical K1 run as documented in the earlier audit. This packet is a
combined post-254 local execution. It does **not** assert a new full179 report
at 094. If a further full179 run is retained as a current verification choice,
it remains separately pending; it is not an original requirement that all179
or the UI succeed before this local child can finish.

## Actual ordinary local records

| Requirement | Executed local scenario | Fixed original evidence |
|---|---|---|
| E01 | Contextual labels/enums/compatible variables, expected-type candidates, insertion and ownership controls | 73 Go events |
| E02 | Independent incomplete-source diagnostics with full byte/rune/UTF-16 ranges and causal corruptions | 24 Go events |
| E03 | Shared-service hover/signature/definition and scoped semantic rename, including comments/literals/shadows and capture controls | 48 Go events |
| E05 | Actual versioned mobile service state and response ownership; production Swift publication bodies with controlled asynchronous adapters | 20 Go events and 26 actual Swift controls |
| E06 | Actual framed default/negotiated UTF-16 LSP, mobile coordinate producers, and Foundation caret conversion | 33 LSP events, 35 mobile events, and 17 actual Swift controls |

Every selected original event ran and passed once in its corresponding process,
with the expected package, command, inventory and UTC interval. No failed or
skipped selected event was accepted. The ordinary record set retains exactly
five `PENDING_EXTERNAL` results: E01/E02/E03/E05 have only `service`; E06 has
only `protocol`. The selected five-row manifest reports zero full passes,
zero failures and five skipped external obligations. These two presentations
describe the same local/external boundary.

The separate real-alias control actually repeats E05 and E06, retaining another
20/33/35 Go events and 26/17 Swift controls. These repeated observations are
reported separately; they do not create additional accepted requirements.

## Source, command and executable reconciliation

The retained artifact contains 69 original files, 1,684,448 uncompressed bytes.
Every member's bytes and SHA-256 match the original collector inventory. All
record-to-artifact links also resolve to those exact originals.

Four actual Swift executions are retained: ordinary publication and position,
then publication and position through the owned alias scenario. For each:

- The generated Swift bytes were reconstructed exactly from the immutable
  production bodies and templates, including the original region helper's
  whitespace treatment.
- The outer Python invocation's exact repository and output paths match both
  the Swift compiler command and executed binary path. No archived command
  was normalized or rewritten.
- Generated-source, executable, compiler stdout/stderr and execution
  stdout/stderr hashes match the original receipts and archive files.
- Compilation exited zero inside 90 seconds; publication execution stayed
  inside 45 seconds and position execution inside 20 seconds.
- The original 26 publication and 17 position control inventories are complete.
  Position line/column observations also match the independently fixed
  Hebrew, astral, ZWJ, combining, LF/CRLF and invalid-selection cases.

The Mac `go -v` original log independently records 67 fixed passing events for
the actual-production and canonical-path test families. Their parents passed
in 24.88 and 9.43 seconds respectively. All six original-alias, foreign-output
and foreign-repository contrary controls passed. Another fixed 36 passing
events reject fabricated external tiers and cross-requirement reuse. These
counts are reconciled from the original log, not inferred from the receipt's
`passed` flag.

## Original sources and boundaries

- CI run: <https://github.com/davidpovarsky/cherri/actions/runs/44964931190>
- macOS job: `137031690166`; source: `094388d443e0f95f5d4527ab047852647d38cacb`.
- GitHub artifact `14732682096`: 385,155 bytes; SHA-256
  `e062c85705cba1f5e429fda447639cc2458183a25447b98c4bb4f970c41a0e5e`.
- Inner public-editor archive: 396,968 bytes; SHA-256
  `fec9098232c87673ba7e9d158b76f63e34a512ebf9aa568f0bd138f1f8de949f`.
- Original Mac log: 6,579,972 bytes; SHA-256
  `38d63d66738f4c020585273d8183408b41da61d1f2caca596aeb4094eaf5889c`.
- Prior local-scope audit:
  <https://github.com/davidpovarsky/cherri/blob/e95a56353253288fc66dafe77a5104e94a8f942e/docs/language-v2/p15-editor-local-scope-audit-20261121.md>.

`reconciliation.json` records exact source witnesses, process member paths,
timestamps, commands, binaries, record scopes and this decision boundary.
`source-fetches*.original.json`, `contracts.original.json`,
`source-ancestry.original.json` and `asana-local-child.original.json` retain
the independent source and scope reads. `reconcile_originals.py` is a local
read-only verifier; it does not launch production processes.

The full macOS CI job remains failed: the separate BRG32 inventory failures
and ordinary-suite timeout are preserved. There is no SwiftUI/C ABI/device
execution, real compiler adapter, real signing or Apple UI credit in this
packet. All five full acceptance rows, their UI tier, and parent179 remain
open. The old K1 Mac command tuples were not retained, so its precise `/var`
cause is still unproved; this later successful tuple is not retroactive proof
of that historical cause.
