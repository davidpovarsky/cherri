from pathlib import Path
import subprocess,os,sys,json,hashlib,time,datetime,importlib.util,ctypes,re,traceback
sys.dont_write_bytecode=True
root=Path(r'C:\Users\DAVID\Code\cherrilang-p10r15-docs-s3-20261119')
evidence=Path(r'C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\docs-s3-8b3fcf7')
source='8b3fcf71455ea2c1b4c1cf75f929ccc96f227d46'
docs='5e08813d1dadc7b3e72c5723f76a918f9f2e8361'
cache=evidence/'compiler-cache'
wrong=Path(r'C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\docs-final-b34ae47\compiler-cache\cherri.exe')
os.environ.update(GOMAXPROCS='1',GOFLAGS='-p=1',PYTHONDONTWRITEBYTECODE='1',CHERRI_SMOKE_CACHE_DIR=str(cache),CHERRI_SMOKE_TEST_CACHE=str(cache),CHERRI_SMOKE_TEST_WRONG_BINARY=str(wrong))
records=[]
start=time.monotonic()
class MemoryStatus(ctypes.Structure):
 _fields_=[('dwLength',ctypes.c_ulong),('dwMemoryLoad',ctypes.c_ulong),('ullTotalPhys',ctypes.c_ulonglong),('ullAvailPhys',ctypes.c_ulonglong),('ullTotalPageFile',ctypes.c_ulonglong),('ullAvailPageFile',ctypes.c_ulonglong),('ullTotalVirtual',ctypes.c_ulonglong),('ullAvailVirtual',ctypes.c_ulonglong),('ullAvailExtendedVirtual',ctypes.c_ulonglong)]
def free_memory():
 m=MemoryStatus();m.dwLength=ctypes.sizeof(m)
 assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
 return m.ullAvailPhys
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def run(args,*,cwd=None,check=True):
 before=free_memory()
 heavy=args[0]=='go' and args[1] in ['build','run']
 if heavy and before<2*1024**3:raise RuntimeError('Insufficient available memory for bounded docs build; other owned focused jobs remain untouched.')
 deadline=120 if heavy else 180
 p=subprocess.Popen(args,cwd=cwd,env=os.environ.copy(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 launched=time.monotonic();minimum=before;stopped=None
 while True:
  try:
   out,err=p.communicate(timeout=1);break
  except subprocess.TimeoutExpired:
   minimum=min(minimum,free_memory())
   if time.monotonic()-launched>deadline:stopped='bounded process deadline'
   elif heavy and (minimum<1536*1024**2 or before-minimum>2*1024**3):stopped='available memory dropped materially'
   if stopped:
    subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,check=False)
    out,err=p.communicate(timeout=10);break
 result=subprocess.CompletedProcess(args,p.returncode,out,err)
 row={'command':args,'cwd':str(cwd) if cwd else None,'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-launched,3),'available_memory_before':before,'minimum_available_memory':minimum,'priority':'BELOW_NORMAL_PRIORITY_CLASS','deadline_seconds':deadline,'stopped':stopped}
 records.append(row)
 (evidence/'command-progress.json').write_text(json.dumps({'source':source,'docs':docs,'running':True,'commands':records},indent=2)+'\n',encoding='utf-8')
 if out:print(out,flush=True)
 if err:print(err,file=sys.stderr,flush=True)
 if stopped:raise RuntimeError(stopped)
 if check:result.check_returncode()
 return result
try:
 assert git('rev-parse','HEAD')==docs and not git('status','--porcelain')
 assert sha(wrong)=='89b7de6d44d852e88d13f6191c0e9403f19b37c3b0e85d1c2b79d93d530498df'
 spec=importlib.util.spec_from_file_location('docs_smoke',root/'scripts/smoke_test_snippets.py')
 smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
 assert smoke.PINNED_CHERRI_COMMIT==source
 smoke.command=run
 binary=Path(smoke.ensure_pinned_cherri_binary())
 caps_result=run([str(binary),'--capabilities-json'])
 caps=json.loads(caps_result.stdout)
 (evidence/'compiler-capabilities.json').write_text(json.dumps(caps,indent=2)+'\n',encoding='utf-8')
 metadata=run(['go','version','-m',str(binary)]).stdout
 (evidence/'compiler-build-info.txt').write_text(metadata,encoding='utf-8')
 assert 'vcs.revision='+source in metadata and 'vcs.modified=false' in metadata
 canonical=evidence/'actions-reference-canonical.md'
 generated=run(['go','run','./tools/language-docs',str(canonical)],cwd=cache/'src')
 (evidence/'canonical-generator.log').write_text(generated.stdout+generated.stderr,encoding='utf-8')
 doc_path=root/'fork-language/actions.md'
 current=doc_path.read_text(encoding='utf-8')
 match=re.match(r'\A(---\n.*?\n---\n)(\n*)(.*)\Z',current,re.DOTALL)
 assert match
 canonical_text=canonical.read_text(encoding='utf-8')
 exact=match.group(3)==canonical_text
 receipt={'compiler_commit':source,'docs_commit':docs,'binary':str(binary),'binary_sha256':sha(binary),'cache_receipt':json.loads((cache/smoke.CACHE_RECEIPT).read_text()),'capabilities':caps,'canonical_generator_exit':generated.returncode,'complete_canonical_body_equal':exact,'canonical_body_sha256':sha(canonical),'frontmatter_sha256':hashlib.sha256(match.group(1).encode()).hexdigest(),'docs_source_clean_before':True,'source_cache_clean':not subprocess.check_output(['git','status','--porcelain','--untracked-files=all','--ignored=matching'],cwd=cache/'src').strip()}
 (evidence/'preparation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
 if not exact:
  raise RuntimeError('Canonical body differs; retained generated file for reviewed exact replacement before docs validation.')
 checks=[]
 for label,cmd in [('snippets',[sys.executable,'scripts/smoke_test_snippets.py','--evidence-out',str(evidence/'docs-snippets-5e08813.json')]),('cache-controls',[sys.executable,'scripts/test_smoke_test_snippets.py'])]:
  result=run(cmd,cwd=root,check=False)
  (evidence/(label+'-5e08813.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
  checks.append({'check':label,'command':cmd,'exit_code':result.returncode,'log_sha256':sha(evidence/(label+'-5e08813.log'))})
  result.check_returncode()
 snippet=json.loads((evidence/'docs-snippets-5e08813.json').read_text())
 assert snippet['passed'] is True and snippet['executed']==39 and snippet['compilerCommit']==source
 controls=(evidence/'cache-controls-5e08813.log').read_text()
 assert re.search(r'Ran 12 tests\b',controls) and re.search(r'\nOK\s*$',controls)
 assert not git('status','--porcelain')
 final={'docs_commit':docs,'compiler_commit':source,'docs_source_clean_before':True,'docs_source_clean_after':True,'source_cache_clean':not subprocess.check_output(['git','status','--porcelain','--untracked-files=all','--ignored=matching'],cwd=cache/'src').strip(),'snippet_summary':{k:snippet[k] for k in ['passed','executed','runnable','diagnostic','referenceOnly','binarySha256']},'cache_controls':{'discovered':12,'passed':12,'failed':0,'skipped':0,'wrong_real_binary_sha256':sha(wrong)},'checks':checks,'elapsed_seconds':round(time.monotonic()-start,3),'commands':records}
 (evidence/'local-validation-5e08813.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8')
 print('FINAL_DOCS_LOCAL:'+json.dumps({k:v for k,v in final.items() if k!='commands'}),flush=True)
except BaseException as error:
 (evidence/'preparation-error.json').write_text(json.dumps({'error':str(error),'source':source,'docs':docs,'commands':records,'elapsed_seconds':round(time.monotonic()-start,3)},indent=2)+'\n',encoding='utf-8')
 traceback.print_exc()
 raise
