import json,subprocess,time,hashlib,datetime
from pathlib import Path
p=Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
e=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-go-evidence-discovery-20261121\clean-7e27a7f7");e.mkdir(exist_ok=False)
(e/"submitted-script.py").write_bytes(Path(__file__).read_bytes())
def git(*args):
 r=subprocess.run(["git","--no-replace-objects",*args],cwd=p,capture_output=True,timeout=30);assert r.returncode==0;return r.stdout.decode().strip()
sha=git("rev-parse","HEAD");assert sha=="7e27a7f7139106d90e633396b9c7840f63b26ead" and not git("status","--porcelain")
receipts=[]
for label,cmd in [("list",["go","list","./..."]),("build",["go","build","./..."])]:
 start=time.monotonic();when=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(cmd,cwd=p,capture_output=True,timeout=330)
 (e/(label+".stdout")).write_bytes(r.stdout);(e/(label+".stderr")).write_bytes(r.stderr)
 rec={"command":cmd,"source":sha,"exitCode":r.returncode,"durationSeconds":round(time.monotonic()-start,3),"startedUTC":when,"stdoutSHA256":hashlib.sha256(r.stdout).hexdigest(),"stderrSHA256":hashlib.sha256(r.stderr).hexdigest()}
 if label=="list":rec["packages"]=r.stdout.decode("utf-8",errors="replace").splitlines();assert all("/docs/" not in x for x in rec["packages"])
 receipts.append(rec);(e/"partial.json").write_text(json.dumps(receipts,indent=2)+"\n")
 if r.returncode:break
summary={"source":sha,"sourceCleanBefore":True,"sourceCleanAfter":not git("status","--porcelain"),"headAfter":git("rev-parse","HEAD"),"commands":receipts,"activeSourcesChanged":False,"runtimeOrFormalAcceptanceGranted":False}
(e/"receipt.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(summary))
