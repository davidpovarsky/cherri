import os,sys,pathlib,json,hashlib,time,signal,datetime,re
E=pathlib.Path('/var/tmp/cherri-xcresult-retention-20261126/preparation-02')
Q=E.parent/'oracle-qualification-02';Q.mkdir(mode=0o700,exist_ok=False);os.umask(0o077);sys.dont_write_bytecode=True
pins=json.loads("[{\"bytes\":40602,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/qa_terminal_receipts.py\",\"sha256\":\"cc7b8d3a6f3a8937d9603125f57800d195cac93ee0a50ef35c039c88215aa2be\"},{\"bytes\":21184,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/prepare_public_artifacts.py\",\"sha256\":\"a1c575af90a111dd1828825fae049276650a38e5eac411e3e1b49b1662ba1043\"},{\"bytes\":20494,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/storage_cross_run.py\",\"sha256\":\"6f527c5e22bcd23e220f5d21d09c217abff8859fad16fd743b68183e4ced20c9\"},{\"bytes\":22225,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/xcode_destination_readiness.py\",\"sha256\":\"4b973bd979e3db7b24edb18599846f8a76661bbf5ed55fc758ad753ba7e98079\"},{\"bytes\":19880,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/xcode_destination_diagnostic.py\",\"sha256\":\"adef5a99d7f7c41d297bbcbccabb12a229c07a7d326ecd4f97a76d52e81edf99\"},{\"bytes\":19628,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/simulator_session_recovery.py\",\"sha256\":\"99f0cb92dc9ec32b2727f671f851053d53ae8e204b02d9405d0af85f188c230d\"},{\"bytes\":38742,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/json_body_probe.py\",\"sha256\":\"afaf38f499bdcd4bc56be3a5b7958b96fb65f8eaa7ea22550248a57f678b1520\"},{\"bytes\":12641,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/json_file_body_probe.py\",\"sha256\":\"6ecc10c7765b24957b94365e57bf81e0958136f3ba9629bb7866c98ab868c24f\"},{\"bytes\":36163,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/retry_http_probe.py\",\"sha256\":\"8731f6b1fffcb4c3a84af21f6d60e0969026c67611e90bbf2789ecfb8ce03121\"},{\"bytes\":14611,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/nested_list_runtime.py\",\"sha256\":\"1d78bc44abbd62b14f7af4a3272270736f37eb3a2c86bc43fa37f0d0ea179d8a\"},{\"bytes\":32947,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/nested_list_probe.py\",\"sha256\":\"b21d24eecac940ab6decd9330015a49004ccdbbb7d21e5a3b42f1b15f878d925\"},{\"bytes\":15549,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/tagged_carrier_runtime.py\",\"sha256\":\"34c13f516fe56ec1738860f6093a9af6772f309ec6938b68678aa1acbd3a0da3\"},{\"bytes\":6360,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/tagged_carrier_observation.py\",\"sha256\":\"246225eb68cf80166e608186ff677afdd0ff80e3e4a39ddfc5777374852a6784\"},{\"bytes\":24075,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/tagged_carrier_graph.py\",\"sha256\":\"69296dc7177b9ee8871410f9242fd5b50af56ef354193a47d247ae2d4cad58bf\"},{\"bytes\":9506,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/native_comparison_graph.py\",\"sha256\":\"b25c055f7718f2b47a4f7615388dbc153f66ec788c8732200644a82a54bb860d\"},{\"bytes\":15837,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/debug_label_preview.py\",\"sha256\":\"3ffe6e701c0cf6523ca8a0a3e32ea73777e3b3b3b25e31514162c085960b66cb\"},{\"bytes\":38850,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/debug_label_acceptance.py\",\"sha256\":\"6cdc2685482131f2193f401aa7f99f63492506b82341eb8ec0ddb64830f422e5\"},{\"bytes\":4717,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/project_prerequisite.py\",\"sha256\":\"6c0bed088dc53e73af138221ce72a6faff0dfa0bc0279cc254ae622dd54bd843\"},{\"bytes\":65318,\"path\":\"/var/cache/cherri-ai-darwin-hosted-targeted3-20261126/signal-control-fixture-02/fixed-capture/project_prerequisite_observation.py\",\"sha256\":\"49bcb0e3a0837cae1dc9b31dbac6f53bfa462e5608e6907cff3a1b11832b2cc5\"}]")
start=time.monotonic();first=None
result={'schema':'cherri-xctest-retention-qualification/1','status':'FAILED','nativeInvocations':0,'source':'31d7b8d871618ff3eb82a65f0afd994d2c336d36','sourceChangedAfter':False}
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,x):
 b=x if isinstance(x,bytes) else (json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 return sha(b)
class Stop(BaseException):pass
def stop(number,frame):
 global first
 if first is None:first=number;signal.setitimer(signal.ITIMER_REAL,0);raise Stop(str(number))
for n in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT):signal.signal(n,stop)
signal.setitimer(signal.ITIMER_REAL,100)
try:
 save(Q/'owner.original.py',pathlib.Path(__file__).read_bytes())
 assert sys.version_info >= (3,10)
 result['qualificationPlatform']=sys.platform;result['pythonVersion']=sys.version;result['pythonSHA256']=sha(pathlib.Path(sys.executable).read_bytes())
 s=os.statvfs(str(E));result['availableBefore']=s.f_bavail*s.f_frsize
 # Pure filesystem controls: existing sources/helpers; at most 2 MiB per captured stream and tiny private fixture trees.
 assert result['availableBefore']>16*1024**2,'QUALIFICATION_OUTPUT_CAPACITY'
 for p in pins:
  b=pathlib.Path(p['path']).read_bytes();assert len(b)==p['bytes'] and sha(b)==p['sha256']
 sys.path.insert(0,str(pathlib.Path(pins[-1]['path']).parent))
 from project_prerequisite_observation import capture
 before=E/'shell.before.original.sh';after=E/'shell.after.original.sh';test=E/'test_xcresult_retention.original.py'
 expected={before:'a3c77d4a3ff58c087e7128c6cb8ae7ad38fad08e85803a9be826c8a23a285a72',after:'b029c0bf1af37e38a8e47dfb1a7a3dab8fda0807260592c01b9fb13fd6dd231c',test:'78d7c75e6e6f1b2322689005bb5e775cfe1b748ed43805beea99daca64f259c3'}
 for p,h in expected.items():assert sha(p.read_bytes())==h
 save(Q/'sources.before.original.json',{str(p):h for p,h in expected.items()})
 bridge=json.loads("\"import importlib.util,json,os,pathlib,sys,unittest\\ntest_path,selection,report_path=sys.argv[1:4]\\nspec=importlib.util.spec_from_file_location(\\\"retention_controls\\\",test_path)\\nm=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\\nnames=json.loads(selection)\\nsuite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(x,m) for x in names)\\nevents=[]\\nclass Observed(unittest.TextTestResult):\\n def startTest(self,test):events.append({\\\"event\\\":\\\"start\\\",\\\"id\\\":test.id()});super().startTest(test)\\n def addSuccess(self,test):events.append({\\\"event\\\":\\\"PASS\\\",\\\"id\\\":test.id()});super().addSuccess(test)\\n def addFailure(self,test,error):events.append({\\\"event\\\":\\\"FAIL\\\",\\\"id\\\":test.id()});super().addFailure(test,error)\\n def addError(self,test,error):events.append({\\\"event\\\":\\\"ERROR\\\",\\\"id\\\":test.id()});super().addError(test,error)\\n def addSkip(self,test,reason):events.append({\\\"event\\\":\\\"SKIP\\\",\\\"id\\\":test.id()});super().addSkip(test,reason)\\nr=unittest.TextTestRunner(verbosity=2,resultclass=Observed).run(suite)\\nwith open(report_path,\\\"x\\\") as f:json.dump({\\\"events\\\":events,\\\"testsRun\\\":r.testsRun,\\\"failures\\\":len(r.failures),\\\"errors\\\":len(r.errors),\\\"skips\\\":len(r.skipped)},f,sort_keys=True);f.write(\\\"\\\\n\\\")\\nsys.exit(0 if r.wasSuccessful() else 1)\\n\"");save(Q/'bridge.original.py',bridge.encode())
 methods=re.findall(r'^    def (test_[^(]+)\\(',test.read_text(),re.M) if False else re.findall(r'^    def (test_[^(]+)\(',test.read_text(),re.M)
 assert len(methods)==9 and len(set(methods))==9
 commands=re.findall(r'run_cmd_timeout [0-9]+[^\n]*',before.read_text());assert commands==re.findall(r'run_cmd_timeout [0-9]+[^\n]*',after.read_text())
 save(Q/'unchanged-native-commands.original.json',commands)
 results=[]
 for name,source,names,allowance,expected_code in [('red-original',before,['XCTestRetentionTests.test_normal_cleanup_then_installed_exit_cleanup_is_idempotent','XCTestRetentionTests.test_original_closing_receipt_io_still_has_the_retention_deadline'],20,1),('green-retention',after,['XCTestRetentionTests.'+n for n in methods],60,0)]:
  d=Q/name;d.mkdir(mode=0o700)
  os.environ['CHERRI_RETENTION_TEST_SOURCE']=str(source)
  argv=[sys.executable,'-I','-B','-c',bridge,str(test),json.dumps(names),str(d/'events.original.json')]
  save(d/'intent.original.json',{'argv':argv,'timeoutSeconds':allowance,'sourceSHA256':expected[source],'testSHA256':expected[test]})
  state={}
  def journal(event,details):
   state.update(details)
   save(d/(event+'.original.json'),details)
  with (d/'stdout.original').open('xb') as out,(d/'stderr.original').open('xb') as err:
   observed,details=capture(argv,allowance,output=out,error_output=err,hard_deadline=start+100,journal=journal)
  save(d/'process.original.json',{'observation':observed,'details':details})
  assert details['cleanupParentReaped'] and details['groupAfterCleanup']['state']=='ABSENT',name+':cleanup'
  assert observed['exitCode']==expected_code,name+':exit'
  events=json.loads((d/'events.original.json').read_bytes())
  if name.startswith('red'):
   assert events['testsRun']==2 and events['failures']==2 and events['errors']==0 and events['skips']==0
   assert b'CLOSING_IO_OUTSIDE_RETENTION_DEADLINE' in (d/'stderr.original').read_bytes()
  else:
   assert events['testsRun']==9 and events['failures']==events['errors']==events['skips']==0
   assert len([x for x in events['events'] if x['event']=='PASS'])==9
  results.append({'name':name,'events':events,'exitCode':observed['exitCode'],'cleanup':'REAPED_ABSENT'})
 for p,h in expected.items():assert sha(p.read_bytes())==h
 save(Q/'sources.after.original.json',{str(p):h for p,h in expected.items()})
 result.update(status='TWO_RETENTION_EDGE_CONTROLS_RED_THEN_NINE_PASS',runs=results,nativeCommandLinesUnchanged=len(commands),sourcePins={str(p):h for p,h in expected.items()})
except BaseException as e:result.update(errorType=type(e).__name__,error=str(e)[:1600],firstInterruption=first)
finally:
 signal.setitimer(signal.ITIMER_REAL,0);result['elapsedMs']=round((time.monotonic()-start)*1000);result['completedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 h=save(Q/'result.original.json',result)
print(json.dumps({'path':str(Q/'result.original.json'),'sha256':h,'result':result}))
