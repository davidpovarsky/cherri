import importlib.util,json,os,pathlib,sys,unittest
test_path,selection,report_path=sys.argv[1:4]
spec=importlib.util.spec_from_file_location("retention_controls",test_path)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
names=json.loads(selection)
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(x,m) for x in names)
events=[]
class Observed(unittest.TextTestResult):
 def startTest(self,test):events.append({"event":"start","id":test.id()});super().startTest(test)
 def addSuccess(self,test):events.append({"event":"PASS","id":test.id()});super().addSuccess(test)
 def addFailure(self,test,error):events.append({"event":"FAIL","id":test.id()});super().addFailure(test,error)
 def addError(self,test,error):events.append({"event":"ERROR","id":test.id()});super().addError(test,error)
 def addSkip(self,test,reason):events.append({"event":"SKIP","id":test.id()});super().addSkip(test,reason)
r=unittest.TextTestRunner(verbosity=2,resultclass=Observed).run(suite)
with open(report_path,"x") as f:json.dump({"events":events,"testsRun":r.testsRun,"failures":len(r.failures),"errors":len(r.errors),"skips":len(r.skipped)},f,sort_keys=True);f.write("\n")
sys.exit(0 if r.wasSuccessful() else 1)
