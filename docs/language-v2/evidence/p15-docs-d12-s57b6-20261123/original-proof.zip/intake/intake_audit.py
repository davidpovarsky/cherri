#!/usr/bin/env python3
"""Read original D12 receipts and exact Git objects; no compiler/test/build/API calls."""
import ast,collections,datetime,hashlib,importlib.util,json,pathlib,re,subprocess,sys,zipfile
sys.dont_write_bytecode=True
B=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-docs-d12-20261123')
G=B/'generator-originals'
D=pathlib.Path('/mnt/development/projects/worktrees/cherrilang-p10r15-d12-20261123')
C=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-k12-integration-20261123')
S='57b6d919757e1d0262993c6f11c6dc1cd17d6177'
DS='ce98fa542785fe4298d3acbf38da120b32bd5029'
RUN=45123477520
DR='/home/runner/work/cherrilang.org/cherrilang.org'
CR='/home/runner/work/_temp/cherri-docs-compiler/src'
GR='/home/runner/work/_temp/cherri-docs-generation'
def need(x,msg):
    if not x: raise RuntimeError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_bytes())
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
def blob(root,rev,path):return git(root,'show',rev+':'+path)
def witness(raw):return {'bytes':len(raw),'sha256':sha(raw)}
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,obj):
    with (B/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
def utc(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
need(git(D,'rev-parse','HEAD').decode().strip()==DS,'D12 HEAD')
need(git(D,'status','--porcelain=v1','--untracked-files=all','--ignored=matching')==b'','D12 changed')
need(git(C,'rev-parse',S).decode().strip()==S,'compiler object missing')
run=readj(B/'terminal-run.original.json')
for key,value in {'id':RUN,'workflow_id':411647719,'head_sha':DS,'head_branch':'audit/cherri-p10r15-docs-d12-20261123','run_attempt':1,'event':'workflow_dispatch','path':'.github/workflows/docs-smoke-test.yml','status':'completed','conclusion':'success'}.items():need(run[key]==value,'run binding '+key)
jobs=readj(B/'terminal-jobs.original.json')
need(jobs['total_count']==2 and {x['id'] for x in jobs['jobs']}=={137522372007,137522372573},'job inventory')
for j in jobs['jobs']:need(j['run_id']==RUN and j['head_sha']==DS and j['status']=='completed' and j['conclusion']=='success','job identity/status')
acq=readj(B/'terminal-acquisition.json')
metadata=readj(B/'terminal-artifacts.original.json')['artifacts']
need(len(metadata)==3 and len(acq['artifacts'])==3,'artifact count')
artifact_rows=[]
for a in acq['artifacts']:
    m=next(x for x in metadata if x['id']==a['id'])
    raw=(B/a['original']).read_bytes()
    need(witness(raw)=={'bytes':a['bytes'],'sha256':a['sha256']},'original ZIP digest')
    need(m['name']==a['name'] and m['size_in_bytes']==len(raw) and m['digest']=='sha256:'+sha(raw) and not m['expired'],'GitHub artifact metadata')
    need(m['workflow_run']['id']==RUN and m['workflow_run']['head_sha']==DS and m['workflow_run']['head_branch']==run['head_branch'],'artifact source')
    with zipfile.ZipFile(B/a['original']) as z:
        names=z.namelist()
        need(len(names)==a['members'] and len(set(names))==len(names),'ZIP inventory')
        need(all(not n.startswith('/') and '..' not in pathlib.PurePosixPath(n).parts and '\\' not in n for n in names),'ZIP paths')
        if a['name']=='docs-generator-evidence':
            need(len(list(G.iterdir()))==105,'extracted inventory')
            for n in names:need(z.read(n)==(G/n).read_bytes(),'generator original extraction')
    artifact_rows.append(a)
# Bind every helper used for this intake before importing its pure functions.
bindings=[]
def bind(root,rev,rel,role):
    raw=blob(root,rev,rel)
    row={'role':role,'source':rev,'path':rel,**witness(raw),'gitBlob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
    if row not in bindings:bindings.append(row)
    return raw
for rel in ['scripts/verify_generated_reference.py','scripts/smoke_test_snippets.py','scripts/test_smoke_test_snippets.py','scripts/verify_site_artifacts.py','scripts/test_site_artifacts.py','.github/workflows/docs-smoke-test.yml']:
    need((D/rel).read_bytes()==bind(D,DS,rel,'docs'),'live helper differs '+rel)
sys.path.insert(0,str(D/'scripts'))
import verify_generated_reference as vg
import smoke_test_snippets as smoke
need(vg.COMPILER_SHA==smoke.PINNED_CHERRI_COMMIT==S,'helper pin')
before=readj(G/'before-source-identities.json');after=readj(G/'after-source-identities.json')
need((G/'before-source-identities.json').read_bytes()==(G/'after-source-identities.json').read_bytes(),'before/after identity bytes')
report=readj(G/'generation-report.json')
need(report['before']==before==after==report['after'],'report identity copies')
need(report['schema']=='cherri.docs-generated-reference-ci/v1' and report['compiler_source']==S and report['docs_source']==DS,'report source')
need(report['passed'] is True and report['sources_unchanged'] is True and report['apple_runtime_proved'] is False and report['formal_acceptance_granted'] is False,'report scope/status')
expected={}
for phase in ['before','after']:
    for num,args,cwd in [(1,['git','rev-parse','HEAD'],CR),(2,['git','status','--porcelain','--untracked-files=all','--ignored=matching'],CR),(3,['git','remote','get-url','origin'],CR),(4,['go','version','-m','/home/runner/work/_temp/cherri-docs-compiler/cherri'],DR)]:
        expected[f'{phase}-cache-{num}']=(args,cwd,15)
    for role,root in [('compiler',CR),('docs',DR)]:
        for label,args in [('head',['rev-parse','HEAD']),('root',['rev-parse','--show-toplevel']),('status',['status','--porcelain=v1','--untracked-files=all','--ignored=matching']),('stage',['ls-files','--stage','-z']),('flags',['ls-files','-v','-z'])]:
            expected[f'{phase}-{role}-{label}']=(['git','--no-replace-objects',*args],root,15)
    expected[phase+'-docs-origin']=(['git','remote','get-url','origin'],DR,15)
expected['generate']=(['go','run','-p=2','./tools/language-docs',GR+'/actions-reference.generated.md'],CR,180)
expected['check']=(['go','run','-p=2','./tools/language-docs','--check',GR+'/actions-reference.generated.md'],CR,180)
expected['go-controls']=(['go','test','-p=2','-count=1','-json','-timeout=60s','./tools/language-docs','-run',vg.TEST_PATTERN],CR,90)
expected_order=[k for k in expected if k.startswith('before-')]+['generate','check','go-controls']+[k for k in expected if k.startswith('after-')]
need(len(expected)==33 and [p['label'] for p in report['processes']]==expected_order,'process inventory/order')
process_rows=[]
previous=utc(report['started_utc'])
for row in report['processes']:
    label=row['label'];args,cwd,budget=expected[label]
    need(readj(G/(label+'.process.json'))==row,'process copy '+label)
    need(row['command']==args and row['cwd']==cwd and row['budget_seconds']==budget,'actual command/budget '+label)
    need(row['state']=='TERMINAL' and row['passed'] is True and row['returncode']==0 and row['timed_out'] is False and row['cleanup_complete'] is True and row['orphaned_group'] is False and row['signals']==[],'process outcome '+label)
    start,finish=utc(row['started_utc']),utc(row['finished_utc'])
    need(previous<=start<=finish<=utc(report['finished_utc']) and 0<=row['elapsed_seconds']<budget and abs((finish-start).total_seconds()-row['elapsed_seconds'])<0.1,'process times '+label)
    previous=finish
    for stream in ['stdout','stderr']:
        rec=row[stream];name=label+'.'+stream+'.original';raw=(G/name).read_bytes()
        need(rec['path']==GR+'/'+name and witness(raw)=={'bytes':rec['bytes'],'sha256':rec['sha256']},'stream identity '+name)
        if stream=='stderr':need(raw==b'','stderr nonempty '+label)
    process_rows.append({'label':label,'command':args,'budgetSeconds':budget,'elapsedSeconds':row['elapsed_seconds'],'startedAt':row['started_utc'],'finishedAt':row['finished_utc'],'returncode':0,'stdout':witness((G/(label+'.stdout.original')).read_bytes()),'stderr':witness(b'')})
need(len(list(G.glob('*.process.json')))==33 and len(list(G.glob('*.stdout.original')))==33 and len(list(G.glob('*.stderr.original')))==33,'original process/stream counts')
for field,label in [('generation','generate'),('check','check'),('go_controls','go-controls')]:need(report['commands'][field]==readj(G/(label+'.process.json')),'named command join')
# Compare complete staged tree and flag witnesses to immutable Git objects.
tree_counts={}
cache_text_hashes={}
for role,root,rev,ciroot in [('compiler',C,S,CR),('docs',D,DS,DR)]:
    entries=[]
    for record in git(root,'ls-tree','-r','-z','--full-tree',rev).split(b'\0'):
        if not record:continue
        left,name=record.split(b'\t',1);mode,typ,oid=left.split();need(typ in (b'blob',b'commit'),'Git tree member')
        entries.append((name,mode,oid))
    entries.sort()
    stage=b''.join(mode+b' '+oid+b' 0\t'+name+b'\0' for name,mode,oid in entries)
    flags=b''.join(b'H '+name+b'\0' for name,_,_ in entries)
    for phase in ['before','after']:
        state=before[role]
        need(state['root']==ciroot and state['head']==rev and state['clean'] is True,'source identity '+role)
        need((G/f'{phase}-{role}-stage.stdout.original').read_bytes()==stage and (G/f'{phase}-{role}-flags.stdout.original').read_bytes()==flags,'complete Git inventory '+role)
        need(state['tracked_stage_sha256']==sha(stage) and state['tracked_flags_sha256']==sha(flags),'source inventory digest '+role)
        for suffix,value in [('head',rev+'\n'),('root',ciroot+'\n'),('status','')]:need((G/f'{phase}-{role}-{suffix}.stdout.original').read_bytes()==value.encode(),'source command output '+role+suffix)
    for rel,obs in before[role]['files'].items():
        raw=bind(root,rev,rel,role)
        need(witness(raw)=={'bytes':obs['bytes'],'sha256':obs['sha256']} and obs['git_blob']==hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest() and obs['path']==ciroot+'/'+rel,'file source witness '+rel)
    tree_counts[role]={'trackedEntries':len(entries),'stageSha256':sha(stage),'flagsSha256':sha(flags),'witnessFiles':len(before[role]['files'])}
    if role=='compiler':
        # Cache tests use newline-delimited, Git-quoted output rather than -z.
        text_stage=[]
        text_flags=[]
        for record in git(root,'ls-tree','-r','--full-tree',rev).splitlines():
            left,name=record.split(b'\t',1);mode,typ,oid=left.split()
            text_stage.append(mode+b' '+oid+b' 0\t'+name+b'\n');text_flags.append(b'H '+name+b'\n')
        cache_text_hashes={'trackedStageSha256':sha(b''.join(text_stage)),'trackedFlagsSha256':sha(b''.join(text_flags))}
need(before['docs']['origin']=='https://github.com/davidpovarsky/cherrilang.org','Docs origin')
for phase in ['before','after']:
    need((G/f'{phase}-cache-1.stdout.original').read_bytes()==(S+'\n').encode(),'cache source')
    need((G/f'{phase}-cache-2.stdout.original').read_bytes()==b'','cache dirty')
    need((G/f'{phase}-cache-3.stdout.original').read_bytes()==b'https://github.com/davidpovarsky/cherri.git\n','cache origin')
    need((G/f'{phase}-docs-origin.stdout.original').read_bytes()==b'https://github.com/davidpovarsky/cherrilang.org\n','Docs origin output')
    raw=(G/f'{phase}-compiler-cache-receipt.original.json').read_bytes();obs=before['cache']['receipt_file']
    need(witness(raw)=={'bytes':obs['bytes'],'sha256':obs['sha256']} and json.loads(raw)==before['cache']['receipt'],'cache receipt bytes')
need(before['cache']['receipt']['compilerCommit']==S and before['cache']['receipt']['vcsModified'] is False and before['cache']['receipt']['binarySha256']==before['cache']['binary']['sha256'],'binary source witness')
build_raw=(G/'before-cache-4.stdout.original').read_bytes()
need(build_raw==(G/'after-cache-4.stdout.original').read_bytes(),'binary metadata before/after')
build_lines=build_raw.decode().splitlines()
build={line.split('\t',2)[2].split('=',1)[0]:line.split('=',1)[1] for line in build_lines if line.startswith('\tbuild\t') and '=' in line}
need(build.get('vcs.revision')==S and build.get('vcs.modified')=='false' and build.get('GOOS')=='linux' and build.get('GOARCH')=='amd64','original build-info identity')
need(build_lines[0]=='/home/runner/work/_temp/cherri-docs-compiler/cherri: go1.24.13' and '\tpath\tgithub.com/electrikmilk/cherri' in build_lines,'build metadata module/tool')
go=vg.verify_go_events((G/'go-controls.stdout.original').read_bytes(),report['commands']['go_controls'])
need(go==report['go_events'],'Go event replay')
generated=(G/'actions-reference.generated.md').read_bytes()
need(witness(generated)=={'bytes':report['generated']['bytes'],'sha256':report['generated']['sha256']},'generated original')
reference=vg.verify_reference(generated,bind(C,S,'docs/language-v2/actions-reference.md','compiler'),bind(D,DS,'fork-language/actions.md','docs'))
need(reference==report['reference'],'reference replay')
# Replay source classification/hashes only; never call test_file/check_example.
with zipfile.ZipFile(B/'artifacts/14795155193-docs-snippet-evidence.original.zip') as z:snip=json.loads(z.read('cherri-docs-evidence.json'))
targets=['index.md','fork-language/guide.md','fork-language/migration.md','fork-language/actions.md','language/functions.md','language/variables-constants-globals.md']
expected_snips=[]
for rel in targets:
    content=bind(D,DS,rel,'docs').decode()
    for idx,match in enumerate(smoke.FENCES.finditer(content),1):
        kind,code=match['kind'],match['code'].strip();need(bool(code),'empty snippet')
        isref=(rel=='fork-language/actions.md' or kind in ('cherri-legacy','cherri-fragment'))
        errs=[]
        if not isref:
            need(kind=='cherri','unexpected snippet kind')
            ann=smoke.EXPECTATION.search(content[:match.start()])
            if ann:
                fields=ann[1].split();need(len(fields)>=2 and fields[0]=='diagnostic' and all(re.fullmatch(r'E_[A-Z0-9_]+',x) for x in fields[1:]),'diagnostic annotation');errs=fields[1:]
        classification='generated-signature' if rel=='fork-language/actions.md' else kind if isref else 'diagnostic' if errs else 'runnable'
        expected_snips.append({'file':DR+'/'+rel,'block':idx,'classification':classification,'sourceSha256':sha((code+('' if isref else '\n')).encode()),'executed':not isref,'expectedErrors':errs})
need(len(snip['records'])==len(expected_snips)==563,'snippet inventory')
counts=collections.Counter()
snippet_projection=[]
for actual,exp in zip(snip['records'],expected_snips):
    for field in ['file','block','classification','sourceSha256','executed']:need(actual[field]==exp[field],'snippet source/ordering '+field)
    counts[exp['classification']]+=1
    if exp['executed']:
        need(actual['passed'] is True and actual['expectedErrors']==actual['actualErrors']==exp['expectedErrors'],'snippet exact diagnostic/pass')
        need(actual['schemaFingerprint']=='dc6548076b8320b15e062439f0d8e7b032e1fd62d032b19b06ab6c79a54890a5','snippet schema')
        if exp['classification']=='runnable':
            need(actual['checkExit']==actual['compileExit']==0 and re.fullmatch(r'[0-9a-f]{64}',actual['unsignedSha256']) and type(actual['actionCount']) is int and actual['actionCount']>0,'runnable native output witness')
        else:need(actual['checkExit']!=0 and actual['compileExit']!=0 and 'unsignedSha256' not in actual and 'actionCount' not in actual,'diagnostic rejection')
        snippet_projection.append({**{k:v for k,v in actual.items() if k!='file'},'file':actual['file'][len(DR)+1:]})
need(snip['passed'] is True and snip['compilerCommit']==S and snip['binarySha256']==before['cache']['binary']['sha256'],'snippet compiler/binary')
need(snip['executed']==39 and snip['runnable']==counts['runnable']==36 and snip['diagnostic']==counts['diagnostic']==3 and snip['referenceOnly']==524,'snippet counters')
# Read log witnesses only, joining their exact source-defined inventory.
logs=readj(B/'job-log-acquisition.json')
loglines={}
for item in logs['logs']:
    raw=(B/item['file']).read_bytes();need(witness(raw)=={'bytes':item['bytes'],'sha256':item['sha256']},'original log hash')
    loglines[item['jobId']]=raw.decode('utf-8-sig').splitlines()
def records(job,step):
    result=[]
    for n,line in enumerate(loglines[job],1):
        parts=line.split('\t',2)
        if len(parts)!=3 or parts[1]!=step:continue
        match=re.match(r'^\ufeff?(\d{4}-\d\d-\d\dT\S+Z) (.*)$',parts[2])
        if match:result.append({'line':n,'timestamp':match[1],'text':match[2],'originalLineSha256':sha(line.encode())})
    return result
cache_lines=records(137522372573,'Verify real compiler cache provenance and negative examples')
test_ast=ast.parse((D/'scripts/test_smoke_test_snippets.py').read_text())
names={n.name for n in ast.walk(test_ast) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
passed=[]
for row in cache_lines:
    m=re.fullmatch(r'(test_\w+) \(__main__\.SmokeProductionTests\.\1\) \.\.\. ok',row['text'])
    if m:passed.append((m[1],row))
need(len(names)==12 and len(passed)==12 and {x[0] for x in passed}==names,'12 actual cache tests')
need(sum(row['text']=='Ran 12 tests in 25.808s' for row in cache_lines)==1 and sum(row['text']=='OK' for row in cache_lines)==1,'cache terminal')
events=[]
for row in cache_lines:
    if row['text'].startswith('CACHE_SOURCE_WITNESS '):
        event=json.loads(row['text'][len('CACHE_SOURCE_WITNESS '):])
        events.append((event,row))
need(len(events)==18,'cache witness count')
lease=None;leases=[];mutations=[];pristine=None
for event,row in events:
    case=event['case'];need(case in names,'unknown witness case')
    typ=event['event']
    if typ=='acquire':
        need(lease is None and event['binarySha256']==snip['binarySha256'],'cache lease acquisition')
        st=event['sourceState']
        need(st['revision']==S and st['origin']=='https://github.com/davidpovarsky/cherri.git' and st['status']=='' and st['autocrlf']=='false','cache source lease')
        need(st['goModSha256']==sha(blob(C,S,'go.mod')) and all(st[k]==v for k,v in cache_text_hashes.items()),'cache source tree hashes')
        if pristine is None:pristine=st
        need(st==pristine,'cache pristine witness')
        lease=(case,event['cache'],row['line'])
    elif typ=='release':
        need(lease is not None and lease[:2]==(case,event['cache']) and event['sourceState']==pristine,'cache lease release')
        leases.append({'case':case,'acquireLine':lease[2],'releaseLine':row['line'],'sourceStateEqual':True});lease=None
    else:
        need(lease is not None and lease[:2]==(case,event['cache']),'mutation outside owned lease')
        mutations.append({k:v for k,v in event.items() if k!='cache'})
need(lease is None and len(leases)==6 and len({x['case'] for x in leases})==6,'cache leases complete')
expected_events=[
('test_dirty_tracked_source_rejected_and_preserved','same-byte-replacement-rejected','go.mod'),
('test_dirty_tracked_source_rejected_and_preserved','remove-owned-file','go.mod'),
('test_dirty_tracked_source_rejected_and_preserved','restore-owned-file','go.mod'),
('test_untracked_source_rejected_and_preserved','same-byte-replacement-rejected','docs-cache-local.go'),
('test_untracked_source_rejected_and_preserved','remove-owned-file','docs-cache-local.go'),
('test_untracked_source_rejected_and_preserved','remove-owned-file','docs-cache-local.go')]
need([(x['case'],x['event'],x['path']) for x in mutations]==expected_events,'cache mutations')
for x in mutations:
    if 'mutationSha256' in x:need(x['mutationSha256']==sha(blob(C,S,'go.mod')+b'\n') if x['path']=='go.mod' else x['mutationSha256']==sha(b'package main\n'),'cache mutation digest')
    if 'restoredSha256' in x:need(x['restoredSha256']==sha(blob(C,S,'go.mod')),'restored file digest')
logproof={'runId':RUN,'docsSource':DS,'compilerSource':S,'originalLogs':logs['logs'],'cachePassedTests':[{'name':n,**row} for n,row in passed],'cacheWitnesses':[{'line':r['line'],'timestamp':r['timestamp'],'originalLineSha256':r['originalLineSha256'],'witness':{k:v for k,v in e.items() if k!='cache'}} for e,r in events],'cacheTerminalLines':[r for r in cache_lines if r['text'] in ['Ran 12 tests in 25.808s','OK']],'fullLogsRepublished':False}
audit={'schema':'cherri.docs-d12-original-intake/1','recordedAt':stamp(),'runId':RUN,'attempt':1,'workflowId':411647719,'docsSource':DS,'compilerSource':S,'actualWorkflowConclusion':'success','artifactOriginals':artifact_rows,'generator':{'originalMembers':105,'processes':33,'streams':66,'allOriginalCommandAndStreamJoins':True,'beforeAfterSourceBytesEqual':True,'sourceIdentities':tree_counts,'reference':reference,'goEvents':go,'commands':process_rows,'binaryWitness':before['cache']['binary'],'binaryRawBytesIndependentlyRetained':False,'binaryBuildInfo':{'goVersion':'go1.24.13',**build},'binaryMetadataOriginalSha256':sha(build_raw)},'snippets':{'actualRecords':563,'executed':39,'runnable':36,'diagnostic':3,'referenceOnly':524,'classifications':dict(counts),'sourceRecordsReconciled':563,'binarySha256':snip['binarySha256'],'executedRecords':snippet_projection,'unsignedRawOutputsRetained':False},'cacheControls':{'actualPassedTests':sorted(names),'testCount':12,'elapsedSeconds':25.808,'sourceWitnesses':18,'leases':leases,'mutationWitnesses':mutations,'sourceState':pristine,'binarySha256':snip['binarySha256']},'scope':{'docsMainOrPagesPromoted':False,'appleRuntimeProved':False,'formalAcceptanceGranted':False,'compilerOrTestReexecutionDuringIntake':False,'siteCurrentReceiptIntake':'PENDING_SECOND_STAGE'}}
save('intake-generator-snippets-cache.json',audit)
save('source-bindings.json',{'schemaVersion':1,'docsSource':DS,'compilerSource':S,'files':bindings})
save('cache-log-proof.json',logproof)
print(json.dumps({'status':'GENERATOR_SNIPPETS_CACHE_VERIFIED','processes':33,'streams':66,'sourceFiles':len(bindings),'snippets':39,'cacheTests':12,'cacheWitnesses':18,'referenceSha256':reference['reference_sha256'],'intake':witness((B/'intake-generator-snippets-cache.json').read_bytes())},sort_keys=True))
