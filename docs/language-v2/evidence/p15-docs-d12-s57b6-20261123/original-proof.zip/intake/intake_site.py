#!/usr/bin/env python3
"""Positive validation of original selected built-site bytes; no build/negative-control execution."""
import ast,datetime,hashlib,json,pathlib,re,subprocess,sys,zipfile
from urllib.parse import urljoin,urlsplit,unquote
sys.dont_write_bytecode=True
B=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-docs-d12-20261123')
D=pathlib.Path('/mnt/development/projects/worktrees/cherrilang-p10r15-d12-20261123')
DS='ce98fa542785fe4298d3acbf38da120b32bd5029';S='57b6d919757e1d0262993c6f11c6dc1cd17d6177'
def need(x,msg):
    if not x:raise RuntimeError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def wit(raw):return {'bytes':len(raw),'sha256':sha(raw)}
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=D)
def save(name,obj):
    with (B/name).open('x') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
bindings=json.loads((B/'source-bindings.json').read_bytes())
for rel in ['scripts/verify_site_artifacts.py','scripts/test_site_artifacts.py']:
    raw=git('show',DS+':'+rel)
    need(raw==(D/rel).read_bytes(),'site helper Git binding')
    need(any(x['path']==rel and x['sha256']==sha(raw) for x in bindings['files']),'original helper binding')
sys.path.insert(0,str(D/'scripts'))
import verify_site_artifacts as vs
need(git('rev-parse','HEAD').decode().strip()==DS and git('status','--porcelain=v1','--untracked-files=all','--ignored=matching')==b'','D12 source changed')
source_files=['_config.yml',*sorted('fork-language/'+p.name for p in (D/'fork-language').glob('*.md'))]
for rel in source_files:
    raw=git('show',DS+':'+rel);need(raw==(D/rel).read_bytes(),'site source bytes')
    item={'role':'docs','source':DS,'path':rel,**wit(raw),'gitBlob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
    if item not in bindings['files']:bindings['files'].append(item)
baseurl='/cherrilang.org';origin='https://davidpovarsky.github.io'
routes={'/'}
for p in (D/'fork-language').glob('*.md'):
    m=re.search(r'^permalink:\s*(/\S+)\s*$',p.read_text(),re.MULTILINE);need(m is not None,'missing source route');routes.add(m[1])
archive=B/'artifacts/14795031258-docs-built-site.original.zip'
need(sha(archive.read_bytes())=='7347ec71da8cfc4727553bb8a629a15c11e96cc9a4cb9d0a0c64bf44c89f8404','site archive hash')
destination=B/'site-selected-originals'
need(not destination.exists(),'selected destination occupied')
with zipfile.ZipFile(archive) as z:
    infos={i.filename:i for i in z.infolist()}
    prefix='cherri-docs-site/'
    def built(route):
        tail=route.lstrip('/');target=prefix+tail
        candidates=[target,target+'.html',target.rstrip('/')+'/index.html']
        found=[n for n in candidates if n in infos and not infos[n].is_dir()]
        need(len(found)==1,'unique ZIP route '+route);return found[0]
    selected={prefix+'assets/js/just-the-docs.js',prefix+'assets/js/search-data.json',built('/language/')}
    for route in sorted(routes):
        page=built(route);selected.add(page)
        parsed=vs.PageText();parsed.feed(z.read(page).decode())
        for link in parsed.links+parsed.resources:
            if not link or link.startswith('#') or urlsplit(link).scheme in ('mailto','data','javascript'):continue
            target=urlsplit(urljoin(origin+baseurl+route,link))
            if target.netloc!=urlsplit(origin).netloc:continue
            path=unquote(target.path);need(path.startswith(baseurl+'/'),'outside project URL')
            local=path[len(baseurl):]
            candidate=prefix+local.lstrip('/')
            selected.add(candidate if candidate in infos and not infos[candidate].is_dir() else built(local))
    need(len(selected)<30 and sum(infos[n].file_size for n in selected)<5*1024*1024,'selected original bound')
    need(all(n.startswith(prefix) and '/docs/' not in n and not n.endswith(('.zip','.p7m')) for n in selected),'recursive/historical selection')
    destination.mkdir(mode=0o700)
    inventory=[]
    for name in sorted(selected):
        raw=z.read(name);rel=name[len(prefix):];p=destination/rel;p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as f:f.write(raw)
        inventory.append({'artifactMember':name,'path':rel,**wit(raw)})
    receipt_raw=z.read('cherri-docs-site-evidence.json');control_raw=z.read('cherri-docs-site-controls.json')
receipt=json.loads(receipt_raw);controls=json.loads(control_raw)
actual=vs.verify(destination,D,baseurl)
need(actual==receipt,'original positive site validation differs')
need(controls['docsCommit']==DS and controls['compilerCommit']==S and controls['passed']==6 and controls['failed']==controls['skipped']==0 and controls['artifactsRestoredExactly'] is True,'site controls outcome')
# Source-defined control inventory, without invoking the mutation producer.
tree=ast.parse((D/'scripts/test_site_artifacts.py').read_text())
calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='rejected']
calls.sort(key=lambda n:n.lineno)
expected_names=[ast.literal_eval(n.args[0]) for n in calls]
expected_diagnostics=[ast.literal_eval(n.args[3]) for n in calls]
need(len(expected_names)==6 and [x['name'] for x in controls['controls']]==expected_names,'six source-defined controls')
for row,diagnostic in zip(controls['controls'],expected_diagnostics):need(row['rejected'] is True and diagnostic in row['diagnostic'],'original exact control rejection')
log=(B/'docs-job-137522372007.original.log').read_bytes()
need(sha(log)=='7e322d4d18a5c198d65cc735abe61d33694986cbd419ffa4571bdd02c07eb4a7','site log original hash')
alllines=log.decode('utf-8-sig').splitlines()
def step_json(step,expected):
    rows=[]
    for number,line in enumerate(alllines,1):
        parts=line.split('\t',2)
        if len(parts)!=3 or parts[1]!=step:continue
        m=re.match(r'^\ufeff?(\d{4}-\d\d-\d\dT\S+Z) (.*)$',parts[2])
        if m:rows.append({'line':number,'timestamp':m[1],'text':m[2],'originalLineSha256':sha(line.encode())})
    starts=[i for i,row in enumerate(rows) if row['text']=='{'];need(len(starts)==1,'single original JSON body')
    body=rows[starts[0]:]
    reconstructed='\n'.join(row['text'] for row in body)+'\n'
    need(json.loads(reconstructed)==expected,'original log/receipt JSON join')
    return {'step':step,'firstLine':body[0]['line'],'lastLine':body[-1]['line'],'lineCount':len(body),'timestampFirst':body[0]['timestamp'],'timestampLast':body[-1]['timestamp'],'reconstructedJsonSha256':sha(reconstructed.encode()),'originalLines':[{'line':r['line'],'sha256':r['originalLineSha256']} for r in body]}
logjoins=[step_json('Verify rendered action reference and generated search',receipt),step_json('Reject corrupted real site and search artifacts',controls)]
for name,raw in [('site-evidence.original.json',receipt_raw),('site-controls.original.json',control_raw)]:
    with (B/name).open('xb') as f:f.write(raw)
# Retain the central inventory only; historical nested receipts grant no current credit.
with zipfile.ZipFile(archive) as z:
    history=[i.filename for i in z.infolist() if '/docs/ai-team/evidence/' in i.filename]
    central=[{'name':i.filename,'bytes':i.file_size,'compressedBytes':i.compress_size} for i in z.infolist()]
save('site-original-inventory.json',{'artifactSha256':sha(archive.read_bytes()),'members':central,'selectedOriginalMembers':inventory,'excludedHistoricalMembers':history,'historicalReceiptCreditGranted':False})
save('site-intake.json',{'schema':'cherri.docs-d12-current-site-intake/1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':45123477520,'attempt':1,'docsSource':DS,'compilerSource':S,'actualPositiveValidatorReplay':True,'sourceBoundHelper':next(x for x in bindings['files'] if x['path']=='scripts/verify_site_artifacts.py'),'receipt':receipt,'actualSixOriginalControls':controls,'originalLogJoins':logjoins,'selectedSiteFiles':len(inventory),'selectedSiteBytes':sum(x['bytes'] for x in inventory),'fullSiteZipRepublished':False,'negativeControlsRerun':False,'siteRebuilt':False,'sitePublished':False,'formalAcceptanceGranted':False})
save('source-bindings-complete.json',bindings)
need(git('status','--porcelain=v1','--untracked-files=all','--ignored=matching')==b'','D12 changed during intake')
print(json.dumps({'status':'SITE_ORIGINALS_VERIFIED','selectedFiles':len(inventory),'selectedBytes':sum(x['bytes'] for x in inventory),'sourceBindings':len(bindings['files']),'currentSearchEntries':receipt['searchEntries'],'verifiedLinks':receipt['verifiedLocalLinks'],'controls':len(expected_names),'sitePublished':False,'siteIntake':wit((B/'site-intake.json').read_bytes())},sort_keys=True))
