import pathlib,json,hashlib,datetime,os,importlib.util,traceback
B=pathlib.Path("/var/cache/cherri-final-authoring-k-q-20261126");W=B/"source";E=B/"source-publication-01";E.mkdir(mode=0o700);(E/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
Q="44707350fb6e52dd0d947256bced105ac762a1ac";D="f9ec0e0c62b5fc26ddb6002275bc1abba2c5a257";BR="agent/cherri-p10r15-final-authoring-k-q-20261126";NAME="skills/cherri-shortcuts/compatibility-manifest.json"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
R={"schema":"cherri-final-authoring-K-source/1","status":"FAILED","compilerSource":Q,"docsSource":D,"branch":BR,"commands":[],"GoExecuted":False,"nativeExecuted":False,"liveMutation":False,"finalPackageCreated":False,"finalAcceptance":False}
hp=pathlib.Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py");assert sha(hp)=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
sp=importlib.util.spec_from_file_location("owned",hp);H=importlib.util.module_from_spec(sp);sp.loader.exec_module(H)
try:
 with H.WholeBudget(240,cleanup_seconds=8,final_reserve=20)as budget:
  def git(name,args,seconds=20):
   argv=["/usr/sbin/runuser","-u","ubuntu","--","/usr/bin/git","-C",str(W),"-c","gc.auto=0","-c","maintenance.auto=false","-c","credential.helper=","-c","credential.helper=!gh auth git-credential",*args]
   row=H.run_owned(argv,cwd=str(W),env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0"),output=E,name=name,budget=budget,seconds=seconds);R["commands"].append(row);H.require_success(row);return(E/(name+".stdout.original")).read_text()
  assert git("head-before",["rev-parse","HEAD"]).strip()==Q
  assert git("branch-before",["branch","--show-current"]).strip()==BR
  assert not git("clean-before",["status","--porcelain=v1","--untracked-files=all"])
  assert not git("remote-target-absent",["ls-remote","--heads","origin","refs/heads/"+BR]).strip()
  original=W/NAME;proposal=B/"proposal/compatibility-manifest.json";assert sha(original)=="3afbda0784fa3eddf1fcb8e9e06f56aa7a7353694267887f40236015c07d05c9";assert sha(proposal)=="9c18398b2342d232865633fe2e7100ace47710f6f9c1284ec448fe76f214cb00"
  indexreceipt=B/"ios-documentation-Q-f9-01/result.original.json";assert sha(indexreceipt)=="ce739cd27a9025319cc7da5fe89ef58e4ed2b5db676ad9d6f020355480f3630d";index=json.loads(indexreceipt.read_bytes());assert index["status"]=="PASS_EXISTING_PRODUCER"and index["manifestSHA256"]==sha(proposal)
  before=json.loads(original.read_bytes());after=json.loads(proposal.read_bytes());assert set(before)==set(after)and{k for k in before if before[k]!=after[k]}=={"compilerCommit","docsCommit"}and after["compilerCommit"]==Q and after["docsCommit"]==D
  original.write_bytes(proposal.read_bytes());os.chown(original,1001,1001);os.chmod(original,0o644)
  git("diff-check",["diff","--check"])
  paths=git("changed-paths",["diff","--name-only"]).splitlines();assert paths==[NAME]
  git("source-delta",["diff","--",NAME])
  git("stage",["add","--",NAME]);git("commit",["-c","user.name=David Povarsky","-c","user.email=davidpovarsky@users.noreply.github.com","commit","-m","chore(skill): pin verified Q compiler and current documentation [skip ci]"])
  head=git("head-after",["rev-parse","HEAD"]).strip();tree=git("tree-after",["rev-parse","HEAD^{tree}"]).strip();assert git("parent-after",["rev-parse","HEAD^"]).strip()==Q
  assert not git("clean-after",["status","--porcelain=v1","--untracked-files=all"])
  assert sha(original)==sha(proposal)and sha(W/"ios/scripts/build_documentation_index.py")==index["producerSHA256"]
  git("publish",["push","--porcelain","origin","HEAD:refs/heads/"+BR],120)
  remote=git("remote-readback",["ls-remote","--heads","origin","refs/heads/"+BR]).strip();assert remote==head+"\trefs/heads/"+BR
  R.update(status="PUBLISHED_QUALIFIED_AUTHORING_K",authoringSource=head,tree=tree,parent=Q,manifestSHA256=sha(original),changedPaths=paths,changedFields=["compilerCommit","docsCommit"],capabilitiesUnchanged=True,indexOriginal={"path":str(indexreceipt),"sha256":sha(indexreceipt)},indexOutput={"path":index["output"],"sha256":index["outputSHA256"]},sourceEquivalentToQualifiedProposal=True,roles={"S":Q,"D":D,"K":head,"F":None},sourceClean=True)
except BaseException as e:R.update(error=str(e),traceback=traceback.format_exc())
finally:
 R["finishedUTC"]=datetime.datetime.now(datetime.timezone.utc).isoformat();p=E/"result.original.json";p.write_text(json.dumps(R,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"path":str(p),"sha256":sha(p),"status":R["status"],"K":R.get("authoringSource"),"tree":R.get("tree"),"S":Q,"D":D,"manifestSHA256":R.get("manifestSHA256"),"error":R.get("error")}))
