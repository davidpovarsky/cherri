import pathlib,json,hashlib,os,datetime,importlib.util,traceback
B=pathlib.Path("/var/cache/cherri-final-authoring-k-q-20261126");W=B/"source";D=pathlib.Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126");E=B/"ios-documentation-Q-f9-01";E.mkdir(mode=0o755)
(E/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
P=E/"products";P.mkdir(mode=0o755);os.chown(P,1001,1001)
MAN=B/"proposal/compatibility-manifest.json";OUT=P/"documentation-index.json";SCRIPT=W/"ios/scripts/build_documentation_index.py";Q="44707350fb6e52dd0d947256bced105ac762a1ac";DS="f9ec0e0c62b5fc26ddb6002275bc1abba2c5a257"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
R={"schema":"cherri-ios-documentation-tuple-preflight/1","status":"FAILED","compilerSource":Q,"docsSource":DS,"authoringRole":"external-manifest-proposal-on-clean-Q","manifestSHA256":sha(MAN),"producerSHA256":sha(SCRIPT),"goExecuted":False,"nativeBuildExecuted":False,"liveMutation":False,"formalAcceptance":False,"commands":[]}
assert R["manifestSHA256"]=="9c18398b2342d232865633fe2e7100ace47710f6f9c1284ec448fe76f214cb00";assert R["producerSHA256"]=="f80c86792294bf074ef1ada887f3c2b39869a0e459364cdf56dbea2864b7e252"
hp=pathlib.Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py");assert sha(hp)=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
sp=importlib.util.spec_from_file_location("owned",hp);H=importlib.util.module_from_spec(sp);sp.loader.exec_module(H)
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0",PYTHONDONTWRITEBYTECODE="1")
try:
 with H.WholeBudget(300,cleanup_seconds=8,final_reserve=20)as budget:
  def call(name,argv,cwd=W,seconds=15):
   r=H.run_owned(["/usr/sbin/runuser","-u","ubuntu","--",*argv],cwd=str(cwd),env=env,output=E,name=name,budget=budget,seconds=seconds);R["commands"].append(r);H.require_success(r);return(E/(name+".stdout.original")).read_bytes()
  def snapshot(phase):
   assert D.is_dir()and(D/".git").is_dir()and not(D/".git/objects/info/alternates").exists()
   before={}
   for role,root,head in[("authoring",W,Q),("docs",D,DS)]:
    actual=call(phase+"-"+role+"-head",["/usr/bin/git","-C",str(root),"rev-parse","HEAD"]).decode().strip();assert actual==head
    tree=call(phase+"-"+role+"-tree",["/usr/bin/git","-C",str(root),"rev-parse","HEAD^{tree}"]).decode().strip()
    assert not call(phase+"-"+role+"-status",["/usr/bin/git","-C",str(root),"status","--porcelain=v1","--untracked-files=all"])
    before[role]={"root":str(root),"head":head,"tree":tree}
   origin=call(phase+"-docs-origin",["/usr/bin/git","-C",str(D),"remote","get-url","origin"]).decode().strip();assert origin=="https://github.com/davidpovarsky/cherrilang.org.git"
   before["docs"]["origin"]=origin;before["docs"]["ordinary"]=True
   before["docs"]["sources"]={n:sha(D/n)for n in("fork-language/index.md","fork-language/guide.md","fork-language/actions.md","fork-language/migration.md")}
   before["manifestSHA256"]=sha(MAN);before["producerSHA256"]=sha(SCRIPT)
   assert before["manifestSHA256"]==R["manifestSHA256"]and before["producerSHA256"]==R["producerSHA256"]
   return before
  free=os.statvfs("/").f_bavail*os.statvfs("/").f_frsize;R["freeBefore"]=free;assert free>=896*1024**2
  before=snapshot("before");(E/"source-before.original.json").write_text(json.dumps(before,sort_keys=True,indent=2)+"\n")
  assert not OUT.exists()
  original=["python3","-B",str(SCRIPT),"--manifest",str(MAN)]
  raw=call("generate-index",original+["--docs",str(D),"--fetch","--output",str(OUT)],seconds=180);generation=json.loads(raw)
  assert generation["compilerCommit"]==Q and generation["docsCommit"]==DS and generation["sourceFiles"]==4 and generation["sections"]>0
  assert generation["sha256"]==sha(OUT)and generation["bytes"]==OUT.stat().st_size
  verified=json.loads(call("verify-index",original+["--verify-output","--output",str(OUT),"--receipt",str(E/"generate-index.stdout.original")],seconds=30))
  assert verified["status"]=="VERIFIED_BUNDLED_DOCUMENTATION"and verified["compilerCommit"]==Q and verified["docsCommit"]==DS and verified["sha256"]==sha(OUT)
  after=snapshot("after");(E/"source-after.original.json").write_text(json.dumps(after,sort_keys=True,indent=2)+"\n");assert before==after
  R.update(status="PASS_EXISTING_PRODUCER",sourceUnchanged=True,generation=generation,verified=verified,docsCheckout=str(D),sourceBefore=before,output=str(OUT),outputSHA256=sha(OUT),freeAfter=os.statvfs("/").f_bavail*os.statvfs("/").f_frsize)
except BaseException as e:R.update(error=str(e),traceback=traceback.format_exc())
finally:
 R["finishedUTC"]=now();p=E/"result.original.json";p.write_text(json.dumps(R,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"path":str(p),"sha256":sha(p),"status":R["status"],"generation":R.get("generation"),"error":R.get("error")}))
