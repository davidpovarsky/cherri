import pathlib,json,hashlib,os,datetime,importlib.util,traceback
B=pathlib.Path("/var/cache/cherri-final-authoring-k-q-20261126");W=B/"source";E=B/"preparation-01"
assert not B.exists();B.mkdir(mode=0o755);os.chown(B,1001,1001);E.mkdir(mode=0o700)
(E/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
C=pathlib.Path("/var/cache/cherri-ios-ui-repair-p-20261126/source");Q="44707350fb6e52dd0d947256bced105ac762a1ac";D="f9ec0e0c62b5fc26ddb6002275bc1abba2c5a257";BR="agent/cherri-p10r15-final-authoring-k-q-20261126"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
R={"status":"FAILED","compilerSource":Q,"docsSource":D,"branch":BR,"commands":[],"GoExecuted":False,"nativeExecuted":False,"liveMutation":False}
hp=pathlib.Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py");assert sha(hp)=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
sp=importlib.util.spec_from_file_location("owned",hp);H=importlib.util.module_from_spec(sp);sp.loader.exec_module(H)
try:
 with H.WholeBudget(180,cleanup_seconds=8,final_reserve=20)as budget:
  def git(name,args,root=C,seconds=20):
   row=H.run_owned(["/usr/sbin/runuser","-u","ubuntu","--","/usr/bin/git","-C",str(root),"-c","gc.auto=0","-c","maintenance.auto=false",*args],cwd=str(root),env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0"),output=E,name=name,budget=budget,seconds=seconds);R["commands"].append(row);H.require_success(row);return(E/(name+".stdout.original")).read_text()
  R["freeBefore"]={n:os.statvfs(n).f_bavail*os.statvfs(n).f_frsize for n in("/", "/mnt/development","/dev/shm")};assert R["freeBefore"]["/"]>=896*1024**2
  assert git("worktree-config-enabled",["config","--get","extensions.worktreeConfig"]).strip()=="true"
  common=pathlib.Path(git("common-dir",["rev-parse","--git-common-dir"]).strip()).resolve();assert common==pathlib.Path("/mnt/development/projects/releases/cherri-p10r15-k14-final-source-20261123/.git")
  commonpin=sha(common/"config");R["commonConfigBefore"]=commonpin
  assert git("source-tree",["rev-parse",Q+"^{tree}"]).strip()=="07db998051c5950be6326546b7e743d21beb8390"
  assert not git("branch-absent",["for-each-ref","--format=%(objectname)","refs/heads/"+BR]).strip()
  git("create-sparse-worktree",["worktree","add","--no-checkout","-b",BR,str(W),Q],seconds=30)
  git("enable-scoped-sparse",["config","--worktree","core.sparseCheckout","true"],root=W)
  git("disable-scoped-cone",["config","--worktree","core.sparseCheckoutCone","false"],root=W)
  path=pathlib.Path(git("scoped-pattern-path",["rev-parse","--git-path","info/sparse-checkout"],root=W).strip())
  if not path.is_absolute():path=W/path
  path=path.resolve();assert common in path.parents and "worktrees"in path.parts
  path.parent.mkdir(parents=True,exist_ok=True)
  pattern="/AGENTS.md\n/CONTRIBUTING.md\n/skills/cherri-shortcuts/compatibility-manifest.json\n/ios/scripts/build_documentation_index.py\n"
  path.write_text(pattern);os.chown(path,1001,1001);path.chmod(0o644)
  git("initialize-exact-sparse-index",["read-tree","-mu","HEAD"],root=W,seconds=30)
  assert git("head-after",["rev-parse","HEAD"],root=W).strip()==Q
  assert not git("clean-after",["status","--porcelain=v1","--untracked-files=all"],root=W)
  assert sha(common/"config")==commonpin
  old=W/"skills/cherri-shortcuts/compatibility-manifest.json";assert sha(old)=="3afbda0784fa3eddf1fcb8e9e06f56aa7a7353694267887f40236015c07d05c9"
  assert sha(W/"ios/scripts/build_documentation_index.py")=="f80c86792294bf074ef1ada887f3c2b39869a0e459364cdf56dbea2864b7e252"
  handoff=pathlib.Path("/var/cache/cherri-p10r15-hosted-release-q-20261126/file-only-original-intake-01/pair-handoff.original.json");assert sha(handoff)=="1e09021fab8dd8ac0cb1bb94220abab06b0865ffa3b23b5b4fb5fcd656f4bb8f"
  pair=json.loads(handoff.read_bytes());assert pair["source"]==Q and pair["status"]=="PASS_ORIGINAL_PAIR_INTAKE"
  for entry in pair["products"]:
   p=pathlib.Path(entry["absolutePath"]);assert p.is_file()and not p.is_symlink()and p.stat().st_size==entry["bytes"]and sha(p)==entry["sha256"],entry["path"]
  raw=old.read_bytes();parsed=json.loads(raw)
  for name,caps in pair["capabilities"].items():
   for key in("catalogSchemaVersion","codecFingerprint","languageVersion","macroFingerprint","schemaFingerprint"):assert parsed[key]==caps[key],(name,key)
  after=raw.replace(b'"compilerCommit": "708ed78eda1cad0f1f453559afce100edc59b8a9"',('"compilerCommit": "'+Q+'"').encode()).replace(b'"docsCommit": "381de199405b8acbdf465e3f1420b01070c57f20"',('"docsCommit": "'+D+'"').encode())
  proposed=json.loads(after);assert {k for k in parsed if parsed[k]!=proposed[k]}=={"compilerCommit","docsCommit"}and set(parsed)==set(proposed)
  public=B/"proposal";public.mkdir(mode=0o755);p=public/"compatibility-manifest.json";p.write_bytes(after);p.chmod(0o644)
  oldcopy=public/"compatibility-manifest.before.original.json";oldcopy.write_bytes(raw)
  docs_receipt=pathlib.Path("/var/cache/cherri-docs-q-pin-20261126/success-ci-independent-intake-01/result.original.json");assert sha(docs_receipt).startswith("d7f51684")
  docs=json.loads(docs_receipt.read_bytes());assert docs["status"].startswith("PASS")and docs["docsSource"]==D and docs["compilerSource"]==Q
  R.update(status="PREPARED_SPARSE_Q_AUTHORING_AND_TWO_PIN_PROPOSAL",worktree=str(W),manifestProposal=str(p),manifestSHA256=sha(p),manifestBeforeSHA256=sha(old),changedFields=["compilerCommit","docsCommit"],producerSHA256=sha(W/"ios/scripts/build_documentation_index.py"),pairHandoff={"path":str(handoff),"sha256":sha(handoff)},pairProductsRehashed=pair["products"],actualCapabilities=pair["capabilities"],docsOriginalIntake={"path":str(docs_receipt),"sha256":sha(docs_receipt)},commonConfigAfter=sha(common/"config"),sparse=True,sourceClean=True,finalPackageBuilt=False,finalAcceptance=False,freeAfter={n:os.statvfs(n).f_bavail*os.statvfs(n).f_frsize for n in("/", "/mnt/development","/dev/shm")})
except BaseException as e:R.update(error=str(e),traceback=traceback.format_exc())
finally:
 R["finishedUTC"]=datetime.datetime.now(datetime.timezone.utc).isoformat();out=E/"result.original.json";out.write_text(json.dumps(R,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"path":str(out),"sha256":sha(out),"status":R["status"],"worktree":R.get("worktree"),"manifestSHA256":R.get("manifestSHA256"),"error":R.get("error")}))
