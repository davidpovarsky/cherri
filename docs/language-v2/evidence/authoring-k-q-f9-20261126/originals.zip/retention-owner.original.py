from pathlib import Path
import os,stat,json,hashlib,zipfile,re,datetime,signal
B=Path("/var/cache/cherri-final-authoring-k-q-20261126")
D=B/"public-proof-preparation-01";D.mkdir(mode=0o700)
(D/"owner.original.py").write_bytes(Path(__file__).read_bytes())
signal.alarm(45)
def sha(b):return hashlib.sha256(b).hexdigest()
def stamp(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return (s.st_dev,s.st_ino,s.st_size,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns)
expected={"preparation-01/result.original.json":"27f1537759f201d7a4d32cc6662bc3f2b9ea46b5a75f87f9ed7a8abe4f9008fd","ios-documentation-Q-f9-01/result.original.json":"ce739cd27a9025319cc7da5fe89ef58e4ed2b5db676ad9d6f020355480f3630d","source-publication-01/result.original.json":"9e4a086b54b1fe0cdb8371c5af67fb30e95357954eee7d846cfd34304b62183a"}
for n,h in expected.items():assert sha((B/n).read_bytes())==h,n
files={}
for n in ("preparation-01","ios-documentation-Q-f9-01","source-publication-01"):
 for p in sorted((B/n).rglob("*")):
  if p.is_dir():continue
  files[p.relative_to(B).as_posix()]=p
assert len(files)==177
files["source/qualified-compatibility-manifest.json"]=B/"proposal/compatibility-manifest.json"
files["source/build_documentation_index.py"]=B/"source/ios/scripts/build_documentation_index.py"
files["retention-owner.original.py"]=D/"owner.original.py"
assert sha(files["source/qualified-compatibility-manifest.json"].read_bytes())=="9c18398b2342d232865633fe2e7100ace47710f6f9c1284ec448fe76f214cb00"
assert files["source/qualified-compatibility-manifest.json"].read_bytes()==(B/"source/skills/cherri-shortcuts/compatibility-manifest.json").read_bytes()
assert sha(files["source/build_documentation_index.py"].read_bytes())=="f80c86792294bf074ef1ada887f3c2b39869a0e459364cdf56dbea2864b7e252"
before={n:stamp(p)for n,p in files.items()}
raw={n:p.read_bytes()for n,p in files.items()}
assert sum(map(len,raw.values()))<2*1024**2
patterns=[rb"(?:github_pat_|gh[oprsu]_)[A-Za-z0-9_]{20,}",rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",rb"https://[^/\s\"']+:[^@\s\"']+@"]
for n,b in raw.items():
 for pattern in patterns:assert not re.search(pattern,b),"PUBLIC_SECRET_PATTERN:"+n
archive=D/"originals.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n in sorted(raw):
  info=zipfile.ZipInfo(n,datetime.datetime.fromtimestamp(before[n][6]/10**9,datetime.timezone.utc).timetuple()[:6])
  info.create_system=3;info.external_attr=(stat.S_IFREG|before[n][3])<<16;info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,raw[n])
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and z.namelist()==sorted(raw)
 for n,b in raw.items():
  assert z.read(n)==b and (z.getinfo(n).external_attr>>16)&0o777==before[n][3]
for n,p in files.items():assert stamp(p)==before[n] and p.read_bytes()==raw[n],"ORIGINAL_CHANGED:"+n
inventory=[{"path":n,"bytes":len(raw[n]),"sha256":sha(raw[n]),"mode":format(before[n][3],"04o"),"uid":before[n][4],"gid":before[n][5],"mtimeNs":before[n][6]}for n in sorted(raw)]
manifest={"schema":"cherri-authoring-q-f9-originals/1","scope":"authoring-manifest-and-documentation-index-component","sourceRoles":{"S":"44707350fb6e52dd0d947256bced105ac762a1ac","D":"f9ec0e0c62b5fc26ddb6002275bc1abba2c5a257","K":"3c920873605bd81e098841c2d41686fd1cda573b","F":None},"archive":{"path":"originals.zip","bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"files":len(raw),"uncompressedBytes":sum(map(len,raw.values()))},"originalReceipts":expected,"files":inventory,"finalPackageBuilt":False,"livePromotion":False,"nativeAcceptanceGranted":False}
mp=D/"manifest.json"
with mp.open("x")as f:f.write(json.dumps(manifest,sort_keys=True,indent=2)+"\n")
result={"status":"ALL_COMPONENT_ORIGINALS_BYTE_VERIFIED","originalFiles":177,"retainedFiles":len(raw),"sourceRoles":manifest["sourceRoles"],"archive":manifest["archive"],"manifestSHA256":sha(mp.read_bytes()),"allOriginalsUnchanged":True,"manifestBytesUnchanged":True,"nativeExecuted":False,"goExecuted":False,"finalPackageBuilt":False,"livePromotion":False,"observedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat()}
rp=D/"retention.original.json"
with rp.open("x")as f:f.write(json.dumps(result,sort_keys=True,indent=2)+"\n")
signal.alarm(0)
print(json.dumps({"path":str(rp),"sha256":sha(rp.read_bytes()),**result}))
