"""Execute the unchanged derived-ledger generator from a frozen clean ancestor."""
import argparse
import hashlib
import importlib.util
import json
import os
import pathlib
import signal
import stat
import subprocess
import sys
import time

BASE = pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-505-refresh-20261123")
HELPER = BASE / "run_catalog_producers.py"
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != "ce809d9839a74657d6cbf6fb685a65aef0c86e743642e1eeed31acca03143bb4":
    raise RuntimeError("Original source-bound helper changed")
spec = importlib.util.spec_from_file_location("catalog_execution_helpers", HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)

NAMES = [
    "p10-505-catalog-coverage-matrix.json",
    "p10-pack-15-go-only-audit.json",
    "p10-apple-cherri-crosswalk.json",
    "catalog-supported-by-compiler.md",
    "apple-discovered-not-supported.md",
    "pure-pack-portability.md",
    "baseline-state.json",
]
PREFIX = "docs/apple-runtime/p10/"
RAW_HASHES = {
    "p10-505-execution-evidence.json": "6a99ea3f0e541b4dca416f6cfdef775a7492eef118ddc33f9cc5632398d4aeb8",
    "p10-505-parameter-contract-evidence.json": "74c5ed6ffb65594937aefcf248cef7f1d5ed47388fc57352c148f478e14f8eb5",
}

# Root supplies the final clean C0 SHA/tree explicitly; no candidate is assumed here.
GO_SELECTION = {
    "GOTOOLCHAIN": "go1.24.13",
    "GOMODCACHE": "/mnt/development/tooling/cherri-go/mod",
    "GOCACHE": "/mnt/development/tooling/cherri-go/runtime-persistent-20261123/build-cache",
    "GOTMPDIR": "/mnt/development/tooling/cherri-go/runtime-persistent-20261123/tmp-ubuntu",
    "TMPDIR": "/mnt/development/tooling/cherri-go/runtime-persistent-20261123/tmp-ubuntu",
}
RAW_SOURCE = "57b6d919757e1d0262993c6f11c6dc1cd17d6177"
RAW_ROOT = pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-505-s57b6d919-20261123")
RAW_PROCESS_SHA = "c577f775fac7bdf74fb3dabb71fd586c0e357f9af19df4069a0ba635fedb4877"
RAW_INTAKE_SHA = "0060985be9e4fae05e75f02734ef880edc5b969658ca454c1edc09c3d163d250"
RAW_WITNESS_SHA = "77c5f6494376d8c09047bc709c5ce24800bf2dab13caf48d0affca5c4c2cc82b"
OUTPUT_BASE = pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-derived-s57b6d919-20261123")
OWNED_OUTPUT = None

def clean_environment():
    keep=("PATH","HOME","USER","LOGNAME","LANG","LC_ALL","LC_CTYPE","TZ")
    env={key:os.environ[key] for key in keep if key in os.environ}
    env.update({"GIT_NO_REPLACE_OBJECTS":"1","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"})
    return env

def capture(argv,repo,env=None,timeout=30):
    return h.capture(argv,repo,clean_environment() if env is None else env,timeout)

def source(repo):
    def read(*args):
        return capture(["git","--no-replace-objects",*args],repo).decode().strip()
    if pathlib.Path(read("rev-parse","--show-toplevel")) != repo or read("replace","-l"):
        raise RuntimeError("Actual source routing or replacement identity rejected")
    return {"head":read("rev-parse","HEAD"),"tree":read("rev-parse","HEAD^{tree}"),
            "branch":read("branch","--show-current"),
            "status":capture(["git","--no-replace-objects","status","--porcelain=v1","--untracked-files=all"],repo).decode()}

def fresh_raw_equivalence(repo):
    process_path=RAW_ROOT/"raw-attempt-01/process.original.json"
    intake_path=RAW_ROOT/"independent-intake-01/result.original.json"
    witness_path=RAW_ROOT/"raw-attempt-01/raw-input-witness-before.original.json"
    if (h.digest(process_path.read_bytes())!=RAW_PROCESS_SHA or
        h.digest(intake_path.read_bytes())!=RAW_INTAKE_SHA or
        h.digest(witness_path.read_bytes())!=RAW_WITNESS_SHA):
        raise RuntimeError("Reviewed new-S raw provenance changed")
    process=json.loads(process_path.read_bytes());intake=json.loads(intake_path.read_bytes())
    measured=json.loads(witness_path.read_bytes())
    if (process["source"]["head"]!=RAW_SOURCE or not process["execution_valid"] or
        process["exit_code"]!=0 or process["timed_out"] or
        not intake["intakeAccepted"] or not intake["newSourceMeasurementAtS"] or
        intake["sourceProcessReceiptSHA256"]!=RAW_PROCESS_SHA or
        measured["source"]!=RAW_SOURCE or measured["count"]!=595):
        raise RuntimeError("Actual new-source raw execution/intake is not eligible")
    for name,expected in RAW_HASHES.items():
        if h.digest((RAW_ROOT/"raw-attempt-01/artifacts"/name).read_bytes())!=expected:
            raise RuntimeError("Actual fresh raw output changed")
    tracked={}
    for row in capture(["git","--no-replace-objects","ls-tree","-r","-z","HEAD"],repo).split(b"\0"):
        if not row:continue
        meta,name=row.split(b"\t",1);mode,kind,blob=meta.decode().split();name=name.decode()
        if (("/" not in name and name.endswith(".go")) or name in ("go.mod","go.sum","stdfunc.cherri") or
            name.startswith(("internal/","actions/","testdata/","tools/language-schema/"))):
            tracked[name]={"path":name,"mode":mode,"kind":kind,"blob":blob}
    if sorted(tracked)!=[row["path"] for row in measured["files"]]:
        raise RuntimeError("FinalC0 raw-input inventory drift")
    rows=[]
    for row in measured["files"]:
        expected={key:row[key] for key in ("path","mode","kind","blob")}
        path=repo/row["path"];info=path.lstat();raw=path.read_bytes()
        mode="100755" if info.st_mode&0o111 else "100644"
        if (not stat.S_ISREG(info.st_mode) or tracked[row["path"]]!=expected or mode!=row["mode"] or
            len(raw)!=row["bytes"] or h.digest(raw)!=row["sha256"]):
            raise RuntimeError("FinalC0 raw-input bytes/mode drift")
        rows.append(row)
    return {"measurement_source":RAW_SOURCE,"consumer_source":source(repo)["head"],
            "input_count":len(rows),"process_sha256":RAW_PROCESS_SHA,"intake_sha256":RAW_INTAKE_SHA,
            "measured_witness_sha256":RAW_WITNESS_SHA,"files":rows}


def manifest(repo, names):
    return [{"path": PREFIX + n, "bytes": (repo/PREFIX/n).stat().st_size,
             "sha256": h.digest((repo/PREFIX/n).read_bytes())} for n in sorted(names)]

def main():
    global OWNED_OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--execute-reviewed-plan", action="store_true")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if not args.execute_reviewed_plan:
        print("DERIVED_GENERATOR_SUPERVISOR_INACTIVE", file=sys.stderr)
        return 64
    if os.getuid()!=1001:
        raise RuntimeError("Source owner UID1001 required")
    repo = pathlib.Path(args.repo).resolve(strict=True)
    out = pathlib.Path(args.output).absolute()
    if len(args.expected_source) != 40 or any(c not in "0123456789abcdef" for c in args.expected_source):
        raise RuntimeError("Exact frozen source required")
    if (len(args.expected_tree)!=40 or any(c not in "0123456789abcdef" for c in args.expected_tree)):
        raise RuntimeError("Exact frozen C0 tree required")
    if out.parent.resolve()!=OUTPUT_BASE or out.exists() or out.is_relative_to(repo) or out.parent.resolve().is_relative_to(repo):
        raise RuntimeError("New physical external output required")
    before = source(repo)
    if before["head"] != args.expected_source or before["tree"]!=args.expected_tree or before["status"] or not before["branch"]:
        raise RuntimeError("Source is not the frozen clean ancestor")
    capture(["git","--no-replace-objects","merge-base","--is-ancestor",RAW_SOURCE,args.expected_source],repo)
    raw_before=fresh_raw_equivalence(repo)
    for name, expected in RAW_HASHES.items():
        if h.digest((repo/PREFIX/name).read_bytes()) != expected:
            raise RuntimeError("Fresh raw evidence is missing: " + name)
    out.mkdir(mode=0o700)
    OWNED_OUTPUT=out
    h.original(out/"submitted-supervisor.py",pathlib.Path(__file__).read_bytes())
    h.original(out/"raw-equivalence-before.original.json",raw_before)
    (out/"derived").mkdir(mode=0o700)
    witness_before = h.dependency_witness(repo)
    before_files = manifest(repo,NAMES)
    h.original(out/"source-before.original.json",before)
    h.original(out/"input-witness-before.original.json",witness_before)
    h.original(out/"derived-before.original.json",before_files)
    keep=("PATH","HOME","USER","LOGNAME","LANG","LC_ALL","LC_CTYPE","TZ")
    env={k:os.environ[k] for k in keep if k in os.environ}
    env.update({"GIT_NO_REPLACE_OBJECTS":"1","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"})
    env.update(GO_SELECTION)
    env["PYTHONDONTWRITEBYTECODE"]="1"
    for key in ("GOMODCACHE","GOCACHE","GOTMPDIR","TMPDIR"):
        p=pathlib.Path(env[key])
        if not p.is_dir() or not os.access(p,os.R_OK|os.W_OK|os.X_OK):
            raise RuntimeError("Prepared persistent runtime unavailable")
    goenv=capture(["go","env","-json","GOVERSION","GOOS","GOARCH","GOROOT","GOTOOLCHAIN","GOMODCACHE","GOCACHE","GOTMPDIR"],repo,env,timeout=60)
    h.original(out/"go-env.original.json",goenv)
    if json.loads(goenv)["GOVERSION"]!="go1.24.13":
        raise RuntimeError("Incorrect selected Go")
    argv=[sys.executable,"-B","tools/p10r3/generate_catalog_and_pack_ledgers.py"]
    intent={
        "source":before,"argv":argv,"selected_environment":GO_SELECTION,
        "driver_sha256":h.digest(pathlib.Path(__file__).read_bytes()),
        "shared_helper_sha256":h.digest(HELPER.read_bytes()),
        "generator_sha256":h.digest((repo/"tools/p10r3/generate_catalog_and_pack_ledgers.py").read_bytes()),
        "allowed_outputs":[PREFIX+n for n in NAMES],"original_raw_sha256":RAW_HASHES,
        "wall_limit_seconds":600,"termination_grace_seconds":5,"kill_reap_wait_seconds":5,
        "new_S_raw_process_sha256":RAW_PROCESS_SHA,"new_S_raw_intake_sha256":RAW_INTAKE_SHA,
        "raw_measurement_source":RAW_SOURCE,"final_consumer_source":None,
        "scope":"Actual derived generation; raw producers and release gates are not rerun.",
    }
    h.original(out/"intent.original.json",intent)
    started_utc, started=h.utc(),time.monotonic()
    timed_out=False
    with (out/"stdout.original").open("xb") as stdout,(out/"stderr.original").open("xb") as stderr:
        process=subprocess.Popen(argv,cwd=repo,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        h.original(out/"process-start.original.json",{"pid":process.pid,"started_utc":started_utc})
        try:
            code=process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=5)
    finished_utc,elapsed=h.utc(),time.monotonic()-started
    h.original(out/"process-terminal.original.json",{"argv":argv,"source":before,"pid":process.pid,
        "started_utc":started_utc,"finished_utc":finished_utc,"elapsed_seconds":elapsed,
        "exit_code":code,"timed_out":timed_out,"stdout_sha256":h.digest((out/"stdout.original").read_bytes()),
        "stderr_sha256":h.digest((out/"stderr.original").read_bytes()),"postflight_validation_pending":True})
    after=source(repo)
    witness_after=h.dependency_witness(repo)
    changed=capture(["git","diff","--name-only"],repo).decode().splitlines()
    untracked=capture(["git","ls-files","--others","--exclude-standard"],repo).decode().splitlines()
    h.original(out/"source-after.original.json",after)
    h.original(out/"input-witness-after.original.json",witness_after)
    raw_after=fresh_raw_equivalence(repo)
    h.original(out/"raw-equivalence-after.original.json",raw_after)
    after_files=manifest(repo,NAMES)
    h.original(out/"derived-after.original.json",after_files)
    checks=[]
    def check(name,condition):checks.append({"check":name,"pass":bool(condition)})
    check("actual generator exit zero",code==0 and not timed_out)
    check("same HEAD tree branch",all(before[k]==after[k] for k in ("head","tree","branch")))
    check("only declared derived outputs changed",set(changed)<=set(PREFIX+n for n in NAMES) and not untracked)
    check("all dependency bytes unchanged",witness_before==witness_after)
    check("all595 raw input bytes unchanged",raw_before==raw_after)
    check("fresh raw evidence unchanged",all(h.digest((repo/PREFIX/n).read_bytes())==d for n,d in RAW_HASHES.items()))
    fp=witness_before["fingerprint"]
    derived={n:json.loads((repo/PREFIX/n).read_bytes()) for n in NAMES if n.endswith(".json")}
    for name in ["p10-505-catalog-coverage-matrix.json","p10-apple-cherri-crosswalk.json","baseline-state.json"]:
        obj=derived[name]
        check(name+" exact source",obj["sourceCommit"]==args.expected_source)
        check(name+" current dependency fingerprint",obj["inputDependencyFingerprint"]==fp)
    for name in [n for n in NAMES if n.endswith(".md")]:
        raw=(repo/PREFIX/name).read_text()
        check(name+" source and fingerprint",args.expected_source in raw and fp in raw)
    matrix=derived["p10-505-catalog-coverage-matrix.json"]
    raw=json.loads((repo/PREFIX/"p10-505-execution-evidence.json").read_bytes())
    check("505 distinct catalog entries",matrix["totalCatalogEntries"]==505 and len(matrix["entries"])==505 and len({e["cherriName"] for e in matrix["entries"]})==505)
    summary=matrix["summary"]
    check("505 same callable/construct scope",summary["totalEntries"]==505 and summary["callableActions"]==497 and summary["compilerConstructs"]==8)
    counters={"legacySupportedCount":"legacyPassCount","v2SupportedCount":"v2PassCount","plistIdentifierVerifiedCount":"plistIdentifierPassCount",
        "parameterContractVerifiedCount":"parameterContractPassCount","decompileSupportedCount":"decompilePassCount",
        "roundTripVerifiedCount":"roundTripPassCount","structuralRoundTripVerifiedCount":"structuralRoundTripCount"}
    check("measured local counters preserved",all(summary[k]==raw[v]==505 for k,v in counters.items()))
    check("six measured dimensions preserved",summary["parameterDimensionSummaries"]==raw["parameterDimensionSummaries"])
    check("native and runtime remain zero",summary["nativeSpecimenParityCount"]==summary["appleRuntimeExecutedCount"]==0 and summary["blockedDeviceCount"]==summary["needsEvidenceCount"]==505)
    cross=derived["p10-apple-cherri-crosswalk.json"]
    baseline=derived["baseline-state.json"]
    check("crosswalk and baseline denominators agree",cross["denominators"]==baseline["counts"] and cross["denominators"]["cherriCatalogTotalEntries"]==505)
    check("existing 15-action pack inventory preserved",derived["p10-pack-15-go-only-audit.json"]["summary"]["totalGoOnlyEvaluated"]==15)
    for name in NAMES:
        h.original(out/"derived"/name,(repo/PREFIX/name).read_bytes())
    receipt={
        "source":before,"source_after":after,"argv":argv,"started_utc":started_utc,"finished_utc":finished_utc,
        "elapsed_seconds":elapsed,"exit_code":code,"timed_out":timed_out,"input_fingerprint_before":fp,
        "input_fingerprint_after":witness_after["fingerprint"],"changed_paths":changed,
        "outputs":after_files,"checks":checks,"generation_valid":all(c["pass"] for c in checks),
        "raw_evidence_provenance":{"execution_source":RAW_SOURCE,"parameter_source":RAW_SOURCE,
            "actual_process_sha256":RAW_PROCESS_SHA,"independent_intake_sha256":RAW_INTAKE_SHA,
            "same_deterministic_bytes_as_historical":True,"raw_sha256":RAW_HASHES},
        "release_gate_execution":False,"native_or_device_credit":False,
    }
    h.original(out/"process.original.json",receipt)
    h.original(out/"originals-manifest.json",{"files":[{"path":p.relative_to(out).as_posix(),"bytes":p.stat().st_size,"sha256":h.digest(p.read_bytes())} for p in sorted(out.rglob("*")) if p.is_file()]})
    print(json.dumps(receipt),flush=True)
    return 0 if receipt["generation_valid"] else 1

if __name__=="__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        failure={"status":"GENERATOR_SUPERVISOR_REJECTED","error_type":type(error).__name__,
                 "recorded_utc":h.utc(),"automatic_retry":False}
        if OWNED_OUTPUT is not None:h.original(OWNED_OUTPUT/"supervisor-rejection.original.json",failure)
        print(json.dumps(failure),file=sys.stderr)
        raise SystemExit(1)
