package analysis

import (
	"fmt"

	"github.com/electrikmilk/cherri/internal/language/syntax"
	"github.com/electrikmilk/cherri/internal/language/types"
)

// Provenance records whether lowering can obtain an independent presence flag,
// not whether the value is present. It follows bindings and checked function
// carriers; arbitrary native content and unimplemented value joins have none.
func (a *Analyzer) expressionHasPresence(expr syntax.Expression, value types.Type, scope *Scope) bool {
	if types.DefinitelyPresent(value) {
		return true
	}
	switch node := expr.(type) {
	case *syntax.LiteralExpr:
		return node.Type == syntax.TokenNone
	case *syntax.IdentExpr:
		binding, found := scope.Lookup(node.Name)
		return found && binding.Initialized && binding.optionalPresence
	case *syntax.CallExpr:
		return a.exprPresence[expr]
	}
	return false
}

func (a *Analyzer) requireCompilerPresence(expr syntax.Expression, context string) {
	if expr != nil && !a.exprPresence[expr] {
		a.error(CodeTargetValueShape, expr.NodeSpan(), fmt.Sprintf("current %s transport requires compiler-owned value presence; opaque native output or an untagged optional value cannot supply it", context))
	}
}
