package main

import (
	"fmt"
	"strings"
	"testing"
)

func p15ForwardCarrierGraph(g *p15FunctionGraph, marker string, value p15FunctionArgument, presence any) string {
	if flag, known := presence.(string); known {
		return p15OptionalCarrierGraph(g, "has_value", "value", marker, flag == "1", value)
	}
	group := g.conditional(4, presence, "WFConditionalActionString", "1")
	p15OptionalCarrierGraph(g, "has_value", "value", marker, true, value)
	g.boundary(group, 1, false)
	p15OptionalCarrierGraph(g, "has_value", "value", marker, false, p15FunctionArgument{})
	return g.boundary(group, 2, true)
}

func p15ForwardCallGraph(g *p15FunctionGraph, name string, value p15FunctionArgument, presence any, before, after []p15FunctionArgument) (string, string) {
	carrier := p15ForwardCarrierGraph(g, "_cherri_optional_argument_v1", value, presence)
	args := append([]p15FunctionArgument(nil), before...)
	args = append(args, p15FunctionArgument{true, 0, p15FunctionEdge(carrier)})
	args = append(args, after...)
	result := g.call(g.payload(name, args...))
	return p15DecodeOptionalGraph(g, result, "has_value", "value")
}

func p15ForwardResultGraph(g *p15FunctionGraph, value, presence string) {
	carrier := p15ForwardCarrierGraph(g, "_cherri_optional_result_v1", p15FunctionArgument{true, 0, p15FunctionEdge(value)}, p15FunctionEdge(presence))
	g.output(carrier)
}

func p15ForwardParameterGraph(g *p15FunctionGraph, envelope string, slot int, fallback bool) (value, presence string) {
	if !fallback {
		return p15DecodeOptionalArgumentGraph(g, envelope, slot)
	}
	supplied := g.get(fmt.Sprintf("has_arg_%d", slot), envelope)
	group := g.conditional(4, p15FunctionEdge(supplied), "WFConditionalActionString", "1")
	g.get(fmt.Sprintf("arg_%d", slot), envelope)
	g.boundary(group, 1, false)
	producer := g.value("gettext", map[string]any{"WFTextActionText": "DEFAULT"})
	p15OptionalCarrierGraph(g, "has_value", "value", "_cherri_optional_argument_v1", true, p15FunctionArgument{true, 0, p15FunctionEdge(producer)})
	carrier := g.boundary(group, 2, true)
	return p15DecodeOptionalGraph(g, carrier, "has_value", "value")
}

// Every operation is independently authored. Actual UUIDs are alpha names;
// complete ordering, parameter shape, control joins and edges must match.
func p15OptionalForwardingGraphError(actions []map[string]any, name string) error {
	g := &p15FunctionGraph{actual: actions, groups: map[string]bool{}}
	first := "echo"
	if name == "later_assignment" || name == "implicit_input" {
		first = "pick"
	}
	envelope := g.header(first)
	value, presence := p15ForwardParameterGraph(g, envelope, 0, name == "returned_none_default")
	if first == "pick" {
		g.get("arg_1", envelope)
	}
	p15ForwardResultGraph(g, value, presence)
	second := ""
	if strings.HasPrefix(name, "parameter_") || name == "named_parameter" {
		second = "relay"
	}
	if name == "former_function_forward" {
		second = "forward"
	}
	if name == "former_function_result" {
		second = "absent"
	}
	if second != "" {
		g.nextFunction(second)
		if second == "absent" {
			g.output(p15OptionalCarrierGraph(g, "has_value", "value", "_cherri_optional_result_v1", false, p15FunctionArgument{}))
		} else {
			slot := 0
			if name == "named_parameter" {
				g.get("arg_0", envelope)
				slot = 1
			}
			value, presence = p15DecodeOptionalArgumentGraph(g, envelope, slot)
			value, presence = p15ForwardCallGraph(g, "echo", p15FunctionArgument{true, 0, p15FunctionEdge(value)}, p15FunctionEdge(presence), nil, nil)
			p15ForwardResultGraph(g, value, presence)
		}
	}
	g.caller()
	var output string
	switch {
	case name == "immutable_none" || name == "inferred_none" || name == "former_function_bound":
		g.emit("nothing", nil)
		g.emit("setvariable", map[string]any{"WFVariableName": "candidate"})
		output, _ = p15ForwardCallGraph(g, "echo", p15FunctionArgument{}, "0", nil, nil)
	case name == "immutable_alias":
		g.emit("nothing", nil)
		g.emit("setvariable", map[string]any{"WFVariableName": "initial"})
		g.value("getvariable", map[string]any{"WFVariable": p15FunctionVariable("initial")})
		output, _ = p15ForwardCallGraph(g, "echo", p15FunctionArgument{}, "0", nil, nil)
	case name == "mutable_none" || name == "former_function_mutable":
		flag := p15MutableOptionalAssignGraph(g, "", false, p15MutableOptionalPresentValues()[0])
		output, _ = p15ForwardCallGraph(g, "echo", p15FunctionArgument{true, 0, p15FunctionVariable("candidate")}, p15FunctionVariable(flag), nil, nil)
	case name == "later_assignment":
		flag := p15MutableOptionalAssignGraph(g, "", false, p15MutableOptionalPresentValues()[0])
		oldPresence := g.value("getvariable", map[string]any{"WFVariable": p15FunctionVariable(flag)})
		oldValue := g.value("getvariable", map[string]any{"WFVariable": p15FunctionVariable("candidate")})
		condition := g.value("number", map[string]any{"WFNumberActionNumber": float64(1)})
		group := g.conditional(4, p15FunctionEdge(condition), "WFNumberValue", float64(1))
		p15MutableOptionalAssignGraph(g, flag, true, p15MutableOptionalPresentValues()[0])
		g.value("gettext", map[string]any{"WFTextActionText": "WRITTEN"})
		g.boundary(group, 1, false)
		g.value("gettext", map[string]any{"WFTextActionText": "UNUSED"})
		later := g.boundary(group, 2, true)
		output, _ = p15ForwardCallGraph(g, "pick", p15FunctionArgument{true, 0, p15FunctionEdge(oldValue)}, p15FunctionEdge(oldPresence), nil, []p15FunctionArgument{{true, 0, p15FunctionEdge(later)}})
	case name == "implicit_input":
		g.emit("nothing", nil)
		g.emit("setvariable", map[string]any{"WFVariableName": "supplied"})
		g.emit("gettext", map[string]any{"WFTextActionText": "INPUT"})
		late := g.value("hash", map[string]any{"WFHashType": "SHA256"})
		output, _ = p15ForwardCallGraph(g, "pick", p15FunctionArgument{}, "0", nil, []p15FunctionArgument{{true, 0, p15FunctionEdge(late)}})
	case name == "former_function_result":
		call := g.call(g.payload("absent"))
		value, presence = p15DecodeOptionalGraph(g, call, "has_value", "value")
		output, _ = p15ForwardCallGraph(g, "echo", p15FunctionArgument{true, 0, p15FunctionEdge(value)}, p15FunctionEdge(presence), nil, nil)
	case second != "":
		var before []p15FunctionArgument
		if name == "named_parameter" {
			before = []p15FunctionArgument{p15FunctionString("SEED")}
		}
		flag, argument := "0", p15FunctionArgument{}
		if name == "parameter_empty" || name == "former_function_forward" {
			flag, argument = "1", p15FunctionString("")
		}
		output, _ = p15ForwardCallGraph(g, second, argument, flag, before, nil)
	case strings.HasPrefix(name, "returned_"):
		key := strings.TrimPrefix(name, "returned_")
		if key == "none_default" {
			key = "none"
		}
		found := false
		for _, tc := range p15FunctionOptionalCases()[:6] {
			if tc.name != key {
				continue
			}
			found = true
			flag := "0"
			if tc.valuePresent {
				flag = "1"
			}
			value, presence = p15ForwardCallGraph(g, "echo", tc.value, flag, nil, nil)
			output, _ = p15ForwardCallGraph(g, "echo", p15FunctionArgument{true, 0, p15FunctionEdge(value)}, p15FunctionEdge(presence), nil, nil)
		}
		if !found {
			return fmt.Errorf("unmodeled Optional forwarding value %q", key)
		}
	default:
		return fmt.Errorf("unmodeled Optional forwarding scenario %q", name)
	}
	g.emit("getvariable", map[string]any{"WFVariable": p15FunctionEdge(output)})
	return g.finish()
}

func TestP15OptionalForwardingCompleteNativeGraph(t *testing.T) {
	for _, tc := range p15OptionalForwardingCases() {
		t.Run(tc.name, func(t *testing.T) {
			if err := p15OptionalForwardingGraphError(p15CompiledActions(t, tc.source), tc.name); err != nil {
				t.Fatal(err)
			}
		})
	}
}
