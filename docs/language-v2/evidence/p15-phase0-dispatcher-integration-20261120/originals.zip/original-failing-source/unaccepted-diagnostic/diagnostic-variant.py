import hashlib
import json
import os
import plistlib
import shutil
import subprocess
import sys

root_dir, artifact_dir, source_sha = sys.argv[1], sys.argv[2], sys.argv[3]
sys.path.insert(0, os.path.join(root_dir, "tools", "shortcuts-simulator-qa"))
from retry_http_probe import validate_fixture_graph
from json_body_probe import verify_source as verify_json_body_source, verify_graph as verify_json_body_graph, verify_mutations as verify_json_body_mutations
from export_unicode_diagnostic import validate_export_unicode_graph
from file_materialization_diagnostic import verify_source as verify_file_materialization_source, verify_graph as verify_file_materialization_graph
from n03_text_equality_diagnostic import verify_source as verify_n03_text_equality_source
from optional_forwarding_diagnostic import verify_source as verify_optional_forwarding_source, verify_prepared_unsigned as verify_optional_forwarding_unsigned
from binding_defaults_probe import verify_adapter_source, verify_adapter_graph
from f04_record_empty_probe import verify_source as verify_record_empty_source, verify_graph as verify_record_empty_graph
from native_boundary_diagnostic import verify_source as verify_boundary_source, verify_graph as verify_boundary_graph
from fixture_compile_contract import EXPECTED_REJECTIONS, verify_expected_rejection
from debug_label_acceptance import verify_source as verify_label_source, verify_graph as verify_label_graph, verify_causal_mutations as verify_label_mutations
cherri_bin = os.path.join(artifact_dir, "builds", "cherri")
fixtures_dir = os.path.join(root_dir, "tools", "shortcuts-simulator-qa", "fixtures")
builds_dir = os.path.join(artifact_dir, "builds")

fixture_specs = [
    ("qa-json-body-file-utf8-v2", "qa-json-body-file-utf8-v2.cherri", "v2"),
    ("qa-json-body-control-v2", "qa-json-body-control-v2.cherri", "v2"),
    ("qa-json-body-null-candidate-v2", "qa-json-body-null-candidate-v2.cherri", "v2"),
    ("qa-debug-label-plain-v2", "qa-debug-label-plain-v2.cherri", "v2"),
    ("qa-debug-label-plain-legacy", "qa-debug-label-plain-legacy.cherri", "legacy"),
    ("qa-debug-label-dated-v2", "qa-debug-label-dated-v2.cherri", "v2"),
    ("qa-debug-label-dated-legacy", "qa-debug-label-dated-legacy.cherri", "legacy"),
    ("qa-debug-label-typed-v2", "qa-debug-label-typed-v2.cherri", "v2"),
    ("qa-debug-label-typed-legacy", "qa-debug-label-typed-legacy.cherri", "legacy"),
    ("qa-debug-label-dated-typed-v2", "qa-debug-label-dated-typed-v2.cherri", "v2"),
    ("qa-debug-label-dated-typed-legacy", "qa-debug-label-dated-typed-legacy.cherri", "legacy"),
    ("qa-debug-label-text-v2", "qa-debug-label-text-v2.cherri", "v2"),
    ("qa-debug-label-text-legacy", "qa-debug-label-text-legacy.cherri", "legacy"),
    ("qa-debug-label-dated-text-v2", "qa-debug-label-dated-text-v2.cherri", "v2"),
    ("qa-debug-label-dated-text-legacy", "qa-debug-label-dated-text-legacy.cherri", "legacy"),
    ("CherriBindingCapturePOC", "p15-binding-defaults/CherriBindingCapturePOC.cherri", "v2"),
    ("CherriTypedDefaultsPOC", "p15-binding-defaults/CherriTypedDefaultsPOC.cherri", "v2"),
    ("qa-storage-text-same-run-v2", "qa-storage-text-same-run-v2.cherri", "v2"),
    ("qa-storage-scope-v2", "qa-storage-scope-v2.cherri", "v2"),
    ("qa-storage-delete-v2", "qa-storage-delete-v2.cherri", "v2"),
    ("qa-storage-text-cross-run-v2", "qa-storage-text-cross-run-v2.cherri", "v2"),
    ("qa-http-json-control-v2", "qa-http-json-control-v2.cherri", "v2"),
    ("qa-http-json-fetch-v2", "qa-http-json-fetch-v2.cherri", "v2"),
    ("qa-number-comparison-diag-v2", "qa-number-comparison-diag-v2.cherri", "v2"),
    ("qa-number-coercion-control-v2", "qa-number-coercion-control-v2.cherri", "v2"),
    ("qa-paginate-ordered-v2", "p15-paginate-probes/qa-paginate-ordered-v2.cherri", "v2"),
    ("qa-paginate-cycle-v2", "p15-paginate-probes/qa-paginate-cycle-v2.cherri", "v2"),
    ("qa-paginate-page-cap-v2", "p15-paginate-probes/qa-paginate-page-cap-v2.cherri", "v2"),
    ("qa-paginate-item-cap-v2", "p15-paginate-probes/qa-paginate-item-cap-v2.cherri", "v2"),
    ("qa-paginate-empty-v2", "p15-paginate-probes/qa-paginate-empty-v2.cherri", "v2"),
    ("qa-collect-counts-v2", "qa-collect-counts-v2.cherri", "v2"),
    ("qa-collect-counts-legacy", "qa-collect-counts-legacy.cherri", "legacy"),
    ("qa-collect-dictionaries-v2", "qa-collect-dictionaries-v2.cherri", "v2"),
    ("qa-collect-dictionaries-legacy", "qa-collect-dictionaries-legacy.cherri", "legacy"),
    ("qa-retry-control-v2", "qa-retry-control-v2.cherri", "v2"),
    ("qa-retry-http500-v2", "qa-retry-http500-v2.cherri", "v2"),
    ("qa-retry-http404-v2", "qa-retry-http404-v2.cherri", "v2"),
    ("qa-retry-http429-v2", "qa-retry-http429-v2.cherri", "v2"),
    ("qa-retry-transport-v2", "qa-retry-transport-v2.cherri", "v2"),
    ("qa-label-file-carrier-v2", "p15-label-probes/qa-label-file-carrier-v2.cherri", "v2"),
    ("qa-label-raw-empty-v2", "p15-label-probes/qa-label-raw-empty-v2.cherri", "v2"),
    ("qa-label-raw-grouping-v2", "p15-label-probes/qa-label-raw-grouping-v2.cherri", "v2"),
    ("qa-file-materialization-diagnostic-v2", "qa-file-materialization-diagnostic-v2.cherri", "v2"),
    ("qa-n03-text-equality-diagnostic-v2", "qa-n03-text-equality-diagnostic-v2.cherri", "v2"),
    ("qa-optional-forwarding-diagnostic-v2", "qa-optional-forwarding-diagnostic-v2.cherri", "v2"),
    ("qa-native-boundary-diagnostic-v2", "qa-native-boundary-diagnostic-v2.cherri", "v2"),
    ("qa-export-unicode-diagnostic-v2", "qa-export-unicode-diagnostic-v2.cherri", "v2"),
    ("qa-export-unicode-v2", "p15-export-probes/qa-export-unicode-v2.cherri", "v2"),
    ("qa-export-empty-v2", "p15-export-probes/qa-export-empty-v2.cherri", "v2"),
    ("qa-export-thousand-v2", "p15-export-probes/qa-export-thousand-v2.cherri", "v2"),
    ("qa-export-redacted-v2", "p15-export-probes/qa-export-redacted-v2.cherri", "v2"),
    ("qa-export-unsupported-file-v2", "p15-export-probes/qa-export-unsupported-file-v2.cherri", "v2"),
    ("qa-export-text-file-v2", "p15-export-probes/qa-export-text-file-v2.cherri", "v2"),
    ("qa-functional-v2", "qa-functional-v2.cherri", "v2"),
    ("qa-functional-legacy", "qa-functional-legacy.cherri", "legacy"),
    ("qa-scroll-editor-v2", "qa-scroll-editor-v2.cherri", "v2"),
    ("qa-scroll-editor-legacy", "qa-scroll-editor-legacy.cherri", "legacy"),
    ("qa-rtl-hebrew-v2", "qa-rtl-hebrew-v2.cherri", "v2"),
    ("qa-bool-list-v2", "qa-bool-list-v2.cherri", "v2"),
    ("qa-short-circuit-v2", "qa-short-circuit-v2.cherri", "v2"),
    ("qa-short-circuit-local-v2", "qa-short-circuit-local-v2.cherri", "v2"),
    ("qa-f01-diag-counter-v2", "qa-f01-diag-counter-v2.cherri", "v2"),
    ("qa-f01-diag-predicate-v2", "qa-f01-diag-predicate-v2.cherri", "v2"),
    ("qa-f01-diag-control-v2", "qa-f01-diag-control-v2.cherri", "v2"),
    ("qa-f01-diag-logic-v2", "qa-f01-diag-logic-v2.cherri", "v2"),
    ("qa-require-zero-diag-v2", "qa-require-zero-diag-v2.cherri", "v2"),
    ("qa-label-file-controls-v2", "qa-label-file-controls-v2.cherri", "v2"),
    ("qa-export-file-control-v2", "qa-export-file-control-v2.cherri", "v2"),
    ("qa-export-build-only-v2", "qa-export-build-only-v2.cherri", "v2"),
    ("qa-export-parse-only-v2", "qa-export-parse-only-v2.cherri", "v2"),
    ("qa-nil-clear-v2", "qa-nil-clear-v2.cherri", "v2"),
    ("qa-collect-empty-split-v2", "qa-collect-empty-split-v2.cherri", "v2"),
    ("qa-export-file-bytes-v2", "qa-export-file-bytes-v2.cherri", "v2"),
    ("qa-file-name-binding-v2", "qa-file-name-binding-v2.cherri", "v2"),
    ("qa-file-name-extension-v2", "qa-file-name-extension-v2.cherri", "v2"),
    ("qa-f04-yield-list-v2", "qa-f04-yield-list-v2.cherri", "v2"),
    ("qa-f04-yield-empty-list-v2", "qa-f04-yield-empty-list-v2.cherri", "v2"),
    ("qa-f04-record-empty-v2", "qa-f04-record-empty-v2.cherri", "v2"),
    ("qa-f01-ifresult-let-v2", "qa-f01-ifresult-let-v2.cherri", "v2"),
    ("qa-f01-ifresult-var-v2", "qa-f01-ifresult-var-v2.cherri", "v2"),
    ("qa-require-v2", "qa-require-v2.cherri", "v2"),
    ("qa-measure-v2", "qa-measure-v2.cherri", "v2"),
    ("qa-measure-release-v2", "qa-measure-release-v2.cherri", "v2"),
    ("qa-functional-v2-uninstrumented", "qa-functional-v2-uninstrumented.cherri", "v2"),
    ("qa-functional-legacy-uninstrumented", "qa-functional-legacy-uninstrumented.cherri", "legacy"),
]


# DIAGNOSTIC ONLY: failures are retained, never accepted or published.
diagnostic_failures=[]
def diagnostic_wrapper(name, operation):
    def invoke(*args, **kwargs):
        try:
            return operation(*args, **kwargs)
        except Exception as error:
            row={"fixture":globals().get("fid"),"validator":name,
                 "exception":type(error).__name__,"message":str(error)}
            diagnostic_failures.append(row)
            return {"diagnostic_only_failure":row,"formalAcceptanceGranted":False}
    return invoke
for diagnostic_name in (
    "validate_fixture_graph","verify_json_body_source","verify_json_body_graph",
    "verify_json_body_mutations","validate_export_unicode_graph",
    "verify_file_materialization_source","verify_file_materialization_graph",
    "verify_n03_text_equality_source","verify_optional_forwarding_source",
    "verify_optional_forwarding_unsigned","verify_adapter_source","verify_adapter_graph",
    "verify_record_empty_source","verify_record_empty_graph","verify_boundary_source",
    "verify_boundary_graph","verify_expected_rejection","verify_label_source",
    "verify_label_graph","verify_label_mutations"):
    globals()[diagnostic_name]=diagnostic_wrapper(diagnostic_name,globals()[diagnostic_name])

manifest_entries = []
fixture_rejections = []
compiled_actions_by_id = {}

def native_strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from native_strings(key)
            yield from native_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from native_strings(item)

for fid, fname, dialect in fixture_specs:
    profile = "release" if fid == "qa-measure-release-v2" else "debug"
    trace_expectation = "ABSENT_RELEASE" if profile == "release" else "REQUIRED_NDJSON"
    fpath = os.path.join(fixtures_dir, fname)
    with open(fpath, "rb") as f:
        src_bytes = f.read()
    src_sha256 = hashlib.sha256(src_bytes).hexdigest()
    optional_forwarding_source = verify_optional_forwarding_source(root_dir, fid, src_bytes)

    build_src = os.path.join(builds_dir, fname)
    os.makedirs(os.path.dirname(build_src), exist_ok=True)
    shutil.copyfile(fpath, build_src)
    out_base = os.path.join(builds_dir, fid)
    out_shortcut = out_base + ".shortcut"
    cmd = [cherri_bin, build_src, "--skip-sign", f"--output={out_shortcut}", f"--build-profile={profile}"]
    if dialect == "legacy":
        cmd.append("--legacy")
    proc = subprocess.run(cmd, cwd=builds_dir, capture_output=True, text=True)
    if fid in EXPECTED_REJECTIONS:
        checked = subprocess.run([cherri_bin, "--check=" + build_src, "--json"],
                                 cwd=builds_dir, capture_output=True, text=True)
        rejection = verify_expected_rejection(fid, src_bytes.decode("utf-8"), proc, checked,
            [out_shortcut, os.path.splitext(build_src)[0] + ".shortcut",
             os.path.splitext(build_src)[0] + ".plist"])
        rejection.update(fileName=fname, dialect=dialect, sourceSha256=src_sha256)
        fixture_rejections.append(rejection)
        continue
    if proc.returncode != 0:
        raise RuntimeError(f"Failed to compile {fid}: {proc.stdout}\n{proc.stderr}")

    with open(out_shortcut, "rb") as f:
        plist_bytes = f.read()
    plist_sha256 = hashlib.sha256(plist_bytes).hexdigest()
    doc = plistlib.loads(plist_bytes)
    actions = doc.get("WFWorkflowActions", [])
    compiled_actions_by_id[fid] = actions

    action_ids = [a.get("WFWorkflowActionIdentifier", "") for a in actions]
    release_diagnostics_absent = False
    release_body_verified = False
    if profile == "release":
        # Inspect the emitted graph independently of the CLI flag. An ignored
        # profile flag must not permit the absence of runtime trace evidence.
        release_diagnostics_absent = not any(
            "__cherri_debug_" in item or "__cherri_qa_trace" in item
            or item == "is.workflow.actions.gettimebetweendates"
            for item in native_strings(actions)
        )
        release_body_verified = (
            action_ids.count("is.workflow.actions.delay") == 1
            and action_ids.count("is.workflow.actions.dictionary") == 1
        )
        if not release_diagnostics_absent or not release_body_verified:
            raise RuntimeError("Release measure fixture retained diagnostics or lost/duplicated its native body")
    manifest_entries.append({
        "fixtureId": fid,
        "fileName": fname,
        "dialect": dialect,
        "buildProfile": profile,
        "runtimeTraceExpectation": trace_expectation,
        "httpProbeGraph": validate_fixture_graph(fid, actions),
        "jsonBodySource": verify_json_body_source(root_dir, fid, src_bytes),
        "jsonBodyGraph": verify_json_body_graph(root_dir, fid, actions),
        "jsonBodyCausalMutations": verify_json_body_mutations(root_dir, fid, actions),
        "exportUnicodeDiagnosticGraph": validate_export_unicode_graph(fid, actions),
        "fileMaterializationSource": verify_file_materialization_source(root_dir, fid, src_bytes),
        "n03TextEqualitySource": verify_n03_text_equality_source(root_dir, fid, src_bytes),
        "optionalForwardingSource": optional_forwarding_source,
        "optionalForwardingGraph": verify_optional_forwarding_unsigned(root_dir, artifact_dir, fid, out_shortcut, plist_sha256),
        "fileMaterializationGraph": verify_file_materialization_graph(fid, actions),
        "bindingDefaultsSource": verify_adapter_source(root_dir, fid, src_bytes),
        "bindingDefaultsGraph": verify_adapter_graph(fid, actions),
        "recordEmptyFeasibilitySource": verify_record_empty_source(root_dir, fid, src_bytes),
        "recordEmptyFeasibilityGraph": verify_record_empty_graph(fid, actions),
        "nativeBoundarySource": verify_boundary_source(root_dir, fid, src_bytes),
        "nativeBoundaryGraph": verify_boundary_graph(fid, actions),
        "debugLabelSource": verify_label_source(root_dir, fid, src_bytes),
        "debugLabelGraph": verify_label_graph(fid, actions),
        "debugLabelCausalMutations": verify_label_mutations(fid, actions) if verify_label_source(root_dir, fid, src_bytes) else None,
        "releaseDiagnosticActionsAbsent": release_diagnostics_absent,
        "releaseBodyShapeVerified": release_body_verified,
        "sourceSha256": src_sha256,
        "unsignedPlistSha256": plist_sha256,
        "nativeActionCount": len(actions),
        "actionIdentifiers": action_ids,
    })

compiler_manifest = {
    "diagnosticOnly": True,
    "formalAcceptanceGranted": False,
    "schemaVersion": "1.5",
    "syntheticOnly": True,
    "compilerCommitSha": source_sha,
    "fixtures": manifest_entries,
    "fixtureRejections": fixture_rejections,
    "compileAttempts": len(manifest_entries) + len(fixture_rejections),
    "compiledArtifactCount": len(manifest_entries),
    "expectedDiagnosticRejectionCount": len(fixture_rejections),
}
with open(os.path.join(artifact_dir, "diagnostic-unaccepted-compiler-manifest.json"), "w", encoding="utf-8") as f:
    json.dump(compiler_manifest, f, indent=2)

# Structural classifier matching debug_stdlib.go (never naive substring heuristics)
def is_structural_inline_trace_text(actions, idx):
    if idx < 0 or idx + 1 >= len(actions):
        return False
    act = actions[idx]
    nxt = actions[idx + 1]
    if act.get("WFWorkflowActionIdentifier") != "is.workflow.actions.gettext":
        return False
    if nxt.get("WFWorkflowActionIdentifier") != "is.workflow.actions.appendvariable":
        return False
    nxt_params = nxt.get("WFWorkflowActionParameters", {})
    if nxt_params.get("WFVariableName") != "__cherri_qa_trace":
        return False
    act_uuid = act.get("WFWorkflowActionParameters", {}).get("UUID", "")
    inp = nxt_params.get("WFInput", {}).get("Value", {})
    if not act_uuid or inp.get("OutputUUID") != act_uuid:
        return False
    txt = act.get("WFWorkflowActionParameters", {}).get("WFTextActionText", {})
    if not isinstance(txt, dict) or txt.get("WFSerializationType") != "WFTextTokenString":
        return False
    atts = txt.get("Value", {}).get("attachmentsByRange", {})
    if len(atts) != 1:
        return False
    only_att = next(iter(atts.values()))
    return isinstance(only_att, dict) and only_att.get("Type") == "CurrentDate"

def is_structural_collector_envelope_text(actions, idx):
    if idx <= 0 or idx >= len(actions):
        return False
    prev = actions[idx - 1]
    act = actions[idx]
    if prev.get("WFWorkflowActionIdentifier") != "is.workflow.actions.text.combine":
        return False
    if act.get("WFWorkflowActionIdentifier") != "is.workflow.actions.gettext":
        return False
    prev_params = prev.get("WFWorkflowActionParameters", {})
    combine_uuid = prev_params.get("UUID", "")
    combine_var = prev_params.get("text", {}).get("Value", {}).get("VariableName", "")
    if not combine_uuid or combine_var != "__cherri_qa_trace":
        return False
    txt = act.get("WFWorkflowActionParameters", {}).get("WFTextActionText", {})
    if not isinstance(txt, dict) or txt.get("WFSerializationType") != "WFTextTokenString":
        return False
    s = txt.get("Value", {}).get("string", "")
    if "===CHERRI_QA_TRACE_NDJSON_V14===" not in s:
        return False
    atts = txt.get("Value", {}).get("attachmentsByRange", {})
    if len(atts) != 1:
        return False
    only_att = next(iter(atts.values()))
    return (
        isinstance(only_att, dict)
        and only_att.get("Type") == "ActionOutput"
        and only_att.get("OutputUUID") == combine_uuid
        and only_att.get("OutputName") == "Combined Text"
    )

def classify_actions(actions):
    source_ids = []
    inline_debug_ids = []
    collector_ids = []
    for idx, act in enumerate(actions):
        aid = act.get("WFWorkflowActionIdentifier", "")
        params = act.get("WFWorkflowActionParameters", {})
        vname = str(params.get("WFVariableName", ""))
        if vname in ("__cherri_debug_log", "__cherri_qa_trace") or vname.startswith("__cherri_debug_timer_"):
            inline_debug_ids.append({"nativeIndex": idx, "identifier": aid, "variable": vname})
            continue
        if aid == "is.workflow.actions.detect.date":
            aggs = params.get("WFInput", {}).get("Value", {}).get("Aggrandizements", [])
            if len(aggs) == 1 and aggs[0].get("PropertyUserInfo") == "WFFileCreationDate":
                inline_debug_ids.append({"nativeIndex": idx, "identifier": aid, "reason": "CreationDateCapture"})
                continue
        if aid == "is.workflow.actions.text.combine":
            cvar = params.get("text", {}).get("Value", {}).get("VariableName", "")
            if cvar in ("__cherri_debug_log", "__cherri_qa_trace"):
                collector_ids.append({"nativeIndex": idx, "identifier": aid})
                continue
        if aid == "is.workflow.actions.nothing" and idx + 1 < len(actions):
            nxt = actions[idx + 1]
            next_params = nxt.get("WFWorkflowActionParameters", {})
            if (nxt.get("WFWorkflowActionIdentifier") == "is.workflow.actions.setvariable"
                    and next_params.get("WFVariableName") == "__cherri_debug_log"
                    and "WFInput" not in params and "WFInput" not in next_params):
                inline_debug_ids.append({"nativeIndex": idx, "identifier": aid, "reason": "ClearLogsNothing"})
                continue
        if aid == "is.workflow.actions.gettext":
            if is_structural_inline_trace_text(actions, idx):
                inline_debug_ids.append({"nativeIndex": idx, "identifier": aid, "reason": "TraceEventLine"})
                continue
            if is_structural_collector_envelope_text(actions, idx):
                collector_ids.append({"nativeIndex": idx, "identifier": aid, "reason": "TraceExportEnvelope"})
                continue
            if params.get("WFTextActionText") == "" and idx + 1 < len(actions):
                nxt = actions[idx + 1]
                if (
                    nxt.get("WFWorkflowActionIdentifier") == "is.workflow.actions.setvariable"
                    and nxt.get("WFWorkflowActionParameters", {}).get("WFVariableName") == "__cherri_debug_log"
                ):
                    inline_debug_ids.append({"nativeIndex": idx, "identifier": aid, "reason": "ClearLogsEmptyText"})
                    continue
        source_ids.append(aid)
    return source_ids, inline_debug_ids, collector_ids

comparisons = []
for dialect in ("v2", "legacy"):
    inst_id = f"qa-functional-{dialect}"
    uninst_id = f"qa-functional-{dialect}-uninstrumented"
    inst_src, inst_dbg, inst_col = classify_actions(compiled_actions_by_id[inst_id])
    uninst_src, _, _ = classify_actions(compiled_actions_by_id[uninst_id])
    if inst_src != uninst_src:
        raise RuntimeError(f"SOURCE_ACTION projection mismatch for {dialect}: {inst_src} != {uninst_src}")
    comparisons.append({
        "dialect": dialect,
        "instrumentedFixtureId": inst_id,
        "uninstrumentedFixtureId": uninst_id,
        "uninstrumentedActionCount": len(compiled_actions_by_id[uninst_id]),
        "instrumentedTotalActionCount": len(compiled_actions_by_id[inst_id]),
        "projectedSourceActionCount": len(inst_src),
        "inlineDebugActionCount": len(inst_dbg),
        "collectorEventActionCount": len(inst_col),
        "sourceActionSequenceMatches": (inst_src == uninst_src),
        "sourceActionIdentifiers": inst_src,
        "inlineDebugActions": inst_dbg,
        "collectorActions": inst_col,
    })

with open(os.path.join(artifact_dir, "runtime", "instrumentation-vs-original.json"), "w", encoding="utf-8") as f:
    json.dump({"schemaVersion": "1.4", "comparisons": comparisons}, f, indent=2)

with open(os.path.join(artifact_dir,"diagnostic-failures.json"),"w",encoding="utf-8") as f:
    json.dump({"diagnosticOnly":True,"source":source_sha,"failures":diagnostic_failures,"formalAcceptanceGranted":False},f,indent=2)
print(json.dumps({"compileAttempts":len(manifest_entries)+len(fixture_rejections),"compiled":len(manifest_entries),"expectedRejected":len(fixture_rejections),"diagnosticFailures":diagnostic_failures,"formalAcceptanceGranted":False}))
sys.exit(1 if diagnostic_failures else 0)
