import pathlib,subprocess,json,hashlib,datetime,collections
e=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119")
root=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
out=e/"r4-preflight-independent-audit";out.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding="utf-8"))
def events(p):
 result=[]
 for line in p.read_bytes().splitlines():
  if not line:continue
  result.append(json.loads(line))
 return result
def git(*args,input=None):
 p=subprocess.run(["git","--no-replace-objects",*args],cwd=root,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 assert p.returncode==0,p.stderr.decode("utf-8","replace");return p.stdout
stages=[]
for name in ["r4-preflight-891ff4c2","r4-preflight-0dc40853","r4-preflight-0dc40853-remaining"]:
 p=e/name;process=read(p/"process-original.json")
 assert process["source_sha"]==process["source_sha_after"] and process["source_clean_before"] and process["source_clean_after"] and process["status"]=="FAILED"
 commands=[]
 for c in process["commands"]:
  for stream in ["stdout","stderr"]:
   b=(p/(c["name"]+"-"+stream+"-original.log")).read_bytes()
   assert sha(b)==c[stream+"_sha256"] and len(b)==c[stream+"_bytes"]
  result={k:v for k,v in c.items() if k not in ["bad_events","command"]}
  if "named_passes" in c:
   ev=events(p/(c["name"]+"-stdout-original.log"))
   passed=[x["Test"] for x in ev if x.get("Test") and x.get("Action")=="pass"]
   assert len(passed)==c["named_passes"]==len(set(passed))
   result["failed_named_tests"]=[x["Test"] for x in ev if x.get("Test") and x.get("Action")=="fail"]
   result["skipped_named_tests"]=[x.get("Test") for x in ev if x.get("Action")=="skip"]
  commands.append(result)
 stages.append({"directory":name,"sourceCommit":process["source_sha"],"clean":True,"status":"FAILED","commands":commands})
p=e/"r4-preflight-0dc40853-remaining";source="0dc408530082059ec06e08506fc05eed2fb210d2"
outer=events(p/"actual-acceptance-producers-stdout-original.log")
parents={"RP11":"TestNumberWireActualProductionEvidence","RP16":"TestExhaustiveNodeActualProductionEvidence","U01":"TestUpstreamBoundaryActualProductionEvidence"}
records=[];children=[];source_requirements={}
for req,parent in parents.items():
 assert any(x.get("Test")==parent and x.get("Action")=="pass" for x in outer),parent
 text="".join(x.get("Output","") for x in outer if x.get("Test")==parent)
 receipts=[json.loads(line.split("PRODUCTION_RECEIPT:",1)[1]) for line in text.splitlines() if "PRODUCTION_RECEIPT:" in line]
 assert len(receipts)==1,(parent,len(receipts));receipt=receipts[0]
 assert receipt["source_sha"]==source
 assert len(receipt["records"])==(1 if req=="U01" else 2)
 for record in receipt["records"]:
  assert record["requirements"]==[req] and record["implementation_sha"]==source and record["exit_code"]==0 and record["result"]=="passed"
  for a in record["artifacts"]:
   actual=pathlib.Path(a["path"]);assert actual.is_relative_to(p)
   assert sha(actual.read_bytes())==a["sha256"]
  records.append({"requirement":req,"tier":record["tier"],"testId":record["test_id"],"artifactReferences":len(record["artifacts"])})
 procfiles=list((p/(req.lower()+"-child")).glob("*/*-process.json"));assert len(procfiles)==1
 procpath=procfiles[0];proc=read(procpath);rawpath=procpath.with_name(req.lower()+"-go.jsonl");stderrpath=procpath.with_name(req.lower()+"-stderr.log")
 raw=rawpath.read_bytes();stderr=stderrpath.read_bytes();ev=events(rawpath)
 assert proc["requirement"]==req and proc["source_commit"]==source and proc["source_clean_before"] and proc["source_clean_after"]
 assert proc["exit_code"]==0 and proc["timed_out"] is False and sha(raw)==proc["raw_sha256"] and len(raw)==proc["raw_bytes"]
 assert sha(stderr)==proc["stderr_sha256"] and len(stderr)==proc["stderr_bytes"]==0
 passed=[x["Test"] for x in ev if x.get("Test") and x.get("Action")=="pass"]
 assert len(passed)==len(set(passed)) and set(passed)==set(proc["required_tests"])==set(proc["discovered_tests"])
 assert not [x for x in ev if x.get("Action") in ["fail","skip"]]
 assert len([x for x in ev if x.get("Action")=="pass" and not x.get("Test")])==1
 start=datetime.datetime.fromisoformat(proc["started_utc"].replace("Z","+00:00"));finish=datetime.datetime.fromisoformat(proc["finished_utc"].replace("Z","+00:00"))
 assert 0 < (finish-start).total_seconds() < 240
 for x in ev:
  if x.get("Time"):
   when=datetime.datetime.fromisoformat(x["Time"].replace("Z","+00:00"));assert start<=when<=finish
 for f in proc["source_files"]:
  if f["path"] in source_requirements:assert source_requirements[f["path"]]==f["sha256"]
  source_requirements[f["path"]]=f["sha256"]
 children.append({"requirement":req,"namedPasses":len(passed),"rawBytes":len(raw),"rawSha256":sha(raw),"sourceFiles":len(proc["source_files"]),"command":proc["command"]})
requests=[source+":"+p for p in sorted(source_requirements)]
raw=git("cat-file","--batch",input=("\n".join(requests)+"\n").encode());offset=0;blobs={}
for request in requests:
 end=raw.index(b"\n",offset);h=raw[offset:end].split();assert len(h)==3 and h[1]==b"blob"
 n=int(h[2]);offset=end+1;b=raw[offset:offset+n];assert len(b)==n and raw[offset+n:offset+n+1]==b"\n"
 offset+=n+1;path=request.split(":",1)[1];assert sha(b)==source_requirements[path],path;blobs[path]=b
assert offset==len(raw)
contracts={"tests/language-v2/acceptance-contract.json":"9fdfa8910b09824dc61395d8ddf4aa8fe8914619af0fdde59c63b67ab10b895e","tests/language-v2/repair-regression-plan.json":"eba070df0e1ff229a94e52d977a09c2a0c125a31b1a69caf32787d41600074f5","tests/language-v2/backend-recovery-gates.json":"e7fbb3ad177c5142935f71a46ca7e89b84822061bfc0919eec59708811ab7e7c"}
for path,digest in contracts.items():assert sha(blobs[path])==digest
followups=[]
for name,relative,expected in [
 ("schema","r4-schema-command/replay-f10bf2cf","f10bf2cfce9751aa8f4ca740bce0c1304c1996cd"),
 ("F03","r4-f03-replay-6ec59094","6ec590940e0179f9739ebcf4198696d2662cd100")]:
 d=e/relative;proc=read(d/"process-original.json");raw=(d/"go-test-original.jsonl").read_bytes()
 assert proc["sourceCommit"]==proc["sourceAfter"]==expected and proc["cleanBefore"] and proc["cleanAfter"]
 assert proc["exitCode"]==0 and not proc["outerTimedOut"] and sha(raw)==proc["rawSha256"] and len(raw)==proc["rawBytes"]
 ev=events(d/"go-test-original.jsonl");passes=[x["Test"] for x in ev if x.get("Test") and x.get("Action")=="pass"]
 assert len(passes)==1 and not [x for x in ev if x.get("Action") in ["fail","skip"]]
 followups.append(proc)
result={"formatVersion":1,"auditedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Intermediate R4 exact-source verification only; failed suites remain failed and no final179/Apple/other-ID inheritance","closureComplete":False,"stages":stages,"completedProducerChildren":children,"verifiedRecords":records,"sourceCommit":source,"uniqueSourceBlobsVerified":len(blobs),"immutableContracts":contracts,"followups":followups}
(out/"audit.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"status":"AUDITED","source":source,"uniqueSourceBlobsVerified":len(blobs),"completedChildren":children,"recordCount":len(records),"followups":[{"label":x["label"],"source":x["sourceCommit"],"rawSha256":x["rawSha256"]} for x in followups],"failedStagesPreserved":3}))
