import subprocess,json,hashlib
from pathlib import Path
base=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126")
E=base/"source-checkpoint-01";E.mkdir(exist_ok=False);(E/"owner.original.py").write_text(Path(__file__).read_text())
specs=[
("compiler",Path("/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125"),"agent/cherri-p10r15-consumer-final-alignment-20261126","5f8acea50fec1249390b5aed6db6b073c43d1173",["skills/cherri-shortcuts/SKILL.md","skills/cherri-shortcuts/references/workflow.md","skills/cherri-shortcuts/references/openminis.md","skills/cherri-shortcuts/references/language-boundaries.md"],"docs(skill): align typed values and guarded editing workflow [skip ci]"),
("docs",Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126"),"agent/cherri-p10r15-docs-final-alignment-20261126","428f067090bf54f4d2f214c36951689dd599d153",["fork-language/guide.md","PROJECT_BOARD.md"],"docs: prepare integrated value and macro guide examples [skip ci]")]
def git(W,*a):
 r=subprocess.run(["/usr/sbin/runuser","-u","ubuntu","--","git","-C",str(W),*a],capture_output=True,timeout=60)
 if r.returncode:raise RuntimeError((a,r.stdout.decode(),r.stderr.decode()))
 return r.stdout.decode().strip()
receipts=[]
for name,W,branch,head,files,msg in specs:
 assert git(W,"rev-parse","HEAD")==head
 assert git(W,"branch","--show-current")==branch
 changed=set(git(W,"diff","--name-only").splitlines())|set(git(W,"ls-files","--others","--exclude-standard").splitlines())
 assert changed==set(files),(changed,files)
 git(W,"diff","--check")
 git(W,"add","--",*files)
 commit=git(W,"-c","user.name=David Povarsky","-c","user.email=davidpovarsky@users.noreply.github.com","commit","-m",msg)
 (E/f"{name}.commit.stdout.original.txt").write_text(commit+"\n")
 new=git(W,"rev-parse","HEAD")
 assert not git(W,"status","--porcelain","--untracked-files=all")
 cmd=["/usr/sbin/runuser","-u","ubuntu","--","git","-C",str(W),"-c","credential.helper=","-c","credential.helper=!gh auth git-credential","push","origin",branch]
 r=subprocess.run(cmd,capture_output=True,timeout=60)
 (E/f"{name}.push.stdout.original.bin").write_bytes(r.stdout);(E/f"{name}.push.stderr.original.bin").write_bytes(r.stderr)
 assert r.returncode==0,(name,r.stderr.decode())
 remote=git(W,"ls-remote","--heads","origin","refs/heads/"+branch)
 assert remote.split()[0]==new
 receipts.append({"repo":name,"root":str(W),"base":head,"head":new,"tree":git(W,"rev-parse","HEAD^{tree}"),"branch":branch,"files":files,"pushExit":r.returncode,"remote":remote,"clean":True})
b=(json.dumps({"status":"PUBLISHED_SOURCE_COMPONENT","qualification":"Skill/board static checks passed; executable docs examples pending; no final pins/deploy claim.","sources":receipts},indent=2)+"\n").encode();(E/"result.original.json").write_bytes(b)
print(json.dumps({"path":str(E/"result.original.json"),"sha256":hashlib.sha256(b).hexdigest(),"sources":receipts}))
