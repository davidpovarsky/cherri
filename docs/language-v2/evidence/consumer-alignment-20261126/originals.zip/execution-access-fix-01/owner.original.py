from pathlib import Path
import os,json,subprocess,hashlib
base=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126")
E=base/"execution-access-fix-01";E.mkdir(exist_ok=False);(E/"owner.original.py").write_text(Path(__file__).read_text())
before={"mode":oct(base.stat().st_mode&0o777),"uid":base.stat().st_uid,"gid":base.stat().st_gid}
assert before=={"mode":"0o750","uid":0,"gid":1002}
os.chown(base,1001,1002)
B=Path("/mnt/development/projects/evidence/cherri-p10r15-final-completion-20261125/final-owned-phase0-original-01/products/cherri")
paths=[B,Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126/scripts/smoke_test_snippets.py")]
checks=[]
for p in paths:
 r=subprocess.run(["/usr/sbin/runuser","-u","ubuntu","--","test","-r",str(p)],capture_output=True)
 checks.append({"path":str(p),"readableByExecutionOwner":r.returncode==0})
receipt={"status":"ACCESS_CHECKED","baseBefore":before,"baseAfter":{"mode":oct(base.stat().st_mode&0o777),"uid":base.stat().st_uid,"gid":base.stat().st_gid},"change":"Owner of this task's evidence root only; mode/group unchanged, no other path altered. Failed first launch retained before CLI execution.","checks":checks}
b=(json.dumps(receipt,indent=2)+"\n").encode();(E/"result.original.json").write_bytes(b)
print(json.dumps({"path":str(E/"result.original.json"),"sha256":hashlib.sha256(b).hexdigest(),**receipt}))
