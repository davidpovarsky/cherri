import json,subprocess,hashlib,os
from pathlib import Path
W=Path("/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125")
P=W/"skills/cherri-shortcuts/SKILL.md"
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/static-validation-02")
E.mkdir(parents=True,exist_ok=False);(E/"owner.original.py").write_text(Path(__file__).read_text())
old=P.read_bytes();(E/"SKILL.before.original.md").write_bytes(old)
assert hashlib.sha256(old).hexdigest()=="0a129f247896229f630a1e7a9377cfe6995c77db8a89cdc72c63e2377a487a49"
lines=old.decode().splitlines()
assert lines[2].startswith("description: ")
lines[2]="description: Create, inspect, compile, sign, import, decompile and repair Apple Shortcuts with the real Cherri CLI. Use when building a Shortcut, editing an existing shared plist or unsigned .shortcut, translating requirements into Cherri, discovering actions or glyphs, diagnosing compiler errors, or preparing a signed deliverable. Includes the preserved-original import, edit, compare and sign workflow. Intended for Open Minis, iSH, Alpine or POSIX agent environments."
P.write_text("\n".join(lines)+"\n");os.chown(P,1001,1001)
validator=E.parent/"static-validation-01/quick_validate.original.py"
r=subprocess.run(["python3","-B",str(validator),str(P.parent)],capture_output=True,timeout=30)
(E/"stdout.original.bin").write_bytes(r.stdout);(E/"stderr.original.bin").write_bytes(r.stderr)
receipt={"status":"PASS" if r.returncode==0 else "FAIL","exitCode":r.returncode,"stdout":r.stdout.decode(),"stderr":r.stderr.decode(),"beforeSHA256":hashlib.sha256(old).hexdigest(),"afterSHA256":hashlib.sha256(P.read_bytes()).hexdigest(),"change":"Description only: remove inherited arrow characters, retain trigger/use scope. Prior validator failure retained unchanged.","validatorSHA256":hashlib.sha256(validator.read_bytes()).hexdigest()}
b=(json.dumps(receipt,indent=2)+"\n").encode();(E/"result.original.json").write_bytes(b)
print(json.dumps({"path":str(E/"result.original.json"),"sha256":hashlib.sha256(b).hexdigest(),**receipt}))
