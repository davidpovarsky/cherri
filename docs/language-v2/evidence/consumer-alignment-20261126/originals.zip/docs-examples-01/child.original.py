import os,sys,json,hashlib,importlib.util,subprocess,shutil,datetime
from pathlib import Path
sys.dont_write_bytecode=True
E=Path(sys.argv[1]);D=Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126")
B=Path("/mnt/development/projects/evidence/cherri-p10r15-final-completion-20261125/final-owned-phase0-original-01/products/cherri")
SOURCE="5f8acea50fec1249390b5aed6db6b073c43d1173";DOCS="5e8e738f0b2edb926a2069e042660ef1bbb8e8d4"
BINARY_SHA="b96cba956e2ec5a9c79ad14fba821d64b796b9ade38c4998f10268fcf46617db"
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(["git","-C",str(D),*a],text=True).strip()
assert git("rev-parse","HEAD")==DOCS
assert not git("status","--porcelain","--untracked-files=all")
assert sha(B)==BINARY_SHA
(E/"tmp").mkdir();os.environ["TMPDIR"]=str(E/"tmp")
import tempfile
tempfile.tempdir=str(E/"tmp")
p=D/"scripts/smoke_test_snippets.py";spec=importlib.util.spec_from_file_location("docs_smoke_original",p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
targets=["index.md","fork-language/guide.md","fork-language/migration.md","fork-language/actions.md","language/functions.md","language/variables-constants-globals.md"]
sources={p.relative_to(D).as_posix():sha(p) for p in [D/t for t in targets]+[D/"scripts/smoke_test_snippets.py"]}
inventory=[]
for rel in targets:
 p=D/rel;data=p.read_text();generated=p.name=="actions.md" and p.parent.name=="fork-language"
 if generated:assert "generated automatically from the canonical Cherri v2 ActionSchema registry" in data
 for index,match in enumerate(m.FENCES.finditer(data),1):
  code=match["code"].strip();kind=match["kind"];assert code
  reference=generated or kind in ("cherri-legacy","cherri-fragment")
  expected=[]
  if not reference:
   assert kind=="cherri"
   annotation=m.EXPECTATION.search(data[:match.start()])
   if annotation:
    fields=annotation[1].split();assert len(fields)>=2 and fields[0]=="diagnostic" and all(m.re.fullmatch(r"E_[A-Z0-9_]+",x) for x in fields[1:])
    expected=fields[1:]
  inventory.append({"id":rel+"::"+str(index),"file":rel,"block":index,"classification":"generated-signature" if generated else kind if reference else "diagnostic" if expected else "runnable","code":code,"expectedErrors":expected,"executed":not reference,"sourceSHA256":hashlib.sha256((code+"\n").encode()).hexdigest()})
oldcodes=[]
for rel in targets:
 old=git("show","428f067090bf54f4d2f214c36951689dd599d153:"+rel)
 oldcodes.extend(match["code"].strip() for match in m.FENCES.finditer(old))
from collections import Counter
assert not (Counter(oldcodes)-Counter(x["code"] for x in inventory)), "An original D16 fence was dropped/changed"
selection={"schema":"docs-existing-cli-examples/1","docsCommit":DOCS,"compilerCommit":SOURCE,"binary":str(B),"binarySHA256":BINARY_SHA,"originalSmokeSHA256":sha(D/"scripts/smoke_test_snippets.py"),"unchangedReleasePin":m.PINNED_CHERRI_COMMIT,"targets":targets,"sourceFiles":sources,"originalD16FencesPreserved":len(oldcodes),"inventory":inventory,"scope":"Actual original check_example helper with independently supplied source-hash-verified5f8 binary. Does not invoke/override cache authentication, change release pins, regenerate reference, publish site or execute Apple."}
(E/"selection.original.json").write_text(json.dumps(selection,indent=2)+"\n")
for rel in sources:
 dst=E/"source"/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((D/rel).read_bytes())
original=m.command;current=E/"metadata";current.mkdir();seq=0
def recording(args,*,cwd=None,check=True):
 global seq
 if not args or args[0]!=str(B):raise RuntimeError("Only the exact supplied compiler is permitted")
 seq+=1;stem=current/f"command-{seq:03}"
 (Path(str(stem)+".argv.original.json")).write_text(json.dumps({"argv":args,"cwd":str(cwd) if cwd else None})+"\n")
 try:r=original(args,cwd=cwd,check=check)
 except BaseException as err:
  Path(str(stem)+".error.original.txt").write_text(repr(err)+"\n");raise
 Path(str(stem)+".stdout.utf8.txt").write_text(r.stdout,encoding="utf-8")
 Path(str(stem)+".stderr.utf8.txt").write_text(r.stderr,encoding="utf-8")
 Path(str(stem)+".status.original.json").write_text(json.dumps({"exitCode":r.returncode,"originalTextCapture":"UTF-8 errors=replace, unchanged smoke.command"})+"\n")
 if cwd:
  root=Path(cwd);out=current/f"command-{seq:03}.products";out.mkdir()
  for name in ["snippet.cherri","snippet_unsigned.shortcut"]:
   path=root/name
   if path.exists():
    assert path.is_file() and not path.is_symlink()
    shutil.copyfile(path,out/name)
 return r
m.command=recording
cap=recording([str(B),"--capabilities-json"],check=False)
assert cap.returncode==0
json.loads(cap.stdout)
records=[]
for item in inventory:
 if not item["executed"]:
  records.append({k:v for k,v in item.items() if k!="code"});continue
 current=E/"cases"/(item["file"].replace("/","__")+"__"+str(item["block"]))
 current.mkdir(parents=True)
 (current/"source.original.cherri").write_text(item["code"]+"\n")
 ok,detail,record=m.check_example(str(B),item["code"],tuple(item["expectedErrors"]))
 record.update({k:v for k,v in item.items() if k!="code"});record.update(passed=ok,detail=detail)
 (current/"result.original.json").write_text(json.dumps(record,indent=2)+"\n")
 records.append(record);print(json.dumps({"id":item["id"],"passed":ok,"detail":detail}),flush=True)
assert {rel:sha(D/rel) for rel in sources}==sources
assert git("rev-parse","HEAD")==DOCS and not git("status","--porcelain","--untracked-files=all")
assert sha(B)==BINARY_SHA
ran=[x for x in records if x["executed"]]
summary={"status":"PASS" if all(x["passed"] for x in ran) else "FAIL","compilerCommit":SOURCE,"docsCommit":DOCS,"binarySHA256":BINARY_SHA,"originalSmokeSHA256":sha(D/"scripts/smoke_test_snippets.py"),"executed":len(ran),"passed":sum(x["passed"] for x in ran),"failed":sum(not x["passed"] for x in ran),"runnable":sum(x["classification"]=="runnable" for x in ran),"diagnostic":sum(x["classification"]=="diagnostic" for x in ran),"referenceOnly":len(records)-len(ran),"records":records,"sourceUnchanged":True,"scope":selection["scope"]}
(E/"result.child.original.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({k:v for k,v in summary.items() if k!="records"}),flush=True)
sys.exit(0 if summary["status"]=="PASS" else 1)
