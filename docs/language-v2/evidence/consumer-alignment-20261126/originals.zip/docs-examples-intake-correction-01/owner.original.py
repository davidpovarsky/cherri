import json,subprocess,hashlib
from pathlib import Path
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126")
F=E/"docs-examples-independent-intake-01"
raw=json.loads("{\"ok\":false,\"interpreter\":\"python3\",\"sudo\":false,\"cwd\":null,\"cleanup\":true,\"command\":[\"python3\",\"/var/lib/sentinelx/uploads/.sentinelx_uploads/script_job_43af312ee7ef457a960b2bf9f2c98a45/docs_examples_independent_intake01.py\"],\"output\":\"Traceback (most recent call last):\\n  File \\\"/var/lib/sentinelx/uploads/.sentinelx_uploads/script_job_43af312ee7ef457a960b2bf9f2c98a45/docs_examples_independent_intake01.py\\\", line 31, in <module>\\n    errors=[d.get(\\\"code\\\") for d in checked.get(\\\"diagnostics\\\",[]) if d.get(\\\"severity\\\")==\\\"ERROR\\\"]\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\nTypeError: 'NoneType' object is not iterable\",\"duration\":0.21,\"returncode\":1,\"hub_request_id\":\"hreq_9dcb249ff0ee4533\"}")
(F/"sentinel-result.original.json").write_text(json.dumps(raw,indent=2)+"\n")
src=(F/"owner.original.py").read_text()
needle='checked.get("diagnostics",[])'
assert src.count(needle)==1
fix=src.replace("docs-examples-independent-intake-01","docs-examples-independent-intake-02").replace(needle,'(checked.get("diagnostics") or [])')
P=E/"docs-examples-intake-correction-01";P.mkdir(exist_ok=False)
(P/"owner.original.py").write_text(Path(__file__).read_text())
(P/"intake02.submitted.original.py").write_text(fix)
(P/"correction.original.json").write_text(json.dumps({"scope":"Independent intake only. The original CLI uses JSON null for an empty diagnostic list; match that explicit valid empty-list case. All original46 executions/source/products unchanged; no rerun.","failedOwnerSHA256":hashlib.sha256(src.encode()).hexdigest(),"newOwnerSHA256":hashlib.sha256(fix.encode()).hexdigest(),"originalSentinelStatus":raw.get("returncode")},indent=2)+"\n")
r=subprocess.run(["python3","-B",str(P/"intake02.submitted.original.py")],capture_output=True,timeout=50)
(P/"stdout.original.bin").write_bytes(r.stdout);(P/"stderr.original.bin").write_bytes(r.stderr)
print(json.dumps({"exitCode":r.returncode,"stdout":r.stdout.decode(),"stderr":r.stderr.decode()}))
