import json,hashlib,plistlib,re,subprocess,collections,os,datetime
from pathlib import Path
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126")
R=E/"docs-examples-02";O=E/"docs-examples-independent-intake-02";O.mkdir(exist_ok=False);(O/"owner.original.py").write_text(Path(__file__).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(R/"result.original.json")=="4fcf8710175c0b0c4adf3b48a97599ff6d6d8a7382c6eb0e59ccd2620266f4f0"
owner=json.loads((R/"result.original.json").read_text());result=json.loads((R/"result.child.original.json").read_text());selection=json.loads((R/"selection.original.json").read_text())
assert owner["status"]=="PASS" and owner["exitCode"]==0 and owner["groupGone"] and owner["aborted"] is None
assert sha(R/"result.child.original.json")==owner["childResultSHA256"]
assert result["status"]=="PASS" and result["failed"]==0 and result["executed"]==46 and result["passed"]==46
assert result["compilerCommit"]=="5f8acea50fec1249390b5aed6db6b073c43d1173" and result["docsCommit"]=="5e8e738f0b2edb926a2069e042660ef1bbb8e8d4"
assert len({x["id"] for x in selection["inventory"]})==len(selection["inventory"])
actual={x["id"]:x for x in result["records"]};assert len(actual)==len(result["records"])==len(selection["inventory"])
refs=0;passed=[];commands=0
for expected in selection["inventory"]:
 record=actual[expected["id"]]
 for k in ["file","block","classification","executed","expectedErrors","sourceSHA256"]:assert record[k]==expected[k]
 if not expected["executed"]:
  refs+=1;continue
 case=R/"cases"/(expected["file"].replace("/","__")+"__"+str(expected["block"]))
 assert (case/"source.original.cherri").read_text()==expected["code"]+"\n"
 assert sha(case/"source.original.cherri")==record["sourceSHA256"]==record["sourceSha256"]
 assert json.loads((case/"result.original.json").read_text())==record
 statuses=sorted(case.glob("command-*.status.original.json"));assert len(statuses)==2
 check_st,compile_st=[json.loads(p.read_text()) for p in statuses]
 stems=[str(p).removesuffix(".status.original.json") for p in statuses]
 args=[json.loads(Path(s+".argv.original.json").read_text())["argv"] for s in stems]
 assert args[0][0]==selection["binary"] and args[0][1]=="check" and args[0][-2:]==["--json","--no-ansi"]
 assert args[1][0]==selection["binary"] and args[1][-2:]==["--skip-sign","--no-ansi"]
 checked=json.loads(Path(stems[0]+".stdout.utf8.txt").read_text())
 errors=[d.get("code") for d in (checked.get("diagnostics") or []) if d.get("severity")=="ERROR"]
 assert errors==expected["expectedErrors"]==record["actualErrors"]
 for stem in stems:
  source=Path(stem+".products")/"snippet.cherri";assert sha(source)==record["sourceSha256"]
 output=Path(stems[1]+".products")/"snippet_unsigned.shortcut"
 if expected["expectedErrors"]:
  assert checked["valid"] is False and check_st["exitCode"]!=0 and compile_st["exitCode"]!=0 and not output.exists()
  assert "unsignedSha256" not in record
 else:
  assert checked["valid"] is True and check_st["exitCode"]==compile_st["exitCode"]==0
  doc=plistlib.loads(output.read_bytes());assert isinstance(doc,dict) and isinstance(doc["WFWorkflowActions"],list)
  assert len(doc["WFWorkflowActions"])==record["actionCount"] and sha(output)==record["unsignedSha256"]
  for action in doc["WFWorkflowActions"]:assert isinstance(action,dict) and isinstance(action.get("WFWorkflowActionIdentifier"),str)
 passed.append({"id":expected["id"],"sourceSHA256":record["sourceSha256"],"classification":record["classification"],"unsignedSHA256":record.get("unsignedSha256"),"actionCount":record.get("actionCount")});commands+=2
assert refs==524 and commands==92
for rel,expected in selection["sourceFiles"].items():assert sha(R/"source"/rel)==expected
assert selection["unchangedReleasePin"]=="627c3e7eb4a54a0364b5a5563db89291fa953b97"
caps=json.loads((R/"metadata/command-001.stdout.utf8.txt").read_text())
assert caps["actionCount"]==505 and len(caps["compilerMacros"])==16
# Independent source classification repeats only the original regex/annotation grammar.
fence=re.compile(r"^"+re.escape(chr(96)*3)+r"(?P<kind>cherri(?:-[a-z]+)?)\s*\r?\n(?P<code>.*?)^"+re.escape(chr(96)*3)+r"\s*$",re.M|re.S)
D=Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126")
old=[];new=[]
for rel in selection["targets"]:
 raw=subprocess.check_output(["/usr/sbin/runuser","-u","ubuntu","--","git","-C",str(D),"show","428f067090bf54f4d2f214c36951689dd599d153:"+rel],text=True)
 old.extend(m["code"].strip() for m in fence.finditer(raw))
 new.extend(m["code"].strip() for m in fence.finditer((R/"source"/rel).read_text()))
assert not(collections.Counter(old)-collections.Counter(new)) and len(new)-len(old)==6
receipt={"schema":"cherri-docs-examples-independent-intake/1","status":"PASS","createdAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":{"compiler":result["compilerCommit"],"docs":result["docsCommit"],"binarySHA256":result["binarySHA256"],"smokeSHA256":result["originalSmokeSHA256"]},"ownerSHA256":sha(R/"result.original.json"),"childSHA256":sha(R/"result.child.original.json"),"selectionSHA256":sha(R/"selection.original.json"),"executed":46,"runnableNativePlists":43,"exactDiagnosticRejections":3,"actualCLICommands":92,"referenceOnly":524,"originalD16FencesPreserved":len(old),"newExecutableExamples":6,"actualMacroCount":16,"passed":passed,"scope":"Independent source/stream/native-plist intake of the actual original check_example executions. No final pin/cache/generation/site/signing/native/full-acceptance credit."}
b=(json.dumps(receipt,indent=2)+"\n").encode();(O/"result.original.json").write_bytes(b)
print(json.dumps({"path":str(O/"result.original.json"),"sha256":hashlib.sha256(b).hexdigest(),**{k:v for k,v in receipt.items() if k!="passed"}}))
