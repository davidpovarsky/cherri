# Open Minis / iSH Reference

Open Minis stores imported skill files in the Linux sandbox under:

`/var/minis/skills/cherri-shortcuts/`

Its GitHub skill importer downloads `SKILL.md` plus sibling files recursively, so importing the GitHub URL for this skill installs `scripts/`, `references/`, and metadata together. Archive import also preserves bundled files.

## Install from GitHub

Import the URL pointing to this skill's `SKILL.md` in the Open Minis Skills UI. For the development branch, use the branch URL; after merge, prefer the `main` URL.

Then run:

```sh
sh /var/minis/skills/cherri-shortcuts/scripts/setup.sh
```

## Ready-made ARM64 ZIP

The repository's `OpenMinis Skill` GitHub Action builds the Linux/ARM64 Cherri compiler and `cherri-migrate` companion from the same pinned source and includes both in the ready-to-import ZIP. When that ZIP is imported from Files, `setup.sh` validates the bundled pair and avoids installing Go or compiling Cherri on the device.

Because archive import may not preserve executable mode, invoke skill scripts with `sh ...` and let `setup.sh` apply `chmod +x` to the bundled compiler.

## Persistent state

Default runtime state:

- Compiler/source cache: `/var/minis/cherri/`
- Compiler: `/var/minis/cherri/bin/cherri`
- Migration companion: `/var/minis/cherri/bin/cherri-migrate`
- Upstream docs checkout: `/var/minis/cherri/docs/`

Override with environment variables:

- `CHERRI_HOME`
- `CHERRI_BIN`
- `CHERRI_MIGRATE_BIN`
- `CHERRI_REPO`
- `CHERRI_REF`
- `CHERRI_DOCS_REPO`
- `CHERRI_DOCS_REF`
- `CHERRI_DOCS_DIR`
- `CHERRI_PREBUILT_URL`
- `CHERRI_PREBUILT_SHA256` (required expected SHA-256 when using a prebuilt URL)

Setup requires exact 40-digit compiler and docs commit IDs. It verifies prebuilt downloads before executing them. Both the compiler and migration companion require matching source-commit and SHA-256 receipts, their expected tool roles, and the same clean embedded source revision. Cached tools with missing or stale receipts are rejected; ordinary setup can build or download a verified replacement. Capability compatibility alone does not authenticate an installed tool pair.

Updates stage and validate the compiler and pinned docs before replacing the active pair. Command failures during replacement restore the preceding files; local changes in managed source/docs and unmanaged docs directories are preserved and reported. This rollback protects ordinary update failures and handled signals, but does not claim atomic visibility to concurrent readers or recovery from power loss. An interrupted install that cannot restore its backups retains them with its install lock for recovery.

## Editing an existing Shortcut from a shared plist

The user's iOS helper Shortcut extracts and shares a workflow plist (XML
plist, binary plist, or unsigned `.shortcut` containing a workflow plist).
This is a first-class workflow of the skill:

```text
plist received from iOS helper Shortcut
        -> prepare-edit.sh <path> [WORKSPACE]
        -> preserved original + editable .cherri + unsigned validation build
        -> agent edits the .cherri per the user request
        -> unsigned compile (validate)
        -> explicit sign -> AEA1 .shortcut
```

`prepare-edit.sh` lives in `scripts/`. It creates
`/var/minis/shared/cherri-edits/<safe-name>-<timestamp>/` with
`original/`, `source/`, and `builds/` subdirectories, never modifies the
input, rejects signed `AEA1` input with a clear diagnostic (direct signed
extraction is not supported yet — use the extractor Shortcut / iCloud-link
workflow to provide a plist), and proves the decompiled source recompiles
before reporting readiness. It never signs.

Input contract:

- Supported: XML plist, binary plist, unsigned `.shortcut` (workflow plist).
  The plist is the source of truth.
- Optional: a JSON companion is only an inspection/debugging aid or metadata
  companion — never required, never the source of truth.
- Unsupported direct: signed `AEA1` Shortcut wrappers (clear early
  diagnostic; do not feed AEA1 bytes to the plist import).
- iCloud links remain supported through `decompile.sh` for read-only
  inspection; the plist-based edit workflow is preferred for editing.

The agent receives the shared file as an explicit path (attached/shared file
or a file under the Open Minis shared workspace) and passes that exact path
to `prepare-edit.sh`. Do not rely on "latest file in directory" discovery as
the primary behavior.

## Limitations


- macOS native `shortcuts sign` is unavailable; the default signed path uses Cherri's remote signing service (Shortcuty Sign / HubSign).
- The macOS Shortcuts Toolkit SQLite database is not automatically available inside iSH. Decompile uses `--no-toolkit` by default. A user-supplied Toolkit DB can be used manually with Cherri's `--toolkit` option.
- Third-party app actions depend on Cherri definitions, packages, raw actions, or a supplied Toolkit database.
- Network is required for first source setup/docs cloning, package installation, Git packages, iCloud imports, and remote signing.

## Package provenance and verification

Ready-to-import packages contain the compiler and migration companion from the
immutable compilerCommit in compatibility-manifest.json. The ZIP includes source
commit and SHA-256 receipts for both tools, plus a package-manifest.json inventory
of committed Skill files, source commit, docs pin and runtime platform. The
source-only ZIP contains neither executable.

The release workflow verifies ZIP bytes against the committed Git tree and
trusted compiler build, then runs the existing self-test from the unpacked ARM64
package. A current development compiler cannot be packaged under a different
manifest pin merely because its language/schema capabilities happen to match.

The wrapper self-test report distinguishes actual compile/decompile/prepare-edit
checks from its ten mock installation scenarios. Dedicated acceptance producers
cover package integrity and real installation failures; a wrapper smoke result
does not claim signing, published docs or broader roadmap completion.
