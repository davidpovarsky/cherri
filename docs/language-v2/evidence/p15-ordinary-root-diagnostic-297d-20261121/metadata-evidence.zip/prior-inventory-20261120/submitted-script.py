import pathlib,subprocess,json,hashlib,datetime,time,shutil,os,re
r=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-local-gates-integration-20261120")
source="297d5a657885ec2144f7366be1bcf721a0032a47"
def git(*a):return subprocess.check_output(["git","--no-replace-objects",*a],cwd=r,timeout=25).decode().strip()
assert git("rev-parse","HEAD")==source and not git("status","--porcelain")
out=r/"dist/p15-root-diagnostic-20261120/inventory-297d5a65";out.mkdir(parents=True,exist_ok=False)
(out/"submitted-script.py").write_bytes(pathlib.Path(__file__).read_bytes())
command=["go","test","-list","^Test","."]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic();free=shutil.disk_usage(r).free;timeout=False
with (out/"stdout.txt").open("wb") as stdout,(out/"stderr.txt").open("wb") as stderr:
 p=subprocess.Popen(command,cwd=r,stdout=stdout,stderr=stderr,env=os.environ.copy())
 try:p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  timeout=True;subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=20);p.wait(timeout=20)
elapsed=time.monotonic()-clock;raw=(out/"stdout.txt").read_bytes();errors=(out/"stderr.txt").read_bytes()
lines=raw.decode("utf-8",errors="strict").splitlines();names=[s for s in lines if re.fullmatch(r"Test[A-Za-z0-9_]+",s)]
record={"source":source,"source_clean_before":True,"source_clean_after":git("rev-parse","HEAD")==source and not git("status","--porcelain"),"kind":"inventory-only-no-test-execution","command":command,"started_at":start,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":elapsed,"exit_code":p.returncode,"timed_out":timeout,"stdout_bytes":len(raw),"stdout_sha256":hashlib.sha256(raw).hexdigest(),"stderr_bytes":len(errors),"stderr_sha256":hashlib.sha256(errors).hexdigest(),"test_names":names,"test_count":len(names),"unclassified_lines":[s for s in lines if s not in names],"free_bytes_before":free,"free_bytes_after":shutil.disk_usage(r).free}
(out/"receipt.json").write_bytes((json.dumps(record,indent=2)+"\n").encode())
scenario=(r/"tools/language-acceptance/packaged_skill_execution.go").read_text(encoding="utf-8")
begin=scenario.index("var packagedSkillScenarios") if "var packagedSkillScenarios" in scenario else 0
print(json.dumps({"receipt":str(out/"receipt.json"),**{k:v for k,v in record.items() if k!="test_names"},"rp4_names":[n for n in names if re.match(r"TestP15RP4[245]",n)],"scenario_excerpt":scenario[begin:begin+6500],"stderr_tail":errors.decode("utf-8","replace")[-3000:]}))
