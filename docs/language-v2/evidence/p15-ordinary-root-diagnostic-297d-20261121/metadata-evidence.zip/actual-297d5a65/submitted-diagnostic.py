from pathlib import Path
import subprocess,json,hashlib,datetime,time,collections,shutil,os,re
w=Path(r"C:\Users\DAVID\Code\cherri-p10r15-ordinary-root-diagnostic-297d5a65-20261121")
e=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-ordinary-root-diagnostic-297d5a65-20261121")
source="297d5a657885ec2144f7366be1bcf721a0032a47"
scope_raw=(e/"scope.json").read_bytes();scope=json.loads(scope_raw)
assert scope["sourceSha"]==source and scope["exactDisjointUnion"]
included=scope["included"];excluded=scope["excluded"]
assert len(included)==len(set(included))==1074 and len(excluded)==len(set(excluded))==15
assert not set(included)&set(excluded)
cmd=["go","test","-count=1","-json","-timeout=15m",".","-run","^Test","-skip","^("+"|".join(excluded)+")$"]
assert cmd==scope["command"]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
 p=subprocess.run(["git",*args],cwd=w,capture_output=True,text=True,encoding="utf-8",timeout=20)
 if p.returncode:raise RuntimeError(json.dumps({"args":args,"exit":p.returncode,"stderr":p.stderr}))
 return p.stdout
assert git("rev-parse","HEAD").strip()==source
assert git("status","--porcelain=v1")==""
assert shutil.disk_usage(w).free>3*1024**3
run=e/"actual-297d5a65";run.mkdir()
(run/"submitted-diagnostic.py").write_bytes(Path(__file__).read_bytes())
reservation={"sourceSha":source,"command":cmd,"cwd":str(w),"sourceCleanBefore":True,"scopeSha256":hashlib.sha256(scope_raw).hexdigest(),"reservedAtUtc":utc(),"testTimeoutSeconds":900,"processTimeoutSeconds":1080,"freeBytesBefore":shutil.disk_usage(w).free}
(run/"reservation.json").write_text(json.dumps(reservation,indent=2)+"\n",encoding="utf-8")
started=time.monotonic();outer_timeout=False;kill_result=None
with (run/"go.original.jsonl").open("xb") as out,(run/"stderr.original.bin").open("xb") as err:
 process=subprocess.Popen(cmd,cwd=w,stdout=out,stderr=err)
 start={**reservation,"pid":process.pid,"startedAtUtc":utc()}
 (run/"start.json").write_text(json.dumps(start,indent=2)+"\n",encoding="utf-8")
 print(json.dumps({"started":True,"pid":process.pid,"sourceSha":source,"evidenceRoot":str(run)}),flush=True)
 try:exit_code=process.wait(timeout=1080)
 except subprocess.TimeoutExpired:
  outer_timeout=True
  q=subprocess.run(["taskkill","/PID",str(process.pid),"/T","/F"],capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=20)
  kill_result={"exitCode":q.returncode,"stdout":q.stdout,"stderr":q.stderr}
  try:exit_code=process.wait(timeout=15)
  except subprocess.TimeoutExpired:exit_code=None
finished=utc();elapsed=time.monotonic()-started
raw=(run/"go.original.jsonl").read_bytes();stderr=(run/"stderr.original.bin").read_bytes()
events=[];parse_errors=[]
for number,line in enumerate(raw.splitlines(),1):
 try:
  event=json.loads(line.decode("utf-8"))
  if not isinstance(event,dict):raise ValueError("event is not object")
  events.append(event)
 except Exception as ex:parse_errors.append({"line":number,"error":str(ex),"lineSha256":hashlib.sha256(line).hexdigest()})
package="github.com/electrikmilk/cherri"
root_events=[x for x in events if x.get("Package")==package]
starts=[x["Test"] for x in root_events if x.get("Action")=="run" and isinstance(x.get("Test"),str) and "/" not in x["Test"]]
terminals=[x for x in root_events if x.get("Action") in ["pass","fail","skip"] and isinstance(x.get("Test"),str) and "/" not in x["Test"]]
terminal_names=[x["Test"] for x in terminals]
started_counts=collections.Counter(starts);terminal_counts=collections.Counter(terminal_names)
failed_tests=[{"test":x["Test"],"elapsed":x.get("Elapsed"),"time":x.get("Time")} for x in root_events if x.get("Action")=="fail" and "Test" in x]
output_by_test=collections.defaultdict(list)
for x in root_events:
 if x.get("Action")=="output" and isinstance(x.get("Output"),str):
  output_by_test[x.get("Test","")].append(x["Output"])
failed_parents=[x["Test"] for x in terminals if x["Action"]=="fail"]
incomplete=sorted(set(starts)-set(terminal_names))
failure_details={}
for name in failed_parents+incomplete:
 failure_details[name]="".join(s for test,lines in output_by_test.items() if test==name or test.startswith(name+"/") for s in lines)
(run/"failure-details.json").write_text(json.dumps(failure_details,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
accounting={"schemaVersion":1,"sourceSha":source,"expectedIncludedCount":len(included),"expectedExcludedCount":len(excluded),"startedParents":starts,"terminalParents":[{"name":x["Test"],"status":x["Action"],"elapsed":x.get("Elapsed"),"time":x.get("Time")} for x in terminals],"parentCounts":dict(collections.Counter(x["Action"] for x in terminals)),"unstartedIncludedParents":sorted(set(included)-set(starts)),"incompleteParents":incomplete,"unexpectedParents":sorted((set(starts)|set(terminal_names))-set(included)),"excludedStarted":sorted(set(excluded)&set(starts)),"orphanTerminalParents":sorted(set(terminal_names)-set(starts)),"duplicateParentRuns":{k:v for k,v in started_counts.items() if v!=1},"duplicateParentTerminals":{k:v for k,v in terminal_counts.items() if v!=1},"allNamedFailures":failed_tests,"allEventActionCounts":dict(collections.Counter(x.get("Action","") for x in root_events)),"packageEvents":[x for x in root_events if "Test" not in x and x.get("Action") in ["start","pass","fail","skip"]],"foreignPackages":sorted({x.get("Package","") for x in events}-{package}),"parseErrors":parse_errors,"timeoutOutput":[x["Output"] for x in root_events if x.get("Action")=="output" and ("panic: test timed out" in x.get("Output","") or "running tests:" in x.get("Output",""))],"formalAcceptanceGranted":False}
(run/"event-accounting.json").write_text(json.dumps(accounting,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
state_after=git("status","--porcelain=v1");head_after=git("rev-parse","HEAD").strip()
record={**start,"finishedAtUtc":finished,"elapsedSeconds":round(elapsed,3),"exitCode":exit_code,"outerTimedOut":outer_timeout,"ownedProcessKill":kill_result,"sourceShaAfter":head_after,"sourceCleanAfter":state_after=="","sourceStatusAfter":state_after,"freeBytesAfter":shutil.disk_usage(w).free,"goBytes":len(raw),"goSha256":hashlib.sha256(raw).hexdigest(),"stderrBytes":len(stderr),"stderrSha256":hashlib.sha256(stderr).hexdigest(),"events":len(events),"parseErrorCount":len(parse_errors),"includedCount":len(included),"excludedCount":len(excluded),"startedParentCount":len(starts),"terminalParentCount":len(terminals),"parentCounts":accounting["parentCounts"],"unstartedParentCount":len(accounting["unstartedIncludedParents"]),"incompleteParents":incomplete,"unexpectedParents":accounting["unexpectedParents"],"excludedStarted":accounting["excludedStarted"],"failedParents":failed_parents,"packageEvents":accounting["packageEvents"],"formalAcceptanceGranted":False}
(run/"receipt.json").write_text(json.dumps(record,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps(record,indent=2,ensure_ascii=False),flush=True)
