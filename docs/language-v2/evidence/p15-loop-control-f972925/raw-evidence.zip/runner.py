import pathlib,subprocess,json,os,hashlib,time
base=pathlib.Path(r"C:\Users\DAVID\Code");repo=base/"cherri-p10r15-loop-control-20261119"
source=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip();assert source.startswith("f972925")
def snap():return {"source":subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip(),"status":subprocess.check_output(["git","status","--porcelain"],cwd=repo,text=True)}
before=snap();assert before["status"]==""
out=base/"cherri-p10r15-evidence-20261119"/("loop-control-"+source[:7]);out.mkdir()
(out/"runner.py").write_bytes(pathlib.Path(__file__).read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith("CHERRI")};env.update({"GOMAXPROCS":"1","GOFLAGS":"-p=1"})
cmd=[r"C:\Program Files\Go\bin\go.exe","test","./tools/language-acceptance","-count=1","-json","-timeout=150s","-run","^(TestLoopControlProductionEvidence|TestLoopControlEvidenceRejectsIncompleteSelection)$"]
log=out/"clean.jsonl";start=time.monotonic();timed=False
with log.open("wb") as f:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 try:code=p.wait(timeout=200)
 except subprocess.TimeoutExpired:
  timed=True;subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30);code=p.wait(timeout=30)
events=[]
for line in log.read_text(encoding="utf-8",errors="replace").splitlines():
 try:events.append(json.loads(line))
 except json.JSONDecodeError:pass
counts={a:sum(1 for e in events if e.get("Action")==a and e.get("Test")) for a in ["run","pass","fail","skip"]}
summary={"source":source,"before":before,"after":snap(),"command":cmd,"seconds":round(time.monotonic()-start,3),"exit":code,"timedOut":timed,"counts":counts,"sha256":hashlib.sha256(log.read_bytes()).hexdigest(),"bytes":log.stat().st_size}
(out/"summary.json").write_bytes((json.dumps(summary,indent=2)+"\n").encode());print(json.dumps(summary))
assert code==0 and not timed and summary["before"]==summary["after"] and counts["pass"]>0 and counts["fail"]==0 and counts["skip"]==0
