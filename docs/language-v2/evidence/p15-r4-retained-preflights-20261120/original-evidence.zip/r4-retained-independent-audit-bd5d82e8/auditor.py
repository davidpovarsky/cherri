import pathlib,subprocess,json,hashlib,datetime,collections
code=pathlib.Path(r"C:\Users\DAVID\Code")
e=code/"cherri-p10r15-continuation-evidence-20261119"
root=code/"cherri-p10r15-completion-r4-20261120"
p=e/"r4-retained-preflight-bd5d82e8"
out=e/"r4-retained-independent-audit-bd5d82e8";out.mkdir(exist_ok=True)
source="bd5d82e82828ca1cd0c27981705969c245e85306"
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding="utf-8"))
def events(p):return [json.loads(l) for l in p.read_bytes().splitlines() if l]
def git(*args,input=None):
 r=subprocess.run(["git","--no-replace-objects",*args],cwd=root,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 assert r.returncode==0,r.stderr.decode("utf-8","replace")
 return r.stdout
assert git("rev-parse","HEAD").decode().strip()==source
assert not git("status","--porcelain=v1").strip()
stages=[]
for label,count in [("optional-and-list-root",414),("optional-packages",76),("retained-strict-producers",1189)]:
 proc=read(p/(label+"-process-original.json"));rawpath=p/(label+"-original.jsonl");raw=rawpath.read_bytes();ev=events(rawpath)
 assert proc["sourceCommit"]==source and proc["cleanBefore"] and proc["cleanAfter"] and proc["exitCode"]==0 and not proc["outerTimedOut"]
 assert sha(raw)==proc["rawSha256"] and len(raw)==proc["rawBytes"]
 passed=[(x.get("Package"),x["Test"]) for x in ev if x.get("Test") and x.get("Action")=="pass"]
 assert len(passed)==len(set(passed))==proc["counts"]["pass"]==count
 assert not [x for x in ev if x.get("Action") in ["fail","skip"]]
 assert proc["counts"]["fail"]==proc["counts"]["skip"]==0
 stages.append({k:v for k,v in proc.items() if k!="tests"})
outer=events(p/"retained-strict-producers-original.jsonl")
parents={"RP11":"TestNumberWireActualProductionEvidence","RP16":"TestExhaustiveNodeActualProductionEvidence","U01":"TestUpstreamBoundaryActualProductionEvidence","RP33":"TestStructuralMigrationActualProductionEvidence","BRG19":"TestSafeImportEditActualProductionEvidence"}
records=[];children=[];source_requirements={}
for req,parent in parents.items():
 assert any(x.get("Test")==parent and x.get("Action")=="pass" for x in outer),parent
 text="".join(x.get("Output","") for x in outer if x.get("Test")==parent)
 receipts=[json.loads(line.split("PRODUCTION_RECEIPT:",1)[1]) for line in text.splitlines() if "PRODUCTION_RECEIPT:" in line]
 assert len(receipts)==1,(parent,len(receipts));receipt=receipts[0]
 assert receipt["source_sha"]==source
 assert len(receipt["records"])==(1 if req=="U01" else 2)
 for record in receipt["records"]:
  assert record["requirements"]==[req] and record["implementation_sha"]==source and record["exit_code"]==0 and record["result"]=="passed"
  for a in record["artifacts"]:
   actual=pathlib.Path(a["path"]);assert actual.is_relative_to(p)
   assert sha(actual.read_bytes())==a["sha256"],a["path"]
  records.append({"requirement":req,"tier":record["tier"],"testId":record["test_id"],"artifactReferences":len(record["artifacts"])})
 procfiles=list((p/(req.lower()+"-child")).glob("*/*-process.json"));assert len(procfiles)==1,(req,len(procfiles))
 procpath=procfiles[0];proc=read(procpath);rawpath=procpath.with_name(req.lower()+"-go.jsonl");stderrpath=procpath.with_name(req.lower()+"-stderr.log")
 raw=rawpath.read_bytes();stderr=stderrpath.read_bytes();ev=events(rawpath)
 assert proc["requirement"]==req and proc["source_commit"]==source and proc["source_clean_before"] and proc["source_clean_after"]
 assert proc["exit_code"]==0 and proc["timed_out"] is False and sha(raw)==proc["raw_sha256"] and len(raw)==proc["raw_bytes"]
 assert sha(stderr)==proc["stderr_sha256"] and len(stderr)==proc["stderr_bytes"]==0
 passed=[x["Test"] for x in ev if x.get("Test") and x.get("Action")=="pass"]
 assert len(passed)==len(set(passed)) and set(passed)==set(proc["required_tests"])==set(proc["discovered_tests"])
 assert not [x for x in ev if x.get("Action") in ["fail","skip"]]
 assert len([x for x in ev if x.get("Action")=="pass" and not x.get("Test")])==1
 start=datetime.datetime.fromisoformat(proc["started_utc"].replace("Z","+00:00"));finish=datetime.datetime.fromisoformat(proc["finished_utc"].replace("Z","+00:00"))
 assert 0 < (finish-start).total_seconds() < 240
 for x in ev:
  if x.get("Time"):
   when=datetime.datetime.fromisoformat(x["Time"].replace("Z","+00:00"));assert start<=when<=finish
 for f in proc["source_files"]:
  if f["path"] in source_requirements:assert source_requirements[f["path"]]==f["sha256"]
  source_requirements[f["path"]]=f["sha256"]
 children.append({"requirement":req,"namedPasses":len(passed),"rawBytes":len(raw),"rawSha256":sha(raw),"sourceFiles":len(proc["source_files"]),"command":proc["command"],"elapsedSeconds":(finish-start).total_seconds()})
requests=[source+":"+name for name in sorted(source_requirements)]
raw=git("cat-file","--batch",input=("\n".join(requests)+"\n").encode());offset=0;blobs={}
for request in requests:
 end=raw.index(b"\n",offset);h=raw[offset:end].split();assert len(h)==3 and h[1]==b"blob"
 n=int(h[2]);offset=end+1;b=raw[offset:offset+n];assert len(b)==n and raw[offset+n:offset+n+1]==b"\n"
 offset+=n+1;name=request.split(":",1)[1];assert sha(b)==source_requirements[name],name;blobs[name]=b
assert offset==len(raw)
contracts={"tests/language-v2/acceptance-contract.json":"9fdfa8910b09824dc61395d8ddf4aa8fe8914619af0fdde59c63b67ab10b895e","tests/language-v2/repair-regression-plan.json":"eba070df0e1ff229a94e52d977a09c2a0c125a31b1a69caf32787d41600074f5","tests/language-v2/backend-recovery-gates.json":"e7fbb3ad177c5142935f71a46ca7e89b84822061bfc0919eec59708811ab7e7c"}
for name,digest in contracts.items():assert sha(blobs[name])==digest
assert git("rev-parse","HEAD").decode().strip()==source and not git("status","--porcelain=v1").strip()
result={"formatVersion":1,"auditedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Exact intermediate R4 source only; no full179, Apple, final consumer or other-ID inheritance","closureComplete":False,"sourceCommit":source,"sourceCleanBeforeAndAfterAudit":True,"stages":stages,"completedProducerChildren":children,"verifiedRecords":records,"uniqueSourceBlobsVerified":len(blobs),"immutableContracts":contracts,"prior059RetentionLimit":"059 strict outer tests passed; child receipts were not explicitly retained and that run is not used as retained child evidence."}
(out/"audit.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"status":"AUDITED","source":source,"uniqueSourceBlobsVerified":len(blobs),"completedChildren":children,"recordCount":len(records),"stagePasses":{x["name"]:x["counts"]["pass"] for x in stages},"auditSha256":sha((out/"audit.json").read_bytes())}))
