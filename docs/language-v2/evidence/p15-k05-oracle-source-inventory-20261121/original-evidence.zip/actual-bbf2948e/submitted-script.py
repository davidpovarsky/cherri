from pathlib import Path
import subprocess,json,hashlib,time,datetime
w=Path(r"C:\Users\DAVID\Code\cherri-p10r15-oracle-source-inventory-20261121")
e=Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-oracle-source-inventory-20261121")
source="bbf2948e3f33cec19e9a0a448b05595a8b3db883"
def git(*args):
 p=subprocess.run(["git",*args],cwd=w,capture_output=True,text=True,encoding="utf-8",timeout=15)
 assert p.returncode==0,p.stderr
 return p.stdout
assert git("rev-parse","HEAD").strip()==source and git("status","--porcelain=v1")==""
oracle="p15_skill_edit_native_graph_test.go"
blob=subprocess.run(["git","--no-replace-objects","show",source+":"+oracle],cwd=w,capture_output=True,timeout=15);assert blob.returncode==0
assert blob.stdout==(w/oracle).read_bytes()
run=e/"actual-bbf2948e";run.mkdir()
(run/"submitted-script.py").write_bytes(Path(__file__).read_bytes())
expected=["TestRequirementsEvidenceMap_CompleteCoverage","TestLocalGateMainOutputDependencies"]
command=["go","test","-count=1","-json","-timeout=90s","./tools/language-acceptance","-run","^("+"|".join(expected)+")$"]
start={"sourceSha":source,"sourceCleanBefore":True,"command":command,"cwd":str(w),"startedAtUtc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"testTimeoutSeconds":90,"processTimeoutSeconds":180,"oracleBlobSha256":hashlib.sha256(blob.stdout).hexdigest(),"noSignerSelected":True}
(run/"start.json").write_text(json.dumps(start,indent=2)+"\n",encoding="utf-8")
then=time.monotonic();timedout=False
with (run/"go.original.jsonl").open("xb") as out,(run/"stderr.original.bin").open("xb") as err:
 try:p=subprocess.run(command,cwd=w,stdout=out,stderr=err,timeout=180);exitcode=p.returncode
 except subprocess.TimeoutExpired:timedout=True;exitcode=None
raw=(run/"go.original.jsonl").read_bytes();stderr=(run/"stderr.original.bin").read_bytes()
events=[json.loads(line) for line in raw.splitlines()]
passed=[x["Test"] for x in events if x.get("Action")=="pass" and "Test" in x]
failed=[x.get("Test","<package>") for x in events if x.get("Action")=="fail"]
skipped=[x.get("Test","<package>") for x in events if x.get("Action")=="skip"]
parents=[n for n in passed if "/" not in n]
head=git("rev-parse","HEAD").strip();status=git("status","--porcelain=v1")
report={**start,"finishedAtUtc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsedSeconds":round(time.monotonic()-then,3),"exitCode":exitcode,"outerTimedOut":timedout,"namedPass":passed,"failed":failed,"skipped":skipped,"missingParents":sorted(set(expected)-set(parents)),"unexpectedPassedParents":sorted(set(parents)-set(expected)),"goBytes":len(raw),"goSha256":hashlib.sha256(raw).hexdigest(),"stderrBytes":len(stderr),"stderrSha256":hashlib.sha256(stderr).hexdigest(),"sourceShaAfter":head,"sourceCleanAfter":status=="","sourceStatusAfter":status,"formalAcceptanceGranted":False}
(run/"receipt.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report,indent=2),flush=True)
assert exitcode==0 and not failed and not skipped and not report["missingParents"] and not report["unexpectedPassedParents"] and head==source and status==""
