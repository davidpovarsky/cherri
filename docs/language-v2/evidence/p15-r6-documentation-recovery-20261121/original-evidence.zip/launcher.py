import pathlib,subprocess,json,time,hashlib,sys,os
root=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
source=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-source-c46902bb-20261121")
evidence=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-c46902bb-20261121")
sha="c46902bbe6cf7d0d8a6f5acd2d776eb1f77c7262"
assert not source.exists() and not evidence.exists()
evidence.mkdir(parents=True);(evidence/"launcher.py").write_bytes(pathlib.Path(__file__).read_bytes());source.mkdir()
receipts=[]
def run(name,args,cwd,budget=180):
 started=time.monotonic()
 p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=budget)
 raw=evidence/(name+".stdout");err=evidence/(name+".stderr");raw.write_bytes(p.stdout);err.write_bytes(p.stderr)
 rec={"name":name,"command":args,"cwd":str(cwd),"exit":p.returncode,"elapsed":time.monotonic()-started,"budget":budget,"stdoutSha256":hashlib.sha256(p.stdout).hexdigest(),"stderrSha256":hashlib.sha256(p.stderr).hexdigest()}
 receipts.append(rec);(evidence/"processes.json").write_text(json.dumps(receipts,indent=2)+"\n",encoding="utf8")
 if p.returncode:raise RuntimeError(name+" failed: "+p.stderr.decode(errors="replace")[-1200:])
 return p.stdout
run("01-init",["git","init"],source)
run("02-origin",["git","remote","add","origin","https://github.com/davidpovarsky/cherri.git"],source)
run("03-fetch",["git","--no-replace-objects","fetch","--depth=1",str(root),sha],source)
run("04-checkout",["git","--no-replace-objects","checkout","--detach",sha],source)
assert run("05-head",["git","--no-replace-objects","rev-parse","HEAD"],source).decode().strip()==sha
assert not run("06-clean",["git","status","--porcelain=v1","--untracked-files=all"],source).strip()
run("07-build-compiler",["go","build","-o",str(evidence/"compiler.exe"),"."],source)
run("08-build-migrator",["go","build","-o",str(evidence/"cherri-migrate.exe"),"./cmd/cherri-migrate"],source)
for name in ["compiler","cherri-migrate"]:
 raw=run("09-"+name+"-identity",["go","version","-m",str(evidence/(name+".exe"))],source)
 assert ("\tvcs.revision="+sha).encode() in raw or ("vcs.revision="+sha).encode() in raw
 assert b"vcs.modified=false" in raw
run("10-capabilities",[str(evidence/"compiler.exe"),"--capabilities-json"],source)
run("11-canonical-docs",["go","run","./tools/language-docs",str(evidence/"actions-reference.md")],source)
run("12-canonical-docs-check",["go","run","./tools/language-docs","--check",str(evidence/"actions-reference.md")],source)
assert not run("13-clean-after",["git","status","--porcelain=v1","--untracked-files=all"],source).strip()
result={"compilerCommit":sha,"source":str(source),"evidence":str(evidence),"compilerSha256":hashlib.sha256((evidence/"compiler.exe").read_bytes()).hexdigest(),"migratorSha256":hashlib.sha256((evidence/"cherri-migrate.exe").read_bytes()).hexdigest(),"referenceSha256":hashlib.sha256((evidence/"actions-reference.md").read_bytes()).hexdigest(),"capabilities":json.loads((evidence/"10-capabilities.stdout").read_bytes())}
(evidence/"build-report.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf8");print(json.dumps(result))
