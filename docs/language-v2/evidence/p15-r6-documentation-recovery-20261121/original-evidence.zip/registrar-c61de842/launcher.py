import pathlib,subprocess,os,json,time
repo=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-docs-acceptance-r5-20261120")
e=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-c46902bb-20261121\registrar-c61de842")
e.mkdir()
env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","PYTHONUTF8":"1","CHERRI_TEST_BASH":r"C:\Program Files\Git\bin\bash.exe","CHERRI_DOCS_PYTHON":r"C:\ProgramData\SentinelX\.venv\Scripts\python.exe","CHERRI_DOCUMENTATION_SOURCE_ROOT":r"C:\Users\DAVID\Code\cherri-p10r15-source-c46902bb-exact-20261121","CHERRI_D03_DOCS_REPO":r"C:\Users\DAVID\Code\cherrilang-p10r15-docs-r5-20261120","CHERRI_DOCUMENTATION_COMPILER":r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-c46902bb-20261121\compiler-exact.exe","CHERRI_DOCS_RECOVERY_ACCEPTANCE_OUTPUT":str(e/"originals")}
cmd=["go","test","./tools/language-acceptance","-count=1","-json","-timeout=8m","-run","^TestDocumentationRecoveryActualProductionEvidence$"]
(e/"launcher.py").write_bytes(pathlib.Path(__file__).read_bytes());started=time.monotonic()
with (e/"go.jsonl").open("xb") as out,(e/"stderr.log").open("xb") as err:
 p=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err,timeout=540)
report={"command":cmd,"exit":p.returncode,"elapsed":time.monotonic()-started,"source":"c61de84284198cf4dcd3b0d5bb9963b9d7201505","evidence":str(e)}
(e/"launcher-report.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
print(json.dumps(report))
print((e/"go.jsonl").read_text(encoding="utf8",errors="replace")[-7000:])
raise SystemExit(p.returncode)
