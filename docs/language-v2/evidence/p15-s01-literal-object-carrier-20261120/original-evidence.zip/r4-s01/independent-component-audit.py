import pathlib,json,hashlib,subprocess,zipfile,base64,datetime
root=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-s01-literal-token-20261120")
e=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r4-s01")
source="da0ba0e5e49a1be56f97b725f33ff56e3a2c91af";K="8e66254d56ea3e4ac70f6cda6ef9d31217e0937c";observer="1c531a1f30d071a219a80044bfc2347f3b2e4fa8"
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text(encoding="utf-8"))
def git(*a):
 p=subprocess.run(["git","--no-replace-objects",*a],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 assert p.returncode==0,p.stderr.decode("utf-8","replace");return p.stdout
def events(p):return [json.loads(x) for x in p.read_bytes().splitlines() if x]
assert git("rev-parse","HEAD").decode().strip()==source and not git("status","--porcelain")
clean=e/"clean-da0ba0e5";summary=load(clean/"summary-original.json")
assert summary["sourceCommit"]==source and summary["clean"]
result={"sourceCommit":source,"scope":"S01 compiler component and real WorkflowKit serialization only; corrected Shortcut runtime must be observed separately","closureComplete":False,"commands":[]}
for label,count,packages in [("root",194,1),("lower-analysis-backend",88,3)]:
 proc=load(clean/(label+"-process-original.json"));raw=(clean/(label+"-original.jsonl")).read_bytes();ev=events(clean/(label+"-original.jsonl"))
 assert proc["sourceCommit"]==source and proc["cleanBefore"] and proc["cleanAfter"] and proc["exitCode"]==0 and not proc["outerTimedOut"]
 assert sha(raw)==proc["rawSha256"] and len(raw)==proc["rawBytes"]
 passed=[x["Test"] for x in ev if x.get("Test") and x.get("Action")=="pass"]
 assert len(passed)==len(set(passed))==count==proc["passes"]
 assert not [x for x in ev if x.get("Action") in ["fail","skip"]]
 assert len([x for x in ev if x.get("Action")=="pass" and not x.get("Test")])==packages
 result["commands"].append({"label":label,"namedPasses":count,"rawSha256":sha(raw),"rawBytes":len(raw),"elapsedSeconds":proc["elapsedSeconds"]})
fixtures={}
for name in ["CherriS01F01CoveragePOC.cherri","CherriS01F01CoveragePOC.expected.json"]:
 p="tests/runtime_poc/"+name;a=git("show",K+":"+p);b=git("show",source+":"+p)
 assert a==b==(root/p).read_bytes()
 fixtures[p]={"bytes":len(b),"sha256":sha(b),"unchangedFromK":True}
result["fixtures"]=fixtures
assert git("show",source+":shared_codec.go")==git("show",K+":shared_codec.go")
source_paths=["internal/language/lower/lower.go","internal/language/backend/contracts.go","p15_s01_literal_placeholder_test.go","p15_unicode_text_acceptance_test.go","p15_runtime_s01_f01_coverage_test.go","shared_codec.go"]
result["sourceFiles"]=[]
for p in source_paths:
 b=git("show",source+":"+p);assert b==(root/p).read_bytes();result["sourceFiles"].append({"path":p,"bytes":len(b),"sha256":sha(b)})
initial=e/"baseline-da3d437d";r=load(initial/"process-original.json");ev=events(initial/"stdout-original.jsonl");raw=(initial/"stdout-original.jsonl").read_bytes()
assert sha(raw)=="6f435eef4da461550a3663766afdc5d7b619d2cd74a93cea9a85fac4e64ee5b5"
assert len([x for x in ev if x.get("Test") and x.get("Action")=="pass"])==6
assert len([x for x in ev if x.get("Test") and x.get("Action")=="fail"])==7
result["initialPlaceholderCounterexample"]={"source":"da3d437d2ed737bdfa900d0cdd1aff23f7481588","rawSha256":sha(raw),"failedRoutes":6,"positiveControls":6}
malformed=e/"implicit-input-baseline-4c10e9a4";ev=events(malformed/"go-test-original.jsonl")
faults=[x for x in ev if "unexpected token in expression" in x.get("Output","")]
assert len(faults)==6
result["malformedProbe"]={"source":"4c10e9a4c40eff84587fbdfeb9afb7dca515e935","status":"TEST_SYNTAX_FAILURE_NO_IMPLICIT_INPUT_CAUSAL_CREDIT","parseFailures":6}
correct=e/"implicit-input-corrected-baseline-2b878da9";r=load(correct/"process-original.json");raw=(correct/"go-test-original.jsonl").read_bytes()
assert r["sourceCommit"]=="2b878da9e01337679fd7dc026cffb14ec3560212" and r["cleanBefore"] and r["cleanAfter"] and r["exitCode"]==1 and not r["outerTimedOut"]
assert sha(raw)==r["rawSha256"]=="90674b29a6575751e63f9be6a378382437beca0e4e0a7f9fce27f754dafa2ff0"
assert len(r["actualImplicitOrderFaults"])==6 and len(r["failedTests"])==7
result["implicitInputCounterexample"]={"source":r["sourceCommit"],"rawSha256":sha(raw),"failedRoutes":6,"actualDiagnostics":r["actualImplicitOrderFaults"]}
obs=e/"native-observer-44666226513";published=obs/"published";dl=load(obs/"download-audit.json");blob=(obs/(str(dl["artifactId"])+"-original.zip")).read_bytes()
assert dl["run"]==44666226513 and dl["sourceCommit"]==observer and sha(blob)==dl["zipSha256"]=="952b2a92d6bec6f940a508dead9b6298d924ce78ee7569fad1a17440083c327a"
with zipfile.ZipFile(obs/(str(dl["artifactId"])+"-original.zip")) as z:
 for f in dl["files"]:
  b=z.read(f["path"]);assert b==(published/f["path"]).read_bytes() and sha(b)==f["sha256"] and len(b)==f["bytes"]
proc=load(published/"process-original.json")
assert proc["source_sha"]==observer and proc["run_id"]=="44666226513" and proc["source_clean_before"] and proc["source_clean_after"]
assert proc["exit_code"]==0 and proc["timed_out"] is False and proc["mock"] is False and proc["shortcut_runtime"] is False
assert proc["command"][0]=="/usr/bin/osascript" and proc["command"][1:3]==["-l","JavaScript"]
js=git("show",observer+":tools/shortcut-runtime/jxa/observe_literal_object_character.js");assert sha(js)==proc["script_sha256"]
prelude=base64.b64decode(load(e/"shortcutkit-prelude-git-blob-original.json")["content"])
assert sha(prelude)==proc["prelude_sha256"]=="d6fbcaad5104562b04004b39ca098486449399c15c83176c49b2ac28f47a3461"
combined=(published/"combined-original.js").read_bytes();assert sha(combined)==proc["combined_sha256"] and prelude in combined and js in combined
data=load(published/"observations-original.json");assert data["engineLoaded"] is True and data["mock"] is False and data["shortcutRuntime"] is False and data["status"]=="OBSERVED" and len(data["observations"])==16
observations={(x["className"],x["name"]):x for x in data["observations"]};assert len(observations)==16
for cls in ["WFStringParameterState","WFVariableStringParameterState"]:
 for name in ["plain_literal_only","plain_literal_with_unicode","literal_backslash_escape"]:
  x=observations[(cls,name)];assert x["accepted"] is True and x["input"]==x["serializedRepresentation"]
for name,expected in [("empty_token_literal_only",""),("literal_then_astral_then_token","🙂")]:
 x=observations[("WFVariableStringParameterState",name)];assert x["accepted"] is True and x["serializedRepresentation"]==expected
for name in ["ordinary_token_after_astral","ordinary_full_token_coverage"]:
 x=observations[("WFVariableStringParameterState",name)];assert x["accepted"] is True and x["serializedRepresentation"]==x["input"]
result["nativeObservation"]={"run":44666226513,"sourceCommit":observer,"artifactId":dl["artifactId"],"zipSha256":sha(blob),"observationsSha256":sha((published/"observations-original.json").read_bytes()),"platform":proc["platform"],"actualForms":16,"mock":False,"shortcutRuntime":False}
result["auditedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(e/"independent-component-audit.json").write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"status":"VERIFIED_COMPONENT_ONLY","source":source,"commands":result["commands"],"nativeObservation":result["nativeObservation"],"fixtures":fixtures,"implicitInputCounterexample":result["implicitInputCounterexample"],"malformedProbe":result["malformedProbe"]}))
