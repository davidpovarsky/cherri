// Shared prelude for the JXA extraction probes (concatenated in front of each script by
// extract-builtin-actions.sh; osascript has no module system).
//
// Why JXA: about a quarter of the built-in actions (Ask for Input, Show Alert, Count, URL, ...)
// live in ActionKit.framework, whose +[WFActionKitStaticInitializer load] asserts that the host
// is an Apple platform binary. osascript is one, has no library validation, and can dlopen
// frameworks and call Objective-C through the bridge. A platform process refuses to map any
// non-platform code, so the probes cannot be compiled; they are written in JavaScript.
ObjC.import("Foundation");
ObjC.import("AppKit");
ObjC.bindFunction("dlopen", ["void *", ["string", "int"]]);
ObjC.bindFunction("objc_getClass", ["void *", ["string"]]);
ObjC.bindFunction("class_getSuperclass", ["void *", ["void *"]]);
ObjC.bindFunction("class_getName", ["string", ["void *"]]);
ObjC.bindFunction("class_copyMethodList", ["void **", ["void *", "unsigned int *"]]);
ObjC.bindFunction("method_getName", ["void *", ["void *"]]);
ObjC.bindFunction("sel_getName", ["string", ["void *"]]);
ObjC.bindFunction("free", ["void", ["void *"]]);

const RTLD_NOW = 2;
function loadEngine() {
  // ActionKit first: its +load registers the actions it owns with WorkflowKit's provider.
  // dlopen hands back a raw pointer the bridge cannot test for NULL, so success is checked
  // by the presence of a class each framework defines.
  $.dlopen("/System/Library/PrivateFrameworks/ActionKit.framework/ActionKit", RTLD_NOW);
  $.dlopen("/System/Library/PrivateFrameworks/WorkflowKit.framework/WorkflowKit", RTLD_NOW);
  if (!hasClass("WFBundledActionProvider")) throw new Error("WorkflowKit did not load or its internals changed");
  if (!hasClass("WFAskForInputAction")) throw new Error("ActionKit did not load; is this process a platform binary (osascript)?");
}
const str = (v) => ObjC.unwrap(v);
const cls = (v) => str(v.className);
const isNil = (v) => v === null || v === undefined || ((typeof v === "object" || typeof v === "function") && typeof v.isNil === "function" && v.isNil());
// The bridge hands some return values back as JavaScript primitives or raw pointers.
// Bridged Objective-C objects are callable proxies, so typeof reports "function" for them.
const isObj = (v) => v !== null && (typeof v === "object" || typeof v === "function") && typeof v.isKindOfClass === "function";
const count = (v) => Number(v.count); // Swift-backed arrays hand count back as a string
const isA = (v, name) => isObj(v) && v.isKindOfClass($[name]);
const klass = (name) => $.NSClassFromString(name);
const hasClass = (name) => !klass(name).isNil();
const items = (v) => (isA(v, "NSArray") ? v : isA(v, "NSSet") ? v.allObjects : v.array); // NSOrderedSet -> array
// Direct message sends on raw pointers. The bridge's own `Class.alloc.initWith...` chain does not
// resolve initializers of these private classes, so instances are created through objc_msgSend.
ObjC.bindFunction("sel_registerName", ["void *", ["string"]]);
const toRef = (v) => (typeof v === "object" || typeof v === "function") && typeof v.isKindOfClass === "function" ? ObjC.castObjectToRef(v) : ObjC.castObjectToRef($(v));
const NIL = () => ObjC.castObjectToRef($());
function sendObjects(targetRef, selector, ...args) {
  const sig = ["void *", ["void *", "void *"].concat(args.map(() => "void *"))];
  ObjC.bindFunction("objc_msgSend", sig);
  return $.objc_msgSend(targetRef, $.sel_registerName(selector), ...args.map((a) => (a === null ? NIL() : toRef(a))));
}
const allocRef = (className) => sendObjects($.objc_getClass(className), "alloc");
// [[cls alloc] selector:args...] with object arguments; null passes nil.
function make(className, selector, ...args) { return ObjC.castRefToObject(sendObjects(allocRef(className), selector, ...args)); }
function makeBool(className, selector, b) {
  ObjC.bindFunction("objc_msgSend", ["void *", ["void *", "void *", "bool"]]);
  return ObjC.castRefToObject($.objc_msgSend(allocRef(className), $.sel_registerName(selector), b));
}
function makeUInts(className, selector, a, b) {
  ObjC.bindFunction("objc_msgSend", ["void *", ["void *", "void *", "unsigned long", "unsigned short"]]);
  return ObjC.castRefToObject($.objc_msgSend(allocRef(className), $.sel_registerName(selector), a, b));
}
// WFIntentActionProvider also lists SiriKit intents of whatever App Store apps are installed
// (Keynote, Pages, ...). Only intents whose app ships with macOS belong in committed data:
// those resolve to /System or to no app at all (Apple Watch settings, Accessibility).
function isSystemBundle(bundleId) {
  if (!bundleId) return true;
  const url = $.NSWorkspace.sharedWorkspace.URLForApplicationWithBundleIdentifier(bundleId);
  if (isNil(url)) return true;
  return str(url.path).startsWith("/System/");
}
function methodNames(className) {
  const out = [];
  for (let c = $.objc_getClass(className); ; c = $.class_getSuperclass(c)) {
    const name = $.class_getName(c); // the runtime returns "nil" for a NULL class
    if (name === "NSObject" || name === "nil") break;
    const n = Ref("unsigned int"); const ms = $.class_copyMethodList(c, n);
    for (let i = 0; i < n[0]; i++) out.push($.sel_getName($.method_getName(ms[i])));
    $.free(ms);
  }
  return out;
}
// Plain JSON view of Foundation values: strings, numbers, dictionaries, arrays; anything else by class name.
function plain(v, depth) {
  if (isNil(v) || isA(v, "NSNull")) return null;
  if (!isObj(v)) return typeof v === "object" || typeof v === "function" ? String(v) : v;
  if (depth > 8) return str(v.description);
  if (isA(v, "NSString") || isA(v, "NSNumber")) return str(v);
  if (isA(v, "NSDictionary")) { const d = {}; const keys = v.allKeys; for (let i = 0; i < keys.count; i++) { const k = keys.objectAtIndex(i); d[str(k.description)] = plain(v.objectForKey(k), depth + 1); } return d; }
  if (isA(v, "NSArray")) { const a = []; for (let i = 0; i < count(v); i++) a.push(plain(v.objectAtIndex(i), depth + 1)); return a; }
  return "<" + cls(v) + ">";
}
function writeJSON(path, value) {
  const err = Ref();
  const json = $.NSJSONSerialization.dataWithJSONObjectOptionsError($(value), 1 | 2, err); // pretty | sortedKeys
  if (json.isNil()) throw new Error("JSON error: " + str(err[0].description));
  if (!json.writeToFileAtomically(path, true)) throw new Error("write failed: " + path);
}
function readJSON(path) {
  const s = $.NSString.stringWithContentsOfFileEncodingError(path, 4, null);
  if (s.isNil()) throw new Error("cannot read " + path);
  return JSON.parse(str(s));
}

// Synthetic, read-only WorkflowKit observations for the S01 literal-U+FFFC failure.
// Concatenate the pinned shortcutkit prelude before this file. No Shortcut runs here.
function observeTokenValue(value, methods) {
  const out = { className: cls(value) };
  for (const name of ["string", "serializedRepresentation"]) {
    if (methods.includes(name)) {
      try { out[name] = plain(value[name], 0); }
      catch (_) { out[name + "Error"] = "native property exception"; }
    }
  }
  return out;
}

function run(argv) {
  if (argv.length !== 1) throw new Error("Expected one output JSON path");
  const report = {
    schemaVersion: 1, engine: "WorkflowKit parameter-state API", engineLoaded: false,
    scope: "S01 literal object character serialization observations only",
    shortcutRuntime: false, mock: false, observations: [], directTokenObservations: [],
  };
  try {
    loadEngine();
    report.engineLoaded = true;
    const tokenMethods = hasClass("WFTextTokenString") ? methodNames("WFTextTokenString") : [];
    report.tokenSelectors = tokenMethods.filter(name => /string|serial|init|attribut/i.test(name)).sort();
    const ref = { Type: "Variable", VariableName: "S01PublicVariable" };
    const forms = [
      { name: "plain_literal_only", value: "\uFFFC" },
      { name: "plain_literal_with_unicode", value: "L\uFFFC🙂éשָׁR" },
      { name: "empty_token_literal_only", value: { WFSerializationType: "WFTextTokenString", Value: { string: "\uFFFC", attachmentsByRange: {} } } },
      { name: "ordinary_token_after_astral", value: { WFSerializationType: "WFTextTokenString", Value: { string: "🙂\uFFFC", attachmentsByRange: { "{2, 1}": ref } } } },
      { name: "literal_then_astral_then_token", value: { WFSerializationType: "WFTextTokenString", Value: { string: "\uFFFC🙂\uFFFC", attachmentsByRange: { "{3, 1}": ref } } } },
      { name: "token_then_literal", value: { WFSerializationType: "WFTextTokenString", Value: { string: "\uFFFCL\uFFFC", attachmentsByRange: { "{0, 1}": ref } } } },
      { name: "ordinary_full_token_coverage", value: { WFSerializationType: "WFTextTokenString", Value: { string: "\uFFFC🙂\uFFFC", attachmentsByRange: { "{0, 1}": ref, "{3, 1}": ref } } } },
      { name: "literal_backslash_escape", value: "\\ufffc" },
    ];
    for (const className of ["WFStringParameterState", "WFVariableStringParameterState"]) {
      if (!hasClass(className)) {
        report.observations.push({ className, unavailable: true });
        continue;
      }
      const selectors = methodNames(className);
      for (const form of forms) {
        const row = { className, name: form.name, input: form.value };
        try {
          const state = make(className, "initWithSerializedRepresentation:variableProvider:parameter:", $(form.value), null, null);
          row.accepted = !isNil(state);
          if (row.accepted) {
            row.serializedRepresentation = plain(state.serializedRepresentation, 0);
            for (const property of ["string", "value", "stringValue", "textTokenString"]) {
              if (!selectors.includes(property)) continue;
              try {
                const observed = state[property];
                row[property] = isA(observed, "WFTextTokenString")
                  ? observeTokenValue(observed, tokenMethods) : plain(observed, 0);
              } catch (_) { row[property + "Error"] = "native property exception"; }
            }
          }
        } catch (_) { row.error = "native parameter-state exception"; }
        report.observations.push(row);
      }
    }
    if (tokenMethods.includes("initWithString:")) {
      for (const value of ["\uFFFC", "L\uFFFC🙂éשָׁR", "\\ufffc"]) {
        const row = { initializer: "initWithString:", input: value };
        try {
          const token = make("WFTextTokenString", "initWithString:", $(value));
          row.accepted = !isNil(token);
          if (row.accepted) row.value = observeTokenValue(token, tokenMethods);
        } catch (_) { row.error = "native token-string exception"; }
        report.directTokenObservations.push(row);
      }
    }
    report.status = "OBSERVED";
  } catch (_) { report.status = "NOT_RUN"; report.error = "engine loading or observation failed"; }
  writeJSON(argv[0], report);
  if (report.status !== "OBSERVED") throw new Error(report.error);
  console.log("Observed " + report.observations.length + " parameter-state forms; no Shortcut runtime or acceptance credit");
}
