PIN=$(python3 -c 'import json; print(json.load(open("skills/cherri-shortcuts/compatibility-manifest.json"))["compilerCommit"])')
PINNED_SOURCE="$RUNNER_TEMP/cherri-skill-pinned-source"
git --no-replace-objects -C "$PINNED_SOURCE" cat-file -e "$PIN^{tree}"
test "$(git --no-replace-objects -C "$PINNED_SOURCE" rev-parse HEAD)" = "$PIN"
test -z "$(git --no-replace-objects -C "$PINNED_SOURCE" status --porcelain)"
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go -C "$PINNED_SOURCE" build -buildvcs=true -trimpath -ldflags='-s -w' -o "$PWD/dist/cherri-pinned-linux-arm64" .
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go -C "$PINNED_SOURCE" build -buildvcs=true -trimpath -ldflags='-s -w' -o "$PWD/dist/cherri-migrate-pinned-linux-arm64" ./cmd/cherri-migrate
test -z "$(git --no-replace-objects -C "$PINNED_SOURCE" status --porcelain)"
python3 tools/p10r15/package_skill.py create --repo . --skill-commit "$GITHUB_SHA" --kind source --archive dist/cherri-shortcuts-skill-source.zip --report dist/skill-source-integrity.json
python3 tools/p10r15/package_skill.py create --repo . --skill-commit "$GITHUB_SHA" --kind runtime --compiler dist/cherri-pinned-linux-arm64 --migrator dist/cherri-migrate-pinned-linux-arm64 --archive dist/cherri-shortcuts-openminis-arm64.zip --report dist/skill-runtime-integrity.json
python3 tools/p10r15/package_skill.py verify --repo . --skill-commit "$GITHUB_SHA" --kind runtime --compiler dist/cherri-pinned-linux-arm64 --migrator dist/cherri-migrate-pinned-linux-arm64 --archive dist/cherri-shortcuts-openminis-arm64.zip --unpack dist/unpacked-arm64 --report dist/skill-unpacked-integrity.json

