PIN=$(python3 -c 'import json; print(json.load(open("skills/cherri-shortcuts/compatibility-manifest.json"))["compilerCommit"])')
test "${#PIN}" -eq 40
case "$PIN" in *[!0-9a-f]*) exit 1 ;; esac
PINNED_SOURCE="$RUNNER_TEMP/cherri-skill-pinned-source"
test ! -e "$PINNED_SOURCE"
git init --quiet "$PINNED_SOURCE"
git --no-replace-objects -C "$PINNED_SOURCE" config core.autocrlf false
git --no-replace-objects -C "$PINNED_SOURCE" remote add origin https://github.com/davidpovarsky/cherri.git
git --no-replace-objects -C "$PINNED_SOURCE" fetch --quiet --no-tags --depth=1 origin "$PIN"
git --no-replace-objects -C "$PINNED_SOURCE" checkout --quiet --detach "$PIN"
git --no-replace-objects -C "$PINNED_SOURCE" cat-file -e "$PIN^{tree}"
test "$(git --no-replace-objects -C "$PINNED_SOURCE" rev-parse HEAD)" = "$PIN"
test -z "$(git --no-replace-objects -C "$PINNED_SOURCE" status --porcelain)"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go -C "$PINNED_SOURCE" build -buildvcs=true -trimpath -ldflags='-s -w' -o "$PWD/dist/cherri-pinned-linux-amd64" .
test -z "$(git --no-replace-objects -C "$PINNED_SOURCE" status --porcelain)"
dist/cherri-migrate-linux-amd64 --inspect-build-json dist/cherri-pinned-linux-amd64 > dist/signing-pinned-build-identity.json
python3 -c 'import hashlib,json; expected=json.load(open("skills/cherri-shortcuts/compatibility-manifest.json"))["compilerCommit"]; actual=json.load(open("dist/signing-pinned-build-identity.json")); assert actual == {"tool":"cherri","modulePath":"github.com/electrikmilk/cherri","sourceCommit":expected,"buildState":"clean","goos":"linux","goarch":"amd64","sha256":hashlib.sha256(open("dist/cherri-pinned-linux-amd64","rb").read()).hexdigest()}, actual'
printf '%s\n' "$PIN" > dist/cherri-pinned-linux-amd64.commit
sha256sum dist/cherri-pinned-linux-amd64 | awk '{print $1}' > dist/cherri-pinned-linux-amd64.sha256

