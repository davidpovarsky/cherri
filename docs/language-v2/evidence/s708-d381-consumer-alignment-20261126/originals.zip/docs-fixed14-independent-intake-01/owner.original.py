import json,hashlib,subprocess,zipfile,importlib.util,sys,re,ast
from pathlib import Path
sys.dont_write_bytecode=True
D=Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126');A=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126');E=A/'docs-fixed14-independent-intake-01';E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(rel,expected=None):
 p=A/rel
 if expected:assert sha(p)==expected,(rel,sha(p))
 return json.loads(p.read_bytes())
red=read('docs-fixed14-red-01/result.original.json','66e9ca8f52090ac353829340bfb52af11a2434cc05fab9480a87c7872719a295')
green=read('docs-fixed14-green-01/result.original.json','1aaad15290da55cd8eb49ac2dec629675f1b003f547ba3b016fd2d40d98910ed')
assert red['status']=='EXPECTED_RED_FIXED_INVENTORY' and red['process']['exitCode']==1
assert green['status']=='UNEXPECTED_RESULT'
g=green['process'];assert g['status']=='PASS' and g['exitCode']==0 and not g['timedOut'] and not g['cancelled'] and g['cleanup']['noLiveGroupMembers'] and g['cleanup']['parentReaped']
errp=A/'docs-fixed14-green-01/inventory-controls.stderr.original';assert sha(errp)==g['stderr']['sha256']
err=errp.read_text();names=re.findall(r'^test_(\w+) \(__main__\.GeneratedGoInventoryTests\.test_\1\) \.\.\. ok$',err,re.M)
expected={'actual_fourteen_source_bound_identities','missing_scoped_child_rejected','foreign_scoped_child_rejected','duplicate_scoped_run_rejected','parent_cannot_pass_before_scoped_child'}
assert set(names)==expected and len(names)==5 and err.splitlines()[-1]=='OK' and 'Ran 5 tests' in err
assert green['sourceUnchanged'] and red['sourceUnchanged']
for rel,digest in green['sourceFiles'].items():assert sha(D/rel)==digest
for p in ['scripts/test_generated_reference_contract.py','scripts/fixtures/generated-reference-s708-go-controls.jsonl','scripts/fixtures/generated-reference-s708-go-process.json']:assert red['sourceFiles'][p]==green['sourceFiles'][p]
sys.path.insert(0,str(D/'scripts'));import verify_generated_reference as verifier
ci=A/'docs-S708-ci-acquisition-01'
with zipfile.ZipFile(ci/'docs-generator-evidence.original.zip') as z:
 raw=z.read('go-controls.stdout.original');process=json.loads(z.read('go-controls.process.json'));report=json.loads(z.read('generation-report.json'));generated=z.read('actions-reference.generated.md')
assert report['passed'] is False and report['error']=='RuntimeError: unexpected Go test identity'
assert report['compiler_source']=='708ed78eda1cad0f1f453559afce100edc59b8a9' and report['docs_source']=='c51812c39719d26828f9e672c92ca72dc84f7a29'
assert all(x['returncode']==0 and x['passed'] for x in report['commands'].values()) and report['sources_unchanged'] is True
events=verifier.verify_go_events(raw,process);assert len(events['run_once'])==14 and events['run_once']==events['passed_once']
S=Path('/mnt/development/projects/releases/cherri-p10r15-final-s708-compiler-pair-20261126/src')
reference=verifier.verify_reference(generated,(S/'docs/language-v2/actions-reference.md').read_bytes(),(D/'fork-language/actions.md').read_bytes())
assert reference['reference_sha256']=='370ccff0d1d2708117522d847ebd306124751d7cfb4968fc9c4dcadb38333a20'
diagnosis={'ownerResultPreserved':'UNEXPECTED_RESULT','actualProcessStatus':'PASS','actualMethods':5,'actualCausalFaultSubcases':8,'reason':'Owner checked a literal backslash-n sequence instead of the actual newline-delimited unittest OK footer. No production or test failure occurred; no suite rerun.','originalStderrSHA256':sha(errp)}
receipt={'schema':'cherri-docs-fixed14-independent-intake/1','status':'PASS_COMPONENT_INTAKE','compilerSource':report['compiler_source'],'failedDocsSource':report['docs_source'],'failedRun':45745574747,'actualGoEvents':events,'actualReference':reference,'controlDiagnosis':diagnosis,'originalRedReceiptSHA256':sha(A/'docs-fixed14-red-01/result.original.json'),'originalGreenOwnerReceiptSHA256':sha(A/'docs-fixed14-green-01/result.original.json'),'originalTestFilesUnchangedRedToGreen':True,'sourceFiles':green['sourceFiles'],'ciFailedResultUnchanged':True,'newDocsCIRequired':True,'goRerun':False,'nativeAcceptance':False,'fullAcceptance':False}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),**receipt}))
