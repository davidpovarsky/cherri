import os,sys,json,hashlib,subprocess,importlib.util,time
from pathlib import Path
sys.dont_write_bytecode=True
D=Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126')
E=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/docs-fixed14-red-01')
B=Path('/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01')
E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(B/'owned_source_process.py')=='4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85'
sp=importlib.util.spec_from_file_location('owned_source_process',B/'owned_source_process.py');o=importlib.util.module_from_spec(sp);sys.modules[sp.name]=o;sp.loader.exec_module(o)
paths=['scripts/test_generated_reference_contract.py','scripts/verify_generated_reference.py','scripts/fixtures/generated-reference-s708-go-controls.jsonl','scripts/fixtures/generated-reference-s708-go-process.json']
def git(*a):return subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(D),*a],text=True,timeout=15).strip()
def snapshot():return {'source':git('rev-parse','HEAD'),'status':git('status','--porcelain','--untracked-files=all'),'files':{p:sha(D/p) for p in paths}}
before=snapshot();assert before['source']=='c51812c39719d26828f9e672c92ca72dc84f7a29'
assert before['files']['scripts/verify_generated_reference.py']=='a40afb8db8f18b05083cc0bf86ea042449a643dae4a491d1297d072c94205865'
assert before['files']['scripts/test_generated_reference_contract.py']=='b01031443c942ab0f3db4f794200581e2260381fa0d0f20b82605a318f614172'
(E/'before.original.json').write_text(json.dumps(before,indent=2)+'\n')
argv=['/usr/sbin/runuser','-u','ubuntu','--','python3','-B',str(D/'scripts/test_generated_reference_contract.py'),'GeneratedGoInventoryTests']
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
with o.WholeBudget(90,cleanup_seconds=8,final_reserve=20) as budget:
 row=o.run_owned(argv,cwd=D,env=env,output=E,name='inventory-controls',budget=budget,seconds=60)
after=snapshot();(E/'after.original.json').write_text(json.dumps(after,indent=2)+'\n')
err=(E/'inventory-controls.stderr.original').read_text()
expected=row['exitCode']==1 and not row['timedOut'] and not row['cancelled'] and before==after and 'Ran 5 tests' in err and 'unexpected Go test identity' in err and 'FAILED (' in err
receipt={'schema':'cherri-docs-fixed14-red/1','status':'EXPECTED_RED_FIXED_INVENTORY' if expected else 'UNEXPECTED_RESULT','process':row,'sourceUnchanged':before==after,'sourceFiles':before['files'],'originalFailedCI':45745574747,'goExecuted':False,'testsChangedDuringRun':False}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),**receipt}));print(err[-3000:])
sys.exit(0 if expected else 1)
