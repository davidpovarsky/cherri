import json,hashlib,subprocess,ast
from pathlib import Path
D=Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126');E=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/docs-fixed14-production-01');E.mkdir(parents=True,exist_ok=False)
(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
p=D/'scripts/verify_generated_reference.py';before=p.read_bytes();assert sha(before)=='a40afb8db8f18b05083cc0bf86ea042449a643dae4a491d1297d072c94205865';t=before.decode()
pairs=[('"return_type", "macro_identity", "missing_category", "extra_section",','"return_type", "macro_identity", "scoped_dialect", "scoped_void_result",\n    "missing_category", "extra_section",'),('len(run) == 12 and len(passed) == 12','len(run) == 14 and len(passed) == 14'),('missing complete package/12-test execution','missing complete package/14-test execution'),('    "scripts/test_generated_reference_contract.py",\n    "fork-language/actions.md",','    "scripts/test_generated_reference_contract.py",\n    "scripts/fixtures/generated-reference-s708-go-controls.jsonl",\n    "scripts/fixtures/generated-reference-s708-go-process.json",\n    "fork-language/actions.md",')]
for a,b in pairs:assert t.count(a)==1,a;t=t.replace(a,b,1)
ast.parse(t);(E/'before.original.py').write_bytes(before);(E/'after.original.py').write_text(t);p.write_text(t)
assert sha((D/'scripts/test_generated_reference_contract.py').read_bytes())=='b01031443c942ab0f3db4f794200581e2260381fa0d0f20b82605a318f614172'
patch=subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(D),'diff','--','scripts/verify_generated_reference.py']);(E/'source.patch').write_bytes(patch)
receipt={'schema':'docs-fixed14-production/1','status':'SOURCE_PATCHED_PENDING_GREEN','beforeSHA256':sha(before),'afterSHA256':sha(p.read_bytes()),'patchSHA256':sha(patch),'actualRedSHA256':'66e9ca8f52090ac353829340bfb52af11a2434cc05fab9480a87c7872719a295','sourceWitnessSHA256':'ea5a3ca1228f144af51aa0f4aa4cc8a86f8cf4eb58951a80db8ea3aa1648c7e3','retainedParents':4,'retainedOriginalIdentities':12,'addedExactIdentities':['TestP15D01CheckGateProducesAndRejectsFaults/scoped_dialect','TestP15D01CheckGateProducesAndRejectsFaults/scoped_void_result'],'goCommandChanged':False,'budgetsChanged':False,'testBytesUnchanged':True}
r=E/'result.original.json';r.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(r),'sha256':sha(r.read_bytes()),**receipt}))
