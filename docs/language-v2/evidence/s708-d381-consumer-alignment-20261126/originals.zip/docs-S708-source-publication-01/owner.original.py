import os,subprocess,hashlib,json,datetime
from pathlib import Path
D=Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126')
E=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/docs-S708-source-publication-01')
E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,a,timeout=60):
 r=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(D),*a],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 (E/(name+'.stdout.original')).write_bytes(r.stdout);(E/(name+'.stderr.original')).write_bytes(r.stderr)
 (E/(name+'.result.original.json')).write_text(json.dumps({'argv':a,'exitCode':r.returncode,'stdoutSHA256':hashlib.sha256(r.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(r.stderr).hexdigest()})+'\n')
 assert r.returncode==0,(name,r.stderr.decode(errors='replace'));return r.stdout.decode().strip()
parent=run('pre-head',['rev-parse','HEAD']);assert parent=='2680b7b490078d54c279ed7c25985f0aa4b150f0'
paths=['fork-language/actions.md','scripts/smoke_test_snippets.py','scripts/verify_generated_reference.py']
expected=['82710678021367d083d516a68c656efea7f01aa77542008f8589856a89cdd65c','dec0a76d3b48e16ff5de53b559369a012234b6f369f57ad81079253313fb9e5a','a40afb8db8f18b05083cc0bf86ea042449a643dae4a491d1297d072c94205865']
assert [sha(D/p) for p in paths]==expected
assert sorted(run('changed',['diff','--name-only']).splitlines())==sorted(paths)
assert not run('untracked',['ls-files','--others','--exclude-standard'])
assert run('branch',['branch','--show-current'])=='agent/cherri-p10r15-docs-final-alignment-20261126'
heads=run('remote-heads-before',['ls-remote','--heads','origin'],90)
remote=dict((ref,commit) for commit,ref in (l.split() for l in heads.splitlines()))
assert remote['refs/heads/agent/cherri-p10r15-docs-final-alignment-20261126']==parent
run('stage',['add','--',*paths])
run('commit',['-c','user.name=David Povarsky','-c','user.email=davidpovarsky@users.noreply.github.com','commit','-m','docs: bind reference and examples to compiler S708'])
head=run('head',['rev-parse','HEAD']);tree=run('tree',['rev-parse','HEAD^{tree}'])
assert not run('post-status',['status','--porcelain','--untracked-files=all'])
run('push',['-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','origin','agent/cherri-p10r15-docs-final-alignment-20261126'],90)
assert run('remote-after',['ls-remote','origin','refs/heads/agent/cherri-p10r15-docs-final-alignment-20261126']).split()[0]==head
receipt={'schema':'cherri-docs-source-publication/1','status':'PUBLISHED_CANDIDATE','parent':parent,'source':head,'tree':tree,'sourceClean':True,'branch':'agent/cherri-p10r15-docs-final-alignment-20261126','compilerSource':'708ed78eda1cad0f1f453559afce100edc59b8a9','files':dict(zip(paths,expected)),'staticQualificationSHA256':'644a77aafadcbd8a08943c1edd5ca0471cac84608f01b9a5e2fd512519e8295b','canonicalReferenceSHA256':'370ccff0d1d2708117522d847ebd306124751d7cfb4968fc9c4dcadb38333a20','mainChanged':False,'sitePublished':False,'ciResult':'PENDING','at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),**receipt}))
