import os,sys,json,subprocess,hashlib,time,datetime,importlib.util,ast
from pathlib import Path
sys.dont_write_bytecode=True
D=Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126')
E=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/docs-S708-static-qualification-01')
B=Path('/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01')
E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(B/'owned_source_process.py')=='4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85'
spec=importlib.util.spec_from_file_location('owned_source_process',B/'owned_source_process.py');own=importlib.util.module_from_spec(spec);sys.modules[spec.name]=own;spec.loader.exec_module(own)
def git(*a):return subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(D),*a],text=True,timeout=15).strip()
expected={'fork-language/actions.md':'82710678021367d083d516a68c656efea7f01aa77542008f8589856a89cdd65c','scripts/smoke_test_snippets.py':'dec0a76d3b48e16ff5de53b559369a012234b6f369f57ad81079253313fb9e5a','scripts/verify_generated_reference.py':'a40afb8db8f18b05083cc0bf86ea042449a643dae4a491d1297d072c94205865','scripts/test_generated_reference_contract.py':'4faf6ddd441b05824e72d0cd2e2332ed3569610f4f7c8a9036dc2fb62255e128'}
def snapshot():
 return {'head':git('rev-parse','HEAD'),'status':git('status','--porcelain','--untracked-files=all'),'files':{n:sha(D/n) for n in expected}}
before=snapshot();assert before['head']=='2680b7b490078d54c279ed7c25985f0aa4b150f0' and before['files']==expected
assert sorted(git('diff','--name-only').splitlines())==sorted(k for k in expected if k!='scripts/test_generated_reference_contract.py')
for n in expected:
 if n.endswith('.py'):ast.parse((D/n).read_text(),filename=n)
(E/'before.original.json').write_text(json.dumps(before,indent=2)+'\n')
def resources():
 r={k:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for k,p in [('root','/'),('development','/mnt/development'),('shm','/dev/shm')]}
 r['memory']=next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'));return r
admission={'root':939524096,'development':1073741824,'shm':402653184,'memory':3221225472};floor={'root':805306368,'development':805306368,'shm':201326592,'memory':2147483648}
samples=[]
def monitor():
 r=resources();samples.append(r);assert all(r[k]>=v for k,v in floor.items()),'LIVE_RESOURCE_FLOOR'
r=resources();assert all(r[k]>=v for k,v in admission.items()),'ADMISSION';samples.append(r)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
argv=['/usr/sbin/runuser','-u','ubuntu','--','python3','-B',str(D/'scripts/test_generated_reference_contract.py')]
with own.WholeBudget(90,cleanup_seconds=8,final_reserve=20) as budget:
 row=own.run_owned(argv,cwd=D,env=env,output=E,name='reference-controls',budget=budget,seconds=60,monitor=monitor)
after=snapshot();(E/'after.original.json').write_text(json.dumps(after,indent=2)+'\n')
stderr=(E/'reference-controls.stderr.original').read_text()
passed=row['status']=='PASS' and before==after and 'Ran 6 tests' in stderr and '\nOK\n' in stderr
receipt={'schema':'cherri-docs-S708-static/1','status':'PASS' if passed else 'FAIL','sourceHead':before['head'],'sourceFiles':expected,'sourceUnchanged':before==after,'methods':6,'causalFaultCases':12,'process':row,'minimumFree':{k:min(x[k] for x in samples) for k in r},'goExecuted':False,'runtimeAcceptance':False,'formalAcceptance':False}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),**receipt}))
sys.exit(0 if passed else 1)
