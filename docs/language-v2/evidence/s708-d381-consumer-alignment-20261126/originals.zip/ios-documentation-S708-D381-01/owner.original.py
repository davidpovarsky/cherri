import os,sys,json,hashlib,subprocess,importlib.util,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125');A=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126');E=A/'ios-documentation-S708-D381-01';E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
B=Path('/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01')
I=Path('/mnt/development/projects/releases/cherri-p10r15-final-consumer-inputs-20261126');D=I/'docs';K='e96a363e9cb7e7347e383e873c43f9f7382cbeed';S='708ed78eda1cad0f1f453559afce100edc59b8a9';DS='381de199405b8acbdf465e3f1420b01070c57f20'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(user,p,*a):return subprocess.check_output(['/usr/sbin/runuser','-u',user,'--','git','-C',str(p),*a],text=True,timeout=20).strip()
assert git('ubuntu',W,'rev-parse','HEAD')==K and not git('ubuntu',W,'status','--porcelain','--untracked-files=all')
manifest=W/'skills/cherri-shortcuts/compatibility-manifest.json';producer=W/'ios/scripts/build_documentation_index.py'
assert sha(manifest)=='3afbda0784fa3eddf1fcb8e9e06f56aa7a7353694267887f40236015c07d05c9' and sha(producer)=='f80c86792294bf074ef1ada887f3c2b39869a0e459364cdf56dbea2864b7e252'
assert not I.exists() and not I.is_symlink();I.mkdir(mode=0o755);os.chown(I,1002,1002)
products=E/'products';products.mkdir();os.chown(products,1002,1002);os.chmod(E,0o755)
commands=E/'commands';commands.mkdir()
assert sha(B/'owned_source_process.py')=='4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85'
sp=importlib.util.spec_from_file_location('owned_source_process',B/'owned_source_process.py');o=importlib.util.module_from_spec(sp);sys.modules[sp.name]=o;sp.loader.exec_module(o)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_TERMINAL_PROMPT='0')
out=products/'documentation-index.json'
argv=['/usr/sbin/runuser','-u','chatgpt-agent','--','python3','-B',str(producer),'--manifest',str(manifest),'--docs',str(D),'--fetch','--output',str(out)]
rows=[];failure=None;before={'source':K,'manifestSHA256':sha(manifest),'producerSHA256':sha(producer),'sourceClean':True}
(E/'source-before.original.json').write_text(json.dumps(before,indent=2)+'\n')
def free():
 r={k:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for k,p in [('root','/'),('development','/mnt/development'),('shm','/dev/shm')]};r['memory']=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'));return r
floor={'root':805306368,'development':805306368,'shm':201326592,'memory':2147483648};admission={'root':939524096,'development':1073741824,'shm':402653184,'memory':3221225472};samples=[free()];assert all(samples[0][k]>=v for k,v in admission.items())
def monitor():
 x=free();samples.append(x);assert all(x[k]>=v for k,v in floor.items()),'LIVE_RESOURCE_FLOOR'
with o.WholeBudget(300,cleanup_seconds=8,final_reserve=20) as budget:
 try:
  row=o.run_owned(argv,cwd=W,env=env,output=commands,name='generate-index',budget=budget,seconds=180,monitor=monitor);rows.append(row);o.require_success(row)
  generated=commands/'generate-index.stdout.original';g=json.loads(generated.read_bytes());assert g['compilerCommit']==S and g['docsCommit']==DS and g['sourceFiles']==4 and g['sha256']==sha(out) and g['bytes']==out.stat().st_size
  verify=['/usr/sbin/runuser','-u','chatgpt-agent','--','python3','-B',str(producer),'--manifest',str(manifest),'--verify-output','--output',str(out),'--receipt',str(generated)]
  row=o.run_owned(verify,cwd=W,env=env,output=commands,name='verify-index',budget=budget,seconds=30,monitor=monitor);rows.append(row);o.require_success(row)
  verified=json.loads((commands/'verify-index.stdout.original').read_bytes());assert verified['status']=='VERIFIED_BUNDLED_DOCUMENTATION' and verified['sha256']==g['sha256']
 except BaseException as err:failure=type(err).__name__+': '+str(err)
after={'source':git('ubuntu',W,'rev-parse','HEAD'),'manifestSHA256':sha(manifest),'producerSHA256':sha(producer),'sourceClean':not git('ubuntu',W,'status','--porcelain','--untracked-files=all')}
(E/'source-after.original.json').write_text(json.dumps(after,indent=2)+'\n')
identity=None
if failure is None:
 assert after==before
 assert (D/'.git').is_dir() and not (D/'.git/objects/info/alternates').exists()
 assert git('chatgpt-agent',D,'rev-parse','HEAD')==DS and not git('chatgpt-agent',D,'status','--porcelain','--untracked-files=all')
 assert git('chatgpt-agent',D,'remote','get-url','origin')=='https://github.com/davidpovarsky/cherrilang.org.git'
 index=json.loads(out.read_bytes());m=json.loads(manifest.read_bytes())
 assert all(index[k]==m[k] for k in ['docsCommit','compilerCommit','languageVersion','schemaFingerprint','macroFingerprint'])
 for item in index['sourceFiles']:assert sha(D/item['path'])==item['sha256']
 identity={'source':DS,'tree':git('chatgpt-agent',D,'rev-parse','HEAD^{tree}'),'ordinary':True,'shallow':git('chatgpt-agent',D,'rev-parse','--is-shallow-repository')=='true','uid':D.stat().st_uid,'sourceClean':True,'sourceFiles':index['sourceFiles']}
receipt={'schema':'cherri-ios-documentation-tuple-preflight/1','status':'PASS_EXISTING_PRODUCER' if failure is None else 'FAILED','failure':failure,'authoringSource':K,'compilerSource':S,'docsSource':DS,'manifestSHA256':sha(manifest),'producerSHA256':sha(producer),'sourceUnchanged':before==after,'originalFailedAppleLogSHA256':'c0db1b973dcede3ae9eba2cc1ff9d8b72304bd0fe6927bd32e357706d2d7eb77','processes':rows,'docsCheckout':str(D),'docsIdentity':identity,'output':str(out),'outputSHA256':sha(out) if out.exists() else None,'generation':g if failure is None else None,'minimumFree':{k:min(x[k] for x in samples) for k in floor},'goExecuted':False,'nativeBuildExecuted':False,'liveMutation':False,'formalAcceptance':False}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),'status':receipt['status'],'failure':failure,'authoringSource':K,'docsIdentity':identity,'generation':receipt['generation'],'sourceUnchanged':receipt['sourceUnchanged']}))
sys.exit(0 if failure is None else 1)
