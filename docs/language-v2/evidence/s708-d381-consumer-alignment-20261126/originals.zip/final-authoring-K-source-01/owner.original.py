import json,subprocess,hashlib,os,datetime
from pathlib import Path
W=Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125');A=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126');E=A/'final-authoring-K-source-01';E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
S='708ed78eda1cad0f1f453559afce100edc59b8a9';D='381de199405b8acbdf465e3f1420b01070c57f20';branch='agent/cherri-p10r15-final-consumer-tuple-20261126';previous='af26937399d73a66a7412e7b278eca2fba338d5c'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,args,limit=60):
 r=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit)
 (E/(name+'.stdout.original')).write_bytes(r.stdout);(E/(name+'.stderr.original')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.stderr.decode(errors='replace'));return r.stdout.decode().strip()
assert run('head-before',['rev-parse','HEAD'])==previous and not run('clean-before',['status','--porcelain','--untracked-files=all'])
heads=run('remote-heads-before',['ls-remote','--heads','origin'],90);assert '\trefs/heads/'+branch not in heads
run('new-branch',['switch','-c',branch,S]);run('retain-proof',['-c','user.name=David Povarsky','-c','user.email=davidpovarsky@users.noreply.github.com','merge','--no-ff',previous,'-m','merge: retain original consumer qualification evidence [skip ci]'])
base=run('base',['rev-parse','HEAD']);assert not run('clean-base',['status','--porcelain','--untracked-files=all'])
rel='skills/cherri-shortcuts/compatibility-manifest.json';p=W/rel;before=p.read_bytes();old=json.loads(before)
assert old['compilerCommit']=='12f07521b3e9612b97f4e1fc52ccbee40e3b867a' and old['docsCommit']=='428f067090bf54f4d2f214c36951689dd599d153' and old['macroFingerprint']=='747aeae202f541b1a66fad508eb3b151abd604aa4198dc52efab492e1f842629'
caps=json.loads((A/'final-S708-pair-build-01/result.original.json').read_bytes())['capabilities'];assert caps['cherri']==caps['cherri-migrate']
manifest=dict(old);manifest.update(compilerCommit=S,docsCommit=D,macroFingerprint=caps['cherri']['macroFingerprint'])
for k,v in caps['cherri'].items():assert manifest[k]==v
assert {k for k in old if old[k]!=manifest[k]}=={'compilerCommit','docsCommit','macroFingerprint'}
(E/'manifest.before.original.json').write_bytes(before);p.write_text(json.dumps(manifest,indent=2)+'\n');(E/'manifest.after.original.json').write_bytes(p.read_bytes())
assert run('changed',['diff','--name-only'])==rel
run('stage',['add','--',rel]);run('commit',['-c','user.name=David Povarsky','-c','user.email=davidpovarsky@users.noreply.github.com','commit','-m','chore: align authoring consumer tuple to S708 and D381 [skip ci]'])
head=run('head',['rev-parse','HEAD']);tree=run('tree',['rev-parse','HEAD^{tree}']);assert not run('clean-after',['status','--porcelain','--untracked-files=all'])
run('source-ancestor',['merge-base','--is-ancestor',S,head]);run('proof-ancestor',['merge-base','--is-ancestor',previous,head])
run('push',['-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','origin',branch],90)
assert run('remote-after',['ls-remote','origin','refs/heads/'+branch]).split()[0]==head
receipt={'schema':'cherri-authoring-consumer-tuple/1','status':'PUBLISHED_AUTHORING_TUPLE_PENDING_IOS_INDEX','source':head,'tree':tree,'mergeBase':base,'compilerSource':S,'docsSource':D,'branch':branch,'manifest':manifest,'manifestSHA256':sha(p),'sourceClean':True,'pairBuildReceiptSHA256':'b85ef4cdaf6cfd5e219ee0db72e7e68d8e41bc9b5338fe62a4d6231018c16e90','pairIntakeSHA256':'3923502edaf6f65ea9c0f93a757f3d71b1bdd4b54578a6bc42dbf346969c8433','docsCIRun':45747139317,'docsCIStatus':'success','finalStageSource':'M_REQUIRED_NOT_THIS_AUTHORING_K','liveChanged':False,'formalAcceptance':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),**receipt}))
