import os,json,subprocess,hashlib,zipfile,time,datetime
from pathlib import Path
E=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/docs-S708-ci-acquisition-02');E.mkdir(parents=True,exist_ok=False)
(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
repo='davidpovarsky/cherrilang.org';runid=45747139317;source='381de199405b8acbdf465e3f1420b01070c57f20';rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fetch(name,route,limit=60):
 out=E/name;start=time.monotonic()
 with out.open('xb') as f,(E/(name+'.stderr.original')).open('xb') as err:
  r=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','gh','api',route],stdout=f,stderr=err,timeout=limit)
 row={'route':route,'path':str(out),'exitCode':r.returncode,'sha256':sha(out),'bytes':out.stat().st_size,'seconds':time.monotonic()-start};rows.append(row)
 assert r.returncode==0,(name,r.returncode);return out
rp=fetch('run.original.json',f'repos/{repo}/actions/runs/{runid}');run=json.loads(rp.read_bytes());assert run['head_sha']==source and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
jp=fetch('jobs.original.json',f'repos/{repo}/actions/runs/{runid}/jobs?per_page=20');jobs=json.loads(jp.read_bytes())['jobs']
ap=fetch('artifacts.original.json',f'repos/{repo}/actions/runs/{runid}/artifacts?per_page=20');artifacts=json.loads(ap.read_bytes())['artifacts']
for j in jobs:fetch(f'job-{j["id"]}.log.original',f'repos/{repo}/actions/jobs/{j["id"]}/logs')
expected={int(k):v for k,v in {"15084405027":["docs-built-site","748fef62c79020a760f4e03b2d9c0952e043fad6ef4f67d64031fed5f2db7ece"],"15084270238":["docs-snippet-evidence","225a747ccef263bec45ebcca84e6ccd1d9f99e044bf1e9cdd4e600606dc86bc2"],"15084170430":["docs-generator-evidence","80c6a6ac6f7385c4edcedb5702fa8619ce210ab26c8fd0785bc591e1ab70c195"]}.items()}
reports={}
for a in artifacts:
 assert a['id'] in expected and a['workflow_run']['head_sha']==source and not a['expired'];name,digest=expected[a['id']];assert a['name']==name and a['digest']=='sha256:'+digest
 p=fetch(name+'.original.zip',f'repos/{repo}/actions/artifacts/{a["id"]}/zip');assert sha(p)==digest
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  inventory=[{'name':i.filename,'bytes':i.file_size,'compressed':i.compress_size,'crc':i.CRC} for i in z.infolist()]
  (E/(name+'.inventory.original.json')).write_text(json.dumps(inventory,indent=2)+'\n')
  for i in z.infolist():
   assert not i.filename.startswith('/') and '..' not in Path(i.filename).parts
   if Path(i.filename).name in ['generation-report.json','cherri-docs-evidence.json','cherri-docs-site-evidence.json','cherri-docs-site-controls.json']:
    b=z.read(i);dest=E/(name+'--'+Path(i.filename).name);dest.write_bytes(b);reports[str(dest)]=json.loads(b)
receipt={'schema':'cherri-docs-gha-original-acquisition/1','status':'ACQUIRED_ORIGINAL_SUCCESS_RUN','source':source,'run':runid,'runAttempt':1,'conclusion':run['conclusion'],'jobs':[{k:j[k] for k in ['id','name','conclusion']} for j in jobs],'files':rows,'artifactCount':len(artifacts),'noRerun':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=E/'result.original.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(p),'sha256':sha(p),'status':receipt['status'],'reports':{n:{k:v for k,v in j.items() if k in ['error','postflight_error','passed','commands','source_commit','summary','compiler_source','docs_source','go_events','reference']} for n,j in reports.items()}}))
