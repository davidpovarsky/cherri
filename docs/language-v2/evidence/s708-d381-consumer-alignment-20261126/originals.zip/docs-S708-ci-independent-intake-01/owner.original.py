import json,hashlib,zipfile,sys,subprocess,re,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
A=Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126');C=A/'docs-S708-ci-acquisition-02';E=A/'docs-S708-ci-independent-intake-01';E.mkdir(parents=True,exist_ok=False);(E/'owner.original.py').write_bytes(Path(__file__).read_bytes())
D=Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126');S=Path('/mnt/development/projects/releases/cherri-p10r15-final-s708-compiler-pair-20261126/src');DS='381de199405b8acbdf465e3f1420b01070c57f20';SS='708ed78eda1cad0f1f453559afce100edc59b8a9'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def git(p,*a):return subprocess.check_output(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(p),*a],timeout=20)
assert sha(C/'result.original.json')=='434f66b517758eca5a331dc56503bf1139d59792cce53e56bfb63a21b3370d9f'
acq=load(C/'result.original.json');assert acq['status']=='ACQUIRED_ORIGINAL_SUCCESS_RUN'
for row in acq['files']:
 p=Path(row['path']);assert row['exitCode']==0 and sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
run=load(C/'run.original.json');assert run['id']==45747139317 and run['head_sha']==DS and run['conclusion']=='success' and run['status']=='completed' and run['event']=='push' and run['run_attempt']==1
jobs=load(C/'jobs.original.json')['jobs'];assert len(jobs)==2 and {j['name'] for j in jobs}=={'Build documentation and search index','smoke-test-snippets'}
assert all(j['head_sha']==DS and j['status']=='completed' and j['conclusion']=='success' for j in jobs)
critical={'smoke-test-snippets':['Run standalone docs snippet smoke test against pinned Cherri compiler','Verify real compiler cache provenance and negative examples','Regenerate and verify the pinned action reference','Verify exact reference inventory and causal corruption controls'],'Build documentation and search index':['Build Jekyll site','Verify rendered action reference and generated search','Reject corrupted real site and search artifacts']}
for job in jobs:
 for name in critical[job['name']]:
  rows=[r for r in job['steps'] if r['name']==name];assert len(rows)==1 and rows[0]['conclusion']=='success'
for root,head in [(D,DS),(S,SS)]:assert git(root,'rev-parse','HEAD').decode().strip()==head and not git(root,'status','--porcelain','--untracked-files=all').strip()
sys.path.insert(0,str(D/'scripts'));import verify_generated_reference as verifier;import smoke_test_snippets as smoke
assert verifier.COMPILER_SHA==smoke.PINNED_CHERRI_COMMIT==SS
with zipfile.ZipFile(C/'docs-generator-evidence.original.zip') as z:
 assert z.testzip() is None
 report=json.loads(z.read('generation-report.json'));assert report['passed'] and report['sources_unchanged'] and report['compiler_source']==SS and report['docs_source']==DS and report['before']==report['after']
 for label,root,head in [('compiler',S,SS),('docs',D,DS)]:
  state=report['before'][label];assert state['clean'] and state['head']==head
  for rel,info in state['files'].items():
   b=(root/rel).read_bytes();blob=git(root,'show','HEAD:'+rel);assert b==blob and digest(b)==info['sha256'] and len(b)==info['bytes'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==info['git_blob']
 for row in report['processes']:
  assert row['state']=='TERMINAL' and row['returncode']==0 and row['passed'] and not row['timed_out'] and not row['orphaned_group'] and row['cleanup_complete']
  for key in ['stdout','stderr']:
   data=z.read(row['label']+'.'+key+'.original');assert len(data)==row[key]['bytes'] and digest(data)==row[key]['sha256']
 events=verifier.verify_go_events(z.read('go-controls.stdout.original'),report['commands']['go_controls']);assert events==report['go_events'] and len(events['run_once'])==14
 reference=verifier.verify_reference(z.read('actions-reference.generated.md'),(S/'docs/language-v2/actions-reference.md').read_bytes(),(D/'fork-language/actions.md').read_bytes());assert reference==report['reference']
 cache=report['before']['cache']['receipt'];assert cache['compilerCommit']==SS and cache['vcsModified'] is False and cache['compilerRepository']=='https://github.com/davidpovarsky/cherri.git'
snippets=load(C/'docs-snippet-evidence--cherri-docs-evidence.json');assert snippets['passed'] and snippets['compilerCommit']==SS and snippets['binarySha256']==cache['binarySha256']
targets=['index.md','fork-language/guide.md','fork-language/migration.md','fork-language/actions.md','language/functions.md','language/variables-constants-globals.md']
expected={}
for rel in targets:
 text=(D/rel).read_text();generated=rel=='fork-language/actions.md'
 for number,match in enumerate(smoke.FENCES.finditer(text),1):
  code=match['code'].strip();kind=match['kind'];reference_only=generated or kind in ['cherri-legacy','cherri-fragment'];errors=[]
  if not reference_only:
   annotation=smoke.EXPECTATION.search(text[:match.start()])
   if annotation:errors=annotation[1].split()[1:]
  expected[(rel,number)]={'sourceSha256':digest((code+('' if reference_only else '\n')).encode()),'classification':'generated-signature' if generated else kind if reference_only else 'diagnostic' if errors else 'runnable','executed':not reference_only,'expectedErrors':errors}
actual={}
for row in snippets['records']:
 rel=Path(row['file']).relative_to(Path(report['before']['docs']['root'])).as_posix();key=(rel,row['block']);assert key not in actual and key in expected;actual[key]=row;want=expected[key]
 for k in ['sourceSha256','classification','executed']:assert row[k]==want[k],(key,k)
 if row['executed']:
  assert row['passed'] and row['schemaFingerprint']=='378d23912e98d11fe5da550de96f1715407f0754a2f29cd3593a2c7f4dd4b8c5'
  assert row['expectedErrors']==row['actualErrors']==want['expectedErrors']
  if want['expectedErrors']:assert row['checkExit']!=0 and row['compileExit']!=0 and 'unsignedSha256' not in row
  else:assert row['checkExit']==row['compileExit']==0 and re.fullmatch('[0-9a-f]{64}',row['unsignedSha256']) and type(row['actionCount']) is int and row['actionCount']>=0
assert set(actual)==set(expected) and len(actual)==571
counts={'executed':sum(r['executed'] for r in actual.values()),'runnable':sum(r['classification']=='runnable' for r in actual.values()),'diagnostic':sum(r['classification']=='diagnostic' for r in actual.values()),'referenceOnly':sum(not r['executed'] for r in actual.values())}
assert counts=={k:snippets[k] for k in counts}=={'executed':46,'runnable':43,'diagnostic':3,'referenceOnly':525}
site=load(C/'docs-built-site--cherri-docs-site-evidence.json');controls=load(C/'docs-built-site--cherri-docs-site-controls.json')
assert site['docsCommit']==controls['docsCommit']==DS and site['compilerCommit']==controls['compilerCommit']==SS
assert site['sourceTreeClean'] and site['sourceReferenceSha256']==sha(D/'fork-language/actions.md') and site['nativeActionCount']==505 and site['renderedReferenceSignatures']==521 and site['historicalSearchEntries']==0
assert controls['passed']==6 and controls['failed']==controls['skipped']==0 and controls['artifactsRestoredExactly'] and len(controls['controls'])==6 and all(r['rejected'] for r in controls['controls'])
with zipfile.ZipFile(C/'docs-built-site.original.zip') as z:
 assert z.testzip() is None
 assert digest(z.read('cherri-docs-site/fork-language/actions.html'))==site['renderedActionPageSha256']
 assert digest(z.read('cherri-docs-site/assets/js/search-data.json'))==site['searchIndexSha256']
summary={'schema':'cherri-docs-S708-independent-ci-intake/1','status':'PASS_DOCS_COMPONENT','docsSource':DS,'docsTree':git(D,'rev-parse','HEAD^{tree}').decode().strip(),'compilerSource':SS,'workflowRun':45747139317,'workflowAttempt':1,'workflowConclusion':'success','acquisitionSHA256':sha(C/'result.original.json'),'artifacts':[{k:r[k] for k in ['name','id','digest','size_in_bytes']} for r in load(C/'artifacts.original.json')['artifacts']],'sourceBoundRecords':len(actual),'snippets':counts,'actualCLICommands':2*counts['executed'],'actualGoIdentities':len(events['passed_once']),'generatorParents':len(events['parents']),'generatorFaultChildren':len(events['mutations']),'reference':reference,'site':site,'siteCausalControls':6,'localCLIOrGoRerun':False,'nativeAcceptance':False,'sitePublished':False,'finalTupleAcceptance':False}
p=E/'result.original.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),**summary}))
