import pathlib,json,hashlib,subprocess,os,time,signal,shutil,datetime,importlib.util,traceback,stat,plistlib
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-activation-cycle-01')
ST=pathlib.Path('/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream')
LIVE=pathlib.Path('/mnt/development/projects/agent-workspaces/cherri-remote')
TARGET=LIVE/'pure-upstream';ALIAS=pathlib.Path('/home/chatgpt-agent/workspaces/cherri-remote/pure-upstream')
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(E/'operation.original.py')=='f2ced679cf9d27b4985f47ae850da1825955e4a20303025ea73813b52437043c'
assert h(E.parent/'pure-wrapper-1.0.1-actual-02/result.original.json')=='0558d1cf9e691503bc122fe3a1df203e60bf6f55fb5c4fdc1122142436c98b19'
assert h(E.parent/'pure-independent-intake-04/result.original.json')=='b4dc26752faa731c8885526f9758811a32c269adf633ec7f36321b2fbc3b8532'
with (E/'cycle-owner.original.py').open('xb') as f:f.write(pathlib.Path(__file__).read_bytes())
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys_dont=None
import sys
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('pure_activation_owned',E/'operation.original.py');op=importlib.util.module_from_spec(spec);spec.loader.exec_module(op)
steps=[];phases=[];owned=[];new_final=[];status='FAILED';error=None;recovery=None
def write(name,value):return op.record(E/name,value)
def guard():
 q=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
 clean=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),'status','--porcelain'],capture_output=True,text=True,check=True).stdout
 assert q=='d58a55e81720b3396aa0c3cc868876eda22aea81' and clean==''
 op.protected();return q
def run(label,root,exe,args,request=False,user='chatgpt-agent',parse=True):
 d=E/label;d.mkdir(mode=0o700)
 before=set((root/'outputs').iterdir())
 argv=['/usr/sbin/runuser','-u',user,'--','env','GIT_OPTIONAL_LOCKS=0','PYTHONDONTWRITEBYTECODE=1',str(exe),*args]
 start=time.monotonic()
 with (d/'stdout.original.bin').open('xb') as so,(d/'stderr.original.bin').open('xb') as se:
  p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
  try:p.wait(timeout=25)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 added=set((root/'outputs').iterdir())-before
 if request:
  assert len(added)==1,(label,sorted(str(x) for x in added))
  output=added.pop();owned.append(output.name)
 process={'label':label,'argv':argv,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':h(d/'stdout.original.bin'),'stderrSHA256':h(d/'stderr.original.bin')}
 op.record(d/'process.original.json',process);steps.append(process)
 assert p.returncode==0,(label,p.returncode,(d/'stderr.original.bin').read_text()[-500:])
 if request:
  result=json.loads((output/'result.original.json').read_text())
  assert result['status']=='COMPILED_UNSIGNED_PLIST' and result['wrapperVersion']=='1.0.1'
  assert result['engine']['binarySHA256']=='f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5'
  assert result['process']['cleanup']['groupGone'] and not result['process']['cancelled'] and not result['process']['timedOut']
  artifact=pathlib.Path(result['artifact']['path']);assert h(artifact)==result['artifact']['sha256']
  assert len(plistlib.loads(artifact.read_bytes())['WFWorkflowActions'])==result['actions']>0
  shutil.copytree(output,d/'request-originals')
  for source in pathlib.Path(result['requestDirectory']).glob('*.cherri'):shutil.copyfile(source,d/'request-originals'/('input-'+source.name))
  return result
 assert not added
 return json.loads((d/'stdout.original.bin').read_text()) if parse else None
started=time.monotonic()
try:
 controller=guard()
 phases.append(op.activate('activate-01'))
 a=run('activated-status',TARGET,TARGET/'bin/pure-cherri-service.sh',['status']);assert a['wrapperVersion']=='1.0.1' and a['packLoaded'] is False
 b=run('activated-alias-status',TARGET,ALIAS/'bin/pure-cherri-service.sh',['status']);assert a==b
 run('activated-pack-verify',TARGET,ALIAS/'bin/cherri-with-actions.sh',['verify'],parse=False)
 r=run('activated-pure-compile',TARGET,ALIAS/'bin/pure-cherri-service.sh',['compile',str(ALIAS/'jobs/pure-public-smoke.cherri')],request=True);assert r['sourceSHA256']=='55779c8f08eb2d2426fb695691d94bf3d488ebe14c097fbd9accbeda386b08d3'
 run('activated-explicit-pack-compile',TARGET,ALIAS/'bin/cherri-with-actions.sh',['enhanced','compile',str(ALIAS/'jobs/pure-pack-counterfactual.cherri')],request=True)
 write('phase1-requests.original.json',{'requestIDs':owned.copy(),'commands':[x['label'] for x in steps if 'compile' in x['label']]})
 phases.append(op.rollback('rollback-01',E/'phase1-requests.original.json'));owned.clear()
 a=run('rolled-back-staged-status',ST,ST/'bin/pure-cherri-service.sh',['status'],user='ubuntu');assert a['wrapperVersion']=='1.0.1'
 op.verify(ST,'baseline',True,True);assert not os.path.lexists(TARGET)
 phases.append(op.activate('reapply-01'))
 a=run('reapplied-status',TARGET,TARGET/'bin/pure-cherri-service.sh',['status']);assert a['packLoaded'] is False and a['wrapperVersion']=='1.0.1'
 b=run('reapplied-alias-status',TARGET,ALIAS/'bin/pure-cherri-service.sh',['status']);assert a==b
 run('reapplied-pack-verify',TARGET,ALIAS/'bin/cherri-with-actions.sh',['verify'],parse=False)
 r=run('reapplied-pure-compile',TARGET,ALIAS/'bin/pure-cherri-service.sh',['compile',str(ALIAS/'jobs/pure-public-smoke.cherri')],request=True)
 assert r['sourceSHA256']=='55779c8f08eb2d2426fb695691d94bf3d488ebe14c097fbd9accbeda386b08d3'
 write('final-owned-requests.original.json',{'requestIDs':owned.copy()})
 current=op.verify(TARGET,'live',False,False);op.no_active(TARGET)
 for section in ('jobs','outputs'):
  baseline={pathlib.PurePosixPath(n).parts[1] for n in op.by if n.startswith(section+'/')}
  assert {p.name for p in (TARGET/section).iterdir()}-baseline==set(owned)
 final=[]
 for rel,(p,s) in sorted(current.items()):
  row={'path':rel,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtimeNS':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev,'kind':'file' if stat.S_ISREG(s.st_mode) else 'directory','size':s.st_size}
  if row['kind']=='file':row['sha256']=h(p)
  final.append(row)
 final_sha=write('live-physical-after.original.json',final)
 assert guard()==controller and not os.path.lexists(ST)
 status='PASS_ACTIVATE_ROLLBACK_REAPPLY'
except BaseException as ex:
 error=type(ex).__name__+': '+str(ex);write('error.original.json',{'error':error,'traceback':traceback.format_exc()})
 try:
  manifest=E/'failure-owned-requests.original.json';write(manifest.name,{'requestIDs':owned.copy()})
  recovery=op.rollback('failure-recovery-01',manifest)
 except BaseException as rex:recovery={'error':type(rex).__name__+': '+str(rex),'liveLexists':os.path.lexists(TARGET),'stageLexists':os.path.lexists(ST)}
finally:
 report={'schema':'cherri-pure-isolated-activation-cycle/1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':status,'controller':'d58a55e81720b3396aa0c3cc868876eda22aea81','engine':'bcc0095754e2cc0baaeb4d93dae172b8153b4716','binarySHA256':'f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5','manifestSHA256':'ccdc5ef66b0184a89ed62061e3e49ec1b36fe721d0b597fce6d65fd594d74e82','freshBuild':True,'historicalBinaryRestored':False,'liveRoot':str(TARGET),'phases':phases,'actualCLICommands':steps,'finalPhysicalInventorySHA256':locals().get('final_sha'),'error':error,'failureRecovery':recovery,'newServices':False,'newListeners':False,'goExecuted':False,'nativeRuntimeCredit':False,'finalCherriTupleCredit':False,'elapsedSeconds':time.monotonic()-started}
 sha=write('result.original.json',report);print(json.dumps({'path':str(E/'result.original.json'),'sha256':sha,'status':status,'commands':len(steps),'phases':len(phases),'error':error,'recovery':recovery}))
if error:raise SystemExit(1)
