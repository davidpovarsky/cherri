import pathlib,json,hashlib,os,stat,datetime,sys
E=pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-activation-cycle-01")
P=E.parent/"pure-activation-preparation-01"
ST=pathlib.Path("/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream")
LIVE=pathlib.Path("/mnt/development/projects/agent-workspaces/cherri-remote")
TARGET=LIVE/"pure-upstream"
ALIAS=pathlib.Path("/home/chatgpt-agent/workspaces/cherri-remote")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/"result.original.json")=="8b06372af35edfc0a0fb91c1502a4a861c20de87f0923b62cfcc815a0f265e1d"
plan=json.loads((P/"result.original.json").read_text())
assert sha(P/"stage-physical-before.original.json")==plan["inventorySHA256"]
rows=json.loads((P/"stage-physical-before.original.json").read_text());by={r["path"]:r for r in rows}
def record(path,value):
 b=(json.dumps(value,indent=2)+"\n").encode()
 with path.open("xb") as f:f.write(b)
 return hashlib.sha256(b).hexdigest()
def protected():
 for name,digest in plan["protected"].items():assert sha(LIVE/name)==digest,name
 s=ALIAS.lstat();a=plan["alias"]
 assert os.readlink(ALIAS)==a["target"] and (s.st_ino,s.st_dev,s.st_uid,s.st_gid,s.st_mtime_ns,stat.S_IMODE(s.st_mode))==(a["inode"],a["device"],a["uid"],a["gid"],a["mtimeNS"],a["mode"])
def no_active(root):
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdecimal() or int(p.name)==os.getpid():continue
  try:
   cwd=os.readlink(p/"cwd");cmd=(p/"cmdline").read_bytes().replace(b"\0",b" ").decode(errors="replace")
  except OSError:continue
  assert not (cwd==str(root) or cwd.startswith(str(root)+"/") or str(root)+"/bin/" in cmd or str(root)+"/lib/" in cmd),("active owner",p.name)
def actual(root):
 found={}
 for p in [root,*sorted(root.rglob("*"))]:
  s=p.lstat();rel=str(p.relative_to(root))
  assert stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode),("nonregular",rel)
  assert not stat.S_ISREG(s.st_mode) or s.st_nlink==1,("shared inode",rel)
  found[rel]=(p,s)
 return found
def verify(root,owner,strict,exact):
 current=actual(root)
 assert set(by)<=set(current),sorted(set(by)-set(current))
 if exact:assert set(by)==set(current),sorted(set(current)-set(by))
 for rel,r in by.items():
  p,s=current[rel]
  assert s.st_ino==r["inode"] and s.st_dev==r["device"],("inode changed",rel)
  assert stat.S_IMODE(s.st_mode)==r["mode"],("mode",rel)
  assert stat.S_ISREG(s.st_mode)==(r["kind"]=="file"),rel
  if r["kind"]=="file":assert s.st_size==r["size"] and sha(p)==r["sha256"],("bytes",rel)
  if owner=="baseline":assert (s.st_uid,s.st_gid)==(r["uid"],r["gid"]),("owner",rel)
  elif owner=="live":assert (s.st_uid,s.st_gid)==(1002,1002),("owner",rel)
  elif owner=="recoverable":assert (s.st_uid,s.st_gid) in ((r["uid"],r["gid"]),(1002,1002)),("foreign owner",rel)
  if strict or r["kind"]=="file":assert s.st_mtime_ns==r["mtimeNS"],("mtime",rel)
 return current
def set_owners(root,live):
 for r in rows:
  p=root/r["path"];s=p.lstat()
  assert s.st_ino==r["inode"] and s.st_dev==r["device"]
  assert r["kind"]!="file" or s.st_nlink==1
  os.chown(p,1002 if live else r["uid"],1002 if live else r["gid"],follow_symlinks=False)
  os.chmod(p,r["mode"],follow_symlinks=False)
 for r in reversed(rows):
  p=root/r["path"];s=p.lstat();os.utime(p,ns=(s.st_atime_ns,r["mtimeNS"]),follow_symlinks=False)
def activate(phase):
 out=E/phase;out.mkdir(mode=0o700)
 protected();assert ST.is_dir() and not os.path.lexists(TARGET);no_active(ST)
 verify(ST,"baseline",True,True)
 assert ST.stat().st_dev==LIVE.stat().st_dev
 record(out/"before.original.json",{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":str(ST),"target":str(TARGET),"manifestSHA256":sha(ST/"installation.json"),"absentLive":True})
 set_owners(ST,True);verify(ST,"live",True,True)
 ST.rename(TARGET)
 verify(TARGET,"live",True,True);protected()
 result={"status":"ACTIVATED_EXACT_FRESH_PURE","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"target":str(TARGET),"manifestSHA256":sha(TARGET/"installation.json"),"entries":len(rows),"uid":1002,"atomicRename":True,"k18AndAliasUnchanged":True}
 digest=record(out/"result.original.json",result);return {"path":str(out/"result.original.json"),"sha256":digest}
def rollback(phase,request_manifest):
 out=E/phase;out.mkdir(mode=0o700)
 protected()
 assert os.path.lexists(ST)!=os.path.lexists(TARGET),"ambiguous source/target"
 root=TARGET if TARGET.exists() else ST
 no_active(root);verify(root,"recoverable",False,False)
 owned=json.loads(request_manifest.read_text());ids=set(owned["requestIDs"])
 assert len(ids)==len(owned["requestIDs"]) and all(x.startswith("pure-request-") and "/" not in x and x not in (".","..") for x in ids)
 archived=[]
 for section in ("jobs","outputs"):
  baseline={pathlib.PurePosixPath(r).parts[1] for r in by if r.startswith(section+"/")}
  present={p.name for p in (root/section).iterdir()}
  assert present-baseline==ids,("unexpected request",section,sorted(present-baseline),sorted(ids))
  dest=out/"preserved-generated-requests"/section;dest.mkdir(parents=True)
  for name in sorted(ids):
   p=root/section/name;assert p.is_dir() and not p.is_symlink()
   p.rename(dest/name);archived.append({"from":str(p),"to":str(dest/name)})
 verify(root,"recoverable",False,True)
 if root==TARGET:TARGET.rename(ST)
 set_owners(ST,False);verify(ST,"baseline",True,True)
 protected();assert not os.path.lexists(TARGET)
 result={"status":"ROLLED_BACK_TO_EXACT_STAGED_BASELINE","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":str(ST),"liveAbsent":True,"manifestSHA256":sha(ST/"installation.json"),"originalFilesModesOwnersMtimesRestored":True,"newRequestOriginalsPreserved":archived,"requestManifestSHA256":sha(request_manifest),"k18AndAliasUnchanged":True,"ctimeRestorationClaim":False}
 digest=record(out/"result.original.json",result);return {"path":str(out/"result.original.json"),"sha256":digest}
if __name__=="__main__":
 assert len(sys.argv) in (3,4)
 if sys.argv[1]=="activate":result=activate(sys.argv[2])
 elif sys.argv[1]=="rollback":
  assert len(sys.argv)==4;manifest=pathlib.Path(sys.argv[3]).resolve();assert manifest.parent==E
  result=rollback(sys.argv[2],manifest)
 else:raise SystemExit("Expected activate or rollback")
 print(json.dumps(result))
