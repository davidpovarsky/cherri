import pathlib,json,hashlib,subprocess,os,time,plistlib,signal,shutil,datetime,ast,traceback
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-wrapper-1.0.1-actual-02');E.mkdir(mode=0o750)
ST=pathlib.Path('/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream');LIVE=pathlib.Path('/mnt/development/projects/agent-workspaces/cherri-remote')
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
P=E.parent/'pure-wrapper-1.0.1-actual-01'
(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
h=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
 b=(json.dumps(value,indent=2)+'\n').encode()
 with (E/name).open('xb') as f:f.write(b)
 return h(b)
prior=json.loads("{\"ok\":true,\"job\":{\"id\":\"job_ef725c8f8db3\",\"type\":\"job_result\",\"source\":\"script_run@host_299cf75f6b338ecd\",\"severity\":\"warning\",\"tool\":\"script_run\",\"host\":\"host_299cf75f6b338ecd\",\"status\":\"failed\",\"exit_code\":1,\"created_at\":1795650126.6851425,\"started_at\":\"2026-11-25T23:42:06.763580+00:00\",\"finished_at\":\"2026-11-25T23:42:08.567730+00:00\",\"duration_s\":1.8,\"error\":null,\"output_truncated\":false,\"timeout_s\":180,\"read\":false,\"notified\":{\"telegram\":null,\"resend\":null},\"notify_spec\":{},\"output\":\"Traceback (most recent call last):\\n  File \\\"/var/lib/sentinelx/uploads/.sentinelx_uploads/script_job_5fefefa58e384729b75c57b7fe3be610/pure_wrapper_actual01.py\\\", line 47, in <module>\\n    params=a['WFWorkflowActionParameters'];assert isinstance(params.get('UUID'),str);params.pop('UUID')\\n                                                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\nAssertionError\"}}")
write('prior-failed-owner.original.json',prior)
assert prior['job']['id']=='job_ef725c8f8db3' and prior['job']['status']=='failed' and prior['job']['exit_code']==1
assert "params.get('UUID')" in prior['job']['output']
q=json.loads((E.parent/'pure-actual-qualification-01/result.original.json').read_text())
protected={n:h((LIVE/n).read_bytes()) for n in q['k18Before']};assert protected==q['k18Before']
manifest=h((ST/'installation.json').read_bytes());assert manifest=='ccdc5ef66b0184a89ed62061e3e49ec1b36fe721d0b597fce6d65fd594d74e82'
def source():
 argv=['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W)]
 a=subprocess.run(argv+['rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
 b=subprocess.run(argv+['status','--porcelain'],capture_output=True,text=True,check=True).stdout
 assert a=='d58a55e81720b3396aa0c3cc868876eda22aea81' and b==''
 return a
source_before=source()
public=ST/'jobs/pure-public-smoke.cherri';packsrc=ST/'jobs/pure-pack-counterfactual.cherri'
assert h(public.read_bytes())=='55779c8f08eb2d2426fb695691d94bf3d488ebe14c097fbd9accbeda386b08d3'
assert h(packsrc.read_bytes())=='442f40c162d5b8a9b10f337b4cd6ac25463858bd7eb25ff58777561d0fb22bd7'
reused=[]
for label,sha in [('status','55112867515e46fd9cde18b23edf4341a3be39662ce18f4b529770d18916cf4f'),('compile-public','2112e3233f0d73d85b9a9264eee86f74a36dd28c884d5a2fe02a7863fb5fb523')]:
 d=P/label;b=(d/'process.original.json').read_bytes();assert h(b)==sha;r=json.loads(b)
 assert r['exitCode']==r['expectedExit']==0
 assert h((d/'stdout.original.bin').read_bytes())==r['stdoutSHA256']
 assert h((d/'stderr.original.bin').read_bytes())==r['stderrSHA256']
 reused.append({'label':label,'processPath':str(d/'process.original.json'),'sha256':sha})
status=json.loads((P/'status/stdout.original.bin').read_text());assert status['wrapperVersion']=='1.0.1'
rp=P/'compile-public/request-originals';rb=(rp/'result.original.json').read_bytes();assert h(rb)=='c2f5e5dc9c1f7fee4c1f1bc9083d73fac0140aaf6b72cc855b6a3df5923701b3';r=json.loads(rb)
assert r['status']=='COMPILED_UNSIGNED_PLIST' and r['process']['cleanup']['groupGone']
assert r['sourceSHA256']==h(public.read_bytes()) and r['engine']['binarySHA256']==h((ST/'bin/cherri').read_bytes())
art=(rp/'unsigned.shortcut').read_bytes();assert h(art)==r['artifact']['sha256']
baseline=E.parent/'pure-actual-qualification-01/products/pure-smoke/unsigned.shortcut'
actual=plistlib.loads(art)['WFWorkflowActions'];original=plistlib.loads(baseline.read_bytes())['WFWorkflowActions']
assert actual==original and len(actual)==1
assert actual[0]['WFWorkflowActionIdentifier']=='is.workflow.actions.gettext'
assert set(actual[0]['WFWorkflowActionParameters'])=={'WFTextActionText'}
write('actual-native-graph-comparison.original.json',{'status':'PASS_EXACT_FULL_GRAPH','actual':str(rp/'unsigned.shortcut'),'actualSHA256':h(art),'baseline':str(baseline),'baselineSHA256':h(baseline.read_bytes()),'exactEqual':True,'normalizedFields':[],'actions':actual,'oldOracleError':'New owner required a UUID on an unconsumed Text action; both unchanged actual graphs have no UUID.','reusedCommands':reused})
old=(P/'owner.original.py').read_bytes();assert h(old)=='809cf94cbfb9e832b9d531c17346dd3b5dd9b9e6a5cd60ad7dcde253eb5c6a7e'
fn=next(n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name=='run')
steps=[];requests=[]
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(P/'owner.original.py'),'exec'),globals())
started=time.monotonic();error=None;kind='FAILED';signed=b''
try:
 r=run('pure-reject-pack-call',ST/'bin/pure-cherri-service.sh',['compile',str(packsrc)],expected=1,request=True);assert r['status']=='FAILED' and r['process']['exitCode']!=0
 r=run('explicit-pack-call',ST/'bin/cherri-with-actions.sh',['enhanced','compile',str(packsrc)],request=True);assert r['status']=='COMPILED_UNSIGNED_PLIST'
 r=run('sign-public',ST/'bin/pure-cherri-service.sh',['sign',str(public)],request=True,limit=110)
 assert r['status']=='UPSTREAM_AEA1_FORMAT_ONLY' and r['cryptographicSignatureVerified'] is False
 signed=pathlib.Path(r['artifact']['path']).read_bytes();assert signed.startswith(b'AEA1') and len(signed)>4 and h(signed)==r['artifact']['sha256']
 assert manifest==h((ST/'installation.json').read_bytes()) and protected=={n:h((LIVE/n).read_bytes()) for n in protected}
 assert source()==source_before
 kind='PASS_WRAPPER_1_0_1_ACTUAL_JOINED'
except BaseException as e:
 error=type(e).__name__+': '+str(e);write('error.original.json',{'error':error,'traceback':traceback.format_exc()})
finally:
 report={'schema':'cherri-pure-wrapper-actual-current/2','status':kind,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller':source_before,'manifestSHA256':manifest,'priorFailedOwnerPreserved':True,'reusedActualCommands':reused,'newActualCommands':steps,'requests':requests,'totalDistinctCommands':len(reused)+len(steps),'oneRunClaim':False,'nativeGraphComparisonSHA256':h((E/'actual-native-graph-comparison.original.json').read_bytes()),'k18ProtectedFilesUnchanged':protected=={n:h((LIVE/n).read_bytes()) for n in protected},'liveMutation':False,'goExecuted':False,'signatureCredit':'AEA1 format only','nativeRuntimeCredit':False,'elapsedSeconds':time.monotonic()-started,'error':error}
 sha=write('result.original.json',report);print(json.dumps({'path':str(E/'result.original.json'),'sha256':sha,'status':kind,'reusedCommands':len(reused),'newCommands':len(steps),'signedBytes':len(signed),'error':error}))
if error:raise SystemExit(1)
