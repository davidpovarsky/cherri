import copy,datetime,hashlib,json,os,pathlib,plistlib,pwd,re,shutil,signal,stat,subprocess,time,traceback
ST=pathlib.Path("/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream")
PACK=ST/"apple-actions-pack"
E=pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-actual-qualification-01")
E.mkdir(mode=0o750);u=pwd.getpwnam("ubuntu");os.chown(E,u.pw_uid,u.pw_gid)
(E/"products").mkdir();(E/"steps").mkdir()
h=lambda b:hashlib.sha256(b).hexdigest()
def save(p,obj):
 raw=(json.dumps(obj,sort_keys=True,ensure_ascii=False,indent=2)+"\n").encode();p.write_bytes(raw);return h(raw)
save(E/"owner.original.json",{"scriptSHA256":h(pathlib.Path(__file__).read_bytes()),"controller":"735828d4a01c4ab1fe6cec430c675925d33a2dd0","upstream":"bcc0095754e2cc0baaeb4d93dae172b8153b4716","binarySHA256":"f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5","moduleChildTimeout":20,"entryChildTimeout":15,"wholeOwnerSeconds":330,"originalProducerExecuted":False,"description":"New replay of exact archived calls using the unchanged original source-generation templates; historical catalog remains unavailable."})
(E/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
def snapshot(root):
 return {str(p.relative_to(root)):{"sha256":h(p.read_bytes()),"bytes":p.stat().st_size,"mode":stat.S_IMODE(p.stat().st_mode),"uid":p.stat().st_uid,"gid":p.stat().st_gid,"mtimeNS":p.stat().st_mtime_ns} for p in root.rglob("*") if p.is_file() and ".git" not in p.relative_to(root).parts}
def resource():
 out={}
 for n,p in (("development","/mnt/development"),("root","/"),("shm","/dev/shm")):
  x=os.statvfs(p);out[n]=x.f_bavail*x.f_frsize
 out["MemAvailable"]=next(int(x.split()[1])*1024 for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:"))
 return out
floor={"development":768*1024**2,"root":768*1024**2,"shm":192*1024**2,"MemAvailable":2*1024**3}
start=time.monotonic();samples=[];steps=[];replay=[];controls=[]
def run(label,args,timeout=20,extra_env=None,cwd=None):
 assert time.monotonic()-start<330,"Whole owner deadline"
 z=resource();samples.append({"elapsedSeconds":time.monotonic()-start,**z});assert all(z[n]>=v for n,v in floor.items()),"Resource floor"
 d=E/"steps"/label;d.mkdir()
 argv=["/usr/sbin/runuser","-u","ubuntu","--",*args]
 begun=time.monotonic();p=None
 with (d/"stdout.original.bin").open("xb") as out,(d/"stderr.original.bin").open("xb") as err:
  p=subprocess.Popen(argv,cwd=cwd or ST,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",**(extra_env or {})),stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  timed=False
  try:p.wait(timeout=min(timeout,330-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
 o={"label":label,"argv":argv,"exitCode":p.returncode,"timedOut":timed,"elapsedSeconds":time.monotonic()-begun,"stdoutSHA256":h((d/"stdout.original.bin").read_bytes()),"stderrSHA256":h((d/"stderr.original.bin").read_bytes())}
 save(d/"result.original.json",o);steps.append(o);return o,(d/"stdout.original.bin").read_bytes(),(d/"stderr.original.bin").read_bytes()
def jobfile(name,data):
 p=ST/"jobs"/name
 assert not p.exists()
 p.write_bytes(data);p.chmod(0o600);os.chown(p,u.pw_uid,u.pw_gid);return p
def graph(data,ids,keys):
 assert not data.startswith(b"AEA1")
 x=plistlib.loads(data);a=x["WFWorkflowActions"]
 assert isinstance(a,list) and len(a)==len(ids)
 for i,q in enumerate(a):
  assert isinstance(q,dict) and q.get("WFWorkflowActionIdentifier")==ids[i]
  params=q.get("WFWorkflowActionParameters",{})
  assert isinstance(params,dict) and sorted(params)==keys[i]
 return x
def retain_requests(before,label):
 added=sorted(set((ST/"outputs").iterdir())-before)
 assert len(added)==1,(label,len(added))
 d=E/"products"/label;d.mkdir()
 for p in added[0].iterdir():
  if p.is_file():shutil.copyfile(p,d/p.name)
 r=json.loads((d/"result.original.json").read_bytes())
 request=pathlib.Path(r["requestDirectory"])
 source=pathlib.Path(r["source"])
 for p in request.iterdir():
  if p.is_file() and p.suffix==".cherri":shutil.copyfile(p,d/("input-"+p.name))
 return r
live=pathlib.Path("/mnt/development/projects/agent-workspaces/cherri-remote")
protected=["active.json","bin/cherri-remote-legacy.sh","bin/cherri-remote-runner.sh","bin/cherri-shortcut-lint.py","config/default-language-mode","tools/go/VERSION","tools/go/bin/go","tools/go/pkg/tool/linux_arm64/asm","tools/go/pkg/tool/linux_arm64/compile","tools/go/pkg/tool/linux_arm64/link"]
r={"schema":"cherri-pure-original-current-qualification/1","status":"FAILED","source":"bcc0095754e2cc0baaeb4d93dae172b8153b4716","controller":"735828d4a01c4ab1fe6cec430c675925d33a2dd0","freshBinarySHA256":"f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5","originalProducerExecuted":False,"nativeRuntimeCredit":False,"historicalBinaryRestored":False,"liveMutation":False,"steps":steps,"replay":replay,"controls":controls}
held=E/"pack-held-for-default-isolation";pack_before=None;source_before=None;docs_before=None
try:
 assert h((ST/"bin/cherri").read_bytes())==r["freshBinarySHA256"]
 assert h((ST/"installation.json").read_bytes())=="6ce1f04579c4182aff2c9470b866a2dbed6cb475c394c59236139c6efd4d7992"
 live_before={n:h((live/n).read_bytes()) for n in protected};assert live_before["active.json"]=="6b9fdfe037a0acccc8a782c649770bf927e96a493bb21af36041274ccb0d4258"
 r["k18Before"]=live_before
 pack_before=snapshot(PACK);source_before=snapshot(ST/"src");docs_before=snapshot(ST/"docs")
 r["packBeforeSHA256"]=save(E/"pack-before.original.json",pack_before)
 r["sourceBeforeSHA256"]=save(E/"source-before.original.json",source_before);r["docsBeforeSHA256"]=save(E/"docs-before.original.json",docs_before)
 prior=json.loads((PACK/"entry-verification.json").read_bytes())
 mods=json.loads((PACK/"module-verification.json").read_bytes())
 assert len(prior)==204 and len(mods)==21
 assert h((PACK/"entry-verification.json").read_bytes())=="18751d74b8cdc251f48d8234540e61d6da75dd744c84425b4cc38db2f2795e8f"
 assert h((PACK/"module-verification.json").read_bytes())=="29dc3d20d8b0f0c461692d6a5e445c68876371b5c7f20006decffb3da9dcbf35"
 assert all(x["ok"] and not x["missingKeys"] and x["actualActionId"]==x["expectedActionId"] for x in prior)
 assert len({(x["module"],x["alias"] or x["name"],x["variant"]) for x in prior})==204
 shutil.copyfile(PACK/"entry-verification.json",E/"historical-entry-records.original.json")
 shutil.copyfile(PACK/"module-verification.json",E/"historical-module-records.original.json")
 for label,args in (("pure-status",[str(ST/"bin/pure-cherri-service.sh"),"status"]),("pure-docs",[str(ST/"bin/pure-cherri-service.sh"),"docs","text"]),("pack-verify",[str(ST/"bin/cherri-with-actions.sh"),"verify"])):
  step,out,err=run(label,args);assert step["exitCode"]==0,(label,err.decode());controls.append({"name":label,"status":"PASS"})
 smoke=jobfile("pure-public-smoke.cherri",b'#define name PurePublicProbe\ntext("Pure upstream public probe")\n')
 extension=jobfile("pure-pack-counterfactual.cherri",b'#define name PurePackCounterfactual\ngetType(Ask)\n')
 inputs_before={str(p):h(p.read_bytes()) for p in (smoke,extension)}
 old=set((ST/"outputs").iterdir());s,out,err=run("pure-smoke",[str(ST/"bin/pure-cherri-service.sh"),"compile",str(smoke)],timeout=30);q=retain_requests(old,"pure-smoke");assert s["exitCode"]==0 and q["status"]=="COMPILED_UNSIGNED_PLIST",(s,err.decode())
 graph((E/"products/pure-smoke/unsigned.shortcut").read_bytes(),["is.workflow.actions.gettext"],[["WFTextActionText"]]);controls.append({"name":"pure-smoke","status":"PASS","request":q})
 old=set((ST/"outputs").iterdir());s,out,err=run("pure-pack-action-rejected",[str(ST/"bin/pure-cherri-service.sh"),"compile",str(extension)],timeout=30);q=retain_requests(old,"pure-pack-action-rejected")
 assert s["exitCode"]!=0 and q["process"]["exitCode"]!=0 and "artifact" not in q
 controls.append({"name":"pure-pack-action-rejected","status":"PASS_EXPECTED_UPSTREAM_REJECTION","request":q})
 old=set((ST/"outputs").iterdir());s,out,err=run("pack-same-call-accepted",[str(ST/"bin/cherri-with-actions.sh"),"enhanced","compile",str(extension)],timeout=30);q=retain_requests(old,"pack-same-call-accepted")
 assert s["exitCode"]==0 and q["status"]=="COMPILED_UNSIGNED_PLIST",(s,err.decode())
 graph((E/"products/pack-same-call-accepted/unsigned.shortcut").read_bytes(),["is.workflow.actions.gettypeaction"],[["WFInput"]]);controls.append({"name":"pack-same-call-accepted","status":"PASS","request":q})
 assert {str(p):h(p.read_bytes()) for p in (smoke,extension)}==inputs_before
 home=E/"alias-home";logical=home/"workspaces/cherri-remote";logical.parent.mkdir(parents=True);logical.symlink_to(ST.parent,target_is_directory=True)
 s,out,err=run("original-pack-alias-guard-red",["/usr/bin/env","HOME="+str(home),"/bin/bash",str(PACK/"bin/cherri-with-actions.sh"),"enhanced","compile",str(extension)],timeout=30)
 assert s["exitCode"]!=0 and b"Source must be under" in err,(s,err.decode())
 controls.append({"name":"original-pack-alias-guard-red","status":"EXPECTED_RED_WITH_ACTUAL_BINARY"})
 PACK.rename(held)
 try:
  s,out,err=run("pure-verify-without-pack",[str(ST/"bin/pure-cherri-service.sh"),"verify"]);assert s["exitCode"]==0
  controls.append({"name":"pure-verify-without-pack","status":"PASS"})
  old=set((ST/"outputs").iterdir());s,out,err=run("pure-compile-without-pack",[str(ST/"bin/pure-cherri-service.sh"),"compile",str(smoke)],timeout=30);q=retain_requests(old,"pure-compile-without-pack")
  assert s["exitCode"]==0 and q["status"]=="COMPILED_UNSIGNED_PLIST"
  graph((E/"products/pure-compile-without-pack/unsigned.shortcut").read_bytes(),["is.workflow.actions.gettext"],[["WFTextActionText"]])
  controls.append({"name":"pure-compile-without-pack","status":"PASS"})
  s,out,err=run("pack-missing-fails-closed",[str(ST/"bin/cherri-with-actions.sh"),"verify"]);assert s["exitCode"]!=0
  controls.append({"name":"pack-missing-fails-closed","status":"PASS_EXPECTED_REJECTION"})
 finally:held.rename(PACK)
 J=ST/"jobs/preserved-pack-source-replay-01";J.mkdir(mode=0o700);os.chown(J,u.pw_uid,u.pw_gid)
 for p in (PACK/"modules").glob("*.cherri"):
  q=J/p.name;shutil.copyfile(p,q);q.chmod(0o600);os.chown(q,u.pw_uid,u.pw_gid)
 cases=[]
 for x in mods:
  assert x["ok"] and x["return"]==0
  code="#define name "+x["name"]+"\n"+"".join("#include '"+n+".cherri'\n" for n in x["modules"])+'show("probe")\n'
  cases.append({"group":"module","label":x["name"],"source":code,"expectedIDs":x["actions"],"expectedKeys":x["native_keys"],"timeout":20})
 for x in prior:
  target=x["alias"] or x["name"];label=re.sub("[^a-zA-Z0-9]","",target)+("Full" if x["variant"]=="full" else "Min")
  code="#define name "+label+"\n#include '"+x["module"]+".cherri'\n"+x["call"]+"\n"
  assert x["actions"]==1
  cases.append({"group":"entry","label":label,"source":code,"expectedIDs":[x["expectedActionId"]],"expectedKeys":[x["nativeKeys"]],"timeout":15,"historicalCall":x["call"],"variant":x["variant"],"originalName":x["name"]})
 assert len(cases)==225 and len({x["label"] for x in cases})==225
 r["sourceSelectionSHA256"]=save(E/"source-selection.original.json",cases)
 for case in cases:
  label=case["label"];src=J/(label+".cherri");src.write_text(case["source"]);src.chmod(0o600);os.chown(src,u.pw_uid,u.pw_gid)
  d=E/"products"/label;d.mkdir();shutil.copyfile(src,d/"source.original.cherri")
  s,out,err=run("replay-"+label,[str(ST/"bin/cherri"),str(src),"--skip-sign","--no-ansi"],timeout=case["timeout"],cwd=J)
  record={"label":label,"group":case["group"],"status":"FAILED","sourceSHA256":h(src.read_bytes()),"step":s}
  artifact=J/(label+"_unsigned.shortcut")
  try:
   assert s["exitCode"]==0 and not s["timedOut"],(s,err.decode()[-1000:])
   raw=artifact.read_bytes();shutil.copyfile(artifact,d/"unsigned.original.shortcut")
   graph(raw,case["expectedIDs"],case["expectedKeys"])
   assert src.read_text()==case["source"]
   record.update(status="PASS",artifactSHA256=h(raw),artifactBytes=len(raw),actualActions=len(case["expectedIDs"]))
  except Exception as ex:record["error"]=str(ex)
  save(d/"result.original.json",record);replay.append(record)
 r["replayPassed"]=sum(x["status"]=="PASS" for x in replay);r["replayFailed"]=[x["label"] for x in replay if x["status"]!="PASS"]
 assert r["replayPassed"]==225,r["replayFailed"]
 sample=next(x for x in cases if x["group"]=="entry" and len(x["expectedKeys"][0])>=3)
 original=plistlib.loads((E/"products"/sample["label"]/"unsigned.original.shortcut").read_bytes())
 mutations=[]
 for name in ("wrong-action-id","missing-native-key","extra-native-key","wrong-action-count","non-list-actions","malformed-parameters"):
  m=copy.deepcopy(original);a=m["WFWorkflowActions"]
  if name=="wrong-action-id":a[0]["WFWorkflowActionIdentifier"]="invalid.original.action"
  elif name=="missing-native-key":a[0]["WFWorkflowActionParameters"].pop(sample["expectedKeys"][0][0])
  elif name=="extra-native-key":a[0]["WFWorkflowActionParameters"]["UNEXPECTED_ORACLE_CONTROL"]=True
  elif name=="wrong-action-count":a.append(copy.deepcopy(a[0]))
  elif name=="non-list-actions":m["WFWorkflowActions"]={}
  else:a[0]["WFWorkflowActionParameters"]=[]
  raw=plistlib.dumps(m)
  rejected=False
  try:graph(raw,sample["expectedIDs"],sample["expectedKeys"])
  except (AssertionError,KeyError,TypeError,ValueError):rejected=True
  assert rejected,name
  mutations.append({"name":name,"status":"REJECTED","faultyGraphSHA256":h(raw)})
 r["causalFaults"]=mutations
 s,out,err=run("pure-final-verify",[str(ST/"bin/pure-cherri-service.sh"),"verify"]);assert s["exitCode"]==0
 s,out,err=run("pack-final-verify",[str(ST/"bin/cherri-with-actions.sh"),"verify"]);assert s["exitCode"]==0
 assert snapshot(PACK)==pack_before and snapshot(ST/"src")==source_before and snapshot(ST/"docs")==docs_before
 assert h((ST/"bin/cherri").read_bytes())==r["freshBinarySHA256"]
 assert {n:h((live/n).read_bytes()) for n in protected}==live_before
 r["status"]="PASS_SOURCE_QUALIFIED_PURE_AND_PACK";r["upstreamUnchanged"]=True;r["packUnchanged"]=True;r["k18Unchanged"]=True
except Exception as ex:
 r["error"]=str(ex);(E/"exception.original.txt").write_text(traceback.format_exc())
finally:
 if held.exists() and not PACK.exists():held.rename(PACK)
 r["resourceSamplesSHA256"]=save(E/"resources.original.json",samples)
 r["elapsedSeconds"]=time.monotonic()-start;r["finishedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r["modulePasses"]=sum(x["status"]=="PASS" and x["group"]=="module" for x in replay)
 r["entryPasses"]=sum(x["status"]=="PASS" and x["group"]=="entry" for x in replay)
 r["controlCount"]=len(controls)
 if pack_before is not None:r["packUnchangedAtExit"]=snapshot(PACK)==pack_before
 sha=save(E/"result.original.json",r)
 print(json.dumps({"status":r["status"],"error":r.get("error"),"modulePasses":r["modulePasses"],"entryPasses":r["entryPasses"],"controls":len(controls),"causalFaults":len(r.get("causalFaults",[])),"elapsedSeconds":r["elapsedSeconds"],"receiptSHA256":sha,"packUnchangedAtExit":r.get("packUnchangedAtExit")}))
