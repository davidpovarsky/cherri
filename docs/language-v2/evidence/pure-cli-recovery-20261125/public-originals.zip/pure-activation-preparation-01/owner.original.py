import pathlib,json,hashlib,os,stat,subprocess,datetime
S=pathlib.Path("/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream")
E=pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-activation-preparation-01");E.mkdir(mode=0o700)
L=pathlib.Path("/mnt/development/projects/agent-workspaces/cherri-remote")
A=pathlib.Path("/home/chatgpt-agent/workspaces/cherri-remote")
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(E/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
assert not os.path.lexists(L/"pure-upstream")
assert h(S/"installation.json")=="ccdc5ef66b0184a89ed62061e3e49ec1b36fe721d0b597fce6d65fd594d74e82"
rows=[]
for p in [S,*sorted(S.rglob("*"))]:
 st=p.lstat();r={"path":str(p.relative_to(S)),"mode":stat.S_IMODE(st.st_mode),"uid":st.st_uid,"gid":st.st_gid,"mtimeNS":st.st_mtime_ns,"inode":st.st_ino,"device":st.st_dev,"size":st.st_size,"nlink":st.st_nlink}
 if stat.S_ISREG(st.st_mode):r.update(kind="file",sha256=h(p))
 elif stat.S_ISDIR(st.st_mode):r["kind"]="directory"
 else:raise AssertionError(("unexpected file type",str(p)))
 rows.append(r)
b=(json.dumps(rows,indent=2)+"\n").encode();(E/"stage-physical-before.original.json").write_bytes(b)
hard=[r for r in rows if r["kind"]=="file" and r["nlink"]!=1]
q=json.loads((E.parent/"pure-actual-qualification-01/result.original.json").read_text())
protected={k:h(L/k) for k in q["k18Before"]};assert protected==q["k18Before"]
extra={"p15-s627c-d16-k18-20261125/runtime/bin/cherri":"7d7cfb5e44cc667e7f164192090ef21b031f992f61be802a563b2cc75cdbbdd8","p15-s627c-d16-k18-20261125/runtime/bin/cherri-migrate":"d40086414f33251bae70a2c047e1691709de1b002712123aeb5ef3e1b6bfb3b6"}
for k,v in extra.items():assert h(L/k)==v
sa=A.lstat();alias={"path":str(A),"target":os.readlink(A),"mode":stat.S_IMODE(sa.st_mode),"uid":sa.st_uid,"gid":sa.st_gid,"mtimeNS":sa.st_mtime_ns,"inode":sa.st_ino,"device":sa.st_dev};assert A.resolve()==L
active=[]
for p in pathlib.Path("/proc").iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:
  cwd=os.readlink(p/"cwd");cmd=(p/"cmdline").read_bytes().replace(b"\0",b" ").decode(errors="replace")
 except (OSError,PermissionError):continue
 if cwd==str(S) or cwd.startswith(str(S)+"/") or str(S)+"/bin/" in cmd or str(S)+"/lib/" in cmd:active.append({"pid":int(p.name),"cwd":cwd,"comm":(p/"comm").read_text().strip()})
assert not active,active
r={"schema":"cherri-pure-activation-preflight/1","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"status":"READY_NO_SHARED_INODES" if not hard else "HOLD_SHARED_INODES","source":str(S),"target":str(L/"pure-upstream"),"manifestSHA256":h(S/"installation.json"),"inventorySHA256":hashlib.sha256(b).hexdigest(),"entries":len(rows),"files":sum(r["kind"]=="file" for r in rows),"bytes":sum(r["size"] for r in rows if r["kind"]=="file"),"ownerPairs":sorted({(r["uid"],r["gid"]) for r in rows}),"hardlinkedFiles":hard,"protected":protected|extra,"alias":alias,"sameFilesystem":S.stat().st_dev==L.stat().st_dev,"activeProcesses":active,"liveAbsent":True}
out=(json.dumps(r,indent=2)+"\n").encode();(E/"result.original.json").write_bytes(out)
print(json.dumps({"path":str(E/"result.original.json"),"sha256":hashlib.sha256(out).hexdigest(),"status":r["status"],"entries":len(rows),"files":r["files"],"bytes":r["bytes"],"owners":r["ownerPairs"],"hardlinkedFiles":hard[:5]}))
