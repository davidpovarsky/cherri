import pathlib,hashlib,json,subprocess,ast,os,time
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-process-lifecycle-replay-01')
E.mkdir(mode=0o755);os.chown(E,1001,1001);(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
def g(*a):
 p=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],capture_output=True,text=True,timeout=20)
 assert p.returncode==0,p.stderr
 return p.stdout.strip()
sha='675d62f0aeb22cad650a261790e42ab3e028dcc4'
assert g('rev-parse','HEAD')==sha and not g('status','--porcelain=v1','--untracked-files=all')
names=('service.py','test_execute.py','test_service.py','assemble.py','pack_adapter.py')
pins={n:hashlib.sha256((W/'tools/pure_remote'/n).read_bytes()).hexdigest() for n in names}
for n in ('service.py','test_execute.py'):(E/n).write_bytes((W/'tools/pure_remote'/n).read_bytes())
(E/'controls').mkdir();os.chown(E/'controls',1001,1001)
runner=(E.parent/'pure-process-lifecycle-red-01/runner.original.py').read_text()
old='suite=unittest.defaultTestLoader.loadTestsFromTestCase(test_execute.PureExecuteLifecycleTests)'
assert runner.count(old)==1
runner=runner.replace(old,"import test_service\nsuite=unittest.TestSuite([test_execute.PureExecuteLifecycleTests('test_timeout_direct_preserves_unrelated_owned_control'),unittest.defaultTestLoader.loadTestsFromModule(test_service)])")
(E/'runner.original.py').write_text(runner)
expected=['test_execute.PureExecuteLifecycleTests.test_timeout_direct_preserves_unrelated_owned_control']
tree=ast.parse((W/'tools/pure_remote/test_service.py').read_text())
for cls in tree.body:
 if isinstance(cls,ast.ClassDef):
  expected.extend('test_service.'+cls.name+'.'+fn.name for fn in cls.body if isinstance(fn,ast.FunctionDef) and fn.name.startswith('test_'))
assert len(expected)==32
(E/'selection.original.json').write_text(json.dumps({'source':sha,'expectedIDs':sorted(expected),'sourcePins':pins},indent=2))
argv=['/usr/sbin/runuser','-u','ubuntu','--','env','PYTHONDONTWRITEBYTECODE=1','PYTHONPATH='+str(W/'tools/pure_remote'),'PURE_EXECUTE_CONTROL_OUT='+str(E/'controls'),'/usr/bin/python3','-B',str(E/'runner.original.py')]
start=time.monotonic()
with (E/'stdout.original.bin').open('xb') as so,(E/'stderr.original.bin').open('xb') as se:
 p=subprocess.run(argv,cwd=E,stdout=so,stderr=se,timeout=90)
events=json.loads((E/'events.original.json').read_text())
stable=g('rev-parse','HEAD')==sha and not g('status','--porcelain=v1','--untracked-files=all') and pins=={n:hashlib.sha256((W/'tools/pure_remote'/n).read_bytes()).hexdigest() for n in names}
passed=p.returncode==0 and len(events)==32 and {x['id']:x['status'] for x in events}=={x:'PASS' for x in expected} and stable
r={'schema':'cherri-pure-lifecycle-focused-replay/1','status':'PASS_EXACT_32' if passed else 'FAILED','source':sha,'sourceStable':stable,'sourcePins':pins,'productionEquivalentTo':'eee6ce1f3860ce59fad731033454ab33aeaf2418','testOnlyCorrection':'Atomic publication of child identity JSON; no PID/start/PGID assertions removed.','exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'argv':argv,'events':events,'originals':{n:hashlib.sha256((E/n).read_bytes()).hexdigest() for n in ('stdout.original.bin','stderr.original.bin','events.original.json','selection.original.json','runner.original.py','owner.original.py')}}
b=(json.dumps(r,indent=2)+'\n').encode();(E/'result.original.json').write_bytes(b)
print(json.dumps({'path':str(E/'result.original.json'),'sha256':hashlib.sha256(b).hexdigest(),'status':r['status'],'elapsedSeconds':r['elapsedSeconds'],'events':len(events),'nonPass':[x for x in events if x['status']!='PASS']}))
raise SystemExit(0 if passed else 1)
