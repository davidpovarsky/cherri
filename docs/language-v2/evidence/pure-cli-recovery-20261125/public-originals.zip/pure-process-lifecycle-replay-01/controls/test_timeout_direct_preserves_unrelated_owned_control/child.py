
import json, os, pathlib, signal, subprocess, sys, time
mode, directory = sys.argv[1:]
root = pathlib.Path(directory)
def pin(name):
    raw = pathlib.Path('/proc/%d/stat' % os.getpid()).read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    pending = root / (name + '.pending')
    pending.write_text(json.dumps({
        'pid': os.getpid(), 'pgid': os.getpgrp(), 'sid': os.getsid(0),
        'start': fields[19]}))
    pending.replace(root / (name + '.json'))
if mode == 'grandchild':
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    pin('grandchild')
    time.sleep(30)
elif mode in ('descendant_timeout', 'descendant_success'):
    subprocess.Popen([sys.executable, __file__, 'grandchild', directory])
    pin('leader')
    deadline = time.monotonic() + 8
    while not (root / 'grandchild.json').exists():
        if time.monotonic() > deadline:
            raise RuntimeError('grandchild did not become ready')
        time.sleep(.01)
    if mode == 'descendant_success':
        sys.exit(0)
    time.sleep(30)
elif mode == 'direct_stubborn':
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    pin('leader')
    time.sleep(30)
elif mode == 'direct':
    pin('leader')
    time.sleep(30)
elif mode == 'success':
    pin('leader')
    print('actual child stdout', flush=True)
    print('actual child stderr', file=sys.stderr, flush=True)
elif mode == 'nonzero':
    pin('leader')
    sys.exit(7)
else:
    raise RuntimeError('unknown child mode')
