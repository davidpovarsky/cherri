import pathlib,json,hashlib,os,stat,plistlib,datetime,subprocess
E=pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-live-independent-intake-03");E.mkdir(mode=0o700)
C=E.parent/"pure-activation-cycle-01";P=E.parent/"pure-activation-preparation-01";L=pathlib.Path("/mnt/development/projects/agent-workspaces/cherri-remote");T=L/"pure-upstream";S=pathlib.Path("/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream")
A=pathlib.Path("/home/chatgpt-agent/workspaces/cherri-remote")
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):
 raw=(json.dumps(value,indent=2)+"\n").encode()
 with (E/name).open("xb") as f:f.write(raw)
 return hashlib.sha256(raw).hexdigest()
(E/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
terminal=json.loads("{\"ok\":true,\"job\":{\"id\":\"job_1e9f151bc058\",\"type\":\"job_result\",\"source\":\"script_run@host_299cf75f6b338ecd\",\"severity\":\"info\",\"tool\":\"script_run\",\"host\":\"host_299cf75f6b338ecd\",\"status\":\"succeeded\",\"exit_code\":0,\"created_at\":1795650890.9033628,\"started_at\":\"2026-11-25T23:54:50.982405+00:00\",\"finished_at\":\"2026-11-25T23:55:16.636936+00:00\",\"duration_s\":25.65,\"error\":null,\"output_truncated\":false,\"timeout_s\":240,\"read\":false,\"notified\":{\"telegram\":null,\"resend\":null},\"notify_spec\":{},\"output\":\"{\\\"path\\\": \\\"/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-activation-cycle-01/result.original.json\\\", \\\"sha256\\\": \\\"b9120c29e72ff282b2d21d7a446ff1818d0472eb1647b3076706c71df3df32d5\\\", \\\"status\\\": \\\"PASS_ACTIVATE_ROLLBACK_REAPPLY\\\", \\\"commands\\\": 10, \\\"phases\\\": 3, \\\"error\\\": null, \\\"recovery\\\": null}\"}}")
put("activation-job.original.json",terminal)
assert terminal["job"]["id"]=="job_1e9f151bc058" and terminal["job"]["status"]=="succeeded" and terminal["job"]["exit_code"]==0
assert h(C/"result.original.json")=="b9120c29e72ff282b2d21d7a446ff1818d0472eb1647b3076706c71df3df32d5"
cycle=json.loads((C/"result.original.json").read_text());assert cycle["status"]=="PASS_ACTIVATE_ROLLBACK_REAPPLY" and cycle["error"] is None
assert h(P/"result.original.json")=="8b06372af35edfc0a0fb91c1502a4a861c20de87f0923b62cfcc815a0f265e1d"
prep=json.loads((P/"result.original.json").read_text());assert h(P/"stage-physical-before.original.json")==prep["inventorySHA256"]
before=json.loads((P/"stage-physical-before.original.json").read_text())
assert len(before)==1096 and sum(x["kind"]=="file" for x in before)==955
assert h(C/"live-physical-after.original.json")==cycle["finalPhysicalInventorySHA256"]
after=json.loads((C/"live-physical-after.original.json").read_text());current_names={str(p.relative_to(T)) for p in [T,*T.rglob("*")]}
assert current_names=={x["path"] for x in after}
for x in after:
 p=T/x["path"];s=p.lstat()
 assert (s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode),s.st_mtime_ns,s.st_ino,s.st_dev)==(x["uid"],x["gid"],x["mode"],x["mtimeNS"],x["inode"],x["device"]),x["path"]
 assert (s.st_uid,s.st_gid)==(1002,1002)
 if x["kind"]=="file":assert s.st_nlink==1 and h(p)==x["sha256"] and s.st_size==x["size"]
after_by={x["path"]:x for x in after}
for x in before:
 y=after_by[x["path"]]
 assert (x["inode"],x["device"],x["mode"])==(y["inode"],y["device"],y["mode"])
 if x["kind"]=="file":assert (x["sha256"],x["size"],x["mtimeNS"])==(y["sha256"],y["size"],y["mtimeNS"])
for phase,status in zip(cycle["phases"],["ACTIVATED_EXACT_FRESH_PURE","ROLLED_BACK_TO_EXACT_STAGED_BASELINE","ACTIVATED_EXACT_FRESH_PURE"]):
 p=pathlib.Path(phase["path"]);assert h(p)==phase["sha256"]
 value=json.loads(p.read_text());assert value["status"]==status and value["k18AndAliasUnchanged"] is True
rb=json.loads(pathlib.Path(cycle["phases"][1]["path"]).read_text());assert rb["originalFilesModesOwnersMtimesRestored"] is True and rb["liveAbsent"] is True
assert h(C/"phase1-requests.original.json")==rb["requestManifestSHA256"]
ids=json.loads((C/"phase1-requests.original.json").read_text())["requestIDs"];assert len(ids)==2 and len(set(ids))==2
for link in rb["newRequestOriginalsPreserved"]:
 p=pathlib.Path(link["to"]);assert p.is_dir()
 assert p.name in ids
expected=["activated-status","activated-alias-status","activated-pack-verify","activated-pure-compile","activated-explicit-pack-compile","rolled-back-staged-status","reapplied-status","reapplied-alias-status","reapplied-pack-verify","reapplied-pure-compile"]
assert [x["label"] for x in cycle["actualCLICommands"]]==expected
products=[]
for x in cycle["actualCLICommands"]:
 d=C/x["label"];assert x==json.loads((d/"process.original.json").read_text())
 assert x["exitCode"]==0 and h(d/"stdout.original.bin")==x["stdoutSHA256"] and h(d/"stderr.original.bin")==x["stderrSHA256"]
 assert x["argv"][:4]==["/usr/sbin/runuser","-u","ubuntu" if x["label"]=="rolled-back-staged-status" else "chatgpt-agent","--"]
 if x["label"].endswith("status"):
  result=json.loads((d/"stdout.original.bin").read_text())
  assert result["wrapperVersion"]=="1.0.1" and result["source"]=="bcc0095754e2cc0baaeb4d93dae172b8153b4716" and result["packLoaded"] is False
 if x["label"].endswith("compile"):
  rdir=d/"request-originals";req=json.loads((rdir/"result.original.json").read_text())
  assert req["status"]=="COMPILED_UNSIGNED_PLIST" and req["wrapperVersion"]=="1.0.1"
  proc=json.loads((rdir/"process.original.json").read_text());assert proc==req["process"]
  assert proc["exitCode"]==0 and proc["cleanup"]["groupGone"] is True and not proc["cancelled"] and not proc["timedOut"]
  assert h(rdir/"stdout.original.bin")==req["stdoutSHA256"] and h(rdir/"stderr.original.bin")==req["stderrSHA256"]
  art=rdir/"unsigned.shortcut";assert h(art)==req["artifact"]["sha256"]
  baseline=E.parent/"pure-actual-qualification-01/products"/("pack-same-call-accepted" if "explicit-pack" in x["label"] else "pure-smoke")/"unsigned.shortcut"
  actions=plistlib.loads(art.read_bytes())["WFWorkflowActions"];assert actions==plistlib.loads(baseline.read_bytes())["WFWorkflowActions"]
  assert len(actions)==req["actions"]==1
  inputs=sorted(rdir.glob("input-*.cherri"));main=rdir/("input-"+pathlib.Path(req["source"]).name)
  assert main in inputs and h(main)==req["sourceSHA256"]
  if "explicit-pack" in x["label"]:
   assert len(inputs)==22
   import re
   pack=T/"apple-actions-pack";script=pack/"bin/cherri-with-actions.sh"
   assert h(script)=="bf0b491a012b46140af31203aaaede4dc4bf0ff3fd4ad88318a512030f4a5e8e"
   categories=re.findall(r"for category in ([a-z ]+); do",script.read_text());assert len(categories)==1
   modules=sorted((pack/"modules").glob("*.cherri"));assert len(modules)==20
   expected_index="".join("#include 'actions/"+category+"'\n" for category in categories[0].split())+"".join("#include '"+module.name+"'\n" for module in modules)
   assert (rdir/"input-apple-actions-pack-index.cherri").read_bytes()==expected_index.encode()
   for dependency in inputs:
    if dependency==main or dependency.name=="input-apple-actions-pack-index.cherri":continue
    original=pack/"modules"/dependency.name.removeprefix("input-")
    assert original in modules and h(dependency)==h(original),dependency.name
   assert req["sourceSHA256"]=="37579247ffd353b04f69f09849c741349fc26000fcc078cb45c4aa5d45a2e964"
  else:assert inputs==[main]
  products.append({"label":x["label"],"artifactSHA256":h(art),"originalSourceSHA256":req["sourceSHA256"],"exactNativeGraphEqualToQualifiedBaseline":True,"normalizedFields":[]})
for name,digest in prep["protected"].items():assert h(L/name)==digest
sa=A.lstat();alias=prep["alias"];assert os.readlink(A)==alias["target"] and (sa.st_uid,sa.st_gid,sa.st_ino,sa.st_dev,sa.st_mtime_ns)==(alias["uid"],alias["gid"],alias["inode"],alias["device"],alias["mtimeNS"])
assert not os.path.lexists(S) and T.is_dir()
manifest=json.loads((T/"installation.json").read_text());assert h(T/"installation.json")==cycle["manifestSHA256"]=="ccdc5ef66b0184a89ed62061e3e49ec1b36fe721d0b597fce6d65fd594d74e82"
for name,digest in manifest["files"].items():assert h(T/name)==digest
proofs={"qualification":"b4dc26752faa731c8885526f9758811a32c269adf633ec7f36321b2fbc3b8532","actualCurrent":"0558d1cf9e691503bc122fe3a1df203e60bf6f55fb5c4fdc1122142436c98b19"}
assert h(E.parent/"pure-independent-intake-04/result.original.json")==proofs["qualification"]
assert h(E.parent/"pure-wrapper-1.0.1-actual-02/result.original.json")==proofs["actualCurrent"]
report={"schema":"cherri-pure-live-independent-intake/1","status":"PASS_CURRENT_LIVE_FRESH_PURE","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"controller":manifest["controllerSource"],"binarySHA256":manifest["files"]["bin/cherri"],"manifestSHA256":h(T/"installation.json"),"liveRoot":str(T),"liveOwner":1002,"originalPreexistingFilesVerified":955,"currentFilesVerified":sum(x["kind"]=="file" for x in after),"exactExistingFileBytesModesMtimesPreserved":True,"actualCLICommands":10,"threeNativeGraphsExactlyEqual":products,"actualRollbackAndReapply":True,"k18ProtectedCount":len(prep["protected"]),"k18AndAliasUnchanged":True,"phaseReceipts":cycle["phases"],"cycleResultSHA256":h(C/"result.original.json"),"qualificationProofs":proofs,"freshBuild":True,"historicalBinaryRestored":False,"goExecuted":False,"newServicesOrListeners":False,"nativeRuntimeCredit":False,"finalCherriTupleCredit":False}
digest=put("result.original.json",report)
print(json.dumps({"path":str(E/"result.original.json"),"sha256":digest,"status":report["status"],"files":report["currentFilesVerified"],"commands":10,"graphs":len(products)}))
