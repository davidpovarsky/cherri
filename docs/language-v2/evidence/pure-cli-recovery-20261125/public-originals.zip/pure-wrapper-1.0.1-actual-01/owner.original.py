import pathlib,json,hashlib,subprocess,os,time,plistlib,signal,shutil,datetime
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-wrapper-1.0.1-actual-01');E.mkdir(mode=0o750)
ST=pathlib.Path('/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream');LIVE=pathlib.Path('/mnt/development/projects/agent-workspaces/cherri-remote')
(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
h=lambda b:hashlib.sha256(b).hexdigest()
q=json.loads((E.parent/'pure-actual-qualification-01/result.original.json').read_text())
protected={n:h((LIVE/n).read_bytes()) for n in q['k18Before']};assert protected==q['k18Before']
manifest=h((ST/'installation.json').read_bytes());assert manifest=='ccdc5ef66b0184a89ed62061e3e49ec1b36fe721d0b597fce6d65fd594d74e82'
public=ST/'jobs/pure-public-smoke.cherri';packsrc=ST/'jobs/pure-pack-counterfactual.cherri'
assert h(public.read_bytes())=='55779c8f08eb2d2426fb695691d94bf3d488ebe14c097fbd9accbeda386b08d3'
assert h(packsrc.read_bytes())=='442f40c162d5b8a9b10f337b4cd6ac25463858bd7eb25ff58777561d0fb22bd7'
steps=[];requests=[]
def run(label,exe,args,expected=0,request=False,limit=25):
 d=E/label;d.mkdir()
 before=set((ST/'outputs').iterdir())
 argv=['/usr/sbin/runuser','-u','ubuntu','--','env','GIT_OPTIONAL_LOCKS=0','PYTHONDONTWRITEBYTECODE=1',str(exe),*args]
 start=time.monotonic()
 with (d/'stdout.original.bin').open('xb') as so,(d/'stderr.original.bin').open('xb') as se:
  p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
  try:p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 rec={'label':label,'argv':argv,'exitCode':p.returncode,'expectedExit':expected,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':h((d/'stdout.original.bin').read_bytes()),'stderrSHA256':h((d/'stderr.original.bin').read_bytes())}
 (d/'process.original.json').write_text(json.dumps(rec,indent=2));steps.append(rec)
 assert p.returncode==expected,(label,p.returncode,(d/'stderr.original.bin').read_text()[-500:])
 if request:
  added=set((ST/'outputs').iterdir())-before;assert len(added)==1
  root=added.pop();r=json.loads((root/'result.original.json').read_text())
  assert r['wrapperVersion']=='1.0.1' and r['engine']['binarySHA256']=='f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5'
  assert r['process']['cleanup']['groupGone'] and not r['process']['cancelled'] and not r['process']['timedOut']
  product=d/'request-originals';shutil.copytree(root,product)
  for f in pathlib.Path(r['requestDirectory']).glob('*.cherri'):shutil.copyfile(f,product/('input-'+f.name))
  requests.append({'label':label,'result':r,'preservedDirectory':str(product)})
  return r
 return json.loads((d/'stdout.original.bin').read_text())
r=run('status',ST/'bin/pure-cherri-service.sh',['status']);assert r['wrapperVersion']=='1.0.1'
r=run('compile-public',ST/'bin/pure-cherri-service.sh',['compile',str(public)],request=True)
assert r['status']=='COMPILED_UNSIGNED_PLIST'
art=pathlib.Path(r['artifact']['path']).read_bytes();assert h(art)==r['artifact']['sha256']
actual=plistlib.loads(art)['WFWorkflowActions'];baseline=plistlib.loads((E.parent/'pure-actual-qualification-01/products/pure-smoke/unsigned.shortcut').read_bytes())['WFWorkflowActions']
assert len(actual)==len(baseline)==1
assert actual[0]['WFWorkflowActionIdentifier']==baseline[0]['WFWorkflowActionIdentifier']
for a in actual+baseline:
 params=a['WFWorkflowActionParameters'];assert isinstance(params.get('UUID'),str);params.pop('UUID')
assert actual==baseline
r=run('pure-reject-pack-call',ST/'bin/pure-cherri-service.sh',['compile',str(packsrc)],expected=1,request=True);assert r['status']=='FAILED' and r['process']['exitCode']!=0
r=run('explicit-pack-call',ST/'bin/cherri-with-actions.sh',['enhanced','compile',str(packsrc)],request=True);assert r['status']=='COMPILED_UNSIGNED_PLIST'
r=run('sign-public',ST/'bin/pure-cherri-service.sh',['sign',str(public)],request=True,limit=110)
assert r['status']=='UPSTREAM_AEA1_FORMAT_ONLY' and r['cryptographicSignatureVerified'] is False
signed=pathlib.Path(r['artifact']['path']).read_bytes();assert signed.startswith(b'AEA1') and len(signed)>4 and h(signed)==r['artifact']['sha256']
assert manifest==h((ST/'installation.json').read_bytes()) and protected=={n:h((LIVE/n).read_bytes()) for n in protected}
report={'schema':'cherri-pure-wrapper-actual-current/1','status':'PASS_WRAPPER_1_0_1_ACTUAL','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller':'d58a55e81720b3396aa0c3cc868876eda22aea81','manifestSHA256':manifest,'steps':steps,'requests':requests,'k18ProtectedFilesUnchanged':True,'liveMutation':False,'goExecuted':False,'signatureCredit':'AEA1 format only','nativeRuntimeCredit':False}
b=(json.dumps(report,indent=2)+'\n').encode();(E/'result.original.json').write_bytes(b);print(json.dumps({'path':str(E/'result.original.json'),'sha256':h(b),'status':report['status'],'commands':len(steps),'signedBytes':len(signed)}))
