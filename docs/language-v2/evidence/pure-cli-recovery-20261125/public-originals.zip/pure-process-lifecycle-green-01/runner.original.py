import json,unittest,pathlib
import test_execute
suite=unittest.defaultTestLoader.loadTestsFromTestCase(test_execute.PureExecuteLifecycleTests)
class Result(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.events=[]
    def addSuccess(self,test):super().addSuccess(test);self.events.append({'id':test.id(),'status':'PASS'})
    def addFailure(self,test,err):super().addFailure(test,err);self.events.append({'id':test.id(),'status':'FAIL','trace':self._exc_info_to_string(err,test)})
    def addError(self,test,err):super().addError(test,err);self.events.append({'id':test.id(),'status':'ERROR','trace':self._exc_info_to_string(err,test)})
    def addSkip(self,test,reason):super().addSkip(test,reason);self.events.append({'id':test.id(),'status':'SKIP','reason':reason})
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
pathlib.Path('events.original.json').write_text(json.dumps(r.events,indent=2)+'\n')
raise SystemExit(0 if r.wasSuccessful() else 1)
