import pathlib,json,hashlib,os,stat,subprocess,time,datetime
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125/pure-assembly-03');E.mkdir(mode=0o750)
ST=pathlib.Path('/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream')
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
h=lambda b:hashlib.sha256(b).hexdigest()
def snapshot(root):
 r={}
 for p in root.rglob('*'):
  s=p.lstat();kind='dir' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'other'
  assert kind!='other',str(p)
  if kind=='file':r[p.relative_to(root).as_posix()]={'sha256':h(p.read_bytes()),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtimeNS':s.st_mtime_ns,'nlink':s.st_nlink}
 return r
def save(path,obj):
 b=(json.dumps(obj,indent=2)+'\n').encode();path.write_bytes(b);return h(b)
(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
manifest=(ST/'installation.json').read_bytes();assert h(manifest)=='6ce1f04579c4182aff2c9470b866a2dbed6cb475c394c59236139c6efd4d7992'
assert h((W/'tools/pure_remote/service.py').read_bytes())=='f14022765a0ee23f98c98da66bad0717c466fe607ad4ae016275fd47cda3256a'
before={n:snapshot(ST/n) for n in ('src','docs','apple-actions-pack','jobs','outputs')}
binary=h((ST/'bin/cherri').read_bytes());assert binary=='f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5'
invsha=save(E/'preserved-subtrees-before.original.json',before)
protected=['installation.json','lib/service.py','lib/pack_adapter.py','bin/pure-cherri-service.sh','bin/cherri-with-actions.sh']
old={}
for n in protected:
 p=ST/n;s=p.stat();old[n]={'sha256':h(p.read_bytes()),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtimeNS':s.st_mtime_ns}
save(E/'previous-wrapper-files.original.json',old)
held=E/'preserved-wrapper-1.0.0';held.mkdir()
for n in protected:
 dest=held/n;dest.parent.mkdir(parents=True,exist_ok=True);(ST/n).rename(dest)
(ST/'lib').rmdir()
for n in ('jobs','outputs'):(ST/n).rename(E/('held-'+n))
argv=['/usr/sbin/runuser','-u','ubuntu','--','env','PYTHONDONTWRITEBYTECODE=1','GIT_OPTIONAL_LOCKS=0','/usr/bin/python3','-B',str(W/'tools/pure_remote/assemble.py'),'--root',str(ST),'--controller',str(W),'--build-receipt',str(E.parent/'pure-fresh-build-01/result.original.json'),'--build-sha256','6269d703d441ef22f62dbb7ed3909271d6434b915553109439c5bf381099ff75']
status='FAILED';proc=None;assembly=None
try:
 with (E/'stdout.original.bin').open('xb') as so,(E/'stderr.original.bin').open('xb') as se:
  proc=subprocess.run(argv,stdout=so,stderr=se,timeout=40)
 assert proc.returncode==0,(E/'stderr.original.bin').read_text()
 assembly=json.loads((E/'stdout.original.bin').read_text())
 assert assembly['wrapperVersion']=='1.0.1' and assembly['controllerSource']=='d58a55e81720b3396aa0c3cc868876eda22aea81'
 assert assembly['binarySHA256']==binary
 for n in ('jobs','outputs'):
  (ST/n).rmdir();(E/('held-'+n)).rename(ST/n)
 after={n:snapshot(ST/n) for n in before}
 assert after==before
 for n,v in old.items():
  p=held/n;s=p.stat()
  assert h(p.read_bytes())==v['sha256'] and stat.S_IMODE(s.st_mode)==v['mode'] and (s.st_uid,s.st_gid,s.st_mtime_ns)==(v['uid'],v['gid'],v['mtimeNS'])
 assert h((ST/'bin/cherri').read_bytes())==binary
 status='PASS_REASSEMBLED_WRAPPER_ONLY'
finally:
 if status!='PASS_REASSEMBLED_WRAPPER_ONLY':
  partial=E/'failed-new-wrapper';partial.mkdir()
  for n in protected:
   p=ST/n
   if p.exists():
    dst=partial/n;dst.parent.mkdir(parents=True,exist_ok=True);p.rename(dst)
  if (ST/'lib').exists():(ST/'lib').rmdir()
  (ST/'lib').mkdir();os.chown(ST/'lib',1001,1001)
  for n in protected:(held/n).rename(ST/n)
  for n in ('jobs','outputs'):
   if (E/('held-'+n)).exists():
    if (ST/n).exists():(ST/n).rmdir()
    (E/('held-'+n)).rename(ST/n)
 r={'schema':'cherri-pure-stage-reassembly/2','status':status,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'exitCode':proc.returncode if proc else None,'assembly':assembly,'previousManifestSHA256':h(manifest),'preservedSubtreesSHA256':invsha,'priorWrapperFiles':old,'binaryUnchanged':h((ST/'bin/cherri').read_bytes())==binary,'jobsOutputsRestoredAtOriginalPaths':all((ST/n).exists() for n in ('jobs','outputs')),'liveMutation':False,'goExecuted':False,'stdoutSHA256':h((E/'stdout.original.bin').read_bytes()) if (E/'stdout.original.bin').exists() else None,'stderrSHA256':h((E/'stderr.original.bin').read_bytes()) if (E/'stderr.original.bin').exists() else None}
 sha=save(E/'result.original.json',r);print(json.dumps({'path':str(E/'result.original.json'),'sha256':sha,'status':status,'assembly':assembly}))
