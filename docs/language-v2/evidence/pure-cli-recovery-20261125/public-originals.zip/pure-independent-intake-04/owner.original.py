import pathlib,json,hashlib,re,plistlib,subprocess,stat,datetime,ast
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-recovery-20261125')
D=E/'pure-independent-intake-04';D.mkdir(mode=0o700)
(D/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
ST=pathlib.Path('/mnt/development/projects/releases/cherri-pure-original-fresh-20261125-01/pure-upstream')
W=pathlib.Path('/mnt/development/projects/worktrees/cherri-p10r15-general-language-completion-20261125')
LIVE=pathlib.Path('/mnt/development/projects/agent-workspaces/cherri-remote')
h=lambda b:hashlib.sha256(b).hexdigest()
sources=[]
def read(name,expected=None):
 p=E/name;b=p.read_bytes()
 if expected:assert h(b)==expected,(name,'digest')
 sources.append({'path':str(p),'sha256':h(b)})
 return json.loads(b)
Q=read('pure-actual-qualification-01/result.original.json','47f7acb4fb5cf4259f2c4c2a58dc058a588b1a2184a4e9f728522e59977d9ae0')
B=read('pure-fresh-build-01/result.original.json','6269d703d441ef22f62dbb7ed3909271d6434b915553109439c5bf381099ff75')
S=read('pure-public-hubsign-01/result.original.json','541685c510975848ffa2ace610e0eecd238c26b763f13d6cec66bb1d958bc9e8')
R=read('pure-process-lifecycle-red-01/result.original.json','5008fadaac9ed59529e6c0b02e34b10d4a18c419d052846484ff325797bfdd9d')
G=read('pure-process-lifecycle-green-01/result.original.json','2ed2b48d6bd5f18c24024d45a8d25d04ea4f6343c88b9a6e268d9b988988cf11')
N=read('pure-process-lifecycle-replay-01/result.original.json','a02d962383ddb1d06be004be7aa40284a8434cccfad709d1f50d4af828bf1517')
qdir=E/'pure-actual-qualification-01'
prior=read('pure-actual-qualification-01/historical-entry-records.original.json','18751d74b8cdc251f48d8234540e61d6da75dd744c84425b4cc38db2f2795e8f')
mods=read('pure-actual-qualification-01/historical-module-records.original.json','29dc3d20d8b0f0c461692d6a5e445c68876371b5c7f20006decffb3da9dcbf35')
assert len(prior)==204 and len(mods)==21
selection=read('pure-actual-qualification-01/source-selection.original.json',Q['sourceSelectionSHA256'])
expected={}
for x in mods:
 assert x['ok'] and x['return']==0
 expected[x['name']]={
  'source':("#define name "+x['name']+"\n"+''.join("#include '"+n+".cherri'\n" for n in x['modules'])+'show("probe")\n').encode(),
  'ids':x['actions'],'keys':x['native_keys'],'group':'module'}
for x in prior:
 name=re.sub('[^a-zA-Z0-9]','',x['alias'] or x['name'])+('Full' if x['variant']=='full' else 'Min')
 assert name not in expected and x['actions']==1
 expected[name]={'source':("#define name "+name+"\n#include '"+x['module']+".cherri'\n"+x['call']+"\n").encode(),'ids':[x['expectedActionId']],'keys':[x['nativeKeys']],'group':'entry'}
assert len(expected)==225 and {x['label'] for x in selection}==set(expected)
seen={}
for selected in selection:
 n=selected['label'];case=expected[n]
 assert selected['source'].encode()==case['source']
 assert selected['expectedIDs']==case['ids'] and selected['expectedKeys']==case['keys']
 d=qdir/'products'/n
 raw=(d/'source.original.cherri').read_bytes();artifact=(d/'unsigned.original.shortcut').read_bytes()
 assert raw==case['source'] and not artifact.startswith(b'AEA1')
 record=json.loads((d/'result.original.json').read_text())
 assert record['status']=='PASS' and record['group']==case['group'] and record['sourceSHA256']==h(raw)
 assert record['artifactSHA256']==h(artifact) and record['artifactBytes']==len(artifact)
 acts=plistlib.loads(artifact)['WFWorkflowActions']
 assert isinstance(acts,list) and len(acts)==len(case['ids'])
 assert [a['WFWorkflowActionIdentifier'] for a in acts]==case['ids']
 assert [sorted(a.get('WFWorkflowActionParameters',{})) for a in acts]==case['keys']
 step=record['step'];sd=qdir/'steps'/step['label']
 assert step['exitCode']==0 and not step['timedOut'] and step['argv'][4]==str(ST/'bin/cherri')
 assert json.loads((sd/'result.original.json').read_text())==step
 for stream in ('stdout','stderr'):assert h((sd/(stream+'.original.bin')).read_bytes())==step[stream+'SHA256']
 seen[n]={'sourceSHA256':h(raw),'artifactSHA256':h(artifact),'nativeActionIDs':case['ids']}
assert {x['label']:x for x in Q['replay']}=={n:json.loads((qdir/'products'/n/'result.original.json').read_text()) for n in expected}
for step in Q['steps']:
 sd=qdir/'steps'/step['label']
 assert json.loads((sd/'result.original.json').read_text())==step
 for stream in ('stdout','stderr'):assert h((sd/(stream+'.original.bin')).read_bytes())==step[stream+'SHA256']
assert Q['status']=='PASS_SOURCE_QUALIFIED_PURE_AND_PACK' and Q['replayPassed']==225 and not Q['replayFailed']
assert {x['name']:x['status'] for x in Q['controls']}=={'pure-status':'PASS','pure-docs':'PASS','pack-verify':'PASS','pure-smoke':'PASS','pure-pack-action-rejected':'PASS_EXPECTED_UPSTREAM_REJECTION','pack-same-call-accepted':'PASS','original-pack-alias-guard-red':'EXPECTED_RED_WITH_ACTUAL_BINARY','pure-verify-without-pack':'PASS','pure-compile-without-pack':'PASS','pack-missing-fails-closed':'PASS_EXPECTED_REJECTION'}
assert len(Q['causalFaults'])==6 and all(x['status']=='REJECTED' for x in Q['causalFaults'])
assert Q['originalProducerExecuted'] is False and Q['historicalBinaryRestored'] is False and Q['nativeRuntimeCredit'] is False
assert B['status']=='PASS_PINNED_PURE_BUILD' and B['buildExitCode']==0 and B['buildInvocations']==1
assert B['sourceUnchanged'] and B['vcsModified'] is False and B['source']==Q['source']
assert B['embeddedBuildSettings']['vcs.revision']==B['source'] and B['embeddedBuildSettings']['vcs.modified']=='false'
assert h((ST/'bin/cherri').read_bytes())==B['binarySHA256']==Q['freshBinarySHA256']=='f1f4396d8e45479b323ad63247f49bd28f0e50a6cd79f1f435f3e392fcf4bec5'
def git(root,*args):
 r=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(root),*args],capture_output=True,timeout=20)
 assert r.returncode==0,r.stderr.decode()
 return r.stdout
counts={}
for sub,pin in (('src',('bcc0095754e2cc0baaeb4d93dae172b8153b4716','4fe9fbc8c742aaf01d6ec8193d9be708fb1de7b5','https://github.com/electrikmilk/cherri.git')),
                ('docs',('4165cc7224b8f4f0500d95129da9fa14eca5458f','f6c3af5143a1bec1a6391c58569fd0aa47673e29','https://github.com/electrikmilk/cherrilang.org.git'))):
 root=ST/sub;assert (root/'.git').is_dir()
 assert not (root/'.git/objects/info/alternates').exists()
 assert git(root,'rev-parse','HEAD').decode().strip()==pin[0]
 assert git(root,'rev-parse','HEAD^{tree}').decode().strip()==pin[1]
 assert git(root,'remote','get-url','origin').decode().strip()==pin[2]
 assert not git(root,'status','--porcelain=v1','--untracked-files=all','--ignored=matching').strip()
 count=0
 for row in git(root,'ls-tree','-r','-z','HEAD').split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t');mode,kind,oid=meta.split();p=root/name.decode();data=p.read_bytes()
  assert kind==b'blob' and mode in (b'100644',b'100755') and not p.is_symlink()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid.decode()
  assert bool(p.stat().st_mode&0o111)==(mode==b'100755');count+=1
 counts[sub]=count
assert counts=={'src':112,'docs':87}
for sub,label,key in (('src','source','sourceBeforeSHA256'),('docs','docs','docsBeforeSHA256'),('apple-actions-pack','pack','packBeforeSHA256')):
 inv=read('pure-actual-qualification-01/'+label+'-before.original.json',Q[key])
 actualFiles={p.relative_to(ST/sub).as_posix():p for p in (ST/sub).rglob('*') if p.is_file() and '.git' not in p.relative_to(ST/sub).parts}
 assert set(actualFiles)==set(inv),(sub,'file set')
 for n,v in inv.items():
  p=actualFiles[n];s=p.stat()
  assert h(p.read_bytes())==v['sha256'] and s.st_size==v['bytes'] and stat.S_IMODE(s.st_mode)==v['mode']
assert {n:h((LIVE/n).read_bytes()) for n in Q['k18Before']}==Q['k18Before']
signed=(E/'pure-public-hubsign-01/request-signed.shortcut').read_bytes()
assert h(signed)==S['signedSHA256'] and len(signed)==S['signedBytes'] and signed.startswith(b'AEA1')
assert not S['cryptographicSignatureVerified'] and not S['appleImportOrRuntimeVerified']
assert R['status']=='EXPECTED_RED_EXACT_INVENTORY' and len(R['events'])==8
assert sum(x['status']=='FAIL' for x in R['events'])==4 and R['causalFailuresObserved']
assert G['status']=='UNEXPECTED_RESULT' and G['sourceStable'] and N['status']=='PASS_EXACT_32' and N['sourceStable']
fixed='test_execute.PureExecuteLifecycleTests.test_timeout_direct_preserves_unrelated_owned_control'
assert [(x['id'],x['status']) for x in G['events'] if x['status']!='PASS']==[(fixed,'ERROR')]
assert 'JSONDecodeError' in next(x['trace'] for x in G['events'] if x['id']==fixed)
joined={x['id'] for x in G['events'] if x['status']=='PASS'}
assert len(joined)==7
assert next(x['status'] for x in N['events'] if x['id']==fixed)=='PASS';joined.add(fixed)
assert joined==set(R['expected']) and len(joined)==8
prod=h((W/'tools/pure_remote/service.py').read_bytes())
assert prod==h((E/'pure-process-lifecycle-green-01/service.py').read_bytes())==N['sourcePins']['service.py']=='f14022765a0ee23f98c98da66bad0717c466fe607ad4ae016275fd47cda3256a'
for event in G['events']:
 if event['status']!='PASS':continue
 name=event['id'].rsplit('.',1)[1]
 d=E/'pure-process-lifecycle-green-01/controls'/name
 obs=json.loads((d/'control-observations.original.json').read_text())
 assert obs['beforeControlCleanup'] and all(not v['alive'] for v in obs['beforeControlCleanup'].values())
 proc=json.loads((d/'streams/process.original.json').read_text())
 assert proc['cleanup']['groupGone'] and proc['status']!='FAILED'
obs=json.loads((E/'pure-process-lifecycle-replay-01/controls'/fixed.rsplit('.',1)[1]/'control-observations.original.json').read_text())
assert all(not v['alive'] for v in obs['beforeControlCleanup'].values()) and obs['unrelatedGroupPreserved']['state']!='Z'
assert sum(x['id'].startswith('test_service.') and x['status']=='PASS' for x in N['events'])==31
payload=(json.dumps(seen,indent=2)+'\n').encode();(D/'artifacts-225.original.json').write_bytes(payload)
r={'schema':'cherri-pure-original-independent-intake/1','status':'PASS_SOURCE_QUALIFICATION_AND_JOINED_LIFECYCLE','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilerSource':B['source'],'binarySHA256':B['binarySHA256'],'sourceFiles':counts,'moduleImports':21,'entryCases':204,'actualArtifactsIndependentlyReparsed':225,'artifactsManifestSHA256':h(payload),'originalSourcesAndNativeIDsExact':True,'processStreamsVerified':len(Q['steps']),'operationalControls':10,'causalGraphFaults':6,'k18ProtectedFilesUnchanged':len(Q['k18Before']),'wrapperProductionSHA256':prod,'wrapperController':'675d62f0aeb22cad650a261790e42ab3e028dcc4','lifecycleDistinctPassed':8,'lifecycleJoin':'7 genuine passes from failed GREEN01 plus the exact corrected positive replay; not a single8-case GREEN run.','existingWrapperControlsPassed':31,'priorFailuresPreserved':True,'oldIntakeSetupAttemptsPreserved':True,'freshBuildNotHistoricalRecovery':True,'originalCatalogProducerExecuted':False,'nativeRuntimeCredit':False,'signatureCredit':'Original public HubSign output AEA1 shape+bytes only; no cryptographic or Apple execution claim.','liveMutation':False,'sourceReceipts':sources}
b=(json.dumps(r,indent=2)+'\n').encode();(D/'result.original.json').write_bytes(b);(D/'result.original.json').chmod(0o600)
print(json.dumps({'path':str(D/'result.original.json'),'sha256':h(b),'status':r['status'],'artifacts':225,'lifecycleJoined':8,'wrapperControls':31}))
