"""Fixed raw505 / original five-parent S4 routes with a shared bounded owner.

No command, environment, test expression, or acceptance code comes from config.
The config selects exact source identity, fresh private paths and one fixed role.
"""
from pathlib import Path
import ast
import collections
import datetime
import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import time

HELPER_SHA256 = "4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
_helper = Path(__file__).with_name("owned_source_process.py")
if hashlib.sha256(_helper.read_bytes()).hexdigest() != HELPER_SHA256:
    raise SystemExit("OWNER_HELPER_BYTES_CHANGED")
_spec = importlib.util.spec_from_file_location("cherri_fixed_owned_process", _helper)
owned = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = owned
_spec.loader.exec_module(owned)

GO = Path("/mnt/development/tooling/cherri-go/runtime-persistent-20261123/owned-mod-cache-restored-20261125/golang.org/toolchain@v0.0.1-go1.24.13.linux-arm64/bin/go")
GO_SHA256 = "aedb1694ac1516bbd353a7c737f31be252f59f17746133d46f9e77f2f5fe9d22"
OBSERVER = Path(__file__).resolve().with_name("observe_go_exclusive.py")
OBSERVER_SHA256 = "97e699223bc7438e6d4f9de643d9ebc27497e28e9c3a31715f93652c35248ba8"
MANIFEST_SHA256 = "766ac82ef7d92f50a894e50bc84d3fed9cc2d375f81ffe2771dbe8a5a6de5f39"
ORIGINAL_AUDITOR_SHA256 = "f186bc74fb355aa0334ca60696e387a2a55deea0ab5ffb0230a58285bc66ce77"
RAW_ORIGINAL_OWNER_SHA256 = "ce809d9839a74657d6cbf6fb685a65aef0c86e743642e1eeed31acca03143bb4"
S4_BINDINGS = {
    "00-p12-par": ("TestP12_PAR_12_CorpusComplexParamsAndZeroStage3Gate", "p12_complex_params_test.go", "86172facc402af313872a2412e6dcd2d1dbd50f9f125d88a102acf21088db1ed"),
    "01-p13": ("TestP13_CorpusFidelityAndSourceSizeAudit", "p13_fidelity_promotion_test.go", "8163a5d80ef4ee23423fff2eef54599b5289c73e44337b02e006b2e47b9d6279"),
    "02-p10-measure": ("TestP10R10CorpusMeasure", "p10r10_corpus_test.go", "a6188a41ff23fd43f25308b8547391d9186d3c1b6ad92dbaea9ae514d865a761"),
    "03-p11-fresh38x2": ("TestP11_WIRE_01_Fresh38x2NativeActionWire", "p11_wire_fidelity_test.go", "c4ab56f1ee4f1eea58e4075da0965f525f85e8f1efc30452d2dc3703b34b8f67"),
    "04-p12-lifecycle": ("TestP12_BASE_02_LifecycleStagesAndReconcileCorpus", "p12_baseline_truth_test.go", "eb8b70716337cba945409df4d60edb23063c2998330bc15da8c1ec8e08c87658"),
}
RAW_PARENTS = ["TestP10_VerifyAndRecord505CatalogExecution", "TestP10_ParameterContractMatrix_AllCatalogActions"]
RAW_ARTIFACTS = ["p10-505-execution-evidence.json", "p10-505-parameter-contract-evidence.json"]
LIVE_FLOORS = {"root": 805306368, "development": 805306368,
               "shm": 201326592, "memoryAvailable": 2147483648}


def require(condition, code):
    if not condition:
        raise owned.OwnerAbort(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def free():
    memory = {k: int(v.strip().split()[0]) * 1024 for k, v in
              (line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())}
    return {"root": shutil.disk_usage("/").free,
            "development": shutil.disk_usage("/mnt/development").free,
            "shm": shutil.disk_usage("/dev/shm").free,
            "memoryAvailable": memory["MemAvailable"]}


def fixed_config(config):
    shared = {"schema", "role", "worktree", "output", "head", "tree", "branch", "ownerSHA256", "helperSHA256"}
    role = config.get("role")
    require(role in ("raw505", "s4"), "FIXED_ROLE_REQUIRED")
    extra = {"rawExecutionTestFileSHA256", "rawParameterTestFileSHA256"} if role == "raw505" else {"mode", "test", "testFile", "testFileSHA256", "privateManifest", "privateInput"}
    require(set(config) == shared | extra, "CLOSED_CONFIG_FIELDS")
    require(config["schema"] == "cherri-fixed-source-owner-config/1", "CONFIG_SCHEMA")
    require(all(type(config[k]) is str for k in config), "STRING_CONFIG_FIELDS")
    require(re.fullmatch(r"[a-f0-9]{40}", config["head"]) is not None and
            re.fullmatch(r"[a-f0-9]{40}", config["tree"]) is not None, "SOURCE_IDENTITY")
    require(config["helperSHA256"] == HELPER_SHA256, "CONFIG_HELPER_PIN")
    if role == "s4":
        require(config["mode"] in S4_BINDINGS, "FIXED_S4_MODE")
        require(tuple(config[k] for k in ("test", "testFile", "testFileSHA256")) == S4_BINDINGS[config["mode"]],
                "FIXED_S4_PARENT_FILE_PIN")
    return role


class SourceOwner:
    def __init__(self, config, output, budget):
        self.config, self.out, self.budget = config, output, budget
        self.worktree = Path(config["worktree"])
        self.commands = output / "commands"
        self.commands.mkdir(mode=0o700)
        self.sequence = 0
        self.minimum = free()
        keep = ("PATH", "LANG", "LC_ALL", "LC_CTYPE", "TZ")
        self.env = {key: os.environ[key] for key in keep if key in os.environ}
        base = "/mnt/development/tooling/cherri-go/runtime-persistent-20261123/"
        self.env.update(PATH=str(GO.parent) + ":/usr/local/bin:/usr/bin:/bin", GOTOOLCHAIN="go1.24.13",
            GOMAXPROCS="2", GOFLAGS="-p=2 -mod=readonly", GOPROXY="off", GOSUMDB="off",
            PYTHONDONTWRITEBYTECODE="1", GOMODCACHE=base+"owned-mod-cache-restored-20261125",
            GOCACHE=base+"build-cache-restored-20261125", GOTMPDIR=base+"tmp-ubuntu", TMPDIR=base+"tmp-ubuntu",
            GIT_NO_REPLACE_OBJECTS="1", GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")

    def monitor(self):
        observed = free()
        for key in self.minimum:
            self.minimum[key] = min(self.minimum[key], observed[key])
        require(all(observed[k] >= v for k, v in LIVE_FLOORS.items()), "LIVE_CAPACITY_FLOOR")

    def read(self, path):
        self.budget.check()
        parts = []
        with Path(path).open("rb") as stream:
            while True:
                self.budget.check()
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                parts.append(chunk)
        self.budget.check()
        return b"".join(parts)

    def command(self, label, argv, seconds=25, finalizing=False, require_zero=True):
        self.sequence += 1
        name = f"{self.sequence:03d}-{label}"
        actual = ["/usr/sbin/runuser", "-u", "ubuntu", "--", *map(str, argv)]
        row = owned.run_owned(actual, cwd=self.worktree, env=self.env, output=self.commands,
            name=name, budget=self.budget, seconds=seconds, monitor=self.monitor,
            post_reserve=2 if finalizing else None)
        if require_zero:
            owned.require_success(row)
        return row, self.commands / (name + ".stdout.original"), self.commands / (name + ".stderr.original")

    def observe_concurrent_owner(self):
        # This explicitly new conservative observer is read-only and requires
        # the controller's existing UID0. No caller-supplied root argv exists.
        require(os.getuid() == 0, "NEW_ROOT_OBSERVER_IDENTITY")
        observer_raw = self.read(OBSERVER)
        require(sha(observer_raw) == OBSERVER_SHA256, "NEW_ROOT_OBSERVER_BYTES")
        owned.original(self.out/"admission-observer.original.py", observer_raw)
        self.sequence += 1
        name = f"{self.sequence:03d}-concurrent-owner"
        row = owned.run_owned(["/usr/bin/python3", "-I", "-B", str(OBSERVER)],
            cwd=self.worktree, env=self.env, output=self.commands, name=name,
            budget=self.budget, seconds=25, monitor=self.monitor)
        owned.require_success(row)
        decision = json.loads(self.read(self.commands/(name + ".stdout.original")))
        require(decision.get("schema") == "cherri-exclusive-go-observation/1" and
                decision.get("policy") == "new-conservative-all-live-go-20261126" and
                decision.get("observerUid") == 0 and decision.get("errors") == [],
                "NEW_ROOT_OBSERVER_PROTOCOL")
        return row, self.commands / (name + ".stdout.original"), self.commands / (name + ".stderr.original")

    def git(self, *args, finalizing=False):
        row, path, _ = self.command("git", ["git", "--no-replace-objects", "-C", str(self.worktree), *args],
                                    finalizing=finalizing)
        return self.read(path)

    def snapshot(self, finalizing=False):
        self.budget.check()
        w = self.worktree
        require(w.resolve(strict=True) == w and (w/".git").is_dir() and not (w/".git").is_symlink(), "ORDINARY_SOURCE_REQUIRED")
        require(not (w/".git/objects/info/alternates").exists() and not (w/".git/info/grafts").exists(), "NO_ALTERNATES_OR_GRAFTS")
        require(not self.git("replace", "-l", finalizing=finalizing), "NO_REPLACE_REFS")
        metadata = {}
        for key, args in (("head", ("rev-parse", "HEAD")), ("tree", ("rev-parse", "HEAD^{tree}")),
                          ("branch", ("branch", "--show-current")), ("status", ("status", "--porcelain=v1", "--untracked-files=all"))):
            raw = self.git(*args, finalizing=finalizing).decode()
            metadata[key] = raw if key == "status" else raw.strip()
        tracked = {}
        listing = self.git("ls-tree", "-rz", "--full-tree", "HEAD", finalizing=finalizing)
        for index, line in enumerate(listing.split(b"\0")):
            if not line:
                continue
            self.budget.check()
            if index % 128 == 0:
                self.monitor()
            left, name = line.split(b"\t", 1)
            mode, kind, blob = left.decode().split()
            name = name.decode()
            require(kind == "blob" and mode in ("100644", "100755", "120000"), "TRACKED_FILE_KIND")
            path = w/name
            info = path.lstat()
            if mode == "120000":
                require(stat.S_ISLNK(info.st_mode), "TRACKED_LINK_KIND")
                raw = os.fsencode(os.readlink(path))
            else:
                require(stat.S_ISREG(info.st_mode) and bool(info.st_mode & 0o111) == (mode == "100755"), "TRACKED_FILE_MODE")
                raw = self.read(path)
            require(hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == blob, "PHYSICAL_GIT_BLOB_MISMATCH")
            tracked[name] = {"mode": mode, "blob": blob, "bytes": len(raw), "sha256": sha(raw)}
        metadata["trackedPhysicalInputs"] = tracked
        return metadata

    def dependencies(self):
        target = self.worktree / "tools/p10r3/generate_catalog_and_pack_ledgers.py"
        tree = ast.parse(self.read(target))
        nodes = [n for n in tree.body if isinstance(n, ast.Assign) and
                 any(isinstance(t, ast.Name) and t.id == "DEPENDENCY_GLOBS" for t in n.targets)]
        require(len(nodes) == 1, "DEPENDENCY_GLOBS_IDENTITY")
        patterns = ast.literal_eval(nodes[0].value)
        names = sorted({p.relative_to(self.worktree).as_posix() for pattern in patterns
                        for p in self.worktree.glob(pattern) if p.is_file()})
        rows, material = [], hashlib.sha256()
        for name in names:
            raw = self.read(self.worktree/name)
            normalized = sha(raw.replace(b"\r\n", b"\n"))
            rows.append({"path": name, "bytes": len(raw), "sha256": sha(raw), "normalized_sha256": normalized})
            material.update((name+":"+normalized+"\n").encode())
        return {"fingerprint": material.hexdigest(), "patterns": patterns, "files": rows}

    def private_guard(self):
        base, manifest = Path(self.config["privateInput"]), Path(self.config["privateManifest"])
        require(base.resolve(strict=True) == base and manifest.resolve(strict=True) == manifest, "PRIVATE_PATH_IDENTITY")
        raw = self.read(manifest)
        require(sha(raw) == MANIFEST_SHA256, "ORIGINAL_PRIVATE_MANIFEST")
        entries = json.loads(raw)
        require(type(entries) is list and len(entries) == 38 and sum(x["bytes"] for x in entries) == 62980131, "ORIGINAL_PRIVATE_COUNT_SIZE")
        names = [x["name"] for x in entries]
        require(len(set(names)) == 38 and all(type(n) is str and Path(n).name == n and n not in ("", ".", "..")
                and "/" not in n and chr(92) not in n for n in names), "PRIVATE_NAMES")
        require({x.name for x in base.iterdir()} == set(names), "PRIVATE_CLOSED_INVENTORY")
        state = {}
        def fields(st):
            return (st.st_dev, st.st_ino, st.st_mode, st.st_uid, st.st_gid, st.st_size, st.st_mtime_ns)
        for row in entries:
            path = base / row["name"]
            before = path.lstat()
            require(stat.S_ISREG(before.st_mode) and before.st_size == row["bytes"], "PRIVATE_REGULAR_SIZE")
            require(sha(self.read(path)) == row["sha256"], "PRIVATE_BYTES")
            after = path.lstat()
            require(fields(before) == fields(after), "PRIVATE_DURING_READ_MUTATION")
            state[row["name"]] = {"stat": fields(after), "sha256": row["sha256"]}
        return entries, state


def raw_core(raw, artifacts, budget):
    rows, errors = [], 0
    for line in raw.splitlines():
        budget.check()
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            if type(row) is not dict:
                raise ValueError("EVENT_TYPE")
            rows.append(row)
        except (ValueError, UnicodeError):
            errors += 1
    run = [r["Test"] for r in rows if r.get("Test") and r.get("Action") == "run"]
    passed = [r["Test"] for r in rows if r.get("Test") and r.get("Action") == "pass"]
    bad = [r for r in rows if r.get("Action") in ("fail", "skip")]
    packages = [r for r in rows if r.get("Action") == "pass" and not r.get("Test")]
    names = sorted(p.name for p in artifacts.iterdir())
    verified = not errors and sorted(run) == sorted(passed) == sorted(RAW_PARENTS) and not bad and len(packages) == 1 and names == sorted(RAW_ARTIFACTS)
    return {"eventsVerified": verified, "summaryVerified": verified, "run": run, "pass": passed,
            "failedOrSkippedCount": len(bad), "parseErrorCount": errors, "artifactNames": names,
            "artifactSemanticsPendingIndependentIntake": True, "gatedNotRun": False, "goTimedOut": False}


def four_parent_core(mode, test, out, manifest, binding):
    raw=(out/"stdout.jsonl").read_bytes();rows=[];parse_errors=0
    for line in raw.splitlines():
     if not line.strip():continue
     try:rows.append(json.loads(line))
     except (ValueError,UnicodeDecodeError):parse_errors+=1
    starts=collections.Counter((x.get("Package"),x["Test"]) for x in rows if x.get("Action")=="run" and x.get("Test"))
    ends=collections.Counter((x.get("Package"),x["Test"]) for x in rows if x.get("Action") in ["pass","fail","skip"] and x.get("Test"))
    counts=collections.Counter(x["Action"] for x in rows if x.get("Action") in ["pass","fail","skip"] and x.get("Test"))
    own=[x for x in rows if x.get("Test")==test];parent_runs=sum(x.get("Action")=="run" for x in own);parent_passes=[x for x in own if x.get("Action")=="pass"]
    packages=[{"package":x.get("Package"),"action":x["Action"],"elapsed":x.get("Elapsed")} for x in rows if x.get("Action") in ["pass","fail","skip"] and not x.get("Test")]
    outputs=[x.get("Output","") for x in rows];text="".join(outputs)
    patterns={
    "00-p12-par":r"P12_PAR_12 corpus verified: files=(\d+) actions=(\d+) natural=(\d+) fallback=(\d+) invalid=(\d+) demotions=(\d+) thirdParty=(\d+)",
    "01-p13":r"P10R13 Corpus Summary: total=(\d+) natural=(\d+) \([^\n)]*\) fallback=(\d+) invalid=(\d+) demoted=(\d+)",
    "02-p10-measure":r"TOTAL actions=(\d+) natural=(\d+) \([^\n)]*\) reasons=",
    "03-p11-fresh38x2":r"P11_WIRE_01 checked (\d+) files, (\d+) total actions, (\d+) NATURAL_VERIFIED"}
    matches=list(re.finditer(patterns[mode],text));summary={};summary_ok=False;per_input_count=None
    if len(matches)==1:
     nums=[int(x) for x in matches[0].groups()]
     if mode=="00-p12-par":
      summary=dict(zip(["files","actions","natural","fallback","invalid","demotions","thirdParty"],nums))
      summary_ok=nums[:6]==[38,27652,23353,4298,1,0] and nums[6]>0
     elif mode=="01-p13":
      summary=dict(zip(["actions","natural","fallback","invalid","demotions"],nums));summary_ok=nums==[27652,23353,4298,1,0]
     elif mode=="02-p10-measure":
      summary=dict(zip(["actions","natural"],nums))
      per=list(re.finditer(r"(?m)^(\d{3}) actions=\d+ natural=\d+ \([0-9.]+%\) OK \(\d+ms\)\s*$",text))
      per_input_count=len(per)
      summary_ok=nums==[27652,23353] and len(per)==38 and sorted(x[1]+".plist" for x in per)==sorted(x["name"] for x in manifest)
     elif mode=="03-p11-fresh38x2":
      summary=dict(zip(["files","actions","natural"],nums));summary_ok=nums==[38,27652,23353]
    events_ok=(parent_runs==len(parent_passes)==1 and not parse_errors and len(starts)==1 and set(starts)==set(ends) and all(n==1 for n in starts.values()) and all(n==1 for n in ends.values()) and counts.get("pass",0)==1 and not counts.get("fail",0) and not counts.get("skip",0) and len(packages)==1 and packages[0]["action"]=="pass")
    go_timeout="panic: test timed out after" in text
    not_run=bool(re.search(r"(?m)^\s*"+re.escape(binding["file"])+r":\d+: NOT_RUN_PRIVATE_CORPUS: set CHERRI_P10R10_CORPUS=1",text))
    return {
        "eventCount": len(rows), "parseErrorCount": parse_errors, "startedCaseCount": len(starts),
        "terminalCounts": dict(counts), "incompleteCaseCount": len(set(starts)-set(ends)),
        "orphanTerminalCount": len(set(ends)-set(starts)), "packageTerminals": packages,
        "parentRunCount": parent_runs, "parentPassCount": len(parent_passes),
        "parentElapsedSeconds": parent_passes[0].get("Elapsed") if parent_passes else None,
        "summaryCount": len(matches), "summary": summary, "perInputSummaryCount": per_input_count,
        "summaryVerified": summary_ok, "eventsVerified": events_ok,
        "gatedNotRun": not_run, "goTimedOut": go_timeout,
    }


def lifecycle_core(out):
    raw=(out/"stdout.jsonl").read_bytes()
    rows=[];parse_errors=0
    for line in raw.splitlines():
     if not line.strip():continue
     try:rows.append(json.loads(line))
     except (ValueError,UnicodeDecodeError):parse_errors+=1
    test="TestP12_BASE_02_LifecycleStagesAndReconcileCorpus"
    starts=collections.Counter((x.get("Package"),x["Test"]) for x in rows if x.get("Action")=="run" and x.get("Test"))
    ends=collections.Counter((x.get("Package"),x["Test"]) for x in rows if x.get("Action") in ["pass","fail","skip"] and x.get("Test"))
    parent_runs=[x for x in rows if x.get("Action")=="run" and x.get("Test")==test]
    parent_passes=[x for x in rows if x.get("Action")=="pass" and x.get("Test")==test]
    counts=collections.Counter(x.get("Action") for x in rows if x.get("Action") in ["pass","fail","skip"] and x.get("Test"))
    package_ends=[{"package":x.get("Package"),"action":x["Action"],"elapsed":x.get("Elapsed")} for x in rows if x.get("Action") in ["pass","fail","skip"] and not x.get("Test")]
    outputs=[x.get("Output","") for x in rows]
    matches=[]
    pattern=re.compile(r"P12_BASE_02 corpus reconciliation: files=(\d+) freshNat=(\d+) seqNat=(\d+) diffs=\[([^\]]*)\]")
    for line in outputs:
     for m in pattern.finditer(line):matches.append({"files":int(m[1]),"freshNatural":int(m[2]),"sequentialNatural":int(m[3]),"diffsEmpty":not m[4].strip()})
    demotion_summaries=sum("P12_BASE_02 demotionStages=" in line and "demotionActionReasons=" in line for line in outputs)
    not_run=any("P12_BASE_02 corpus: NOT_RUN" in line for line in outputs)
    timed_out=any("panic: test timed out after" in line for line in outputs)
    corpus_complete=len(matches)==1 and matches[0]["files"]==38 and matches[0]["freshNatural"]==matches[0]["sequentialNatural"] and matches[0]["diffsEmpty"] and demotion_summaries==1 and not not_run
    events_ok=(len(parent_runs)==len(parent_passes)==1 and not parse_errors and set(starts)==set(ends) and all(n==1 for n in starts.values()) and all(n==1 for n in ends.values()) and not counts.get("fail",0) and not counts.get("skip",0) and len(package_ends)==1 and package_ends[0]["action"]=="pass")
    return {
        "eventCount": len(rows), "parseErrorCount": parse_errors, "startedCaseCount": len(starts),
        "terminalCounts": dict(counts), "incompleteCaseCount": len(set(starts)-set(ends)),
        "orphanTerminalCount": len(set(ends)-set(starts)), "packageTerminals": package_ends,
        "parentRunCount": len(parent_runs), "parentPassCount": len(parent_passes),
        "parentElapsedSeconds": parent_passes[0].get("Elapsed") if parent_passes else None,
        "corpusReconciliation": matches, "demotionSummaryCount": demotion_summaries,
        "summaryVerified": corpus_complete, "eventsVerified": events_ok,
        "gatedNotRun": not_run, "goTimedOut": timed_out,
    }


def main():
    require(len(sys.argv) == 2, "EXACT_CONFIG_ARGUMENT_REQUIRED")
    # Config reading itself is timed.  Both fixed roles initially share the
    # stricter970 cap; only a validated raw505 config selects original1200.
    entered = time.monotonic()
    config_path = Path(sys.argv[1])
    with owned.WholeBudget(970, cleanup_seconds=8, final_reserve=20) as budget:
        config_raw = config_path.read_bytes()
        config = json.loads(config_raw)
        role = fixed_config(config)
        if role == "raw505":
            budget.seconds = 1200
            budget.deadline = budget.started + 1200
            __import__("signal").setitimer(__import__("signal").ITIMER_REAL, max(.001, budget.deadline-time.monotonic()))
        require(sha(Path(__file__).read_bytes()) == config["ownerSHA256"], "OWNER_SOURCE_PIN")
        out, w = Path(config["output"]), Path(config["worktree"])
        require(out.is_absolute() and out.parent.resolve(strict=True) == out.parent and not out.exists(), "FRESH_OUTPUT_PARENT")
        require(not out.is_relative_to(w) and not w.is_relative_to(out), "OUTPUT_OUTSIDE_SOURCE")
        out.mkdir(mode=0o700)
        owned.original(out/"owner.original.py", Path(__file__).read_bytes())
        owned.original(out/"helper.original.py", _helper.read_bytes())
        owned.original(out/"config.original.json", config_raw)
        owner = SourceOwner(config, out, budget)
        before = after = witness_before = witness_after = inputs_before = inputs_after = None
        process = core = None
        failures = []
        admission = False
        try:
            before = owner.snapshot()
            owned.original(out/"source-before.original.json", before)
            require(all(before[k] == config[k] for k in ("head", "tree", "branch")) and not before["status"], "FROZEN_CLEAN_SOURCE")
            remote = owner.git("-c", "credential.helper=", "-c", "credential.helper=!gh auth git-credential", "ls-remote", "--heads", "origin", "refs/heads/"+config["branch"])
            owned.original(out/"remote-ref.original.txt", remote)
            require(remote.decode().strip().split() == [config["head"], "refs/heads/"+config["branch"]], "PUBLISHED_EXACT_REF")
            require(sha(owner.read(GO)) == GO_SHA256 and sha(owner.read(OBSERVER)) == OBSERVER_SHA256, "TOOLCHAIN_OBSERVER_PINS")
            if role == "s4":
                for test, name, expected in S4_BINDINGS.values():
                    require(sha(owner.read(w/name)) == expected, "ALL_FIVE_ORIGINAL_TEST_FILES")
                manifest, inputs_before = owner.private_guard()
                owned.original(out/"private-input-state-before.original.json", inputs_before)
                owner.env.update(CHERRI_P10R10_CORPUS="1", CHERRI_P10R10_CORPUS_DIR=config["privateInput"])
            else:
                require(sha(owner.read(w/"p10_catalog_execution_test.go")) == config["rawExecutionTestFileSHA256"], "RAW_EXECUTION_TEST_FILE")
                require(sha(owner.read(w/"p10_structural_roundtrip_test.go")) == config["rawParameterTestFileSHA256"], "RAW_PARAMETER_TEST_FILE")
                witness_before = owner.dependencies()
                owned.original(out/"input-witness-before.original.json", witness_before)
                artifacts = out/"artifacts"
                artifacts.mkdir(mode=0o700)
                os.chown(out, 1001, 1001)
                os.chown(artifacts, 1001, 1001)
                owner.env["CHERRI_CATALOG_EVIDENCE_DIR"] = str(artifacts)
            row, path, errors = owner.observe_concurrent_owner()
            decision = json.loads(owner.read(path))
            require(not owner.read(errors) and decision.get("admitted") is True and decision.get("blockedPids") == [], "SINGLE_GO_OWNER")
            floor = {"root": 939524096, "development": 2147483648 if role == "s4" else 1073741824,
                     "shm": 402653184, "memoryAvailable": 3221225472}
            observed = free()
            admission = all(observed[k] >= v for k, v in floor.items())
            owned.original(out/"preflight.original.json", {"free": observed, "admission": floor, "liveFloor": LIVE_FLOORS,
                "admitted": admission, "wholeOwnerSeconds": budget.seconds, "goSeconds": 900,
                "driverSeconds": 930 if role == "s4" else 1200})
            require(admission, "ADMISSION_CAPACITY")
            row, path, _ = owner.command("go-env", [str(GO), "env", "-json", "GOVERSION", "GOOS", "GOARCH", "GOROOT", "GOTOOLDIR", "GOTOOLCHAIN", "GOMODCACHE", "GOCACHE", "GOTMPDIR"], 60)
            env_raw = owner.read(path)
            owned.original(out/"go-env.original.json", env_raw)
            require(json.loads(env_raw)["GOVERSION"] == "go1.24.13", "ACTUAL_GO_VERSION")
            args = [str(GO), "test", "-count=1", "-json", "-timeout=15m"]
            if role == "raw505":
                args += ["-parallel=2", "-run", "^("+"|".join(RAW_PARENTS)+")$", "."]
            else:
                args += ["-run", "^"+config["test"]+"$", "."]
            owned.original(out/"intent.original.json", {"source": config["head"], "argv": args,
                "environmentSelection": {k: v for k,v in owner.env.items() if k not in ("PATH","LANG","LC_ALL","LC_CTYPE","TZ")},
                "fixedRole": role, "goSeconds": 900, "driverSeconds": 930 if role == "s4" else 1200,
                "wholeOwnerSeconds": budget.seconds, "nativeAcceptance": False, "historicalOwnerReconstructed": False})
            process, stdout, stderr = owner.command("go-tests", args, 930 if role == "s4" else 1200, require_zero=False)
            owned.original(out/"stdout.jsonl", owner.read(stdout))
            owned.original(out/"stderr.bin", owner.read(stderr))
            owned.require_success(process)
            if role == "raw505":
                core = raw_core(owner.read(out/"stdout.jsonl"), artifacts, budget)
            elif config["mode"] == "04-p12-lifecycle":
                core = lifecycle_core(out)
            else:
                core = four_parent_core(config["mode"], config["test"], out, manifest, {"file": config["testFile"]})
            budget.check()
            require(core["eventsVerified"] and core["summaryVerified"] and not core["gatedNotRun"] and not core["goTimedOut"], "ORIGINAL_STRICT_CRITERIA")
        except BaseException as error:
            failures.append({"stage": "execution", "type": type(error).__name__, "message": str(error)})
        finally:
            with budget.finalizing():
                try:
                    if before is not None:
                        after = owner.snapshot(finalizing=True)
                        owned.original(out/"source-after.original.json", after)
                        require(after == before, "SOURCE_CHANGED")
                    if role == "s4" and inputs_before is not None:
                        manifest_after, inputs_after = owner.private_guard()
                        owned.original(out/"private-input-state-after.original.json", inputs_after)
                        require(inputs_before == inputs_after and manifest == manifest_after, "PRIVATE_INPUT_CHANGED")
                    elif role == "raw505" and witness_before is not None:
                        witness_after = owner.dependencies()
                        owned.original(out/"input-witness-after.original.json", witness_after)
                        require(witness_before == witness_after, "DEPENDENCIES_CHANGED")
                except BaseException as error:
                    failures.append({"stage": "post-source", "type": type(error).__name__, "message": str(error)})
                if budget.cancel_signal is not None:
                    failures.append({"stage": "owner", "type": "CANCELLED", "signal": budget.cancel_signal})
                if time.monotonic() >= budget.deadline:
                    failures.append({"stage": "owner", "type": "WHOLE_OWNER_DEADLINE"})
                source_ok = before is not None and before == after
                inputs_ok = (inputs_before is not None and inputs_before == inputs_after) if role == "s4" else (witness_before is not None and witness_before == witness_after)
                passed = not failures and process is not None and core is not None and source_ok and inputs_ok
                report = {"schema": "cherri-fixed-source-owner/1", "role": role, "mode": config.get("mode"),
                    "createdAt": owned.utc(), "status": "PASS" if passed else "FAIL" if process is not None else "NOT_RUN",
                    "source": config["head"], "tree": config["tree"], "branch": config["branch"],
                    "failures": failures, "process": process, "strictCore": core,
                    "sourceUnchanged": source_ok, "inputsUnchanged": inputs_ok, "minimumFree": owner.minimum,
                    "elapsedSeconds": time.monotonic()-entered, "goSeconds": 900,
                    "driverSeconds": 930 if role == "s4" else 1200, "wholeOwnerSeconds": budget.seconds,
                    "ownerSHA256": config["ownerSHA256"], "helperSHA256": HELPER_SHA256,
                    "configSHA256": sha(config_raw), "historicalOwnerReconstructed": False,
                    "originalStrictCoreAuditorSHA256": ORIGINAL_AUDITOR_SHA256 if role == "s4" else None,
                    "originalRawProducerProtocolSHA256": RAW_ORIGINAL_OWNER_SHA256 if role == "raw505" else None,
                    "nativeAcceptance": False, "formal179Acceptance": False, "independentIntakeRequired": True}
                with budget.defer():
                    result_pin = owned.original(out/"result.original.json", report)
    print(json.dumps({"result": str(out/"result.original.json"), "sha256": result_pin["sha256"],
                      "status": report["status"], "role": role, "elapsedSeconds": report["elapsedSeconds"]}), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
