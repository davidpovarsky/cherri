"""Fixed original macro refresh/verify with one new 1200-second whole owner.

The qualified helper, process/admission/source boundaries and original producer
child budgets remain unchanged. Two canonical output paths are the only allowed
source changes. S708 installed-pair provenance is independent of this compiler.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import stat
import sys
import time

P = Path(__file__).resolve().parent
SHARED_SHA256 = "8452dcf07565838816122a027c9800998b3b67ec6b917b5ac66fe8fd38625e81"
HELPER_SHA256 = "4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
for name, digest in (("fixed_source_owner.py", SHARED_SHA256), ("owned_source_process.py", HELPER_SHA256)):
    if hashlib.sha256((P/name).read_bytes()).hexdigest() != digest:
        raise SystemExit("CM_OWNER_DEPENDENCY_CHANGED")
spec = importlib.util.spec_from_file_location("canonical_macro_fixed_owner", P/"fixed_source_owner.py")
fixed = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = fixed
spec.loader.exec_module(fixed)

WORKTREE = Path("/mnt/development/projects/releases/cherri-p10r15-final-generated-source-20261126")
HEAD = "b54e7eb1bc7fecc8b22ba543896873b1d1e4e18e"
TREE = "5d1ef88c190b17dfb2e2fa81e8fa8502a9ac849d"
BRANCH = "agent/cherri-p10r15-final-generated-gates-20261126"
OUTPUT = Path("/mnt/development/projects/evidence/cherri-p10r15-ci-release-20261125/final-macro-original-02")
GENERATOR = "tools/p10r15/generate_macro_contract_coverage.py"
GENERATOR_SHA256 = "cfb8d0f7a7118218e257ee2f71c1006d78a712648a58d5c24ea680c168bae1da"
GENERATED = ("docs/apple-runtime/p10r15/macro-contract-coverage.json",
             "docs/apple-runtime/p10r15/macro-contract-coverage.md")
RAW_PINS = {
    "docs/apple-runtime/p10/p10-505-execution-evidence.json": "dd4532b8ff7d025cd09821979ce785d4ba4f2c4461877686d8d26b4c4779bf28",
    "docs/apple-runtime/p10/p10-505-parameter-contract-evidence.json": "74c5ed6ffb65594937aefcf248cef7f1d5ed47388fc57352c148f478e14f8eb5",
}
C1_PINS = {
    "docs/apple-runtime/p10r15/action-contract-execution.json": "7331c7a49b23fa6a477f873b88c0ce5b855ca4ae232ec256c85486a86416b613",
    "docs/apple-runtime/p10r15/action-contract-coverage.json": "66da687d46c0d4b9a15f9fc4518a3f8d52357523def5ab885c89c7506c7373b5",
    "docs/apple-runtime/p10r15/action-contract-coverage.md": "a4e04182c3679adf9537757dd1daadda5e1f356c2b40a8231e9c87eea064511e",
}
C2_PINS = {
    "docs/apple-runtime/p10/p10-505-catalog-coverage-matrix.json": "f96ad33e44eb8f3ed3d3eb6e85b9718901058675577afe0adda9eae243b58969",
    "docs/apple-runtime/p10/p10-pack-15-go-only-audit.json": "27500b124a5ea217171cec4c2ba1b9a0d557c10ffb5a07281242c2975e5b1eea",
    "docs/apple-runtime/p10/p10-apple-cherri-crosswalk.json": "7466dc29354f7173f3945181086db0aa3b1933d6343906b463867aac10f93e26",
    "docs/apple-runtime/p10/catalog-supported-by-compiler.md": "4530b8db80bbcf485360073c323f03bf54bc7872282312a47786fa73f3a16989",
    "docs/apple-runtime/p10/apple-discovered-not-supported.md": "01602b17ea26dd2d28e3874e4b55c147d0c87aebc3a0e9958817ec99ea9583c1",
    "docs/apple-runtime/p10/pure-pack-portability.md": "94a0231a152437bff0eabd5deb04f6ac895534e980352034f543c8f67e651556",
    "docs/apple-runtime/p10/baseline-state.json": "e8bcaed10862ac89257d46fdfa1886f3ae67a80ffc6eb461a7bba2d9a392cd9c",
}
COMMANDS = (["/usr/bin/python3", "-B", GENERATOR, "--refresh"],
            ["/usr/bin/python3", "-B", GENERATOR, "--verify"])

# Output/source snapshot and partial retention functions follow the reviewed C2
# route; only fixed identities, two output names and diagnostic labels differ.
def validate_post_state(before, after):
    """Validate actual observed bytes; never substitute original output bytes."""
    fixed.require(tuple(before[k] for k in ("head", "tree", "branch", "status")) == (HEAD, TREE, BRANCH, ""), "CM_BEFORE_IDENTITY")
    fixed.require(tuple(after[k] for k in ("head", "tree", "branch")) == (HEAD, TREE, BRANCH), "CM_AFTER_IDENTITY")
    changes = after["status"].splitlines()
    fixed.require(len(changes) == len(set(changes)) and all(line in {" M "+p for p in GENERATED} for line in changes), "CM_UNDECLARED_OR_INDEX_CHANGE")
    old, current = before["trackedPhysicalInputs"], after["trackedPhysicalInputs"]
    fixed.require(set(old) == set(current), "CM_TRACKED_INVENTORY_CHANGED")
    fixed.require(set(GENERATED).issubset(old), "CM_MISSING_DECLARED_PRODUCT")
    for name, row in current.items():
        if name in GENERATED:
            fixed.require(row["mode"] == old[name]["mode"] == "100644" and 0 < row["bytes"] <= 8*1024*1024,
                          "CM_PRODUCT_TYPE_OR_BOUND")
        else:
            fixed.require(row == old[name], "CM_NONPRODUCT_SOURCE_CHANGED:"+name)
    for path, digest in {**RAW_PINS, **C1_PINS, **C2_PINS}.items():
        fixed.require(old[path]["sha256"] == current[path]["sha256"] == digest, "CM_RAW_C0_CHANGED")
    return sorted(name for name in old if old[name] != current[name])

def snapshot_after(owner, before):
    """Strict physical snapshot permitting only exact macro tracked output paths."""
    w = owner.worktree
    fixed.require(w.resolve(strict=True) == w and (w/".git").is_dir() and not (w/".git").is_symlink(), "ORDINARY_SOURCE_REQUIRED")
    fixed.require(not (w/".git/objects/info/alternates").exists() and not (w/".git/info/grafts").exists(), "NO_ALTERNATES_OR_GRAFTS")
    fixed.require(not owner.git("replace", "-l", finalizing=True), "NO_REPLACE_REFS")
    metadata = {}
    for key, args in (("head", ("rev-parse", "HEAD")), ("tree", ("rev-parse", "HEAD^{tree}")),
                      ("branch", ("branch", "--show-current")), ("status", ("status", "--porcelain=v1", "--untracked-files=all"))):
        raw = owner.git(*args, finalizing=True).decode()
        metadata[key] = raw if key == "status" else raw.strip()
    fixed.require(not owner.git("diff", "--cached", "--name-only", finalizing=True), "CM_INDEX_CHANGED")
    tracked = {}
    listing = owner.git("ls-tree", "-rz", "--full-tree", "HEAD", finalizing=True)
    for index, line in enumerate(listing.split(b"\0")):
        if not line:
            continue
        owner.budget.check()
        if index % 128 == 0:
            owner.monitor()
        left, name = line.split(b"\t", 1)
        mode, kind, blob = left.decode().split()
        name = name.decode()
        fixed.require(name not in tracked and kind == "blob" and mode in ("100644", "100755", "120000"), "CM_TRACKED_FILE_KIND")
        fixed.require(name in before["trackedPhysicalInputs"] and
                      (mode, blob) == tuple(before["trackedPhysicalInputs"][name][k] for k in ("mode", "blob")), "CM_GIT_TREE_CHANGED")
        path = w/name
        info = path.lstat()
        if mode == "120000":
            fixed.require(stat.S_ISLNK(info.st_mode), "TRACKED_LINK_KIND")
            raw = os.fsencode(os.readlink(path))
        else:
            fixed.require(stat.S_ISREG(info.st_mode) and bool(info.st_mode & 0o111) == (mode == "100755"), "TRACKED_FILE_MODE")
            raw = owner.read(path)
        observed_blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if name not in GENERATED:
            fixed.require(observed_blob == blob, "CM_PHYSICAL_SOURCE_MISMATCH:"+name)
        tracked[name] = {"mode": mode, "blob": observed_blob, "bytes": len(raw), "sha256": fixed.sha(raw)}
    metadata["trackedPhysicalInputs"] = tracked
    validate_post_state(before, metadata)
    return metadata

def retain_partial_products(owner):
    directory = owner.out/"observed-products"
    directory.mkdir(mode=0o700)
    inventory = {}
    for path in GENERATED:
        p = owner.worktree/path
        if not p.exists() and not p.is_symlink():
            inventory[path] = {"state": "ABSENT"}
            continue
        info = p.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > 8*1024*1024:
            inventory[path] = {"state": "UNRETAINED_INVALID_TYPE_OR_SIZE", "mode": info.st_mode, "bytes": info.st_size}
            continue
        inventory[path] = {"state": "RETAINED", **fixed.owned.original(directory/p.name, owner.read(p))}
    fixed.owned.original(directory/"inventory.original.json", inventory)




def producer_fingerprint(owner):
    """Call the actual pinned producer's read-only fingerprint function."""
    raw = owner.read(WORKTREE/GENERATOR)
    fixed.require(fixed.sha(raw) == GENERATOR_SHA256, "CM_PRODUCER_PIN")
    spec = importlib.util.spec_from_file_location("owned_macro_fingerprint", WORKTREE/GENERATOR)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    owner.budget.check()
    value = module.input_fingerprint(WORKTREE)
    owner.budget.check()
    fixed.require(re.fullmatch(r"[a-f0-9]{64}", value) is not None, "CM_FINGERPRINT_SHAPE")
    return value


def validate_product_values(values, fingerprint):
    fixed.require(set(values) == set(GENERATED), "CM_CLOSED_PRODUCT_INVENTORY")
    report = json.loads(values[GENERATED[0]])
    fixed.require(report["formatVersion"] == 1 and report["sourceSha"] == HEAD and
                  report["worktreeDirtyBeforeExecution"] is False and
                  report["sourceFingerprint"] == fingerprint and
                  report["generatorSHA256"] == GENERATOR_SHA256, "CM_ACTUAL_SOURCE_BINDING")
    fixed.require(report["scope"] == "SYNTHETIC_CLI_STRUCTURAL_AND_LOSSLESS_NATIVE_ONLY" and
                  report["privacy"] == {"privateCorpusRead": False, "signerUsed": False,
                                         "networkFixtureExecuted": False, "liveConsumerChanged": False},
                  "CM_NO_EXTERNAL_ACCEPTANCE")
    summary = report["summary"]
    counts = {"asanaChildren": 11, "open": 11, "closed": 0, "compilerMacros": 16,
              "compileChecks": 21, "compilePassed": 21, "causalMutationChecks": 38,
              "labelCompileChecks": 12, "labelMutationChecks": 314}
    fixed.require(all(type(summary.get(k)) is int and summary[k] == v for k, v in counts.items()) and
                  summary["structuralExecutionVerdict"] == "PASS" and
                  summary["releaseCompletion"] == "OPEN", "CM_ORIGINAL_COUNTS_AND_SCOPE")
    fixed.require(len(report["compiles"]) == 21 and len(report["causalMutations"]) == 38 and
                  len(report["requirements"]) == 11, "CM_ORIGINAL_RECORD_INVENTORY")
    fixed.require(report["compilerMacroCount"] == 16 and report["nativeCatalogCount"] == 505 and
                  re.fullmatch(r"[a-f0-9]{64}", report["compilerSHA256"]) is not None, "CM_COMPILER_OBSERVATION")
    labels = report["labelControls"]
    fixed.require(labels["implementationSha"] == HEAD and labels["cleanCheckout"] is True and
                  labels["compilerSha256"] == report["compilerSHA256"] and
                  labels["nativeExecution"] == "NOT_RUN" and labels["formalAcceptanceGranted"] is False,
                  "CM_LABEL_SOURCE_AND_SCOPE")
    for row in report["requirements"]:
        fixed.require(row["status"] == "OPEN" and row["signedSimulator"] == "NOT_ESTABLISHED_BY_THIS_LEDGER" and
                      row["physicalDevice"] == "BLOCKED_DEVICE" and
                      row["closure"] == "NOT_PROVEN_BY_STRUCTURAL_EVIDENCE", "CM_REQUIREMENTS_REMAIN_OPEN")
    fixed.require(values[GENERATED[1]].decode("utf-8").strip(), "CM_MARKDOWN_NONEMPTY")
    return {"summary": summary, "compilerSHA256": report["compilerSHA256"],
            "sourceFingerprint": fingerprint, "macroFingerprint": report["macroFingerprint"],
            "observationsSHA256": report["observationsSHA256"]}


def verify_products(owner, fingerprint):
    directory = owner.out/"products"
    directory.mkdir(mode=0o700)
    values, pins = {}, {}
    for path in GENERATED:
        p = owner.worktree/path
        fixed.require(p.is_file() and not p.is_symlink(), "CM_PRODUCT_REGULAR_FILE")
        raw = owner.read(p)
        fixed.require(0 < len(raw) <= 8*1024*1024, "CM_PRODUCT_SIZE")
        raw.decode("utf-8")
        values[path] = raw
        pins[path] = fixed.owned.original(directory/p.name, raw)
    return {"pins": pins, "observations": validate_product_values(values, fingerprint)}


def main():
    fixed.require(len(sys.argv) == 1, "CM_FIXED_NO_ARGUMENT_ROUTE")
    sys.dont_write_bytecode = True
    with fixed.owned.WholeBudget(1200, cleanup_seconds=8, final_reserve=20) as budget:
        fixed.require(OUTPUT.parent.resolve(strict=True) == OUTPUT.parent and not OUTPUT.exists(), "CM_FRESH_OUTPUT")
        OUTPUT.mkdir(mode=0o750)
        os.chown(OUTPUT, 1001, 1001)
        owner = fixed.SourceOwner({"worktree": str(WORKTREE)}, OUTPUT, budget)
        before = after = dependency_before = dependency_after = macro_before = macro_after = None
        processes, failures, products = [], [], None
        plan = {"schema": "cherri-canonical-macro-selection/1", "source": HEAD, "tree": TREE, "branch": BRANCH,
                "worktree": str(WORKTREE), "commands": COMMANDS, "wholeOwnerSeconds": 1200,
                "ownerBudgetOrigin": "New explicit whole observation budget; not a historical producer budget",
                "canonicalChildBudgetsSeconds": {"build": 300, "docsGoRun": 300, "ordinaryCLI": 90, "labelCLI": 60},
                "refreshMaximumSeconds": 1200, "verifyMaximumSeconds": 120,
                "cleanupAndPostSourceIncluded": True, "rawPins": RAW_PINS, "c1Pins": C1_PINS, "c2Pins": C2_PINS,
                "generatedPaths": list(GENERATED), "generatorSHA256": GENERATOR_SHA256,
                "nativeAcceptance": False, "global179Acceptance": False}
        fixed.owned.original(OUTPUT/"selection.original.json", plan)
        for name in ("fixed_source_owner.py", "owned_source_process.py", "canonical_macro_owner.py"):
            fixed.owned.original(OUTPUT/name, (P/name).read_bytes())
        try:
            before = owner.snapshot()
            fixed.owned.original(OUTPUT/"source-before.original.json", before)
            fixed.require(tuple(before[k] for k in ("head", "tree", "branch", "status")) == (HEAD, TREE, BRANCH, ""), "CM_CLEAN_EXACT_SOURCE")
            remote = owner.git("-c", "credential.helper=", "-c", "credential.helper=!gh auth git-credential", "ls-remote", "--heads", "origin", "refs/heads/"+BRANCH)
            fixed.owned.original(OUTPUT/"remote-ref.original.txt", remote)
            fixed.require(remote.decode().strip().split() == [HEAD, "refs/heads/"+BRANCH], "CM_PUBLISHED_SOURCE")
            for path, digest in {GENERATOR: GENERATOR_SHA256, **RAW_PINS, **C1_PINS, **C2_PINS}.items():
                fixed.require(fixed.sha(owner.read(WORKTREE/path)) == digest, "CM_INPUT_PIN:"+path)
            fixed.require(fixed.sha(owner.read(fixed.GO)) == fixed.GO_SHA256, "CM_GO_BINARY_PIN")
            preimages = OUTPUT/"preimages"
            preimages.mkdir(mode=0o700)
            for path in GENERATED:
                fixed.owned.original(preimages/Path(path).name, owner.read(WORKTREE/path))
            dependency_before = owner.dependencies()
            fixed.require(not (set(GENERATED) & {x["path"] for x in dependency_before["files"]}), "CM_OUTPUT_IN_C2_INPUTS")
            fixed.owned.original(OUTPUT/"dependency-before.original.json", dependency_before)
            macro_before = producer_fingerprint(owner)
            fixed.owned.original(OUTPUT/"macro-fingerprint-before.original.json", {"fingerprint": macro_before})
            _, observer_stdout, observer_stderr = owner.observe_concurrent_owner()
            decision = json.loads(owner.read(observer_stdout))
            fixed.require(not owner.read(observer_stderr) and decision.get("admitted") is True and decision.get("blockedPids") == [], "CM_EXCLUSIVE_GO_ADMISSION")
            floors = {"root": 939524096, "development": 1073741824, "shm": 402653184, "memoryAvailable": 3221225472}
            observed_free = fixed.free()
            admitted = all(observed_free[k] >= v for k, v in floors.items())
            fixed.owned.original(OUTPUT/"preflight.original.json", {"free": observed_free, "admission": floors, "liveFloor": fixed.LIVE_FLOORS, "admitted": admitted})
            fixed.require(admitted, "CM_CAPACITY_ADMISSION")
            for label, command, seconds in zip(("canonical-macro-refresh", "canonical-macro-verify"), COMMANDS, (1200, 120)):
                row, _, _ = owner.command(label, command, seconds, require_zero=False)
                processes.append(row)
                fixed.owned.require_success(row)
            products = verify_products(owner, macro_before)
        except BaseException as error:
            failures.append({"stage": "execution", "type": type(error).__name__, "message": str(error)})
        finally:
            with budget.finalizing():
                try:
                    retain_partial_products(owner)
                except BaseException as error:
                    failures.append({"stage": "product-retention", "type": type(error).__name__, "message": str(error)})
                try:
                    if before is not None:
                        after = snapshot_after(owner, before)
                        fixed.owned.original(OUTPUT/"source-after.original.json", after)
                    if dependency_before is not None:
                        dependency_after = owner.dependencies()
                        fixed.owned.original(OUTPUT/"dependency-after.original.json", dependency_after)
                        fixed.require(dependency_before == dependency_after, "CM_C2_DEPENDENCY_CHANGED")
                    if macro_before is not None:
                        macro_after = producer_fingerprint(owner)
                        fixed.owned.original(OUTPUT/"macro-fingerprint-after.original.json", {"fingerprint": macro_after})
                        fixed.require(macro_before == macro_after, "CM_MACRO_DEPENDENCY_CHANGED")
                except BaseException as error:
                    failures.append({"stage": "post-source", "type": type(error).__name__, "message": str(error)})
                if budget.cancel_signal is not None or time.monotonic() >= budget.deadline:
                    failures.append({"stage": "owner", "type": "CANCELLED_OR_DEADLINE", "signal": budget.cancel_signal})
                passed = not failures and len(processes) == 2 and products is not None and before is not None and after is not None
                report = {"schema": "cherri-canonical-macro-owned-execution/1", "source": HEAD, "tree": TREE,
                          "status": "PASS" if passed else "FAIL" if processes else "NOT_RUN", "failures": failures,
                          "processes": processes, "products": products, "minimumFree": owner.minimum,
                          "wholeOwnerSeconds": 1200, "elapsedSeconds": time.monotonic()-budget.started,
                          "declaredGeneratedPaths": list(GENERATED), "sourceClosureUnchanged": before is not None and after is not None and not any(f["stage"] == "post-source" for f in failures),
                          "dependenciesUnchanged": dependency_before is not None and dependency_before == dependency_after and macro_before == macro_after,
                          "nativeAcceptance": False, "global179Acceptance": False,
                          "ownerSHA256": fixed.sha(Path(__file__).read_bytes()), "sharedControllerSHA256": SHARED_SHA256, "helperSHA256": HELPER_SHA256}
                with budget.defer():
                    pin = fixed.owned.original(OUTPUT/"result.original.json", report)
    print(json.dumps({"result": str(OUTPUT/"result.original.json"), "sha256": pin["sha256"], "status": report["status"]}), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
