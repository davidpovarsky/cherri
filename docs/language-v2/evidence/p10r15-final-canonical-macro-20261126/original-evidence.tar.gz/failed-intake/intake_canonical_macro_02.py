"""Read-only intake of the fixed second CM execution; no producer replay."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import stat
import sys
import time

BASE = Path('/mnt/development/projects/preserved/cherri-final-owner-20261126')
EXECUTION = Path('/mnt/development/projects/evidence/cherri-p10r15-ci-release-20261125/final-macro-original-02')
OUTPUT = BASE/'canonical-macro-original-intake-02'
OWNER = BASE/'canonical-macro-source-02/canonical_macro_owner.py'
OWNER_SHA = 'd62277f09338a838f310a8e0f4d4746ad9d212f327404bfad5158596dac012ad'
RESULT_SHA = '2dff943a82b60e19dde9554928ef7bb87811698cac19160d01e85d158bb661de'
checks = 0


def require(condition, reason):
    global checks
    checks += 1
    if not condition:
        raise ValueError(reason)


def read(path, digest=None):
    path = Path(path)
    require(stat.S_ISREG(path.lstat().st_mode), 'REGULAR_FILE:'+str(path))
    data = path.read_bytes()
    if digest is not None:
        require(hashlib.sha256(data).hexdigest() == digest, 'EXACT_BYTES:'+str(path))
    return data


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    require(len(sys.argv) == 1 and len(RESULT_SHA) == 64, 'FIXED_ACTUAL_RESULT_REQUIRED')
    sys.dont_write_bytecode = True
    started = time.monotonic()
    read(OWNER, OWNER_SHA)
    owner = load_module('cm_original_owner_intake', OWNER)
    fixed = owner.fixed
    source_raw = read(EXECUTION/'result.original.json', RESULT_SHA)
    source_result = json.loads(source_raw)
    require(source_result['status'] == 'PASS' and source_result['failures'] == [], 'ORIGINAL_OWNER_PASS')
    require((source_result['source'], source_result['tree']) == (owner.HEAD, owner.TREE), 'ACTUAL_SOURCE')
    require(source_result['ownerSHA256'] == OWNER_SHA and
            source_result['sharedControllerSHA256'] == owner.SHARED_SHA256 and
            source_result['helperSHA256'] == owner.HELPER_SHA256, 'OWNER_CLOSURE')
    require(source_result['wholeOwnerSeconds'] == 1200 and source_result['elapsedSeconds'] < 1200 and
            source_result['sourceClosureUnchanged'] is True and source_result['dependenciesUnchanged'] is True,
            'BOUNDED_UNCHANGED_SOURCE')
    require(source_result['nativeAcceptance'] is False and source_result['global179Acceptance'] is False, 'SCOPE')
    OUTPUT.mkdir(mode=0o700, exist_ok=False)
    original = OUTPUT/'originals'
    original.mkdir(mode=0o700)
    files = sorted(p for p in EXECUTION.rglob('*') if p.is_file() or p.is_symlink())
    require(0 < len(files) <= 160, 'BOUNDED_ORIGINAL_INVENTORY')
    inventory = []
    for path in files:
        relative = path.relative_to(EXECUTION)
        data = read(path)
        require(len(data) <= 8*1024*1024, 'ORIGINAL_SIZE_BOUND')
        target = original/relative
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        pin = fixed.owned.original(target, data)
        require(read(target) == data, 'ORIGINAL_COPY_EXACT')
        inventory.append({'path': str(relative), 'bytes': len(data), 'sha256': pin['sha256']})
    require([str(p.relative_to(EXECUTION)) for p in files] ==
            sorted(str(p.relative_to(EXECUTION)) for p in EXECUTION.rglob('*') if p.is_file() or p.is_symlink()),
            'ORIGINAL_INVENTORY_STABLE')
    for item in inventory:
        read(EXECUTION/item['path'], item['sha256'])
    before = json.loads(read(original/'source-before.original.json'))
    after = json.loads(read(original/'source-after.original.json'))
    changed = owner.validate_post_state(before, after)
    require(set(changed) == set(owner.GENERATED), 'ONLY_TWO_GENERATED_PRODUCTS_CHANGED')
    require(read(original/'dependency-before.original.json') == read(original/'dependency-after.original.json'),
            'C2_DEPENDENCY_BYTES_UNCHANGED')
    macro_before = json.loads(read(original/'macro-fingerprint-before.original.json'))
    require(macro_before == json.loads(read(original/'macro-fingerprint-after.original.json')), 'MACRO_DEPENDENCY_UNCHANGED')
    values, products = {}, {}
    for path in owner.GENERATED:
        record = source_result['products']['pins'][path]
        data = read(original/'products'/Path(path).name, record['sha256'])
        require(len(data) == record['bytes'] and data == read(owner.WORKTREE/path), 'ACTUAL_PRODUCT_RETAINED')
        require(after['trackedPhysicalInputs'][path]['sha256'] == record['sha256'], 'POST_SOURCE_PRODUCT_BINDING')
        values[path] = data
        products[path] = {'sha256': record['sha256'], 'bytes': len(data)}
    observation = owner.validate_product_values(values, macro_before['fingerprint'])
    require(observation == source_result['products']['observations'], 'ORIGINAL_SCOPE_GUARD_REPLAY')
    generator_path = owner.WORKTREE/owner.GENERATOR
    read(generator_path, owner.GENERATOR_SHA256)
    generator = load_module('cm_declared_inventory_intake', generator_path)
    report = json.loads(values[owner.GENERATED[0]])
    specs = generator.fixture_specs()
    require(len(specs) == len(report['compiles']) == 21, 'EXACT_TWENTY_ONE_FIXTURES')
    for spec, case in zip(specs, report['compiles']):
        require(all(case[key] == spec[key] for key in ('id', 'kind', 'dialect', 'profile', 'source')), 'FIXTURE_IDENTITY')
        require(case['sourceSHA256'] == hashlib.sha256(spec['source'].encode()).hexdigest() and case['verdict'] == 'PASS', 'FIXTURE_HASH_AND_PASS')
        require(case['signedRuntime'] == case['physicalDevice'] == 'NOT_EXECUTED', 'NO_NATIVE_CREDIT')
        if case['kind'] == 'negative':
            require(case['exitCode'] == 1 and case['noArtifact'] is True and case['expectedDiagnostic'] == spec['diagnostic'], 'EXACT_NEGATIVE_OUTCOME')
            if 'diagnosticExact' in spec:
                require(case['diagnosticTail'] == spec['diagnosticExact'] and case['expectedDiagnosticExact'] == spec['diagnosticExact'], 'FULL_NEGATIVE_DIAGNOSTIC')
        else:
            require(case['exitCode'] == 0 and case['structuralChecks'] and all(v is True for v in case['structuralChecks'].values()), 'POSITIVE_GRAPH')
            require(case['nativeActionCount'] == sum(case['nativeActionIDs'].values()) and
                    case['decompile']['importExitCode'] == case['decompile']['recompileExitCode'] == 0 and
                    case['decompile']['nativeActionsExact'] is True, 'ACTUAL_LOSSLESS_ROUNDTRIP')
    mutations = report['causalMutations']
    require(tuple((m['case'], m['mutation'], m['intendedCheck']) for m in mutations) == generator.MUTATION_SCENARIOS and len(mutations) == 38,
            'EXACT_THIRTY_EIGHT_CAUSAL_IDENTITIES')
    require(all(m['verdict'] == 'PASS' and m['positiveControl'] is True and m['faultRejected'] is True for m in mutations), 'CAUSAL_OUTCOMES')
    require(report['observationsSHA256'] == generator.observations_digest(report), 'OBSERVATION_DIGEST')
    require(values[owner.GENERATED[1]] == generator.markdown(report).encode(), 'EXACT_DERIVED_MARKDOWN')
    processes = source_result['processes']
    require(len(processes) == 2, 'TWO_ORIGINAL_PRODUCER_INVOCATIONS')
    stream_records = []
    for index, (process, command) in enumerate(zip(processes, owner.COMMANDS)):
        require(process['argv'] == ['/usr/sbin/runuser', '-u', 'ubuntu', '--', *command] and
                process['status'] == 'PASS' and process['exitCode'] == 0 and process['error'] is None and
                not process['cancelled'] and not process['timedOut'] and not process['wholeDeadlineExceeded'], 'ACTUAL_FIXED_COMMAND')
        require(process['cleanup']['parentReaped'] and process['cleanup']['noLiveGroupMembers'] and
                not process['cleanup']['errors'] and process['cleanup']['after']['state'] in ('ABSENT','ZOMBIE_ONLY'), 'OWNED_GROUP_CLEANUP')
        streams = {}
        for key in ('stdout', 'stderr'):
            record = process[key]
            relative = Path(record['path']).relative_to(EXECUTION)
            data = read(original/relative, record['sha256'])
            require(len(data) == record['bytes'] and record['complete'], 'COMPLETE_ORIGINAL_STREAM')
            streams[key] = data
        lines = [json.loads(line) for line in streams['stdout'].splitlines() if line.strip()]
        if index == 0:
            expected_cases = [{'case': spec['id'], 'verdict': 'PASS'} for spec in specs]
            require(lines[:-2] == expected_cases and
                    lines[-2] == {'component':'label','actualCompileCount':12,'rejectedMutationCount':314,'nativeExecution':'NOT_RUN'},
                    'ACTUAL_COMPILE_AND_LABEL_STREAM_IDENTITIES')
        else:
            require(len(lines) == 1, 'SINGLE_VERIFY_SUMMARY')
        require(lines[-1] == report['summary'], 'PRODUCER_STREAM_REPORT_JOIN')
        stream_records.append({'command': command, 'stdoutSHA256': process['stdout']['sha256'],
                               'stderrSHA256': process['stderr']['sha256'], 'elapsedSeconds': process['elapsedSeconds'],
                               'observedCleanupState': process['cleanup']['after']['state']})
    result = {'schema':'cherri-canonical-macro-independent-intake/1','status':'PASS',
              'actualProducerSource':owner.HEAD,'actualProducerTree':owner.TREE,'originalResultSHA256':RESULT_SHA,
              'ownerSHA256':OWNER_SHA,'generatorSHA256':owner.GENERATOR_SHA256,
              'originalFiles':inventory,'products':products,'summary':report['summary'],
              'sourceBeforeSHA256':hashlib.sha256(read(original/'source-before.original.json')).hexdigest(),
              'sourceAfterSHA256':hashlib.sha256(read(original/'source-after.original.json')).hexdigest(),
              'rawPins':owner.RAW_PINS,'c1Pins':owner.C1_PINS,'c2Pins':owner.C2_PINS,
              'sourceFingerprint':report['sourceFingerprint'],'macroFingerprint':report['macroFingerprint'],
              'actualCompilerSHA256':report['compilerSHA256'],'commands':stream_records,
              'compileIdentities':[s['id'] for s in specs],'checks':checks,'elapsedSeconds':time.monotonic()-started,
              'producerExecutionsByIntake':0,'goExecutionsByIntake':0,'nativeAcceptance':False,'formal179Acceptance':False,
              'scope':'Synthetic CLI structural checks and exact native-action lossless roundtrip; all11 original macro obligations remainOPEN.'}
    fixed.owned.original(OUTPUT/'intake-source.original.py', Path(__file__).read_bytes())
    pin = fixed.owned.original(OUTPUT/'intake.original.json', result)
    print(json.dumps({'path':str(OUTPUT/'intake.original.json'),'sha256':pin['sha256'],'status':'PASS','checks':checks,'originalFiles':len(inventory),'summary':report['summary']}))


if __name__ == '__main__':
    main()
