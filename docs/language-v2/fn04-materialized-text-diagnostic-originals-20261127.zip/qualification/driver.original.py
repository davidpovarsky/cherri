import json,os,sys,unittest
from pathlib import Path
sys.path[:0]=[sys.argv[1],sys.argv[2]]
import test_native_materialized_caller_diagnostic as tested
events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  events.append({"event":"run","test":test.id()});super().startTest(test)
 def addSuccess(self,test):
  events.append({"event":"pass","test":test.id()});super().addSuccess(test)
 def addSubTest(self,test,subtest,error):
  events.append({"event":"subtest","test":test.id(),"parameters":str(subtest),"status":"PASS" if error is None else "FAIL"});super().addSubTest(test,subtest,error)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(tested.MaterializedCallerDiagnosticTests)
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
value={"testsRun":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),"events":events,"nativeExecuted":False,"signingCalls":0}
with Path(sys.argv[3]).open("x") as f:json.dump(value,f,sort_keys=True,indent=2);f.write("\n")
raise SystemExit(0 if result.wasSuccessful() else 1)
