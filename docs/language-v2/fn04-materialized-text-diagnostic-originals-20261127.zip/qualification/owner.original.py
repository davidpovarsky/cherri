from pathlib import Path
import hashlib, importlib.util, json, os, socket, stat, sys, time, traceback
assert socket.gethostname() == "torah-social" and os.getuid() == 0
sys.dont_write_bytecode = True
os.umask(0o077)
P=Path("/var/cache/cherri-native-contract-producers-20261126")
O=P/"supported-fn04-materialized-native-qualification-01"
Q=P/"supported-fn04-materialized-native-proposal-01/files/tools/shortcuts-simulator-qa"
BASE=P/"source/tools/shortcuts-simulator-qa"
B=P/"supported-fn04-materialized-original-bundle-01/bundle"
H=Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py")
EXPECTED={"native_materialized_caller_diagnostic.py":"ad0cb891c97389cacd46ba187d28286fdfa8f0693e7e2e4df855bf9bfe585509",
          "test_native_materialized_caller_diagnostic.py":"e78526a7046adb92d8459e96646e94a2eacbcdfe0bd3a0bf58180d917882cf45"}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def read(p):
    s=p.lstat();need(stat.S_ISREG(s.st_mode)and not p.is_symlink()and s.st_size<=2*1024*1024,"REGULAR_SOURCE")
    b=p.read_bytes();a=p.lstat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns),"STABLE_SOURCE")
    return b
def snapshot():
    paths=sorted(BASE.glob("*.py"))+sorted(Q.glob("*.py"))+sorted(p for p in B.rglob("*")if p.is_file())
    need(len(paths)<=700,"SOURCE_FILE_BOUND")
    return {str(p):{"bytes":len(raw),"sha256":sha(raw),"mode":stat.S_IMODE(p.lstat().st_mode)} for p in paths for raw in [read(p)]}
need(sha(read(H))=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85","QUALIFIED_OWNER")
spec=importlib.util.spec_from_file_location("owned",H);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
O.mkdir(mode=0o700);C=O/"commands";C.mkdir(mode=0o700)
owned.original(O/"owner.original.py",read(Path(__file__)))
driver='''import json,os,sys,unittest
from pathlib import Path
sys.path[:0]=[sys.argv[1],sys.argv[2]]
import test_native_materialized_caller_diagnostic as tested
events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  events.append({"event":"run","test":test.id()});super().startTest(test)
 def addSuccess(self,test):
  events.append({"event":"pass","test":test.id()});super().addSuccess(test)
 def addSubTest(self,test,subtest,error):
  events.append({"event":"subtest","test":test.id(),"parameters":str(subtest),"status":"PASS" if error is None else "FAIL"});super().addSubTest(test,subtest,error)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(tested.MaterializedCallerDiagnosticTests)
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
value={"testsRun":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),"events":events,"nativeExecuted":False,"signingCalls":0}
with Path(sys.argv[3]).open("x") as f:json.dump(value,f,sort_keys=True,indent=2);f.write("\\n")
raise SystemExit(0 if result.wasSuccessful() else 1)
'''
owned.original(O/"driver.original.py",driver.encode())
result={"schema":"cherri-materialized-diagnostic-control-qualification/1","status":"FAIL","testsReplayed":False,"selectedParents":5,"expectedSubtests":30,"nativeExecuted":False,"signingCalls":0,"compilerInvocations":0,"formalAcceptanceGranted":False,"wholeSeconds":90,"childSeconds":60,"processes":[]}
start=time.monotonic();before=None
try:
 with owned.WholeBudget(90,cleanup_seconds=5,final_reserve=15)as budget:
  for name,pin in EXPECTED.items():need(sha(read(Q/name))==pin,"FROZEN_PROPOSAL")
  need(sha(read(B/"intake.original.json"))=="430c3c6ab5132d63120aad879cd76200bf5c8f555931c0e883d54414fd72e852","AUTHENTIC_ORIGINAL_BUNDLE")
  before=snapshot();owned.original(O/"source-before.original.json",before)
  env={key:value for key,value in os.environ.items()if key in("PATH","HOME","LANG","LC_ALL","LC_CTYPE","TZ")}
  env["CHERRI_MATERIALIZED_DIAGNOSTIC_BUNDLE"]=str(B)
  argv=[sys.executable,"-I","-B","-c",driver,str(Q),str(BASE),str(O/"control-events.original.json")]
  row=owned.run_owned(argv,cwd=Q,env=env,output=C,name="materialized-diagnostic-controls",budget=budget,seconds=60)
  result["processes"].append(row);owned.require_success(row)
  need(row["cleanup"]["parentReaped"]is True and row["cleanup"]["after"]["state"]=="ABSENT","CONTROL_CHILD_CLOSED")
  value=json.loads(read(O/"control-events.original.json"));parents=[e for e in value["events"]if e["event"]=="pass"];subs=[e for e in value["events"]if e["event"]=="subtest"]
  need(value["testsRun"]==5 and value["failures"]==value["errors"]==value["skipped"]==0 and len(parents)==5 and len(subs)==30 and all(e["status"]=="PASS"for e in subs),"EXACT_NEW_CONTROL_COUNTS")
  result.update(status="PASS_FIVE_NEW_PARENTS_THIRTY_SUBTESTS",actualParents=5,actualSubtests=30,eventsSHA256=sha(read(O/"control-events.original.json")))
except BaseException as error:
 result["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
 try:
  after=snapshot();owned.original(O/"source-after.original.json",after);need(before==after,"QUALIFICATION_INPUTS_CHANGED");result["sourceUnchanged"]=True;result["sourceFileCount"]=len(after)
 except BaseException as error:
  result["status"]="FAIL";result["closingError"]={"type":type(error).__name__,"message":str(error)}
 result["elapsedSeconds"]=time.monotonic()-start
 pin=owned.original(O/"result.original.json",result)
 print(json.dumps({"result":str(O/"result.original.json"),"sha256":pin["sha256"],"status":result["status"],"elapsedSeconds":result["elapsedSeconds"],"sourceFileCount":result.get("sourceFileCount"),"error":result.get("error"),"closingError":result.get("closingError"),"processes":[{"pid":p["pid"],"exitCode":p["exitCode"],"status":p["status"],"parentReaped":p["cleanup"]["parentReaped"],"groupAfter":p["cleanup"].get("after")}for p in result["processes"]]},sort_keys=True))
