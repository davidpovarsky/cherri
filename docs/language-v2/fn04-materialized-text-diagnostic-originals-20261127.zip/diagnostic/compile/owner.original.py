from pathlib import Path
import base64, hashlib, importlib.util, json, os, plistlib, pwd, re, shutil, socket, stat, sys, time, traceback, uuid, zipfile

assert socket.gethostname() == "torah-social" and os.getuid() == 0
sys.dont_write_bytecode = True
P = Path("/var/cache/cherri-native-contract-producers-20261126")
O = P / "supported-fn04-materialized-text-compile-01"
B = Path("/var/tmp/cherri-fn04-materialized-text-a763-20261127-01")
H = Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py")
H_SHA = "4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
BIN = Path("/mnt/development/projects/releases/cherri-p10r15-public-runtime-a763-20261127/cherri")
BIN_SHA = "eb79fb4145ed3927dc55f7fe623bc78a484ed35d2390d43ceed1b3777468c4fa"
COMPILER = "a7631a04b36e3a4ed0dffbb919d6508252024365"
TREE = "995c36967cfd881363cd0eb08cf33051ec831a4c"
HANDOFF = Path("/var/cache/cherri-public-products-a763-20261127/hosted-independent-intake-01/products-handoff.original.json")
HANDOFF_SHA = "b63207f73e9d6aa091c43933ad1d7457b5c1cd7552173215e69d078bd2859b2d"
RESTORATION = Path("/var/cache/cherri-raw505-a763-20261127/binary-restoration-01/result.original.json")
RESTORATION_SHA = "dec4ac18477456fdc3cc9a6593b9387910dc1c5ef47002c90f59e6c95040bb0f"
ORIGINAL_PACKET = P / "supported-fn04-companion-without-functions-original-intake-01/originals/native/runtime/exact-file-signing-originals/cases/without_functions/packet.derived.json"
ORIGINAL_PACKET_SHA = "372d5fef3573dca1c360031f0f84010f55df21eb7dffb9462447d0f8fee558f6"
COMPARISON = P / "supported-fn04-shared-clipboard-comparison-01/result.original.json"
COMPARISON_SHA = "fe92327053d0c8f6f257531c3d32d6da6535c6dd942e1d94ae901c0a7b5b842e"
NAME = "CherriFN04Materialized_9f4ac00a6d8c4acba51a9f37a9ce232d"
SOURCE = (b"let first=getVariable(system.input)\n"
          b"let second=getVariable(ShortcutInput)\n"
          b'let clipboardText=f"{first}|{second}"\n'
          b"setClipboard(clipboardText)")
SOURCE_PATH = B / (NAME + ".cherri")
UNSIGNED_PATH = B / (NAME + ".unsigned.shortcut")
ROOT_MIN = 1024 * 1024 * 1024
RAM_MIN = 2 * 1024 * 1024 * 1024

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def need(value, reason):
    if not value:
        raise ValueError(reason)

def strict(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, "DUPLICATE_JSON_KEY")
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs)

def read(path, limit=32 * 1024 * 1024):
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and not path.is_symlink() and before.st_size <= limit, "REGULAR_BOUND_FILE")
    raw = path.read_bytes()
    after = path.lstat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(all(getattr(before, key) == getattr(after, key) for key in fields) and len(raw) == before.st_size, "STABLE_FILE_READ")
    return raw

def pinned(path, expected, limit=32 * 1024 * 1024):
    raw = read(path, limit)
    need(sha(raw) == expected, "FILE_SHA_PIN:" + str(path))
    return raw

def rec(path):
    raw = read(path)
    st = path.lstat()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw), "uid": st.st_uid,
            "gid": st.st_gid, "mode": stat.S_IMODE(st.st_mode)}

def capacity():
    mem = {line.split(":")[0]: int(line.split()[1]) * 1024
           for line in Path("/proc/meminfo").read_text().splitlines()}
    row = {"rootAvailableBytes": shutil.disk_usage("/").free,
           "memoryAvailableBytes": mem["MemAvailable"],
           "rootMinimumBytes": ROOT_MIN, "memoryMinimumBytes": RAM_MIN}
    need(row["rootAvailableBytes"] >= ROOT_MIN, "ROOTFS_ORIGINAL_ONE_GIB_FLOOR")
    need(row["memoryAvailableBytes"] >= RAM_MIN, "TWO_GIB_MEMORY_FLOOR")
    return row

def action(identifier, parameters=None):
    row = {"WFWorkflowActionIdentifier": "is.workflow.actions." + identifier}
    if parameters is not None:
        row["WFWorkflowActionParameters"] = parameters
    return row

def attachment(value):
    return {"WFSerializationType": "WFTextTokenAttachment", "Value": value}

def output_ref(output_uuid, name):
    return {"Type": "ActionOutput", "OutputUUID": output_uuid, "OutputName": name}

def complete_graph(raw, original):
    graph = plistlib.loads(raw)
    need(type(graph) is dict and type(graph.get("WFWorkflowActions")) is list, "PLIST_ACTION_ARRAY")
    actions = graph["WFWorkflowActions"]
    need(len(actions) == 5 and all(type(row) is dict for row in actions), "EXACT_FIVE_ACTIONS")
    uuids = []
    for index, name in enumerate(("first", "second", "clipboardText")):
        q = actions[index].get("WFWorkflowActionParameters")
        need(type(q) is dict and q.get("CustomOutputName") == name and type(q.get("UUID")) is str, "NAMED_OUTPUT")
        value = q["UUID"]
        need(str(uuid.UUID(value)).upper() == value.upper(), "VALID_OUTPUT_UUID")
        uuids.append(value)
    need(len(set(uuids)) == 3, "UNIQUE_OUTPUT_UUIDS")
    text_value = {"WFSerializationType": "WFTextTokenString", "Value": {
        "string": "\ufffc|\ufffc", "attachmentsByRange": {
            "{0, 1}": output_ref(uuids[0], "first"),
            "{2, 1}": output_ref(uuids[1], "second")}}}
    expected = [
        action("getvariable", {"UUID": uuids[0], "CustomOutputName": "first", "WFVariable": attachment({"Type": "ExtensionInput"})}),
        action("getvariable", {"UUID": uuids[1], "CustomOutputName": "second", "WFVariable": attachment({"Type": "ExtensionInput"})}),
        action("gettext", {"UUID": uuids[2], "CustomOutputName": "clipboardText", "WFTextActionText": text_value}),
        action("setclipboard", {"WFInput": attachment(output_ref(uuids[2], "clipboardText"))}),
        action("nothing"),
    ]
    need(actions == expected, "COMPLETE_MATERIALIZED_ACTION_GRAPH")
    original_actions = original["WFWorkflowActions"]
    need(len(original_actions) == 4, "ORIGINAL_FOUR_ACTIONS")
    original_uuids = [original_actions[i]["WFWorkflowActionParameters"]["UUID"] for i in range(2)]
    expected_original = [
        action("getvariable", {"UUID": original_uuids[0], "CustomOutputName": "first", "WFVariable": attachment({"Type": "ExtensionInput"})}),
        action("getvariable", {"UUID": original_uuids[1], "CustomOutputName": "second", "WFVariable": attachment({"Type": "ExtensionInput"})}),
        action("setclipboard", {"WFInput": {"WFSerializationType": "WFTextTokenString", "Value": {
            "string": "\ufffc|\ufffc", "attachmentsByRange": {
                "{0, 1}": output_ref(original_uuids[0], "first"),
                "{2, 1}": output_ref(original_uuids[1], "second")}}}}),
        action("nothing"),
    ]
    need(original_actions == expected_original, "ORIGINAL_COMPLETE_GRAPH_BOUND")
    need(graph.get("WFWorkflowHasShortcutInputVariables") is True and graph.get("WFWorkflowHasOutputFallback") is False, "INPUT_AND_FALLTHROUGH_METADATA")
    if "WFWorkflowName" in graph:
        need(graph["WFWorkflowName"] == NAME, "ACTUAL_WORKFLOW_NAME")
    return {"actions": actions, "topLevelMetadata": {key: value for key, value in graph.items() if key != "WFWorkflowActions"},
            "actionCount": len(actions), "wholeArrayEquality": True,
            "originalInputReadsPreserved": True, "originalFinalNothingPreserved": True,
            "materializedTextIndex": 2, "clipboardConsumerIndex": 3,
            "clipboardInputSerializationType": actions[3]["WFWorkflowActionParameters"]["WFInput"]["WFSerializationType"],
            "workflowNamePresent": "WFWorkflowName" in graph,
            "nativeExecuted": False, "formalAcceptanceGranted": False}

need(not O.exists() and not B.exists(), "CREATE_ONLY_OUTPUTS")
O.mkdir(mode=0o700)
C = O / "commands"
C.mkdir(mode=0o700)
helper_raw = pinned(H, H_SHA)
spec = importlib.util.spec_from_file_location("owned", H)
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
owned.original(O / "owner.original.py", read(Path(__file__)))
owned.original(O / "capture.original.py", helper_raw)
start = time.monotonic()
result = {"schema": "cherri-fn04-materialized-text-diagnostic-compile/1", "status": "FAIL",
          "diagnosticOnly": True, "compilerSource": COMPILER, "compilerTree": TREE,
          "compilerBinarySHA256": BIN_SHA, "compilerBuildRunId": 46012790470,
          "originalPacketCompiler": "5b689c938c73420ef36b3f077764d30f8946f31a",
          "originalAcceptanceReplacement": False, "nativeExecuted": False, "signed": False,
          "formalAcceptanceGranted": False, "newGoBuild": False,
          "wholeSeconds": 180, "childSeconds": 45, "cleanupSeconds": 5, "finalReserveSeconds": 20,
          "processes": [], "compilerInvocations": 0, "packet": None}
before = {}
try:
    with owned.WholeBudget(180, cleanup_seconds=5, final_reserve=20) as budget:
        owned.original(O / "capacity-before.original.json", capacity())
        auth_raw = pinned(HANDOFF, HANDOFF_SHA)
        restoration_raw = pinned(RESTORATION, RESTORATION_SHA)
        auth, restoration = strict(auth_raw), strict(restoration_raw)
        need(auth["source"] == restoration["source"] == COMPILER and auth["tree"] == restoration["tree"] == TREE, "CURRENT_COMPILER_SOURCE")
        need(auth["runId"] == restoration["runId"] == 46012790470 and restoration["status"] == "PASS_EXACT_QUALIFIED_PUBLIC_PRODUCTS_RESTORED", "AUTHENTICATED_BUILD_RESTORATION")
        need(auth["products"]["cherri"]["sha256"] == restoration["products"]["cherri"]["sha256"] == BIN_SHA and
             auth["products"]["cherri"]["bytes"] == restoration["products"]["cherri"]["bytes"] == 24893704 and
             restoration["handoffSHA256"] == HANDOFF_SHA and restoration["products"]["cherri"]["path"] == str(BIN), "EXACT_COMPILER_AUTHORITY")
        owned.original(O / "compiler-handoff.original.json", auth_raw)
        owned.original(O / "compiler-restoration.original.json", restoration_raw)
        archive = Path(auth["archive"])
        archive_raw = pinned(archive, auth["archiveSHA256"], 64 * 1024 * 1024)
        need(len(archive_raw) == auth["archiveBytes"], "BUILD_ARCHIVE_BYTES")
        info = auth["products"]["cherri"]["buildInfo"]
        with zipfile.ZipFile(archive) as z:
            entries = [entry for entry in z.infolist() if entry.filename == info["member"]]
            need(len(entries) == 1 and entries[0].file_size == info["bytes"] <= 65536, "UNIQUE_BUILD_INFO_MEMBER")
            info_raw = z.read(entries[0])
        need(sha(info_raw) == info["sha256"] and b"vcs.revision=" + COMPILER.encode() in info_raw and
             b"vcs.modified=false" in info_raw and b"CGO_ENABLED=0" in info_raw and
             b"GOOS=linux" in info_raw and b"GOARCH=arm64" in info_raw, "AUTHENTICATED_COMPILER_BUILD_INFO")
        owned.original(O / "compiler-build-info.original.txt", info_raw)
        comparison_raw = pinned(COMPARISON, COMPARISON_SHA)
        need(strict(comparison_raw)["status"] == "PASS_ORIGINAL_COMPARISON_ONLY", "ORIGINAL_COMPARISON_CLOSED")
        owned.original(O / "original-comparison.original.json", comparison_raw)
        packet_raw = pinned(ORIGINAL_PACKET, ORIGINAL_PACKET_SHA)
        packet = strict(packet_raw)
        old_source = base64.b64decode(packet["sourceBase64"], validate=True)
        old_unsigned = base64.b64decode(packet["unsignedBase64"], validate=True)
        need(len(old_source) == packet["sourceBytes"] == 107 and sha(old_source) == packet["sourceSha256"] == "8223b9ed6b809aded4295ee9cb8ce5097033e4cad9916f4e2356ad5a2bece794", "UNCHANGED_ORIGINAL_SOURCE")
        need(len(old_unsigned) == packet["unsignedBytes"] == 4239 and sha(old_unsigned) == packet["unsignedSha256"] == "34017b38ceb48e1941265f7bc1cc7abd068148d3a6cc4da23db929aad995dc8c", "UNCHANGED_ORIGINAL_UNSIGNED")
        need(old_source.replace(b'setClipboard(f"{first}|{second}")', b'let clipboardText=f"{first}|{second}"\nsetClipboard(clipboardText)') == SOURCE, "ONE_SOURCE_MATERIALIZATION_CHANGE")
        owned.original(O / "prior-packet.original.json", packet_raw)
        owned.original(O / "prior-source.original.cherri", old_source)
        owned.original(O / "prior-unsigned.original.shortcut", old_unsigned)
        before["binary"] = rec(BIN)
        need(before["binary"]["sha256"] == BIN_SHA and before["binary"]["bytes"] == 24893704 and
             before["binary"]["uid"] == before["binary"]["gid"] == 1001 and before["binary"]["mode"] == 0o755 and
             pwd.getpwuid(1001).pw_name == "ubuntu", "EXACT_RESTORED_BINARY_IDENTITY")
        B.mkdir(mode=0o700)
        os.chown(B, 1001, 1001)
        owned.original(SOURCE_PATH, SOURCE)
        os.chown(SOURCE_PATH, 1001, 1001)
        os.chmod(SOURCE_PATH, 0o400)
        before["source"] = rec(SOURCE_PATH)
        owned.original(O / "before.original.json", before)
        argv = ["/usr/sbin/runuser", "-u", "ubuntu", "--", str(BIN), "compile", str(SOURCE_PATH),
                "--mode=v2", "--skip-sign", "--build-profile=debug", "--output", str(UNSIGNED_PATH)]
        env = {key: value for key, value in os.environ.items() if key in ("PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TZ")}
        owned.original(O / "intent.original.json", {"argv": argv, "cwd": str(B), "source": before["source"],
            "compiler": before["binary"], "compileOnly": True, "signed": False, "expectedActionCount": 5,
            "expectedClipboardExpression": "inputText + '|' + inputText", "expectedClipboardBytesForFreshProtocolInput": 93,
            "sameRuntimeProtocolRequired": ["fresh nonce input", "clipboard reset and readback", "unique signed Add UI", "fresh SUCCESS callback", "original ACK", "one original clipboard read"],
            "formalAcceptanceGranted": False})
        budget.check()
        result["compilerInvocations"] = 1
        process = owned.run_owned(argv, cwd=B, env=env, output=C, name="compile-materialized-text", budget=budget, seconds=45)
        result["processes"].append(process)
        owned.require_success(process)
        need(process["cleanup"]["parentReaped"] is True and process["cleanup"]["after"]["state"] == "ABSENT", "COMPILER_CHILD_CLOSED")
        raw = read(UNSIGNED_PATH, 1024 * 1024)
        graph = complete_graph(raw, plistlib.loads(old_unsigned))
        graph_pin = owned.original(O / "complete-graph.derived.json", graph)
        diagnostic = {"schema": "cherri-fn04-materialized-text-diagnostic-packet/1", "caseId": "without_functions_materialized_text",
            "diagnosticOnly": True, "compilerSource": COMPILER, "compilerTree": TREE, "compilerBinarySHA256": BIN_SHA,
            "compilerBuildRunId": 46012790470, "priorCompilerSource": result["originalPacketCompiler"],
            "priorPacketPath": str(ORIGINAL_PACKET), "priorPacketSHA256": ORIGINAL_PACKET_SHA,
            "compileFilename": SOURCE_PATH.name, "workflowName": NAME,
            "topLevelWorkflowNamePresent": graph["workflowNamePresent"],
            "sourcePath": str(SOURCE_PATH), "sourceBase64": base64.b64encode(SOURCE).decode(),
            "sourceBytes": len(SOURCE), "sourceSha256": sha(SOURCE),
            "unsignedPath": str(UNSIGNED_PATH), "unsignedBase64": base64.b64encode(raw).decode(),
            "unsignedBytes": len(raw), "unsignedSha256": sha(raw), "actionCount": 5,
            "completeGraphSHA256": graph_pin["sha256"], "expectedClipboardExpression": "inputText + '|' + inputText",
            "expectedClipboardBytesForFreshProtocolInput": 93, "nativeExecuted": False, "signed": False,
            "originalAcceptanceReplacement": False, "formalAcceptanceGranted": False}
        packet_pin = owned.original(B / "packet.derived.json", diagnostic)
        result["packet"] = {"path": str(B / "packet.derived.json"), **packet_pin,
            "sourcePath": str(SOURCE_PATH), "sourceSha256": sha(SOURCE), "unsignedPath": str(UNSIGNED_PATH),
            "unsignedSha256": sha(raw), "unsignedBytes": len(raw), "actionCount": 5, "completeGraphSHA256": graph_pin["sha256"]}
        result["status"] = "PASS_ONE_MATERIALIZED_TEXT_DIAGNOSTIC_COMPILED_AND_GRAPH_BOUND"
except BaseException as error:
    result["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
finally:
    try:
        after = {"binary": rec(BIN)}
        if SOURCE_PATH.exists():
            after["source"] = rec(SOURCE_PATH)
        owned.original(O / "after.original.json", after)
        need(after == before, "SOURCE_AND_BINARY_CLOSURE")
        pinned(HANDOFF, HANDOFF_SHA)
        pinned(RESTORATION, RESTORATION_SHA)
        pinned(ORIGINAL_PACKET, ORIGINAL_PACKET_SHA)
        pinned(COMPARISON, COMPARISON_SHA)
        pinned(H, H_SHA)
        owned.original(O / "capacity-after.original.json", capacity())
        result["sourceAndBinaryUnchanged"] = True
        result["allOriginalInputsUnchanged"] = True
    except BaseException as error:
        result["status"] = "FAIL"
        result["closingError"] = {"type": type(error).__name__, "message": str(error)}
    result["elapsedSeconds"] = time.monotonic() - start
    pin = owned.original(O / "result.original.json", result)
    print(json.dumps({"result": str(O / "result.original.json"), "sha256": pin["sha256"], "status": result["status"],
        "elapsedSeconds": result["elapsedSeconds"], "compilerInvocations": result["compilerInvocations"],
        "packet": result["packet"], "processes": [{"pid": row["pid"], "status": row["status"], "exitCode": row["exitCode"],
            "parentReaped": row["cleanup"]["parentReaped"], "groupAfter": row["cleanup"].get("after")} for row in result["processes"]],
        "error": result.get("error"), "closingError": result.get("closingError")}, sort_keys=True))
