import hashlib,json,pathlib,sys,unittest
sys.dont_write_bytecode=True
qa=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(qa))
import native_signed_caller_input_owner as signed
import test_native_signed_caller_input_owner as controls
class Observed(unittest.TextTestResult):
 def __init__(self,*a,**k):
  super().__init__(*a,**k);self.started=[];self.passed=[];self.children=[]
 def startTest(self,test):
  self.started.append(test.id());super().startTest(test)
 def addSuccess(self,test):
  self.passed.append(test.id());super().addSuccess(test)
 def addSubTest(self,test,subtest,error):
  self.children.append({"parent":test.id(),"identity":str(subtest),"status":"PASS"if error is None else"FAIL"})
  super().addSubTest(test,subtest,error)
suite=unittest.defaultTestLoader.loadTestsFromModule(controls)
result=unittest.TextTestRunner(stream=sys.stderr,verbosity=2,resultclass=Observed).run(suite)
report={"schema":"cherri-fn04-signed-owner-focused-controls/1","started":result.started,"passed":result.passed,
 "testsRun":result.testsRun,"subtests":result.children,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),
 "nativeExecuted":False,"signingRepeated":False,"formalAcceptanceGranted":False,"actualPacketBindings":[]}
if result.wasSuccessful():
 packet_root=pathlib.Path(sys.argv[2]);first=pathlib.Path(sys.argv[3]);retry=pathlib.Path(sys.argv[4])
 for case in signed.CASES:
  root=retry if case=="without_functions"else first
  plan={"caseId":case,"compilerCommitSha":"5b689c938c73420ef36b3f077764d30f8946f31a","bundleRoot":str(packet_root),
   "bundleIntakeSHA256":"505933619bcb8bea604bbc375b31cf57824bddfaa514e354784ebb86f00e3678"}
  packet,canonical,checked,evidence=signed.base.bind_packet_bundle(plan)
  pin=hashlib.sha256((root/"intake.original.json").read_bytes()).hexdigest()
  raw,binding,_,_,_=signed.bind_signed_bundle({"bundleRoot":str(root),"bundleIntakeSHA256":pin},plan,checked)
  report["actualPacketBindings"].append({"caseId":case,"workflowName":checked["name"],"sourceSha256":checked["sourceSha256"],
   "unsignedSha256":checked["unsignedSha256"],"signedSHA256":hashlib.sha256(raw).hexdigest(),"signingIntakeSHA256":pin,
   "originalOverallStatus":binding["originalOverallStatus"],"nativeExecuted":False,"formalAcceptanceGranted":False})
 report["inheritedRunUnchanged"]=signed.SignedNativeCallerObservation.run is signed.base.NativeCallerObservation.run
 report["inheritedCaptureUnchanged"]=signed.SignedNativeCallerObservation.capture is signed.base.NativeCallerObservation.capture
 report["inheritedDeviceSelectionUnchanged"]=signed.SignedNativeCallerObservation.select_device is signed.base.NativeCallerObservation.select_device
sources={}
for module in list(sys.modules.values()):
 name=getattr(module,"__file__",None)
 if name:
  path=pathlib.Path(name)
  if path.suffix==".py"and path.parent==qa:
   raw=path.read_bytes();sources[path.name]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
report["loadedSourcePins"]=sources
print(json.dumps(report,sort_keys=True))
sys.exit(0 if result.wasSuccessful()else 1)
