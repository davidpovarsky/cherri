from pathlib import Path
import hashlib,importlib.util,json,os,socket,sys,time,traceback
assert socket.gethostname()=="torah-social"and os.getuid()==0
sys.dont_write_bytecode=True
P=Path("/var/cache/cherri-native-contract-producers-20261126");W=P/"source";QA=W/"tools/shortcuts-simulator-qa"
O=P/"caller-exact-signing-owner-qualification-01";O.mkdir(mode=0o700);C=O/"commands";C.mkdir()
H=Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py")
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert sha(H.read_bytes())=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
sp=importlib.util.spec_from_file_location("owned",H);owned=importlib.util.module_from_spec(sp);sp.loader.exec_module(owned)
owned.original(O/"owner.original.py",Path(__file__).read_bytes())
bridge="import hashlib,json,pathlib,sys,unittest\nsys.dont_write_bytecode=True\nqa=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(qa))\nimport native_signed_caller_input_owner as signed\nimport test_native_signed_caller_input_owner as controls\nclass Observed(unittest.TextTestResult):\n def __init__(self,*a,**k):\n  super().__init__(*a,**k);self.started=[];self.passed=[];self.children=[]\n def startTest(self,test):\n  self.started.append(test.id());super().startTest(test)\n def addSuccess(self,test):\n  self.passed.append(test.id());super().addSuccess(test)\n def addSubTest(self,test,subtest,error):\n  self.children.append({\"parent\":test.id(),\"identity\":str(subtest),\"status\":\"PASS\"if error is None else\"FAIL\"})\n  super().addSubTest(test,subtest,error)\nsuite=unittest.defaultTestLoader.loadTestsFromModule(controls)\nresult=unittest.TextTestRunner(stream=sys.stderr,verbosity=2,resultclass=Observed).run(suite)\nreport={\"schema\":\"cherri-fn04-signed-owner-focused-controls/1\",\"started\":result.started,\"passed\":result.passed,\n \"testsRun\":result.testsRun,\"subtests\":result.children,\"failures\":len(result.failures),\"errors\":len(result.errors),\"skipped\":len(result.skipped),\n \"nativeExecuted\":False,\"signingRepeated\":False,\"formalAcceptanceGranted\":False,\"actualPacketBindings\":[]}\nif result.wasSuccessful():\n packet_root=pathlib.Path(sys.argv[2]);first=pathlib.Path(sys.argv[3]);retry=pathlib.Path(sys.argv[4])\n for case in signed.CASES:\n  root=retry if case==\"without_functions\"else first\n  plan={\"caseId\":case,\"compilerCommitSha\":\"5b689c938c73420ef36b3f077764d30f8946f31a\",\"bundleRoot\":str(packet_root),\n   \"bundleIntakeSHA256\":\"505933619bcb8bea604bbc375b31cf57824bddfaa514e354784ebb86f00e3678\"}\n  packet,canonical,checked,evidence=signed.base.bind_packet_bundle(plan)\n  pin=hashlib.sha256((root/\"intake.original.json\").read_bytes()).hexdigest()\n  raw,binding,_,_,_=signed.bind_signed_bundle({\"bundleRoot\":str(root),\"bundleIntakeSHA256\":pin},plan,checked)\n  report[\"actualPacketBindings\"].append({\"caseId\":case,\"workflowName\":checked[\"name\"],\"sourceSha256\":checked[\"sourceSha256\"],\n   \"unsignedSha256\":checked[\"unsignedSha256\"],\"signedSHA256\":hashlib.sha256(raw).hexdigest(),\"signingIntakeSHA256\":pin,\n   \"originalOverallStatus\":binding[\"originalOverallStatus\"],\"nativeExecuted\":False,\"formalAcceptanceGranted\":False})\n report[\"inheritedRunUnchanged\"]=signed.SignedNativeCallerObservation.run is signed.base.NativeCallerObservation.run\n report[\"inheritedCaptureUnchanged\"]=signed.SignedNativeCallerObservation.capture is signed.base.NativeCallerObservation.capture\n report[\"inheritedDeviceSelectionUnchanged\"]=signed.SignedNativeCallerObservation.select_device is signed.base.NativeCallerObservation.select_device\nsources={}\nfor module in list(sys.modules.values()):\n name=getattr(module,\"__file__\",None)\n if name:\n  path=pathlib.Path(name)\n  if path.suffix==\".py\"and path.parent==qa:\n   raw=path.read_bytes();sources[path.name]={\"bytes\":len(raw),\"sha256\":hashlib.sha256(raw).hexdigest()}\nreport[\"loadedSourcePins\"]=sources\nprint(json.dumps(report,sort_keys=True))\nsys.exit(0 if result.wasSuccessful()else 1)\n"
owned.original(O/"bridge.original.py",bridge.encode())
manifest=json.loads((P/"caller-exact-signing-owner-proposal-02/manifest.original.json").read_bytes())
assert manifest["status"]=="FROZEN_TWO_ORIGINAL_SIGNING_ATTEMPTS_AND_ADDITIVE_OWNER"
for name,pin in manifest["paths"].items():
 raw=(W/name).read_bytes();assert pin=={"bytes":len(raw),"sha256":sha(raw)}
paths=list(QA.glob("*.py"))+[W/name for name in manifest["paths"]if name.endswith(".zip")]
def snapshot():return{str(p.relative_to(W)):{"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())}for p in sorted(paths)}
before=snapshot();owned.original(O/"source-before.original.json",before)
result={"schema":"cherri-fn04-signed-owner-qualification/1","status":"FAIL","wholeOwnerSeconds":180,"childSeconds":120,
"proposalSHA256":sha((P/"caller-exact-signing-owner-proposal-02/manifest.original.json").read_bytes()),
"nativeExecuted":False,"signingRepeated":False,"formalAcceptanceGranted":False}
env={k:v for k,v in os.environ.items()if k in("PATH","HOME","LANG","LC_ALL","LC_CTYPE","TZ")}
try:
 with owned.WholeBudget(180,cleanup_seconds=5,final_reserve=20)as budget:
  argv=[sys.executable,"-I","-B","-c",bridge,str(QA),str(P/"caller-input-hosted-independent-intake-01/bundle"),
        str(P/"caller-exact-file-signing-intake-01/bundle"),str(P/"caller-exact-file-signing-intake-02/bundle")]
  p=owned.run_owned(argv,cwd=W,env=env,output=C,name="nine-focused-controls",budget=budget,seconds=120);result["process"]=p
  owned.require_success(p)
  report=json.loads((C/"nine-focused-controls.stdout.original").read_bytes())
  assert report["testsRun"]==9 and len(report["started"])==len(set(report["started"]))==9 and set(report["passed"])==set(report["started"])
  assert report["failures"]==report["errors"]==report["skipped"]==0
  assert all(x["status"]=="PASS"for x in report["subtests"])
  assert len(report["actualPacketBindings"])==3 and all(report[k]is True for k in("inheritedRunUnchanged","inheritedCaptureUnchanged","inheritedDeviceSelectionUnchanged"))
  for name,pin in report["loadedSourcePins"].items():assert before["tools/shortcuts-simulator-qa/"+name]==pin
  assert p["cleanup"]["parentReaped"]and p["cleanup"]["after"]["state"]=="ABSENT"
  result.update(status="PASS_FOCUSED_SIGNING_BINDING_CONTROLS_AND_THREE_ACTUAL_PACKET_JOINS",report=report)
except BaseException as e:result["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
finally:
 try:
  after=snapshot();owned.original(O/"source-after.original.json",after);assert after==before
  result["sourceUnchanged"]=True
 except BaseException as e:result.update(status="FAIL",closingError={"type":type(e).__name__,"message":str(e)})
 pin=owned.original(O/"result.original.json",result)
 print(json.dumps({"receipt":str(O/"result.original.json"),"sha256":pin["sha256"],"status":result["status"],
 "testsRun":result.get("report",{}).get("testsRun"),"subtests":len(result.get("report",{}).get("subtests",[])),
 "actualPacketBindings":result.get("report",{}).get("actualPacketBindings"),"error":result.get("error"),"closingError":result.get("closingError")},sort_keys=True))
