from pathlib import Path
import hashlib,importlib.util,json,os,sys,traceback
sys.dont_write_bytecode=True
P=Path("/var/cache/cherri-native-contract-producers-20261126")
A=P/"caller-native-owner-proposal-01/source";S=P/"caller-native-owner-proposal-02/source"
O=P/"caller-native-owner-cleanup-qualification-02";O.mkdir(mode=0o700)
H=Path("/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py")
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(H.read_bytes())=="4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85"
sp=importlib.util.spec_from_file_location("owned",H);owned=importlib.util.module_from_spec(sp);sp.loader.exec_module(owned)
owned.original(O/"owner.original.py",Path(__file__).read_bytes())
owned.original(O/"control-driver.original.py","from pathlib import Path\nimport hashlib,json,os,sys,unittest\nQ,O=map(Path,sys.argv[1:3]);sys.path.insert(0,str(Q));sys.dont_write_bytecode=True\nimport test_native_caller_input_owner as tests\nevents=[]\nclass Result(unittest.TextTestResult):\n def startTest(self,t):events.append({\"event\":\"start\",\"id\":t.id()});super().startTest(t)\n def addSuccess(self,t):events.append({\"event\":\"pass\",\"id\":t.id()});super().addSuccess(t)\n def addFailure(self,t,e):events.append({\"event\":\"fail\",\"id\":t.id()});super().addFailure(t,e)\n def addError(self,t,e):events.append({\"event\":\"error\",\"id\":t.id()});super().addError(t,e)\n def addSkip(self,t,r):events.append({\"event\":\"skip\",\"id\":t.id(),\"reason\":r});super().addSkip(t,r)\ndef snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in Q.glob(\"*.py\")}\nbefore=snapshot()\nsuite=unittest.TestSuite([tests.NativeCallerOwnerTests(\"test_first_signal_during_actual_finish_cleanup_is_deferred\")])\nr=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)\nafter=snapshot()\nv={\"schema\":\"cherri-native-caller-finish-signal-control/1\",\"status\":\"PASS\"if r.wasSuccessful()and before==after else\"FAIL\",\n\"testsRun\":r.testsRun,\"failures\":[{\"id\":t.id(),\"trace\":e}for t,e in r.failures],\n\"errors\":[{\"id\":t.id(),\"trace\":e}for t,e in r.errors],\"skips\":r.skipped,\n\"events\":events,\"sourceBefore\":before,\"sourceAfter\":after,\"sourceUnchanged\":before==after,\n\"nativeExecuted\":False,\"formalAcceptanceGranted\":False}\nwith(O/\"tests.original.json\").open(\"x\")as f:json.dump(v,f,sort_keys=True,indent=2);f.write(\"\\n\")\nraise SystemExit(0 if v[\"status\"]==\"PASS\"else 1)\n".encode())
old=O/"old-source-new-control";old.mkdir(mode=0o700)
for p in S.glob("*.py"):
 raw=(A/p.name).read_bytes()if p.name=="native_caller_input_owner.py"else p.read_bytes()
 owned.original(old/p.name,raw)
assert sha((old/"native_caller_input_owner.py").read_bytes())=="a9f22e02fd07a0c0308eaed7c65a6447e018b7556964df7838e9960dcc03b676"
assert sha((S/"native_caller_input_owner.py").read_bytes())=="0270d801d5342d71fdfa2be718770c87142d8cb633c3425da5756cd19dec2465"
assert (old/"test_native_caller_input_owner.py").read_bytes()==(S/"test_native_caller_input_owner.py").read_bytes()
C=O/"commands";C.mkdir()
r={"schema":"cherri-native-caller-finish-cancellation-qualification/1","status":"FAIL","nativeExecuted":False,"goExecuted":False,"formalAcceptanceGranted":False,"processes":[]}
def snapshot(Q):return {p.name:{"bytes":len(p.read_bytes()),"sha256":sha(p.read_bytes())}for p in sorted(Q.glob("*.py"))}
before={"old":snapshot(old),"new":snapshot(S)};owned.original(O/"source-before.original.json",before)
env={k:v for k,v in os.environ.items()if k in("PATH","HOME","LANG","LC_ALL","LC_CTYPE","TZ")}
try:
 with owned.WholeBudget(90,cleanup_seconds=5,final_reserve=10)as budget:
  for name,Q in (("old-red",old),("new-green",S)):
   D=O/name;D.mkdir(mode=0o700);controls=D/"actual-controls";controls.mkdir()
   process=owned.run_owned([sys.executable,"-I","-B",str(O/"control-driver.original.py"),str(Q),str(D)],cwd=Q,
    env={**env,"PYTHONDONTWRITEBYTECODE":"1","CHERRI_CALLER_OWNER_TEST_ROOT":str(controls)},
    output=C,name=name,budget=budget,seconds=30)
   r["processes"].append(process)
   assert process["cleanup"]["parentReaped"]and process["cleanup"]["after"]["state"]=="ABSENT"
   j=json.loads((D/"tests.original.json").read_bytes());assert j["testsRun"]==1 and not j["errors"]and not j["skips"]and j["sourceUnchanged"]
   f=controls/"test_first_signal_during_actual_finish_cleanup_is_deferred"/"finish-signal-control.original.json"
   detail=json.loads(f.read_bytes())
   assert len(detail["injection"])==1 and detail["parentReaped"]and detail["groupAfterTestCleanup"]["present"]is False
   if name=="old-red":
    assert process["exitCode"]==1 and j["status"]=="FAIL"and len(j["failures"])==1
    assert "owned finish must reap before delivering cancellation"in j["failures"][0]["trace"]
    assert detail["groupBeforeTestRescue"]["present"]is True and detail["testRescue"]is not None
   else:
    owned.require_success(process);assert j["status"]=="PASS"and not j["failures"]
    assert detail["groupBeforeTestRescue"]["present"]is False and detail["testRescue"]is None
   r[name]={"testsSHA256":sha((D/"tests.original.json").read_bytes()),"childControlSHA256":sha(f.read_bytes()),"testsRun":1,
    "failureCount":len(j["failures"]),"testRescueRequired":detail["testRescue"]is not None}
  after={"old":snapshot(old),"new":snapshot(S)};owned.original(O/"source-after.original.json",after);assert before==after
  r.update(status="PASS_SAME_REAL_CHILD_SIGNAL_OLD_RED_NEW_GREEN",sourceUnchanged=True,
   originalElevenControlsNotRerun=True,newUniqueMethodCount=1,actualSyntheticOwnedChildren=2,
   sourceSHA256=sha((S/"native_caller_input_owner.py").read_bytes()),testSHA256=sha((S/"test_native_caller_input_owner.py").read_bytes()),
   previousQualificationSHA256="83ecb8c0d28c0beddd73de9f04f0a3fdb71bf16d9b724d0700650a4b5c0a963d")
except BaseException as error:r["error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
 pin=owned.original(O/"result.original.json",r)
 print(json.dumps({"path":str(O/"result.original.json"),"sha256":pin["sha256"],"status":r["status"],"error":r.get("error")}))
