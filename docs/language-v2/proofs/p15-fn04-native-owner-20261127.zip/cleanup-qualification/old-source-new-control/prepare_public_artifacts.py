#!/usr/bin/env python3
"""Stage a synthetic-only, text-only publication set without touching originals.

Raster media, xcresult, archives and raw compiler inputs are quarantined by
policy regardless of OCR or byte-scan results. This is not pixel redaction.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile


ALLOWED = {
    "summary.json", "environment.json", "compiler-manifest.json", "import-attempts.json",
    "runtime/instrumentation-vs-original.json", "runtime/output-assertions.json",
    "runtime/signing-provenance.json", "runtime/callback-events.json", "runtime/runtime-trace.jsonl",
    "runtime/http-probe-diagnostic.json", "runtime/simulator-session-recovery.json",
    "runtime/json-body-diagnostic.json", "runtime/nested-list-observation.json",
    "runtime/tagged-carrier-observation.json",
    "runtime/debug-label-acceptance.json", "editor/debug-label-preview.json",
    "runtime/xcode-destination-readiness.json", "runtime/xcode-destination-command-diagnostic.json",
    "runtime/post-test-inspection.json", "runtime/terminal-acquisition.json",
    "runtime/storage-cross-run-diagnostic.json", "runtime/storage-writer-trace.jsonl",
    "tests/xcresult-summary.json", "editor/editor-action-coverage.json",
    "editor/editor-foreground-recovery.json",
    "editor/screenshots-manifest.json", "editor/editor-actions.json",
    "editor/editor-comparison.json", "editor/editor-tree.json", "editor/editor-report.md",
    "editor/plist-vs-editor-comparison.json", "editor/handshake-status.json", "editor/ax-persistence-diagnostics.json", "docs/report.md",
}
RAW_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".heic", ".webp", ".pdf", ".zip", ".tar", ".gz",
                ".shortcut", ".plist", ".cherri", ".a", ".dylib", ".app", ".xcresult"}
CANARY = re.compile(r"(?i)(cherri-shortcut-audit-20261110|\b[0-3][0-9]\.plist\b|BEGIN [A-Z ]*PRIVATE KEY|"
                    r"ghp_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+|sk-[A-Za-z0-9]{16,}|"
                    r"Bearer\s+[A-Za-z0-9._\-]+|AppleID|iCloudToken|CHERRI_PRIVATE_CANARY|"
                    r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}|"
                    r"(?:access_token|api_key|password|secret|authorization)\s*[=:]\s*[^\s&\"<]+|"
                    r"(?:access_token|api_key|password|secret|authorization)[\"']\s*:\s*[\"'][^\"']+|"
                    r"[?&](?:token|key|auth|password|secret)=[^&\s]+)")
MAGIC = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF8", b"%PDF", b"PK\x03\x04", b"AEA1", b"bplist")


# Source hashes are trusted only for these reviewed nested synthetic files.
# Do not replace this explicit list with rglob, basename flattening or directory-wide trust.
TRUSTED_NESTED_FIXTURES = (
    "p15-binding-defaults/CherriBindingCapturePOC.cherri",
    "p15-binding-defaults/CherriTypedDefaultsPOC.cherri",
    "p15-label-probes/qa-label-file-carrier-v2.cherri",
    "p15-label-probes/qa-label-raw-empty-v2.cherri",
    "p15-label-probes/qa-label-raw-grouping-v2.cherri",
    "p15-export-probes/qa-export-unicode-v2.cherri",
    "p15-export-probes/qa-export-empty-v2.cherri",
    "p15-export-probes/qa-export-thousand-v2.cherri",
    "p15-export-probes/qa-export-redacted-v2.cherri",
    "p15-export-probes/qa-export-unsupported-file-v2.cherri",
    "p15-export-probes/qa-export-text-file-v2.cherri",
    "p15-paginate-probes/qa-paginate-ordered-v2.cherri",
    "p15-paginate-probes/qa-paginate-cycle-v2.cherri",
    "p15-paginate-probes/qa-paginate-page-cap-v2.cherri",
    "p15-paginate-probes/qa-paginate-item-cap-v2.cherri",
    "p15-paginate-probes/qa-paginate-empty-v2.cherri",
)


class PublicationBlocked(ValueError):
    pass


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(path):
    value = path.as_posix()
    return value if re.fullmatch(r"[A-Za-z0-9_./-]{1,180}", value) and not CANARY.search(value) else "path-sha256:" + sha(value.encode())


def trusted_fixture_sources(fixtures):
    fixtures = Path(fixtures)
    if fixtures.is_symlink() or not fixtures.is_dir():
        raise PublicationBlocked("FIXTURE_SOURCE_ROOT_INVALID")
    trusted = {}
    for path in sorted(fixtures.glob("qa-*.cherri")):
        if path.is_symlink():
            raise PublicationBlocked("FIXTURE_SOURCE_SYMLINK")
        if path.is_file():
            trusted[path.name] = sha(path.read_bytes())
    for name in TRUSTED_NESTED_FIXTURES:
        path = fixtures / name
        # Every component below the trusted checkout root must be an actual
        # directory/file. A same-hash link is not reviewed source provenance.
        if any((fixtures / Path(*Path(name).parts[:end])).is_symlink()
               for end in range(1, len(Path(name).parts) + 1)):
            raise PublicationBlocked("FIXTURE_SOURCE_SYMLINK")
        if path.is_file():
            trusted[name] = sha(path.read_bytes())
    return trusted


def verify_synthetic_sources(root, trusted_sources):
    manifest_path = root / "compiler-manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise PublicationBlocked("SYNTHETIC_PROVENANCE_MISSING") from exc
    if not isinstance(manifest, dict) or manifest.get("syntheticOnly") is not True:
        raise PublicationBlocked("SYNTHETIC_PROVENANCE_REQUIRED")
    fixtures = manifest.get("fixtures", [])
    if (not isinstance(fixtures, list) or not fixtures
            or any(not isinstance(f, dict) or not isinstance(f.get("fixtureId"), str) for f in fixtures)
            or len({f["fixtureId"] for f in fixtures}) != len(fixtures)):
        raise PublicationBlocked("FIXTURE_MANIFEST_INVALID")
    for fixture in fixtures:
        file_name = fixture.get("fileName")
        if (not isinstance(file_name, str) or file_name not in trusted_sources
                or fixture.get("sourceSha256") != trusted_sources[file_name]):
            raise PublicationBlocked("FIXTURE_SOURCE_HASH_MISMATCH")
        if fixture["fixtureId"] != PurePosixPath(file_name).stem:
            raise PublicationBlocked("FIXTURE_SOURCE_ID_MISMATCH")


def verify_synthetic_manifest(root, trusted_sources):
    verify_synthetic_sources(root, trusted_sources)
    summary_path = root / "summary.json"
    try:
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise PublicationBlocked("SUMMARY_MISSING") from exc
    if summary.get("privacyGatePassed") is not True:
        raise PublicationBlocked("EXISTING_PRIVACY_GATE_FAILED")



def public_json(text):
    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("duplicate JSON key")
            value[key] = item
        return value
    return json.loads(text, object_pairs_hook=unique_object)


def structured_privacy_failure(value):
    # Inspect decoded strings and keys: valid JSON escapes can conceal every
    # token from a scan of serialized bytes. Duplicate keys are rejected by
    # public_json so canonicalization cannot discard an earlier private value.
    if CANARY.search(json.dumps(value, ensure_ascii=False)):
        return "SECRET_OR_PRIVATE_CANARY"
    pending = [value]
    while pending:
        item = pending.pop()
        if isinstance(item, dict):
            if item.get("publicationPolicy") == "LOCAL_ONLY_RAW_OCR":
                return "RAW_OCR_NOT_PUBLIC"
            pending.extend(item.values())
        elif isinstance(item, list):
            pending.extend(item)
    return None


def scan_public_privacy(root, raw_udid="", custom_server=""):
    """Scan only the existing explicit publication candidates.

    Raw originals remain available under the same root for strict receipt
    validation. They are quarantined by stage(), never treated as sanitized
    content. This function does not approve source, receipts or publication.
    """
    root = Path(root)
    violations = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        name = rel.as_posix()
        if path.is_symlink():
            violations.append({"path": safe_path(rel), "reason": "SYMLINK_NOT_ALLOWED"})
            continue
        if not path.is_file():
            continue
        raw = any(p.suffix.lower() in RAW_SUFFIXES
                  for p in [path] + list(rel.parents))
        if raw or name not in ALLOWED:
            continue
        if path.stat().st_size > 10 * 1024 * 1024:
            violations.append({"path": safe_path(rel), "reason": "TEXT_SIZE_LIMIT"})
            continue
        data = path.read_bytes()
        if data.startswith(MAGIC):
            # Identical classifier to stage(): disguised raster/archive bytes
            # are quarantined, not admitted as public text.
            continue
        reason = None
        try:
            text = data.decode("utf-8")
            if "\x00" in text:
                raise ValueError("binary")
            values = ([public_json(text)] if name.endswith(".json") else
                      [public_json(line) for line in text.splitlines() if line.strip()]
                      if name.endswith(".jsonl") else [])
            reason = next((failure for value in values
                           if (failure := structured_privacy_failure(value))), None)
            if not reason and CANARY.search(text):
                reason = "SECRET_OR_PRIVATE_CANARY"
            observed_text = text + "\n" + "\n".join(json.dumps(v, ensure_ascii=False) for v in values)
            if not reason and raw_udid and len(raw_udid) >= 36 and raw_udid.lower() in observed_text.lower():
                reason = "UNMASKED_DEVICE_ID"
            if (not reason and custom_server and "sign.shortcuty.app" not in custom_server
                    and custom_server in observed_text):
                reason = "CUSTOM_SIGNING_URL"
        except (UnicodeError, ValueError):
            reason = "INVALID_TEXT_OR_STRUCTURED_DATA"
        if reason:
            violations.append({"path": safe_path(rel), "reason": reason})
    return {"passed": not violations, "violations": violations}


def stage(root, output, trusted_sources):
    root, output = Path(root).resolve(), Path(output).absolute()
    if not root.is_dir() or output.exists() or root == output or root in output.parents:
        raise PublicationBlocked("OUTPUT_MUST_BE_NEW_AND_OUTSIDE_RAW_ROOT")
    verify_synthetic_manifest(root, trusted_sources)
    approved, quarantined, failures = [], [], []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        name = rel.as_posix()
        if path.is_symlink():
            failures.append({"path": safe_path(rel), "reason": "SYMLINK_NOT_ALLOWED"})
            continue
        if not path.is_file():
            continue
        data = path.read_bytes()
        entry = {"path": safe_path(rel), "sha256": sha(data), "bytes": len(data)}
        raw = any(p.suffix.lower() in RAW_SUFFIXES for p in [path] + list(path.relative_to(root).parents))
        if raw or data.startswith(MAGIC):
            quarantined.append({**entry, "reason": "RASTER_ARCHIVE_OR_RAW_INPUT_NOT_PUBLIC"})
            continue
        if name not in ALLOWED:
            quarantined.append({**entry, "reason": "PATH_NOT_EXPLICITLY_ALLOWLISTED"})
            continue
        if len(data) > 10 * 1024 * 1024:
            failures.append({**entry, "reason": "TEXT_SIZE_LIMIT"})
            continue
        try:
            text = data.decode("utf-8")
            if "\x00" in text:
                raise ValueError("binary")
            structured = []
            if name.endswith(".json"):
                parsed = public_json(text)
                structured.append(parsed)
                if name in ("runtime/debug-label-acceptance.json", "editor/debug-label-preview.json"):
                    from debug_label_preview import validate_public_diagnostic
                    try:
                        label_diagnostic = public_json((root / "runtime/debug-label-acceptance.json").read_text(encoding="utf-8"))
                        validate_public_diagnostic(label_diagnostic, root)
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_LABEL_PREVIEW"})
                        continue
                if name == "runtime/http-probe-diagnostic.json":
                    from retry_http_probe import validate_public_diagnostic
                    try:
                        validate_public_diagnostic(parsed,
                            json.loads((root / "compiler-manifest.json").read_text(encoding="utf-8")),
                            json.loads((root / "runtime/output-assertions.json").read_text(encoding="utf-8")))
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_HTTP_DIAGNOSTIC"})
                        continue
                if name == "runtime/tagged-carrier-observation.json":
                    from tagged_carrier_runtime import validate_public_diagnostic
                    try:
                        validate_public_diagnostic(parsed, root)
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_TAGGED_CARRIER_OBSERVATION"})
                        continue
                if name == "runtime/nested-list-observation.json":
                    from nested_list_runtime import validate_public_diagnostic
                    try:
                        validate_public_diagnostic(parsed, root)
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_NESTED_LIST_OBSERVATION"})
                        continue
                if name == "runtime/json-body-diagnostic.json":
                    from json_body_probe import validate_public_diagnostic
                    try:
                        validate_public_diagnostic(parsed,
                            public_json((root / "compiler-manifest.json").read_text(encoding="utf-8")),
                            public_json((root / "runtime/output-assertions.json").read_text(encoding="utf-8")),
                            (root / "runtime/callback-events.json").read_bytes())
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_JSON_BODY_DIAGNOSTIC"})
                        continue
                if name == "runtime/simulator-session-recovery.json":
                    from simulator_session_recovery import validate_receipt
                    try:
                        compiler = public_json((root / "compiler-manifest.json").read_text(encoding="utf-8"))
                        assertions = public_json((root / "runtime/output-assertions.json").read_text(encoding="utf-8"))
                        validate_receipt(parsed, compiler["compilerCommitSha"], root.name,
                                         assertions["targetFixtureId"])
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_SESSION_DIAGNOSTIC"})
                        continue
                if name in ("runtime/post-test-inspection.json", "runtime/terminal-acquisition.json"):
                    from qa_terminal_receipts import context, validate_inspection, validate_terminal
                    try:
                        compiler = public_json((root / "compiler-manifest.json").read_text(encoding="utf-8"))
                        assertions = public_json((root / "runtime/output-assertions.json").read_text(encoding="utf-8"))
                        expected = context(root, compiler["compilerCommitSha"], root.name,
                                           assertions["targetFixtureId"])
                        (validate_inspection if name == "runtime/post-test-inspection.json" else
                         validate_terminal)(parsed, root, expected)
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_ACQUISITION_RECEIPT"})
                        continue
                if name in ("runtime/xcode-destination-readiness.json", "runtime/xcode-destination-command-diagnostic.json"):
                    from xcode_destination_readiness import validate_receipt
                    try:
                        compiler = public_json((root / "compiler-manifest.json").read_text(encoding="utf-8"))
                        assertions = public_json((root / "runtime/output-assertions.json").read_text(encoding="utf-8"))
                        readiness = public_json((root / "runtime/xcode-destination-readiness.json").read_text(encoding="utf-8"))
                        if name == "runtime/xcode-destination-command-diagnostic.json" and readiness["schemaVersion"] not in ("1.1", "1.2"):
                            raise ValueError("DESTINATION_DIAGNOSTIC_REQUIRES_BOUND_SCHEMA")
                        validate_receipt(readiness, compiler["compilerCommitSha"], root.name,
                                         assertions["targetFixtureId"], artifact_root=root)
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_DESTINATION_DIAGNOSTIC"})
                        continue
                if name == "runtime/storage-cross-run-diagnostic.json":
                    from storage_cross_run import validate_public_diagnostic
                    try:
                        validate_public_diagnostic(parsed, root)
                    except (OSError, ValueError, TypeError, KeyError):
                        failures.append({**entry, "reason": "INVALID_BOUNDED_STORAGE_DIAGNOSTIC"})
                        continue
            elif name.endswith(".jsonl"):
                for line in text.splitlines():
                    if line.strip():
                        structured.append(public_json(line))
            structured_failure = next((reason for value in structured
                                       if (reason := structured_privacy_failure(value))), None)
            if structured_failure:
                failures.append({**entry, "reason": structured_failure})
                continue
        except (UnicodeError, ValueError):
            failures.append({**entry, "reason": "INVALID_TEXT_OR_STRUCTURED_DATA"})
            continue
        if CANARY.search(text):
            # Never echo the matching secret, its surrounding content or an
            # unsafe filename into stdout or the published manifest.
            failures.append({**entry, "reason": "SECRET_OR_PRIVATE_CANARY"})
            continue
        approved.append((data, rel, entry))
    if failures:
        raise PublicationBlocked("PUBLICATION_BLOCKED:" + json.dumps(failures, separators=(",", ":")))
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".cherri-public-", dir=output.parent))
    try:
        for data, rel, _ in approved:
            destination = temporary / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        manifest = {"schemaVersion": "1.5", "syntheticOnly": True, "publicationGatePassed": True,
                    "pixelRedactionClaimed": False, "rasterPublicationAllowed": False,
                    "policy": "EXPLICIT_SYNTHETIC_TEXT_PATHS_ONLY", "published": [e for _, _, e in approved],
                    "quarantined": quarantined,
                    "limitations": "No arbitrary private-input or pixel sanitization guarantee; all raster/archives/raw files stay outside publication."}
        (temporary / "publication-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        temporary.rename(output)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--fixtures-dir", required=True)
    args = parser.parse_args()
    fixtures = Path(args.fixtures_dir)
    try:
        trusted = trusted_fixture_sources(fixtures)
        manifest = stage(args.root, args.output, trusted)
    except (OSError, PublicationBlocked) as exc:
        print(str(exc))
        return 1
    if os.environ.get("GITHUB_OUTPUT"):
        with open(os.environ["GITHUB_OUTPUT"], "a", encoding="utf-8") as handle:
            handle.write("passed=true\n")
    print(json.dumps({"publicationGatePassed": True, "publishedFiles": len(manifest["published"]),
                      "quarantinedFiles": len(manifest["quarantined"]), "rasterPublicationAllowed": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
