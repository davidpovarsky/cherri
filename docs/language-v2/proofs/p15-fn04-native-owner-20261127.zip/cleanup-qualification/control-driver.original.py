from pathlib import Path
import hashlib,json,os,sys,unittest
Q,O=map(Path,sys.argv[1:3]);sys.path.insert(0,str(Q));sys.dont_write_bytecode=True
import test_native_caller_input_owner as tests
events=[]
class Result(unittest.TextTestResult):
 def startTest(self,t):events.append({"event":"start","id":t.id()});super().startTest(t)
 def addSuccess(self,t):events.append({"event":"pass","id":t.id()});super().addSuccess(t)
 def addFailure(self,t,e):events.append({"event":"fail","id":t.id()});super().addFailure(t,e)
 def addError(self,t,e):events.append({"event":"error","id":t.id()});super().addError(t,e)
 def addSkip(self,t,r):events.append({"event":"skip","id":t.id(),"reason":r});super().addSkip(t,r)
def snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in Q.glob("*.py")}
before=snapshot()
suite=unittest.TestSuite([tests.NativeCallerOwnerTests("test_first_signal_during_actual_finish_cleanup_is_deferred")])
r=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
after=snapshot()
v={"schema":"cherri-native-caller-finish-signal-control/1","status":"PASS"if r.wasSuccessful()and before==after else"FAIL",
"testsRun":r.testsRun,"failures":[{"id":t.id(),"trace":e}for t,e in r.failures],
"errors":[{"id":t.id(),"trace":e}for t,e in r.errors],"skips":r.skipped,
"events":events,"sourceBefore":before,"sourceAfter":after,"sourceUnchanged":before==after,
"nativeExecuted":False,"formalAcceptanceGranted":False}
with(O/"tests.original.json").open("x")as f:json.dump(v,f,sort_keys=True,indent=2);f.write("\n")
raise SystemExit(0 if v["status"]=="PASS"else 1)
