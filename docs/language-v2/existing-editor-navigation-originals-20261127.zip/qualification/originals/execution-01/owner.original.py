import hashlib, importlib.util, json, os, stat, sys, time, traceback
from pathlib import Path

sys.dont_write_bytecode = True
D = Path("/Users/m1/builds/_preflight/cherri-existing-editor-navigation-controls-20261127-01")
PY = "/opt/homebrew/opt/python@3.12/libexec/bin/python3"
PY_SHA = "ab825fde913c394f6fb8dc57da39108ad98e1827a5404119993de3d3bc6d8fb7"
WHOLE, RESERVE, FLOOR = 120, 20, 4 * 1024**3
PHASE_ALLOWANCE = 128 * 1024**2
started = globals().get('OWNER_STARTED_MONOTONIC', time.monotonic())
assert isinstance(started, float) and 0 <= time.monotonic() - started < 20
hard = started + WHOLE

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def available():
    value = os.statvfs(D)
    return value.f_bavail * value.f_frsize

def original(path, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return {"path": str(path), "bytes": len(raw), "sha256": digest(raw)}

assert sys.platform == "darwin" and sys.version_info[:2] == (3, 12)
assert digest(Path(PY).read_bytes()) == PY_SHA
assert len(sys.argv) == 2
manifest_raw = (D / "source-manifest.original.json").read_bytes()
assert digest(manifest_raw) == sys.argv[1]
manifest = json.loads(manifest_raw)

def snapshot():
    rows = {}
    for name, pin in sorted(manifest.items()):
        path = D / name
        assert path.is_file() and not path.is_symlink()
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        identity = lambda x: (x.st_dev, x.st_ino, x.st_mode, x.st_uid, x.st_gid, x.st_size, x.st_mtime_ns)
        assert identity(before) == identity(after)
        assert len(raw) == pin["bytes"] and digest(raw) == pin["sha256"]
        rows[name] = {"bytes": len(raw), "sha256": digest(raw), "mode": stat.S_IMODE(before.st_mode)}
    return rows

before = snapshot()
free = available()
assert free >= FLOOR + PHASE_ALLOWANCE, "FOUNDATION_INCREMENTAL_CAPACITY"
E = D / "execution-01"
E.mkdir(mode=0o700)
original(E / "owner.original.py", Path(__file__).read_bytes())
original(E / "source-before.original.json", before)
(E / "tmp").mkdir(mode=0o700)
(E / "module-cache").mkdir(mode=0o700)
sys.path.insert(0, str(D / "helpers"))
spec = importlib.util.spec_from_file_location("foundation_envelope", D / "sources/collect_ios_xcresult_summary.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
import project_prerequisite_observation as helper
assert digest(Path(helper.__file__).read_bytes()) == "7497edd0afb23d9c85c3ddcf7d979c8e35835031a5d4908e25b4d78d7ea5bbcf"
os.environ["TMPDIR"] = str(E / "tmp")
os.environ["CLANG_MODULE_CACHE_PATH"] = str(E / "module-cache")
os.environ["SWIFT_MODULECACHE_PATH"] = str(E / "module-cache")
os.chdir(E)
R = {
    "schema": "cherri-existing-editor-navigation-foundation-control-owner/1",
    "status": "INCOMPLETE", "nativeExecuted": False, "simulatorInvocations": 0,
    "foundationControlExecuted": False, "originalDefinitionsUnchanged": True, "additiveSelector": True,
    "wholeSeconds": WHOLE, "finalReserveSeconds": RESERVE,
    "compileSeconds": 60, "controlSeconds": 20,
    "capacityProfile": {"osReserveBytes": FLOOR, "incrementalPhaseBytes": PHASE_ALLOWANCE},
    "freeBefore": free, "pythonExecutable": PY, "pythonSHA256": PY_SHA,
    "sourceManifestSHA256": digest(manifest_raw), "commands": [],
}
try:
    with base.envelope(max(0.001, hard - time.monotonic())):
        xcrun = Path("/usr/bin/xcrun")
        info = xcrun.stat()
        assert stat.S_ISREG(info.st_mode) and info.st_uid == 0 and not info.st_mode & 0o022
        raw = xcrun.read_bytes()
        assert 0 < len(raw) <= 16 * 1024**2
        original(E / "xcrun-executable.original.json", {
            "path": str(xcrun), "bytes": len(raw), "sha256": digest(raw),
            "mode": stat.S_IMODE(info.st_mode), "uid": info.st_uid, "gid": info.st_gid,
            "selectedDeveloperDirectoryEnvironment": os.environ.get("DEVELOPER_DIR"),
        })
        binary = E / "verify-existing-editor-navigation"
        commands = [
            ("compile", ["/usr/bin/xcrun", "swiftc", "-module-cache-path", str(E / "module-cache"),
                         "-o", str(binary), str(D / "sources/ImportSheetSelection.swift"),
                         str(D / "sources/verify_existing_editor_navigation.swift")], 60),
            ("control", [str(binary), str(D / "inputs/native-ax.after.original.json")], 20),
        ]
        for name, argv, seconds in commands:
            assert available() >= FLOOR and time.monotonic() + seconds + 2 <= hard - RESERVE
            target = E / name
            target.mkdir(mode=0o700)
            original(target / "intent.original.json", {"argv": argv, "seconds": seconds, "hardDeadlineMonotonic": hard - RESERVE})
            def journal(phase, details):
                original(target / (phase + ".original.json"), details)
            with (target / "stdout.original").open("xb") as stdout, (target / "stderr.original").open("xb") as stderr:
                observed, capture = helper.capture(argv, seconds, output=stdout, error_output=stderr,
                    hard_deadline=hard - RESERVE, stream_limit=1024**2, journal=journal)
            record = {"name": name, "argv": argv, "observed": observed, "capture": capture}
            original(target / "process.original.json", record)
            R["commands"].append(record)
            assert capture["cleanupParentReaped"] and capture["groupAfterCleanup"]["state"] == "ABSENT"
            for side in ("stdout", "stderr"):
                raw = (target / (side + ".original")).read_bytes()
                assert len(raw) == capture[side]["bytes"] and digest(raw) == capture[side]["sha256"]
                assert capture[side]["eof"] and not capture[side]["overflow"]
            assert observed["result"] == "PASS" and observed["exitCode"] == 0
            if name == "compile":
                raw = binary.read_bytes()
                R["controlBinary"] = {"bytes": len(raw), "sha256": digest(raw)}
            else:
                value = json.loads((target / "stdout.original").read_bytes())
                assert value["schema"] == "cherri-existing-editor-navigation-foundation-controls/1"
                assert value["status"] == "PASS" and value["nativeInvocations"] == 0
                assert value["workflowRuns"] == 0 and value["uiTapInvocations"] == 0
                assert value["actualPriorAXInput"] is True and value["candidateHittabilityIsSyntheticControlInput"] is True
                events = value["events"]
                expected_names = ['actual_86_node_capture_selects_only_editor', 'already_invoked', 'background', 'button_has_unobserved_identifier', 'button_outside_bar', 'capture_deadline_expiry_rejected', 'capture_identity_change_rejected', 'deadline_exceeded', 'deadline_reached', 'depth_overflow', 'disabled_navigation_bar', 'duplicate_query', 'duplicate_query_index', 'editor_from_unrelated_bar', 'frame_outside_app', 'global_editor_not_direct_child', 'initial_rejection_does_not_capture_or_reobserve', 'label_overflow', 'matching_label_cannot_replace_identifier', 'node_overflow', 'nonfinite_clock', 'nonfinite_deadline', 'nonfinite_frame', 'not_hittable', 'query_absent', 'query_inconsistent_existence', 'query_not_current_children', 'query_not_current_frame', 'query_not_current_selection', 'simple_exact_identity', 'two_editor_buttons', 'two_named_bars_even_one_has_button', 'wrong_button_Add Shortcut', 'wrong_button_Back', 'wrong_button_Edit', 'wrong_button_Replace', 'wrong_button_Run', 'wrong_button_play', 'wrong_exact_name']
                assert len(events) == 39 and sorted(x["name"] for x in events) == expected_names
                assert all(x == {"name": x["name"], "outcome": "PASS"} for x in events)
                R["control"] = value
                R["foundationControlExecuted"] = True
        after = snapshot()
        assert before == after
        original(E / "source-after.original.json", after)
        R.update(status="PASS_ADDITIVE_EDITOR_SELECTOR_THIRTY_NINE_CONTROLS", sourceUnchanged=True)
except BaseException as error:
    R["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
finally:
    R["freeAfter"] = available()
    R["elapsedSeconds"] = time.monotonic() - started
    R["firstInterruption"] = getattr(base, "_first_interruption", None)
    closures = []
    for name in ("compile", "control"):
        target = E / name
        if (target / "started.original.json").exists():
            launched = json.loads((target / "started.original.json").read_bytes())
            ended = json.loads((target / "finished.original.json").read_bytes()) if (target / "finished.original.json").exists() else None
            closures.append({"name": name, "pid": launched["pid"], "finished": ended is not None,
                "parentReaped": ended["cleanupParentReaped"] if ended else False,
                "groupAfterCleanup": ended["groupAfterCleanup"] if ended else None})
    R["ownedProcessClosure"] = closures
    R["allRecordedGroupsAbsent"] = bool(closures) and all(x["finished"] and x["parentReaped"] and x["groupAfterCleanup"]["state"] == "ABSENT" for x in closures)
    pin = original(E / "result.original.json", R)
    print(json.dumps({"receipt": str(E / "result.original.json"), "sha256": pin["sha256"],
        "status": R["status"], "commands": len(R["commands"]), "allRecordedGroupsAbsent": R["allRecordedGroupsAbsent"],
        "elapsedSeconds": R["elapsedSeconds"], "error": R.get("error")}))

