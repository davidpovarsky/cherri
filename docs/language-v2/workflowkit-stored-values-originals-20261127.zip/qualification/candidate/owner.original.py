from pathlib import Path
import hashlib,importlib.util,json,os,platform,sys,time,traceback,stat,datetime
sys.dont_write_bytecode=True
D=Path("/Users/m1/builds/_preflight/cherri-rp39-darwin-transport-controls-20261127-01")
O=Path(__file__).resolve().parent
PY=Path("/opt/homebrew/opt/python@3.12/libexec/bin/python3")
def sha(b):return hashlib.sha256(b).hexdigest()
def record(name,value):
 raw=value if isinstance(value,bytes)else(json.dumps(value,sort_keys=True,indent=2)+"\n").encode()
 with(O/name).open("xb")as f:f.write(raw);f.flush();os.fsync(f.fileno())
 return{"path":str(O/name),"bytes":len(raw),"sha256":sha(raw)}
assert platform.system()=="Darwin"and sys.version_info[:2]==(3,12)
assert sha(PY.read_bytes())=="ab825fde913c394f6fb8dc57da39108ad98e1827a5404119993de3d3bc6d8fb7"
manifest_raw=(D/"source-manifest.original.json").read_bytes()
assert sha(manifest_raw)=="af3a7a5a15225ef0e834fcfe0e08097b63b5b8c299bbb5b5781f6c907e3a3e1c"
manifest=json.loads(manifest_raw);assert len(manifest)==68
def snapshot():
 rows=[]
 for name,pin in manifest.items():
  p=D/name;s=p.lstat();assert stat.S_ISREG(s.st_mode)and p.is_file()and not p.is_symlink()
  b=p.read_bytes();t=p.lstat()
  assert(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_mode,t.st_uid,t.st_gid,t.st_size,t.st_mtime_ns,t.st_ctime_ns)
  assert len(b)==pin["bytes"]and sha(b)==pin["sha256"]
  rows.append({"path":name,"bytes":len(b),"sha256":sha(b)})
 return rows
before=snapshot();record("source-before.original.json",before)
old_result=D/"execution-01/result.original.json"
assert sha(old_result.read_bytes())=="8bbf8057bfbf4b599a2100ce7271a5379d49bbeeace000ca36d107ec3b81ede8"
probe_manifest=json.loads((O/"probe-source-manifest.original.json").read_bytes())
for name,pin in probe_manifest.items():
 p=O/name;b=p.read_bytes();assert pin=={"bytes":len(b),"sha256":sha(b)}
free=os.statvfs("/System/Volumes/Data").f_bavail*os.statvfs("/System/Volumes/Data").f_frsize
assert free>=4*1024**2+64*1024**2
sp=importlib.util.spec_from_file_location("known_probe_base",D/"old/ios/scripts/collect_ios_xcresult_summary.py")
base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base);helper=base.load_primitives(D/"old",None)
R={"schema":"cherri-workflowkit-original-action-pilot-owner/1","status":"INCOMPLETE","startedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),
"platform":platform.platform(),"python":sys.version,"pythonExecutable":str(PY),"pythonSHA256":sha(PY.read_bytes()),
"helperQualificationSHA256":sha(old_result.read_bytes()),"sourceManifestSHA256":sha(manifest_raw),"probeSourceManifest":probe_manifest,
"wholeOwnerSeconds":60,"commandSeconds":20,"streamLimitBytes":1024**2,"freeDataBefore":free,
"estimatedIncrementalBytes":4*1024**2,"osMarginBytes":64*1024**2,"shortcutImports":0,"engineRunInvocations":None,"nativeAcceptanceGranted":False}
hard=time.monotonic()+60;started=time.monotonic()
try:
 with base.envelope(60):
  (O/"events.original.jsonl").open("xb").close()
  argv=["/usr/bin/osascript","-l","JavaScript",str(O/"probe.original.js"),str(O/"unsigned.original.plist"),str(O/"events.original.jsonl")]
  def journal(phase,detail):record("process."+phase+".original.json",detail)
  record("intent.original.json",{"argv":argv,"seconds":20,"hardDeadlineMonotonic":hard-15,"operation":"original-three-action-transient-workflow-engine-pilot-no-library-import"})
  with(O/"stdout.original").open("xb")as stdout,(O/"stderr.original").open("xb")as stderr:
   observed,capture=helper.capture(argv,20,output=stdout,error_output=stderr,hard_deadline=hard-15,stream_limit=1024**2,journal=journal)
  record("process.original.json",{"observed":observed,"capture":capture});R["process"]={"observed":observed,"capture":capture}
  assert capture["cleanupParentReaped"]and capture["groupAfterCleanup"]["state"]=="ABSENT"
  assert observed["result"]=="PASS"and observed["exitCode"]==0
  raw=(O/"stdout.original").read_bytes();value=json.loads(raw)
  assert value["schema"]=="cherri-workflowkit-original-action-pilot/1"
  assert len(value["events"])<=64 and value["engineRunInvocations"] in (0,1)
  record("pilot.original.json",raw)
  after=snapshot();assert after==before;record("source-after.original.json",after)
  for name,pin in probe_manifest.items():
   b=(O/name).read_bytes();assert pin=={"bytes":len(b),"sha256":sha(b)}
  R.update(status=value["status"],sourceBeforeAfterEqual=True,engineRunInvocations=value["engineRunInvocations"],
   pilot={"bytes":len(raw),"sha256":sha(raw)},pilotError=value.get("error"))
except BaseException as e:R["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
finally:
 R.update(elapsedMs=int((time.monotonic()-started)*1000),freeDataAfter=os.statvfs("/System/Volumes/Data").f_bavail*os.statvfs("/System/Volumes/Data").f_frsize)
 pin=record("result.original.json",R)
 print(json.dumps({"status":R["status"],"receipt":pin,"engineRunInvocations":R.get("engineRunInvocations"),"pilotError":R.get("pilotError"),"error":R.get("error"),"process":R.get("process")}))
