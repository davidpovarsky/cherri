import ast,difflib,hashlib,json,pathlib,signal,time,traceback
P=pathlib.Path
B=P("/var/cache/cherri-native-contract-producers-20261126/caller-generic-seal-qualification-01")
O=B/"ci-independent-delta-review-01"
started=time.monotonic();checks=[];inputs=[]
def h(x):return hashlib.sha256(x).hexdigest()
def ck(v,s):
 if not v:raise AssertionError(s)
 checks.append(s)
def rd(p,expected=None):
 b=p.read_bytes()
 if expected is not None:ck(h(b)==expected,"PIN:"+str(p))
 inputs.append({"path":str(p),"bytes":len(b),"sha256":h(b)})
 return b
def j(p,expected=None):return json.loads(rd(p,expected))
def methods(raw):
 t=ast.parse(raw);return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
def dump(n):return ast.dump(n,include_attributes=False)
def timeout(*_):raise TimeoutError("FILE_REVIEW_45S")
signal.signal(signal.SIGALRM,timeout);signal.alarm(45)
O.mkdir(mode=0o755,exist_ok=False)
(O/"owner.original.py").write_bytes(P(__file__).read_bytes())
result={"schema":"cherri-generic-seal-independent-delta-review/1","status":"FAIL","testsExecuted":False,"GitGoNativeExecuted":False,"sourceMutation":False,"formalAcceptanceGranted":False}
try:
 receipt=j(B/"result.original.json","5a60a25516af2b52675dce9a99a6f9980b16793d03a088f59cc9d8d9cb3e7c2d")
 patch=rd(B/"source.original.patch","e0f432eac2bd01aabde24996fc496aaf6a1c4eab359f3c400df86a8e4a97426d")
 before=j(B/"source-before.original.json","b021d43f03073c44f5ee743b2cb5ed22f5cbe6a282d3618589768f812c0f4e98")
 after=j(B/"source-after.original.json","b021d43f03073c44f5ee743b2cb5ed22f5cbe6a282d3618589768f812c0f4e98")
 ck(before==after==receipt["sources"],"CLOSING_SOURCE_EXACT")
 files={}
 for side in ["old","candidate"]:
  files[side]={}
  for name,pin in before[side].items():
   b=rd(B/side/"ios/scripts"/name,pin["sha256"]);ck(len(b)==pin["bytes"],"SIZE:"+side+"/"+name);files[side][name]=b
 old=files["old"]["seal_rp39_diagnostic.py"];new=files["candidate"]["seal_rp39_diagnostic.py"]
 restored=new.replace(b'    profile = load("record_workspace_presentation_source")\n',b"")
 restored=restored.replace(b'base = load("collect_ios_xcresult_summary")\n',b'base = load("collect_ios_xcresult_summary")\nprofile = load("record_workspace_presentation_source")\n',1)
 ck(restored==old,"EXACT_FULL_MODULE_REVERSE")
 olddefs,newdefs=methods(old),methods(new);ck(set(olddefs)==set(newdefs),"NO_DEFINITION_ADDITION_OR_REMOVAL")
 changed=sorted(n for n in olddefs if dump(olddefs[n])!=dump(newdefs[n]))
 ck(changed==["seal","source_receipts"],"ONLY_TWO_RP39_FUNCTIONS_CHANGED")
 for n in changed:
  node=newdefs[n]
  ck(ast.unparse(node.body[0])=="profile = load('record_workspace_presentation_source')","EXACT_LOCAL_PROFILE_LOAD:"+n)
  node.body=node.body[1:];ck(dump(node)==dump(olddefs[n]),"ALL_RP39_PREDICATES_UNCHANGED:"+n)
 generic=["file_record","make_archive","encrypt_archive"]
 ck(all(dump(olddefs[n])==dump(newdefs[n]) for n in generic),"GENERIC_ARCHIVE_ENCRYPTION_AST_EXACT")
 ck(files["old"]["collect_ios_xcresult_summary.py"]==files["candidate"]["collect_ios_xcresult_summary.py"],"COLLECTOR_EXACT")
 test=files["candidate"]["test_native_diagnostic_seal.py"];ck(test==files["old"]["test_native_diagnostic_seal.py"],"SAME_CAUSAL_CONTROL")
 t=test.decode()
 for witness in ["self.assertFalse((isolated /","self.assertIsNone(import_error","module.make_archive(","module.source_receipts(root, {})","with self.assertRaises(FileNotFoundError)","self.assertEqual(result.read(\"process.original.json\"), raw)"]:
  ck(witness in t,"CONTROL_WITNESS:"+witness)
 reconstructed=("".join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile="a/ios/scripts/seal_rp39_diagnostic.py",tofile="b/ios/scripts/seal_rp39_diagnostic.py"))+"".join(difflib.unified_diff([],test.decode().splitlines(True),fromfile="/dev/null",tofile="b/ios/scripts/test_native_diagnostic_seal.py"))).encode()
 ck(reconstructed==patch,"PATCH_RECONSTRUCTED_EXACT")
 ck(receipt["status"]=="OLD_MISSING_PROFILE_IMPORT_RED_CANDIDATE_GENERIC_ARCHIVE_GREEN" and receipt["source"]=="0d951cf7851fc7a250f4d2a0c6b63aa2b3a6abd6","QUALIFICATION_IDENTITY")
 ck(receipt["oldControlCount"]==receipt["candidateControlCount"]==1 and receipt["sourceUnchanged"] is True and receipt["nativeExecuted"] is False and receipt["signingInvoked"] is False,"QUALIFICATION_SCOPE")
 ck(len(receipt["processes"])==4,"FOUR_ORIGINAL_PROCESSES")
 for row in receipt["processes"]:
  name=row["name"];actual=j(B/(name+".process.original.json"));ck(actual==row,"PROCESS_ORIGINAL:"+name)
  start= j(B/(name+".start.original.json"))
  ck(start["pid"]==row["pid"] and start["pgid"]==row["pgid"],"START_IDENTITY:"+name)
  ck(row["cleanup"]["parentReaped"] and row["cleanup"]["noLiveGroupMembers"] and row["cleanup"]["after"]["state"]=="ABSENT" and not row["cleanup"]["errors"],"REAP_ABSENT:"+name)
  ck(not row["timedOut"] and not row["cancelled"] and not row["wholeDeadlineExceeded"],"FINITE_NO_INTERRUPT:"+name)
  for stream in ["stdout","stderr"]:
   raw=rd(B/(name+"."+stream+".original"),row[stream]["sha256"])
   ck(len(raw)==row[stream]["bytes"] and row[stream]["complete"],"STREAM_COMPLETE:"+name+"/"+stream)
 olderr=(B/"old-one-control.stderr.original").read_text();newerr=(B/"candidate-one-control.stderr.original").read_text()
 ck("FAILED (failures=1)" in olderr and "FileNotFoundError" in olderr and "generic archive transport must not import RP39-only profile" in olderr,"EXACT_CAUSAL_RED")
 ck("Ran 1 test" in newerr and newerr.rstrip().endswith("OK"),"EXACT_ONE_GREEN")
 result.update(status="PASS_NARROW_SOURCE_AND_RETAINED_CAUSAL_EVIDENCE",originalSource=receipt["source"],originalSealSHA256=h(old),candidateSealSHA256=h(new),testSHA256=h(test),patchSHA256=h(patch),changedFunctions=changed,unchangedDefinitions=sorted(set(olddefs)-set(changed)),qualification={"old":1,"green":1,"allFourParentsReapedAbsent":True,"testsRerun":False},finding="Generic import no longer loads the RP39-only profile. Both RP39-specific functions retain identical profile loads and all prior predicates; archive/encryption bodies and deadlines are unchanged. Actual original missing-profile failure and same-control success are retained.",limits=["This review does not establish the inner cause of the failed 0d951 native execution.","The new control covers import, archive/readback and missing-profile rejection; it is not a native execution or encryption replay."])
except BaseException as e:
 result["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
result.update(inputs=inputs,checks=len(checks),checkDetails=checks,elapsedSeconds=time.monotonic()-started)
raw=(json.dumps(result,sort_keys=True,indent=2)+"\n").encode();p=O/"review.original.json";p.write_bytes(raw)
assert p.read_bytes()==raw
signal.alarm(0);print(json.dumps({"path":str(p),"sha256":h(raw),"status":result["status"],"checks":len(checks),"inputs":len(inputs),"error":result.get("error")}))
raise SystemExit(0 if result["status"].startswith("PASS") else 1)
