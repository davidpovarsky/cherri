import ast,difflib,hashlib,json,pathlib,signal,time,traceback
P=pathlib.Path
def h(b):return hashlib.sha256(b).hexdigest()
def alarm(*_):raise TimeoutError("FILE_ONLY_REVIEW_45S")
signal.signal(signal.SIGALRM,alarm);signal.alarm(45)
def save(p,v):
 b=v if isinstance(v,bytes) else (json.dumps(v,sort_keys=True,indent=2)+"\n").encode()
 with p.open("xb") as f:f.write(b)
 p.chmod(0o444)
 return {"path":str(p),"sha256":h(b),"bytes":len(b)}
outputs=[]
for role in ["apple","brg26"]:
 started=time.monotonic();checks=[];inputs=[]
 def ck(v,s):
  if not v:raise AssertionError(s)
  checks.append(s)
 def rd(p,pin=None):
  b=p.read_bytes()
  if pin is not None:ck(h(b)==pin,"PIN:"+str(p))
  inputs.append({"path":str(p),"sha256":h(b),"bytes":len(b)})
  return b
 def js(p,pin=None):return json.loads(rd(p,pin))
 if role=="apple":
  B=P("/var/cache/cherri-native-contract-producers-20261126/caller-hosted-native-seal-successor-01");O=B/"ci-independent-source-review-01"
 else:
  B=P("/var/cache/cherri-native-explicit-signing-20261127");O=B/"ci-independent-export-source-review-01"
 O.mkdir(mode=0o755,exist_ok=False);save(O/"owner.original.py",P(__file__).read_bytes())
 result={"schema":"cherri-independent-bounded-source-review/1","role":role,"status":"FAIL","testsExecuted":False,"GitGoNativeExecuted":False,"sourceMutation":False,"formalAcceptanceGranted":False}
 try:
  if role=="apple":
   m=js(B/"manifest.original.json","143c628df8c2523de4bc2a7fe8b2916621e7d5077abe1bbffd5b9f38fd956bfb")
   patch=rd(B/"source.original.patch","8bef14f8d38824a5b21b812e8a5591e1feded482d8184d9a7833e3a72fc75b6e")
   ck(m["base"]=="c81d6faa3545919f961cebe4cf1a2f865473bf19","EXACT_PUBLISHED_PARENT")
   files=sorted(m["files"]);ck(files==[".github/workflows/p10r15-fn04-native.yml","tools/shortcuts-simulator-qa/native_caller_execution_context.py","tools/shortcuts-simulator-qa/native_caller_hosted_run.py"],"EXACT_THREE_PATHS")
   allpatch=[];oldfiles={};newfiles={}
   for rel in files:
    old=rd(B/"before"/rel,m["files"][rel]["before"]["sha256"]);new=rd(B/"files"/rel,m["files"][rel]["after"]["sha256"])
    ck(len(old)==m["files"][rel]["before"]["bytes"] and len(new)==m["files"][rel]["after"]["bytes"],"SIZES:"+rel)
    oldfiles[rel]=old;newfiles[rel]=new
    allpatch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile="a/"+rel,tofile="b/"+rel))
   ck("".join(allpatch).encode()==patch,"EXACT_FULL_PATCH_RECONSTRUCTION")
   oldprobe=b"probe/cherri-p10r15-fn04-native-direct-20261127";newprobe=b"probe/cherri-p10r15-fn04-native-sealed-20261127"
   for rel in files[:2]:
    ck(newfiles[rel].count(newprobe)==1 and newfiles[rel].replace(newprobe,oldprobe)==oldfiles[rel],"PROBE_LITERAL_ONLY:"+rel)
   rel=files[2];old=oldfiles[rel];new=newfiles[rel]
   oldseal=b"76f28b1d0c5b46997f5a52d7e9639a2a05a468b1201e1453e1b2e206f8db7d35";newseal=b"77bc46a766b6548774984780f695be88b4037b8a821508ad7d9e745b473784a0"
   fields=b'                "nativeChildInvocationScope": "OUTER_OWNER_SUBPROCESSES_ONLY",\n                "innerNativeResultParsed": self.native_result is not None,\n'
   ck(new.count(fields)==1 and new.count(newseal)==1,"EXACT_TWO_SUMMARY_FIELDS_AND_SEAL_LITERAL")
   ck(new.replace(fields,b"",1).replace(newseal,oldseal,1)==old,"FULL_RUN_MODULE_REVERSE_LIFECYCLE_UNCHANGED")
   ast.parse(new);ast.parse(newfiles[files[1]]);ck(True,"BOTH_PYTHON_MODULES_PARSE")
   seal=rd(B.parent/"source/ios/scripts/seal_rp39_diagnostic.py",newseal.decode())
   review=js(B.parent/"caller-generic-seal-qualification-01/ci-independent-delta-review-01/review.original.json","fe9eb53e8a61530edf69f60c6d3a5422b8fbb511f23551629bf9054cb859af7d")
   ck(review["status"]=="PASS_NARROW_SOURCE_AND_RETAINED_CAUSAL_EVIDENCE","QUALIFIED_LAZY_PROFILE_REVIEW")
   ck(len(m["processes"])==3,"THREE_AUTHENTIC_BEFORE_BLOB_READS")
   for i,(rel,row) in enumerate(zip(files,m["processes"])):
    ck(row["status"]=="PASS" and row["exitCode"]==0 and row["cleanup"]["parentReaped"] and row["cleanup"]["after"]["state"]=="ABSENT","BEFORE_READ_CLOSED:"+str(i))
    out=rd(B/("source-"+str(i)+".stdout.original"),row["stdout"]["sha256"])
    err=rd(B/("source-"+str(i)+".stderr.original"),row["stderr"]["sha256"])
    ck(out==oldfiles[rel] and len(err)==row["stderr"]["bytes"],"COMPLETE_AUTHENTIC_BEFORE_STREAM:"+str(i))
    ck(row["argv"][-2:] == ["show",m["base"]+":"+rel],"IMMUTABLE_GIT_BLOB_ARGV:"+str(i))
   result.update(status="PASS_SOURCE_REVIEW_ONLY",base=m["base"],changedPaths=files,probe=m["probe"],sealSHA256=newseal.decode(),findings=["Only a fresh fixed create-probe identity, the already-qualified lazy-profile seal hash, and two explicitly scoped public summary fields change.","Full module reversal proves lifecycle, original assertions, input packets and all inner/outer budgets unchanged.","The child counter describes outer owner subprocesses only; parsed-inner-result presence does not infer inner invocation absence or a fixed native execution cause."],nativeRetryExecuted=False)
  else:
   W=P("/var/cache/cherri-native-numeric-contracts-20261127/source")
   original=rd(W/"p15_signing_explicit_joined_test.go","77b8616bbcc6dc93c5edd33ff9cfd2acffba31f553e5e60e7785e7a00e3f8e29")
   candidate=rd(W/"p15_native_explicit_signing_export_test.go","e80f5fe20869ca1289893c86795e58e54066c7a6a9361d427f8345937541e9f4")
   r=js(B/"author-controls-commit-01/result.original.json","3278c6e3567a5cb6ddf1f6e1ba780c004a70c087ea481fa026cf2f83cd61e603")
   ck(r["actualAfter"]["head"]=="dc80d58a1249b3a485a7c6a3c4a4ee63ca30ecb3" and r["actualAfter"]["tree"]=="9bbfdb6ad848cb32dd4d9ad83295a4aef79978d8" and r["actualAfter"]["status"]=="","ACTUAL_COMMITTED_SOURCE")
   ck(len(original)==13121 and len(candidate)==5318,"EXACT_FULL_SOURCE_SIZES")
   ck(r["all7902PreviousFilesUnchanged"] is True and not r["goExecuted"] and not r["nativeExecuted"] and not r["liveSigningExecuted"],"ORIGINALS_AND_SCOPE_PRESERVED")
   c=r["controls"];ck(c["testsRun"]==6 and c["failures"]==0 and c["errors"]==0 and c["skipped"]==0,"RETAINED_SIX_CONTROL_OUTCOME")
   ck(sum(x["event"]=="subtest_pass" for x in c["events"])==44,"RETAINED_44_SUBTEST_OUTCOME")
   text=candidate.decode();src=original.decode()
   for token in ['[]string{"v2", "legacy"}','a, b, directory, input, output := p15BRG26StaleState(t, mode)','p15BRG26NativeLiteral(t, raw, mode, literal)','p15NativeSigningBlob(t, a, mode, p15BRG26Earlier)','p15NativeSigningBlob(t, b, mode, p15BRG26Current)','p15NativeSigningBlob(t, ambient, mode, p15BRG26Earlier)','!bytes.Equal(earlier, a)','!bytes.Equal(current, b) || bytes.Equal(a, b)','"BRG26_EXISTING_DESTINATION"','!reflect.DeepEqual(before, p15DirectoryDigest(t, directory))','map[string]any{"kind": "None", "presence": "absent", "items": 0}','map[string]any{"kind": "Text", "presence": "one-item", "value": p15BRG26Current}']:
    ck(token in text,"EXPORT_BINDING:"+token)
   for token in ['a = p15BRG26Unsigned(t, mode, "BRG26 A earlier", p15BRG26Earlier)','b = p15BRG26Unsigned(t, mode, p15BRG26Name, p15BRG26Current)','if err := p15M02MainVoidRowsError(actions); err != nil','expectedCount := 1','expectedCount++','inputPath, outputPath = stale, filepath.Join(directory, "A stale output.shortcut")','basename, workflowName, shortcut = "BRG26_STALE_A_NAME", "BRG26_STALE_A_WORKFLOW", earlierShortcut']:
    ck(token in src,"ORIGINAL_AUTHORITY:"+token)
   ck('compileForMobileMode("text("+fmt.Sprintf("%q", literal)+")\\n", name, mode, false)' in src,"ORIGINAL_FACTORY_SOURCE")
   ck('[]byte("text(" + fmt.Sprintf("%q", p15BRG26Earlier) + ")\\n")' in text and '[]byte("text(" + fmt.Sprintf("%q", p15BRG26Current) + ")\\n")' in text,"BOTH_SOURCE_PACKETS_MATCH_FACTORY")
   result.update(status="PASS_SOURCE_REVIEW_ONLY",source=r["actualAfter"]["head"],tree=r["actualAfter"]["tree"],findings=["Both original dialects call the full unchanged stale-state factory; actual globals and A/B files are checked before full unsigned packet export.","The complete original native-literal oracle checks A, B and ambient graph; original V2 Void and Legacy Text final contracts remain distinct.","Original Unicode name, explicit B paths and existing destination are preserved; full directory digest is unchanged after export.","The retained six Python controls/44 subtests are source evidence only here; no Go, signing, native or acceptance credit is inferred."],fullOriginalAuthoritySHA256=h(original),exportSHA256=h(candidate))
 except BaseException as e:result["error"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
 result.update(checks=len(checks),inputs=len(inputs),elapsedSeconds=time.monotonic()-started)
 save(O/"inputs.original.json",inputs);save(O/"checks.original.json",checks)
 pin=save(O/"review.original.json",result);outputs.append({**pin,"status":result["status"],"checks":len(checks),"error":result.get("error")})
print(json.dumps(outputs,sort_keys=True));signal.alarm(0)
raise SystemExit(0 if all(x["status"]=="PASS_SOURCE_REVIEW_ONLY" for x in outputs) else 1)
