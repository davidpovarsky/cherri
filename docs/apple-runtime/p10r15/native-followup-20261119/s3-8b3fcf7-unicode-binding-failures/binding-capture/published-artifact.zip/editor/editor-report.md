# Editor Inspector

Status: `NEEDS_REVIEW`

Expected native actions: 33; observed AX containers: 62.

This compares independent compiled plist data with AX observations. Hidden values and missing identity remain unverified.
Historical detectedActionCards counts distinct UI strings, including toolbar controls and parameters; it is not a native action count.

| Native index | Identifier | Status |
|---|---|---|
| 0 | is.workflow.actions.comment | AX_UNEXPOSED |
| 1 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 2 | is.workflow.actions.setvariable | AX_UNEXPOSED |
| 3 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 4 | is.workflow.actions.appendvariable | AX_UNEXPOSED |
| 5 | is.workflow.actions.number | AX_UNEXPOSED |
| 6 | is.workflow.actions.setvariable | AX_UNEXPOSED |
| 7 | is.workflow.actions.getvariable | AX_UNEXPOSED |
| 8 | is.workflow.actions.number | AX_UNEXPOSED |
| 9 | is.workflow.actions.setvariable | AX_UNEXPOSED |
| 10 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 11 | is.workflow.actions.setclipboard | AX_UNEXPOSED |
| 12 | is.workflow.actions.getvariable | AX_UNEXPOSED |
| 13 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 14 | is.workflow.actions.setclipboard | AX_UNEXPOSED |
| 15 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 16 | is.workflow.actions.setclipboard | AX_UNEXPOSED |
| 17 | is.workflow.actions.comment | AX_UNEXPOSED |
| 18 | is.workflow.actions.getvariable | AX_UNEXPOSED |
| 19 | is.workflow.actions.base64encode | AX_UNEXPOSED |
| 20 | is.workflow.actions.count | AX_UNEXPOSED |
| 21 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 22 | is.workflow.actions.setvariable | AX_UNEXPOSED |
| 23 | is.workflow.actions.conditional | AX_UNEXPOSED |
| 24 | is.workflow.actions.setvariable | AX_UNEXPOSED |
| 25 | is.workflow.actions.conditional | AX_UNEXPOSED |
| 26 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 27 | is.workflow.actions.appendvariable | AX_UNEXPOSED |
| 28 | is.workflow.actions.text.combine | AX_UNEXPOSED |
| 29 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 30 | is.workflow.actions.gettext | AX_UNEXPOSED |
| 31 | is.workflow.actions.comment | AX_UNEXPOSED |
| 32 | is.workflow.actions.output | AX_UNEXPOSED |

## Limitations

- ACTION_COUNT_MISMATCH
- PAGE_OVERLAP_WITHOUT_STABLE_IDENTITY
