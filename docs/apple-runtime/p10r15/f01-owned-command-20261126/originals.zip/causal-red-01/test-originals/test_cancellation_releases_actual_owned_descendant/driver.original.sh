    run_cmd_timeout() {
      local timeout_sec="$1"
      shift
      python3 - "$timeout_sec" "$@" <<'PY'
import os, signal, subprocess, sys
t = int(sys.argv[1])
cmd = sys.argv[2:]
p = subprocess.Popen(cmd, start_new_session=True)
try:
    sys.exit(p.wait(timeout=t))
except subprocess.TimeoutExpired:
    try:
        os.killpg(p.pid, signal.SIGKILL)
    except Exception:
        pass
    try:
        p.wait(timeout=5)
    except Exception:
        pass
    sys.stderr.write(f"command timed out after {t}s: {' '.join(cmd[:4])}\n")
    sys.exit(124)
PY
    }
run_cmd_timeout "$@"
