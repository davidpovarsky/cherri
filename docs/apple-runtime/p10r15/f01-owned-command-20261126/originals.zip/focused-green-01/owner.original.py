import pathlib,os,sys,json,hashlib,signal,time,datetime
os.umask(0o077);sys.dont_write_bytecode=True
w=pathlib.Path("/mnt/development/projects/worktrees/cherri-p10r15-apple-completion-20261125");qa=w/"tools/shortcuts-simulator-qa"
e=pathlib.Path("/var/tmp/cherri-f01-local-command-ownership-20261126/focused-green-01");e.mkdir(mode=0o700)
(e/"owner.original.py").write_bytes(pathlib.Path(__file__).read_bytes())
expected=[{"path":"scripts/ios27_shortcuts_simulator_qa.sh","beforeSha256":"1df6a4b62a01b4522401ceaa8ed803ad9b4b8f4ad2725111cb303683c4c577db","afterSha256":"cd6abb28becfe3add4a380ff57ff26397e02b2f89dd2cb3db0de3c2d648c8fe1","bytes":187022},{"path":"tools/shortcuts-simulator-qa/project_prerequisite_observation.py","beforeSha256":"0d60de3707650e3f48f5023eeb92759abfaf0f5152cc96afa7c6d8a9a2059315","afterSha256":"65148ffb9d2df8fd83c2887d1e56060d96ff2e7a978b9718753b74ab6ffdc24e","bytes":69826},{"path":"tools/shortcuts-simulator-qa/test_owned_shell_command.py","beforeSha256":null,"afterSha256":"d7033c30e3bbdf4cb2d10b949af46343a10e6b39b9269283355257a7d13f4de4","bytes":8342}]
for r in expected:assert hashlib.sha256((w/r["path"]).read_bytes()).hexdigest()==r["afterSha256"]
sys.path.insert(0,str(qa));from project_prerequisite_observation import capture
def pins():
 paths={w/r["path"] for r in expected}
 paths.update(pathlib.Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,"__file__",None) and pathlib.Path(m.__file__).is_relative_to(qa) and str(m.__file__).endswith(".py"))
 return [{"path":str(x.relative_to(w)),"bytes":len(x.read_bytes()),"sha256":hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted(paths)]
def save(name,data):
 b=(json.dumps(data,sort_keys=True,indent=2)+"\n").encode()
 with (e/name).open("xb") as f:f.write(b)
 return {"path":str(e/name),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
before=pins();save("source-before.original.json",before)
for r in before:
 dest=e/"source-originals"/r["path"];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((w/r["path"]).read_bytes())
originals=e/"test-originals";originals.mkdir(mode=0o700);os.environ["CHERRI_OWNED_COMMAND_TEST_ORIGINALS"]=str(originals)
names=["test_owned_shell_command.OwnedShellCommandTests."+name for name in [
 "test_cancellation_releases_actual_owned_descendant","test_zero_parent_cannot_authenticate_live_descendant",
 "test_timeout_retains_original_bound_and_kills_owned_group","test_large_live_streams_and_literal_arguments_are_lossless",
 "test_nonzero_exit_and_original_stdio_are_preserved"]]
driver=r'''import sys,json,unittest
sys.path.insert(0,sys.argv[1]);required=json.loads(sys.argv[2])
suite=unittest.defaultTestLoader.loadTestsFromNames(required)
def flatten(suite):
 for item in suite:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item.id()
found=sorted(flatten(suite))
assert found==sorted(required)
class Observed(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.passed=[]
 def addSuccess(self,test):self.passed.append(test.id());super().addSuccess(test)
r=unittest.TextTestRunner(verbosity=2,resultclass=Observed).run(suite)
print(json.dumps({"found":found,"passed":sorted(r.passed),"testsRun":r.testsRun,"failures":len(r.failures),"errors":len(r.errors),"skipped":len(r.skipped)}))
raise SystemExit(0 if r.wasSuccessful() else 1)
'''
command=[sys.executable,"-I","-B","-c",driver,str(qa),json.dumps(names)]
save("command.original.json",{"argv":command,"childSeconds":60,"hardSeconds":65})
start=time.monotonic();observation=detail=None;error=None
def interrupted(sig,frame):raise TimeoutError("CONTROL_OWNER_INTERRUPTED_"+str(sig))
prev={s:signal.signal(s,interrupted) for s in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT)};signal.setitimer(signal.ITIMER_REAL,65)
try:
 with (e/"stdout.original").open("xb") as out,(e/"stderr.original").open("xb") as err:
  observation,detail=capture(command,60,output=out,error_output=err,hard_deadline=start+65,journal=lambda event,value:save(event+".original.json",value))
except BaseException as x:error=type(x).__name__+":"+str(x)
finally:
 signal.setitimer(signal.ITIMER_REAL,0)
 for s,h in prev.items():signal.signal(s,h)
 after=pins();save("source-after.original.json",after)
 observed=json.loads((e/"stdout.original").read_bytes()) if (e/"stdout.original").stat().st_size else None
 groups=[]
 for path in sorted(originals.glob("*/ready.json")):
  ready=json.loads(path.read_bytes());group=ready["group"];assert group!=os.getpgrp()
  try:os.killpg(group,0);state="PRESENT"
  except ProcessLookupError:state="ABSENT"
  except PermissionError:state="PERMISSION_DENIED"
  groups.append({"ready":str(path.relative_to(e)),"group":group,"state":state})
 passed=(error is None and before==after and observation and observation["result"]=="PASS" and observed and observed["found"]==sorted(names) and observed["passed"]==sorted(names) and observed["testsRun"]==5 and all(observed[k]==0 for k in ("failures","errors","skipped")) and all(r["state"]=="ABSENT" for r in groups))
 result={"schema":"cherri-owned-command-focused-qualification/1","status":"PASS" if passed else "FAIL","sourceBase":"618423ffb40f43b2cc8179d4e5b00a01811bfa73","sourceUnchangedDuringRun":before==after,"observation":observation,"capture":detail,"ownerError":error,"originalTests":observed,"ownedSyntheticGroupsAfter":groups,"elapsedMs":round((time.monotonic()-start)*1000),"nativeInvoked":False,"goExecuted":False}
 pin=save("result.original.json",result)
 print(json.dumps({"result":pin,"status":result["status"],"observation":observation,"testSummary":observed,"groupsAfter":groups,"error":error,"stderr":(e/"stderr.original").read_text()}))
