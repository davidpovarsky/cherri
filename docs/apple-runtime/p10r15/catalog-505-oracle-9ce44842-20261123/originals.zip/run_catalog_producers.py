"""Source-bound execution of the two actual P10 catalog evidence producers."""
import argparse
import ast
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import time

PRODUCERS = [
    "TestP10_VerifyAndRecord505CatalogExecution",
    "TestP10_ParameterContractMatrix_AllCatalogActions",
]
EXPECTED_ARTIFACTS = [
    "p10-505-execution-evidence.json",
    "p10-505-parameter-contract-evidence.json",
]
GO_SELECTION = {
    "GOTOOLCHAIN": "go1.24.13",
    "GOMODCACHE": "/mnt/development/tooling/cherri-go/mod",
    "GOCACHE": "/mnt/development/tooling/cherri-go/build",
    "GOTMPDIR": "/mnt/development/tooling/cherri-go/tmp",
}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def original(path, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2) + "\n").encode()
    with path.open("xb") as f:
        f.write(raw)

def capture(argv, repo, env=None, timeout=30):
    result = subprocess.run(argv, cwd=repo, env=env, capture_output=True, timeout=timeout)
    if result.returncode != 0:
        raise RuntimeError("Preflight command failed: " + repr(argv) + "; exit=" + str(result.returncode))
    return result.stdout

def source(repo):
    return {
        "head": capture(["git", "rev-parse", "HEAD"], repo).decode().strip(),
        "tree": capture(["git", "rev-parse", "HEAD^{tree}"], repo).decode().strip(),
        "branch": capture(["git", "branch", "--show-current"], repo).decode().strip(),
        "status": capture(["git", "status", "--porcelain=v1", "--untracked-files=all"], repo).decode(),
    }

def dependency_witness(repo):
    path = repo / "tools/p10r3/generate_catalog_and_pack_ledgers.py"
    tree = ast.parse(path.read_bytes())
    definitions = [node for node in tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == "DEPENDENCY_GLOBS"
                           for target in node.targets)]
    if len(definitions) != 1:
        raise RuntimeError("Dependency glob definition is ambiguous")
    patterns = ast.literal_eval(definitions[0].value)
    names = sorted({p.relative_to(repo).as_posix() for pattern in patterns
                    for p in repo.glob(pattern) if p.is_file()})
    rows = []
    h = hashlib.sha256()
    for name in names:
        raw = (repo / name).read_bytes()
        normalized = digest(raw.replace(b"\r\n", b"\n"))
        rows.append({"path": name, "bytes": len(raw), "sha256": digest(raw),
                     "normalized_sha256": normalized})
        h.update((name + ":" + normalized + "\n").encode())
    return {"fingerprint": h.hexdigest(), "patterns": patterns, "files": rows}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    repo = pathlib.Path(args.repo).resolve(strict=True)
    out = pathlib.Path(args.output).absolute()
    if len(args.expected_source) != 40 or any(c not in "0123456789abcdef" for c in args.expected_source):
        raise RuntimeError("An exact coordinator-frozen SHA is required")
    if not str(repo).startswith("/mnt/development/projects/worktrees/"):
        raise RuntimeError("Unexpected source location")
    if out.is_relative_to(repo) or out.exists():
        raise RuntimeError("Evidence output must be new and outside the source checkout")
    if not out.parent.exists() or out.parent.resolve().is_relative_to(repo):
        raise RuntimeError("Evidence parent must already exist physically outside the source checkout")
    before = source(repo)
    if before["head"] != args.expected_source or before["status"]:
        raise RuntimeError("Frozen source mismatch or dirty source; producer not started")
    out.mkdir(mode=0o700)
    artifacts = out / "artifacts"
    artifacts.mkdir(mode=0o700)
    original(out / "source-before.original.json", before)
    witness_before = dependency_witness(repo)
    original(out / "input-witness-before.original.json", witness_before)
    keep = ("PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "LC_CTYPE", "TZ")
    env = {key: os.environ[key] for key in keep if key in os.environ}
    env.update(GO_SELECTION)
    env["CHERRI_CATALOG_EVIDENCE_DIR"] = str(artifacts)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for key in ("GOMODCACHE", "GOCACHE", "GOTMPDIR"):
        path = pathlib.Path(env[key])
        if not path.is_dir() or not os.access(path, os.W_OK):
            raise RuntimeError("Configured development-volume cache is not writable")
    go = shutil.which("go", path=env.get("PATH"))
    if not go:
        raise RuntimeError("Go launcher absent")
    goenv_keys = ["GOVERSION", "GOOS", "GOARCH", "GOROOT", "GOTOOLDIR",
                  "GOTOOLCHAIN", "GOMODCACHE", "GOCACHE", "GOTMPDIR"]
    goenv_raw = capture([go, "env", "-json", *goenv_keys], repo, env, timeout=60)
    original(out / "go-env.original.json", goenv_raw)
    goenv = json.loads(goenv_raw)
    if goenv["GOVERSION"] != "go1.24.13":
        raise RuntimeError("Actual toolchain does not match coordinator selection")
    selected_go = pathlib.Path(goenv["GOROOT"]) / "bin/go"
    toolchain = {
        "launcher": str(pathlib.Path(go).resolve()),
        "launcher_sha256": digest(pathlib.Path(go).read_bytes()),
        "selected_go": str(selected_go),
        "selected_go_sha256": digest(selected_go.read_bytes()),
        "go_version": capture([go, "version"], repo, env).decode().strip(),
        "git_version": capture(["git", "--version"], repo).decode().strip(),
        "python_version": sys.version,
    }
    original(out / "toolchain.original.json", toolchain)
    argv = [go, "test", "-count=1", "-json", "-timeout=15m", "-parallel=2",
            "-run", "^(" + "|".join(PRODUCERS) + ")$", "."]
    intent = {
        "source": before, "argv": argv, "environment_selection": {
            **GO_SELECTION, "CHERRI_CATALOG_EVIDENCE_DIR": str(artifacts)},
        "expected_producers": PRODUCERS, "expected_artifacts": EXPECTED_ARTIFACTS,
        "test_timeout_seconds": 900, "process_wall_limit_seconds": 1200,
        "scope": "Actual local catalog execution only; no native specimen or Apple runtime credit.",
        "driver_sha256": digest(pathlib.Path(__file__).read_bytes()), "recorded_utc": utc(),
    }
    original(out / "intent.original.json", intent)
    started_utc, started = utc(), time.monotonic()
    timed_out = False
    with (out / "stdout.original.jsonl").open("xb") as stdout, (out / "stderr.original").open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        original(out / "process-start.original.json", {"pid": process.pid, "started_utc": started_utc})
        try:
            returncode = process.wait(timeout=1200)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                returncode = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                returncode = process.wait(timeout=5)
    finished_utc, elapsed = utc(), time.monotonic() - started
    after = source(repo)
    witness_after = dependency_witness(repo)
    original(out / "source-after.original.json", after)
    original(out / "input-witness-after.original.json", witness_after)
    events = []
    parse_errors = []
    with (out / "stdout.original.jsonl").open("rb") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
                if not isinstance(event, dict):
                    raise ValueError("not an object")
                events.append(event)
            except (ValueError, UnicodeError) as error:
                parse_errors.append({"line": line_number, "error_type": type(error).__name__})
    test_events = [event for event in events if event.get("Test")]
    runs = [event.get("Test") for event in test_events if event.get("Action") == "run"]
    passes = [event.get("Test") for event in test_events if event.get("Action") == "pass"]
    failures = [event.get("Test") for event in events if event.get("Action") in ("fail", "skip")]
    package_pass = sum(event.get("Action") == "pass" and not event.get("Test") for event in events)
    files = [{"path": p.name, "bytes": p.stat().st_size, "sha256": digest(p.read_bytes())}
             for p in sorted(artifacts.iterdir()) if p.is_file()]
    valid = (returncode == 0 and not timed_out and not parse_errors
             and sorted(runs) == sorted(PRODUCERS) and sorted(passes) == sorted(PRODUCERS)
             and not failures and package_pass == 1
             and before == after and witness_before == witness_after
             and sorted(row["path"] for row in files) == sorted(EXPECTED_ARTIFACTS))
    receipt = {
        "source": before, "argv": argv, "pid": process.pid,
        "started_utc": started_utc, "finished_utc": finished_utc,
        "elapsed_seconds": elapsed, "exit_code": returncode, "timed_out": timed_out,
        "source_after": after, "input_fingerprint_before": witness_before["fingerprint"],
        "input_fingerprint_after": witness_after["fingerprint"],
        "ran": runs, "passed": passes, "failed_or_skipped": failures,
        "package_pass_events": package_pass, "json_parse_errors": parse_errors,
        "artifact_files": files, "execution_valid": valid,
        "artifact_semantics_pending_independent_intake": True,
        "native_or_apple_acceptance": False,
    }
    original(out / "process.original.json", receipt)
    manifest = {"files": [{"path": p.relative_to(out).as_posix(), "bytes": p.stat().st_size,
                           "sha256": digest(p.read_bytes())}
                          for p in sorted(out.rglob("*")) if p.is_file()]}
    original(out / "originals-manifest.json", manifest)
    print(json.dumps(receipt), flush=True)
    return 0 if valid else 1

if __name__ == "__main__":
    raise SystemExit(main())
