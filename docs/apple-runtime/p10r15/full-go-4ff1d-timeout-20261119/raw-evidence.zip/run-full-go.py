import pathlib,subprocess,os,time,json,hashlib,collections,datetime
r=pathlib.Path(r'C:\Users\DAVID\Code\cherri-p10r15-release-checks-4ff1d-20261119')
e=pathlib.Path(r'C:\Users\DAVID\Code\cherri-p10r15-evidence-20261119\release-4ff1d')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert sha=='4ff1d089ec49528bb796fe315a74777d69008d9b'
before=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=r,text=True)
assert not before,before
assert subprocess.check_output(['git','rev-parse','--is-shallow-repository'],cwd=r,text=True).strip()=='false'
cmd=['go','test','-count=1','-json','-timeout=25m','-p=1','./...']
env=os.environ.copy()
env.update({'GOMAXPROCS':'2','GOFLAGS':'-p=1','PYTHONDONTWRITEBYTECODE':'1','CHERRI_P10R10_CORPUS':'0','CHERRI_DOCS_DIR':r'C:\Users\DAVID\Code\cherrilang-p10r15-docs-release-20261119'})
env.pop('CHERRI_P10R10_CORPUS_DIR',None)
meta={'source_sha':sha,'source_tree_clean_before':True,'ordinary_git_directory':(r/'.git').is_dir(),'shallow':False,'command':cmd,'go_version':subprocess.check_output(['go','version'],text=True).strip(),'environment':{k:env[k] for k in ['GOMAXPROCS','GOFLAGS','CHERRI_P10R10_CORPUS','CHERRI_DOCS_DIR']},'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
counts=collections.Counter()
discovered=set()
outcomes={}
packages={}
failures={}
tails={}
excluded={}
start=time.time()
last=0
progress=e/'full-go-progress.json'
log_path=e/'full-go.jsonl'
with log_path.open('w',encoding='utf-8',newline='\n') as log:
 p=subprocess.Popen(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
 meta['owned_go_pid']=p.pid
 (e/'full-go-command.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
 for line in p.stdout:
  log.write(line)
  try: item=json.loads(line)
  except Exception: item={}
  action=item.get('Action')
  test=item.get('Test')
  pkg=item.get('Package','')
  key=pkg+':'+test if test else pkg
  if test:
   if action in ['run','pass','fail','skip']: counts[action]+=1
   if action=='run': discovered.add(key)
   if action in ['pass','fail','skip']: outcomes[key]=action
   if action=='output':
    output=item.get('Output','')
    tails[key]=(tails.get(key,'')+output)[-6000:]
    if 'NOT_RUN_PRIVATE_CORPUS' in output or 'set CHERRI_P10R10_CORPUS=1' in output: excluded[key]=output.strip()
   if action in ['fail','skip']: failures[key]={'status':action,'detail':tails.get(key,'')}
  elif action in ['pass','fail','skip']: packages[pkg]=action
  now=time.time()
  if now-last>=5 or action=='fail':
   last=now
   log.flush()
   progress.write_text(json.dumps({'source_sha':sha,'owned_go_pid':p.pid,'running':True,'elapsed_seconds':round(now-start,2),'counts':dict(counts),'packages':packages,'failures_or_skips':failures,'explicit_private_scope_not_run':excluded},indent=2)+'\n',encoding='utf-8')
 code=p.wait()
after=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=r,text=True)
ignored=subprocess.check_output(['git','status','--porcelain','--untracked-files=all','--ignored=matching'],cwd=r,text=True)
summary={**meta,'exit_code':code,'elapsed_seconds':round(time.time()-start,2),'counts':dict(counts),'discovered_unique_named_tests':len(discovered),'unique_final_test_outcomes':len(outcomes),'unfinished_discovered_tests':sorted(discovered-set(outcomes)),'package_outcomes':packages,'failures_or_skips':failures,'explicit_private_scope_not_run':excluded,'source_tree_clean_after':not after,'source_status_after':after,'ignored_generated_output_status':ignored,'log_sha256':hashlib.sha256(log_path.read_bytes()).hexdigest(),'raw_log_bytes':log_path.stat().st_size,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(e/'full-go-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
progress.write_text(json.dumps({'running':False,'exit_code':code,'elapsed_seconds':summary['elapsed_seconds'],'counts':dict(counts),'summary_file':str(e/'full-go-summary.json')},indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['source_sha','exit_code','elapsed_seconds','counts','discovered_unique_named_tests','source_tree_clean_after','log_sha256','raw_log_bytes']}))
