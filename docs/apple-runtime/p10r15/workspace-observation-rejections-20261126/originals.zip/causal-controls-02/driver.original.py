import pathlib,json,sys,unittest,importlib.util,hashlib
mode=sys.argv[1]
assert mode in ('RED','GREEN')
root=pathlib.Path(sys.argv[2]);selectedroot=pathlib.Path(sys.argv[3]);original=pathlib.Path(sys.argv[4])
sys.path[:0]=[str(selectedroot),str(original)]
path=selectedroot/'test_collect_ios_test_evidence.py'
spec=importlib.util.spec_from_file_location('workspace_rejection_controls',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
name='WorkspaceObservationTests.test_first_rejection_reason_is_retained_before_followup_block' if mode=='RED' else 'WorkspaceObservationTests'
suite=unittest.defaultTestLoader.loadTestsFromName(name,module)
def leaves(value):
 for item in value:
  if isinstance(item,unittest.TestSuite):yield from leaves(item)
  else:yield item.id()
planned=list(leaves(suite));events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  super().startTest(test);self.states={};self.states[test.id()]='UNKNOWN'
 def addSuccess(self,test):
  super().addSuccess(test);self.states[test.id()]='PASSED'
 def addFailure(self,test,err):
  super().addFailure(test,err);self.states[test.id()]='FAILED'
 def addError(self,test,err):
  super().addError(test,err);self.states[test.id()]='ERROR'
 def addSkip(self,test,reason):
  super().addSkip(test,reason);self.states[test.id()]='SKIPPED'
 def addSubTest(self,test,subtest,err):
  super().addSubTest(test,subtest,err)
  if err is not None:self.states[test.id()]='FAILED' if issubclass(err[0],test.failureException)else'ERROR'
 def stopTest(self,test):
  events.append({'testId':test.id(),'status':self.states[test.id()]});super().stopTest(test)
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
summary={'schema':'cherri-workspace-rejection-actual-controls/1','mode':mode,'plannedIds':planned,'events':events,'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'successful':result.wasSuccessful(),'collectorSHA256':hashlib.sha256((selectedroot/'collect_ios_test_evidence.py').read_bytes()).hexdigest(),'testsSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'nativeExecuted':False}
with(root/(mode.lower()+'.result.original.json')).open('x')as f:f.write(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:summary[k]for k in ['mode','testsRun','failures','errors','skipped','successful']}))
sys.exit(0 if result.wasSuccessful()else 1)
