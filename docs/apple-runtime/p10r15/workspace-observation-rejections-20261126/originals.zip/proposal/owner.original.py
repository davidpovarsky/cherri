import pathlib,hashlib,json,ast,difflib,os,datetime
W=pathlib.Path('/var/cache/cherri-ios-ui-repair-p-20261126/source')
D=W.parent/'workspace-observation-rejection-proposal-01'
P='ios/scripts/collect_ios_test_evidence.py';T='ios/scripts/test_collect_ios_test_evidence.py'
pins={P:'70936b4b4c0ba0450d6dc7cc95fd9392a139ec1c63211f26415cdb4d9e8b8366',T:'8ae7fde5efb66c8f4dfd87712575b48c097f298eaf9d7c6e8feebaa6847e53d6'}
old={}
for rel,pin in pins.items():
 b=(W/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==pin;old[rel]=b.decode()
source=old[P];tree=ast.parse(source)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='workspace_observation_row')
calls=sorted([n for n in ast.walk(fn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='require'],key=lambda n:(n.lineno,n.col_offset))
codes=[
'ROOT_SHAPE','IDENTITY_OR_CONTEXT','STAGE','PHASE','BUDGET','ELAPSED','POLL_COUNT',
'TERM_VECTOR','TERM_MASK','BEFORE_EVENT_STATE','AFTER_WAIT_STATE','TERM_ORDER',
'COMPLETED_TERM_STATE','TERM_MASK_BINDING','STATE_SHAPE','STATE_BOOLEANS','SEGMENT',
'WINDOW_RELATIONS','WEB_PROGRESS','RESPONDER_SHAPE','RESPONDER_ROLE','RESPONDER_COUNTS',
'NO_WINDOW_COUNTS','WINDOW_VISIT_COUNT','TRUNCATED_VISIT_COUNT','MULTIPLE_RESPONDER_COUNT',
'RESPONDER_ROLE_COUNT','MOUNTED_WINDOW_PRESENT','OTHER_WINDOW_STAGE','ABSENT_OTHER_WINDOW_STATE','OTHER_WINDOW_PRESENT']
assert len(calls)==len(codes)==31
offset=[0]
for line in source.splitlines(keepends=True):offset.append(offset[-1]+len(line))
for node,code in reversed(list(zip(calls,codes))):
 pos=offset[node.end_lineno-1]+node.end_col_offset-1
 assert source[pos]==')'
 source=source[:pos]+', "'+code+'"'+source[pos:]
source=source.replace('    def require(value):\n        if not value:\n            raise ValueError("invalid closed workspace observation")',
'''    def require(value, reason):
        if not value:
            raise ValueError(reason)''',1)
extras=['BLOCKED_AFTER_REJECTION','RAW_SIZE','PREFIX','JSON_DUPLICATE_KEY','JSON_SYNTAX','JSON_DEPTH','SEQUENCE','UNKNOWN_VALIDATION']
allow=sorted(set(codes+extras))
declaration=(
'# Closed validation reasons only. Rejected values and exception text remain private.\n'
'WORKSPACE_OBSERVATION_REASONS = frozenset({\n'
+''.join('    '+repr(c)+',\n'for c in allow)
+'})\n\n\n')
source=source.replace('def workspace_observation_row(raw, active_test):',declaration+'def workspace_observation_row(raw, active_test):',1)
s=source.index('class WorkspaceObservationGuard:');e=source.index('\ndef bounded_log(',s)
guard=source[s:e]
guard=guard.replace('''            if self.blocked or len(raw_line.encode("utf-8")) > 4096:
                raise ValueError("blocked or oversized")''','''            if self.blocked:
                raise ValueError("BLOCKED_AFTER_REJECTION")
            if len(raw_line.encode("utf-8")) > 4096:
                raise ValueError("RAW_SIZE")''')
guard=guard.replace('raise ValueError("duplicate key")','raise ValueError("JSON_DUPLICATE_KEY")')
guard=guard.replace('raise ValueError("prefix")','raise ValueError("PREFIX")')
guard=guard.replace('raise ValueError("duplicate or out-of-order stage")','raise ValueError("SEQUENCE")')
guard=guard.replace('''        except (ValueError, TypeError, RecursionError):
            self.blocked = True
            if self.rejections >= 8:
                return ""
            self.rejections += 1
            return WORKSPACE_OBSERVATION_REJECTED + "INVALID_OBSERVATION"''','''        except (ValueError, TypeError, RecursionError) as error:
            self.blocked = True
            if self.rejections >= 8:
                return ""
            self.rejections += 1
            if isinstance(error, json.JSONDecodeError):
                reason = "JSON_SYNTAX"
            elif isinstance(error, RecursionError):
                reason = "JSON_DEPTH"
            elif (type(error) is ValueError and len(error.args) == 1
                  and type(error.args[0]) is str
                  and error.args[0] in WORKSPACE_OBSERVATION_REASONS):
                reason = error.args[0]
            else:
                reason = "UNKNOWN_VALIDATION"
            return WORKSPACE_OBSERVATION_REJECTED + "INVALID_OBSERVATION:" + reason''')
assert guard!=source[s:e]
source=source[:s]+guard+source[e:]
tests=r'''
    def test_first_rejection_reason_is_retained_before_followup_block(self):
        row = self.row()
        row["state"]["mountedKey"] = 1
        body = self.line(row) + "\n" + self.line(self.row())
        log = self.transaction(status="failed", body=body) + "".join(
            self.transaction(method) for method in self.methods[1:])
        diagnostic, records, outputs = self.collect(log, 65)
        rejected = [line for line in outputs["xcodetest.log"].splitlines()
                    if line.startswith(self.rejected)]
        self.assertEqual(rejected, [
            self.rejected + "INVALID_OBSERVATION:STATE_BOOLEANS",
            self.rejected + "INVALID_OBSERVATION:BLOCKED_AFTER_REJECTION",
        ])
        self.assertEqual(diagnostic["workspacePresentationObservations"], [])
        self.assertEqual({entry["testId"]: entry["observedStatus"]
                          for entry in diagnostic["testResults"]}, {
            self.suite + "/" + self.methods[0]: "failed",
            self.suite + "/" + self.methods[1]: "passed",
            self.suite + "/" + self.methods[2]: "passed",
        })
        self.assertEqual(records, [])

    def test_closed_rejection_reasons_never_publish_payload_or_exception(self):
        from unittest import mock
        row = self.row()
        extra = self.row(); extra["PRIVATE_CANARY"] = "PRIVATE_CANARY"
        phase = self.row(); phase["phase"] = "PRIVATE_CANARY"
        malformed = self.prefix + '{"PRIVATE_CANARY":'
        duplicate = self.line(row).replace('"polls": 0', '"polls": 0, "polls": 1')
        cases = [
            (self.line(extra), "ROOT_SHAPE"),
            (self.line(phase), "PHASE"),
            (malformed, "JSON_SYNTAX"),
            (duplicate, "JSON_DUPLICATE_KEY"),
            (self.line(self.row("code")), "SEQUENCE"),
        ]
        for raw, reason in cases:
            with self.subTest(reason=reason):
                diagnostic, records, outputs = self.collect(
                    self.transaction(status="failed", body=raw), 65)
                rejected = [line for line in outputs["xcodetest.log"].splitlines()
                            if line.startswith(self.rejected)]
                self.assertEqual(rejected, [self.rejected + "INVALID_OBSERVATION:" + reason])
                self.assertEqual(diagnostic["workspacePresentationObservations"], [])
                self.assertEqual(diagnostic["testResults"][0]["observedStatus"], "failed")
                self.assertEqual(records, [])
                self.assertNotIn("PRIVATE_CANARY", "".join(outputs.values()))
                self.assertIn(reason, collector.WORKSPACE_OBSERVATION_REASONS)

        payload = self.line(row)[len(self.prefix):]
        original = collector.json.loads
        injections = []

        def unknown_error(value, *args, **kwargs):
            if value == payload:
                injections.append(True)
                raise ValueError("PRIVATE_CANARY")
            return original(value, *args, **kwargs)

        with mock.patch.object(collector.json, "loads", side_effect=unknown_error):
            diagnostic, records, outputs = self.collect(
                self.transaction(status="failed", body=self.line(row)), 65)
        self.assertEqual(injections, [True])
        self.assertIn(self.rejected + "INVALID_OBSERVATION:UNKNOWN_VALIDATION",
                      outputs["xcodetest.log"])
        self.assertNotIn("PRIVATE_CANARY", "".join(outputs.values()))
        self.assertEqual(diagnostic["workspacePresentationObservations"], [])
        self.assertEqual(records, [])

'''
needle='\n\nif __name__ == "__main__":\n    unittest.main()\n'
assert old[T].endswith(needle)
testsource=old[T][:-len(needle)]+tests+needle
new={P:source,T:testsource}
for text in new.values():ast.parse(text)
afterfn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='workspace_observation_row')
aftercalls=sorted([n for n in ast.walk(afterfn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='require'],key=lambda n:(n.lineno,n.col_offset))
assert len(aftercalls)==31
assert [ast.dump(n.args[0])for n in calls]==[ast.dump(n.args[0])for n in aftercalls]
def methods(text):
 return {(n.name,m.name):ast.dump(m,include_attributes=False)for n in ast.parse(text).body if isinstance(n,ast.ClassDef)for m in n.body if isinstance(m,ast.FunctionDef)}
beforemethods=methods(old[T]);aftermethods=methods(testsource)
assert all(aftermethods[k]==v for k,v in beforemethods.items())
added=sorted(set(aftermethods)-set(beforemethods))
assert len(added)==2 and all(k[0]=='WorkspaceObservationTests'for k in added)
oldtree=ast.parse(old[P]);newtree=ast.parse(source)
skip={'workspace_observation_row','WorkspaceObservationGuard'}
for n in oldtree.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name not in skip:
  other=next(m for m in newtree.body if isinstance(m,type(n))and m.name==n.name)
  assert ast.dump(n,include_attributes=False)==ast.dump(other,include_attributes=False),n.name
assert not D.exists();os.umask(0o077);D.mkdir(mode=0o700)
(D/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
manifest={'schema':'cherri-workspace-rejection-reasons-proposal/1','source':'65eab52553e8f760d99fded448f0268e7cb77abd','nativeRun':45894063759,'status':'SOURCE_PROPOSAL_NOT_QUALIFIED','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'productionUIChanged':False,'nativeAssertionsChanged':False,'nativeExecuted':False,'originalPredicatesPreserved':31,'originalTestMethodsPreserved':len([k for k in beforemethods if k[1].startswith('test_')]),'addedTestMethods':[b for a,b in added],'reasonCodes':allow,'files':[]}
patch=''
for rel in [P,T]:
 for dirname,data in [('before',old[rel]),('files',new[rel])]:
  p=D/dirname/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 patch+=''.join(difflib.unified_diff(old[rel].splitlines(keepends=True),new[rel].splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 manifest['files'].append({'path':rel,'beforeSHA256':hashlib.sha256(old[rel].encode()).hexdigest(),'afterSHA256':hashlib.sha256(new[rel].encode()).hexdigest(),'bytes':len(new[rel].encode())})
(D/'source.original.patch').write_text(patch)
manifest['patchSHA256']=hashlib.sha256(patch.encode()).hexdigest()
(D/'manifest.original.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(D),'patchSHA256':manifest['patchSHA256'],'manifestSHA256':hashlib.sha256((D/'manifest.original.json').read_bytes()).hexdigest(),'files':manifest['files'],'predicates':31,'preservedTests':manifest['originalTestMethodsPreserved'],'newTests':manifest['addedTestMethods'],'status':manifest['status']}))
