import pathlib,hashlib,json,ast,os,datetime,importlib.util,traceback
U=pathlib.Path('/var/cache/cherri-ios-ui-repair-p-20261126')
P=U/'workspace-observation-rejection-proposal-01';D=U/'workspace-observation-rejection-controls-01';W=U/'source'
S='65eab52553e8f760d99fded448f0268e7cb77abd'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert sha(P/'manifest.original.json')=='66a902b68b2dbc284fb64d3b1a9caef38bd15afe71c8ebe15a66efdd7a8f7829'
M=json.loads((P/'manifest.original.json').read_text())
assert sha(P/'source.original.patch')==M['patchSHA256']=='78f796379e23192049de1ca8579f9b9250332509fdc23940f5c6e19fd00971e4'
Hpath=pathlib.Path('/mnt/development/projects/preserved/cherri-final-owner-20261126/exclusive-observer-source-01/owned_source_process.py')
assert sha(Hpath)=='4672474ddb270a5857914041ebb279f20431f87e9da173e6cd8bf83b3fb11c85'
spec=importlib.util.spec_from_file_location('rejection_owned',Hpath);H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)
assert not D.exists();os.umask(0o077);D.mkdir(mode=0o700);(D/'temp').mkdir()
(D/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
R={'schema':'cherri-workspace-rejection-controls/1','status':'FAILED','source':S,'startedUTC':now(),'inputs':[],'commands':[],'newNativeRun':False,'goExecuted':False,'acceptanceGranted':False,'originalNativeOutcomeReclassified':False,'originalPredicateCount':31,'originalTestMethodCount':97}
env=dict(os.environ,PATH='/usr/local/bin:/usr/bin:/bin',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',TMPDIR=str(D/'temp'),TMP=str(D/'temp'),TEMP=str(D/'temp'),PYTHONDONTWRITEBYTECODE='1')
try:
 with H.WholeBudget(120,cleanup_seconds=8,final_reserve=20)as budget:
  def command(name,argv,seconds=30):
   r=H.run_owned(argv,cwd='/',env=env,output=D,name=name,budget=budget,seconds=seconds);R['commands'].append(r);return r
  def git(name,args):
   r=command(name,['/usr/sbin/runuser','-u','ubuntu','--','/usr/bin/git','-C',str(W)]+args,10);H.require_success(r);return(D/(name+'.stdout.original')).read_bytes()
  assert git('head-before',['rev-parse','HEAD']).decode().strip()==S
  assert not git('status-before',['status','--porcelain=v1','--untracked-files=all'])
  for row in M['files']:
   for part,kind in [('before','beforeSHA256'),('files','afterSHA256')]:
    p=P/part/row['path'];assert sha(p)==row[kind];R['inputs'].append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
   assert sha(W/row['path'])==row['beforeSHA256']
  helpers=['documentation_evidence.py','joined_editor_evidence.py','preview_native_evidence.py','e07_pane_observations.py','ui_readiness_observations.py']
  for name in helpers:
   p=W/'ios/scripts'/name
   R['inputs'].append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
  tests=P/'files/ios/scripts/test_collect_ios_test_evidence.py'
  t=ast.parse(tests.read_text());cls=next(n for n in t.body if isinstance(n,ast.ClassDef)and n.name=='WorkspaceObservationTests')
  names=sorted(n.name for n in cls.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_'))
  assert len(names)==9
  selected='test_first_rejection_reason_is_retained_before_followup_block'
  red=D/'red/ios/scripts';red.mkdir(parents=True)
  (red/'collect_ios_test_evidence.py').write_bytes((P/'before/ios/scripts/collect_ios_test_evidence.py').read_bytes())
  (red/'test_collect_ios_test_evidence.py').write_bytes(tests.read_bytes())
  driver=r'''import pathlib,json,sys,unittest,importlib.util,hashlib
mode=sys.argv[1]
assert mode in ('RED','GREEN')
root=pathlib.Path(sys.argv[2]);selectedroot=pathlib.Path(sys.argv[3]);original=pathlib.Path(sys.argv[4])
sys.path[:0]=[str(selectedroot),str(original)]
path=selectedroot/'test_collect_ios_test_evidence.py'
spec=importlib.util.spec_from_file_location('workspace_rejection_controls',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
name='WorkspaceObservationTests.test_first_rejection_reason_is_retained_before_followup_block' if mode=='RED' else 'WorkspaceObservationTests'
suite=unittest.defaultTestLoader.loadTestsFromName(name,module)
def leaves(value):
 for item in value:
  if isinstance(item,unittest.TestSuite):yield from leaves(item)
  else:yield item.id()
planned=list(leaves(suite));events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  super().startTest(test);self.states={};self.states[test.id()]='UNKNOWN'
 def addSuccess(self,test):
  super().addSuccess(test);self.states[test.id()]='PASSED'
 def addFailure(self,test,err):
  super().addFailure(test,err);self.states[test.id()]='FAILED'
 def addError(self,test,err):
  super().addError(test,err);self.states[test.id()]='ERROR'
 def addSkip(self,test,reason):
  super().addSkip(test,reason);self.states[test.id()]='SKIPPED'
 def addSubTest(self,test,subtest,err):
  super().addSubTest(test,subtest,err)
  if err is not None:self.states[test.id()]='FAILED' if issubclass(err[0],test.failureException)else'ERROR'
 def stopTest(self,test):
  events.append({'testId':test.id(),'status':self.states[test.id()]});super().stopTest(test)
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
summary={'schema':'cherri-workspace-rejection-actual-controls/1','mode':mode,'plannedIds':planned,'events':events,'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'successful':result.wasSuccessful(),'collectorSHA256':hashlib.sha256((selectedroot/'collect_ios_test_evidence.py').read_bytes()).hexdigest(),'testsSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'nativeExecuted':False}
with(root/(mode.lower()+'.result.original.json')).open('x')as f:f.write(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:summary[k]for k in ['mode','testsRun','failures','errors','skipped','successful']}))
sys.exit(0 if result.wasSuccessful()else 1)
'''
  driverpath=D/'driver.original.py';driverpath.write_text(driver)
  R['driverSHA256']=sha(driverpath)
  for mode,where in [('RED',red),('GREEN',P/'files/ios/scripts')]:
   process=command(mode.lower(),['/usr/bin/python3','-I','-B',str(driverpath),mode,str(D),str(where),str(W/'ios/scripts')],30)
   assert not process['timedOut']and not process['cancelled']and not process['wholeDeadlineExceeded']
   assert process['cleanup']['parentReaped']and process['cleanup']['after']['state']=='ABSENT'
   value=json.loads((D/(mode.lower()+'.result.original.json')).read_text())
   assert value['testsSHA256']=='48ece1f4052d29fc6783061fc67d56c4be8d84b94a0d542d2745717a2b5ee432'
   if mode=='RED':
    assert process['exitCode']==1 and value['testsRun']==1 and value['failures']==1 and value['errors']==0 and value['skipped']==0 and not value['successful']
    assert value['collectorSHA256']=='70936b4b4c0ba0450d6dc7cc95fd9392a139ec1c63211f26415cdb4d9e8b8366'
    assert value['events']==[{'testId':'workspace_rejection_controls.WorkspaceObservationTests.'+selected,'status':'FAILED'}]
   else:
    H.require_success(process)
    assert value['testsRun']==9 and value['failures']==value['errors']==value['skipped']==0 and value['successful']
    assert value['collectorSHA256']=='b267a838bafb88c6432180b9911673369da3323e5fd2ab2bb99849643b86cc24'
    assert value['events']==[{'testId':'workspace_rejection_controls.WorkspaceObservationTests.'+n,'status':'PASSED'}for n in names]
   R[mode.lower()]={'path':str(D/(mode.lower()+'.result.original.json')),'sha256':sha(D/(mode.lower()+'.result.original.json')),'testsRun':value['testsRun'],'events':value['events']}
  assert git('head-after',['rev-parse','HEAD']).decode().strip()==S
  assert not git('status-after',['status','--porcelain=v1','--untracked-files=all'])
  for item in R['inputs']:assert sha(pathlib.Path(item['path']))==item['sha256']
  R['status']='ACTUAL_CAUSAL_RED_AND_NINE_GREEN'
except BaseException as error:
 R['errorType']=type(error).__name__;R['error']=str(error);(D/'failure.original.txt').write_text(traceback.format_exc())
finally:
 R['finishedUTC']=now();(D/'result.original.json').write_text(json.dumps(R,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(D/'result.original.json'),'sha256':sha(D/'result.original.json'),'status':R['status'],'red':R.get('red'),'green':R.get('green'),'error':R.get('error')}))
if R['status']!='ACTUAL_CAUSAL_RED_AND_NINE_GREEN':raise SystemExit(1)
