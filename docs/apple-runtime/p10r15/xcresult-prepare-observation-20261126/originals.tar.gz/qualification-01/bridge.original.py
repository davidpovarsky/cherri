import json
from pathlib import Path
import sys
import unittest

source, selected, report = sys.argv[1:]
sys.path.insert(0, source)
identities = json.loads(selected)

class Observed(unittest.TextTestResult):
    def startTest(self, test):
        started.append(test.id())
        super().startTest(test)

    def addSuccess(self, test):
        passed.append(test.id())
        super().addSuccess(test)

started, passed = [], []
suite = unittest.TestLoader().loadTestsFromNames(identities)
result = unittest.TextTestRunner(verbosity=2, resultclass=Observed).run(suite)
Path(report).write_text(json.dumps({
    'started': started, 'passed': passed,
    'failed': [test.id() for test, _ in result.failures],
    'errors': [test.id() for test, _ in result.errors],
    'skipped': [test.id() for test, _ in result.skipped],
    'testsRun': result.testsRun,
}, sort_keys=True, indent=2) + '\n')
raise SystemExit(0 if result.wasSuccessful() else 1)
