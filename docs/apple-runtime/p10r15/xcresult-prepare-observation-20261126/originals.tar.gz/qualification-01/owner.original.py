import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
name = sys.argv[1]
selection = json.loads((root / 'selection.original.json').read_text())
case = next(x for x in selection['cases'] if x['name'] == name)
output = root / name / 'run'
output.mkdir(mode=0o700)
source = root / name / 'source'

def pins():
    paths = [root / 'selection.original.json', root / 'bridge.original.py', Path(__file__).resolve()]
    paths.extend(source / x for x in ('collect_ios_xcresult_summary.py',
                                     'verify_ios_xcresult_summary.py',
                                     'test_ios_xcresult_summary.py'))
    return {str(p.relative_to(root)): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                                     'bytes': p.stat().st_size} for p in paths}

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')

before = pins()
save(output / 'source-before.original.json', before)
argv = [sys.executable, '-I', '-B', str(root / 'bridge.original.py'), str(source),
        json.dumps(case['ids'], separators=(',', ':')), str(output / 'events.original.json')]
save(output / 'command.original.json', {'argv': argv, 'timeoutSeconds': 30,
                                     'platform': platform.platform(), 'python': sys.version})
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
save(output / 'process-started.original.json', {'pid': process.pid, 'pgid': process.pid,
                                               'startedAt': started})
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=30)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(process.pid, signal.SIGKILL)
    stdout, stderr = process.communicate(timeout=2)
group = 'UNOBSERVABLE'
try:
    os.killpg(process.pid, 0)
    group = 'PRESENT'
except ProcessLookupError:
    group = 'ABSENT'
except PermissionError:
    group = 'PERMISSION_DENIED'
if group == 'PRESENT':
    os.killpg(process.pid, signal.SIGKILL)
with (output / 'stdout.original').open('xb') as stream:
    stream.write(stdout)
with (output / 'stderr.original').open('xb') as stream:
    stream.write(stderr)
after = pins()
save(output / 'source-after.original.json', after)
events_path = output / 'events.original.json'
events = json.loads(events_path.read_text()) if events_path.exists() else None
expected = case['expected']
matches = events is not None and events['testsRun'] == expected['run'] and \
    len(events['failed']) == expected['failed'] and len(events['errors']) == expected['errors'] and \
    len(events['passed']) == expected['passed'] and not events['skipped'] and \
    events['started'] == case['ids']
value = {'schema': 'cherri-xcresult-prepare-focused-controls/1', 'case': name,
         'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'elapsedMs': round((time.monotonic() - clock) * 1000), 'pid': process.pid,
         'returnCode': process.returncode, 'parentReaped': process.poll() is not None,
         'groupAfter': group, 'timedOut': timed_out, 'sourceUnchanged': before == after,
         'stdout': {'bytes': len(stdout), 'sha256': hashlib.sha256(stdout).hexdigest()},
         'stderr': {'bytes': len(stderr), 'sha256': hashlib.sha256(stderr).hexdigest()},
         'events': events, 'expected': expected, 'expectedOutcomeMatched': matches,
         'nativeExecuted': False}
save(output / 'result.original.json', value)
print(json.dumps(value, sort_keys=True))
raise SystemExit(0 if matches and before == after and not timed_out and group == 'ABSENT' else 1)
