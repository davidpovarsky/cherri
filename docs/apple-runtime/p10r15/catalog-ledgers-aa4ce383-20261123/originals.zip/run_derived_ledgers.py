"""Execute the unchanged derived-ledger generator from a frozen clean ancestor."""
import argparse
import hashlib
import importlib.util
import json
import os
import pathlib
import signal
import subprocess
import sys
import time

BASE = pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-505-refresh-20261123")
HELPER = BASE / "run_catalog_producers.py"
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != "ce809d9839a74657d6cbf6fb685a65aef0c86e743642e1eeed31acca03143bb4":
    raise RuntimeError("Original source-bound helper changed")
spec = importlib.util.spec_from_file_location("catalog_execution_helpers", HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)

NAMES = [
    "p10-505-catalog-coverage-matrix.json",
    "p10-pack-15-go-only-audit.json",
    "p10-apple-cherri-crosswalk.json",
    "catalog-supported-by-compiler.md",
    "apple-discovered-not-supported.md",
    "pure-pack-portability.md",
    "baseline-state.json",
]
PREFIX = "docs/apple-runtime/p10/"
RAW_HASHES = {
    "p10-505-execution-evidence.json": "6a99ea3f0e541b4dca416f6cfdef775a7492eef118ddc33f9cc5632398d4aeb8",
    "p10-505-parameter-contract-evidence.json": "74c5ed6ffb65594937aefcf248cef7f1d5ed47388fc57352c148f478e14f8eb5",
}

def manifest(repo, names):
    return [{"path": PREFIX + n, "bytes": (repo/PREFIX/n).stat().st_size,
             "sha256": h.digest((repo/PREFIX/n).read_bytes())} for n in sorted(names)]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    repo = pathlib.Path(args.repo).resolve(strict=True)
    out = pathlib.Path(args.output).absolute()
    if len(args.expected_source) != 40 or any(c not in "0123456789abcdef" for c in args.expected_source):
        raise RuntimeError("Exact frozen source required")
    if out.exists() or out.is_relative_to(repo) or out.parent.resolve().is_relative_to(repo):
        raise RuntimeError("New physical external output required")
    before = h.source(repo)
    if before["head"] != args.expected_source or before["status"]:
        raise RuntimeError("Source is not the frozen clean ancestor")
    h.capture(["git","merge-base","--is-ancestor","2a6065b1c7fbe7bd4aaaed8bc4aaa8bef165c529",args.expected_source],repo)
    for name, expected in RAW_HASHES.items():
        if h.digest((repo/PREFIX/name).read_bytes()) != expected:
            raise RuntimeError("Fresh raw evidence is missing: " + name)
    out.mkdir(mode=0o700)
    (out/"derived").mkdir(mode=0o700)
    witness_before = h.dependency_witness(repo)
    before_files = manifest(repo,NAMES)
    h.original(out/"source-before.original.json",before)
    h.original(out/"input-witness-before.original.json",witness_before)
    h.original(out/"derived-before.original.json",before_files)
    keep=("PATH","HOME","USER","LOGNAME","LANG","LC_ALL","LC_CTYPE","TZ")
    env={k:os.environ[k] for k in keep if k in os.environ}
    env.update(h.GO_SELECTION)
    env["PYTHONDONTWRITEBYTECODE"]="1"
    goenv=h.capture(["go","env","-json","GOVERSION","GOOS","GOARCH","GOROOT","GOTOOLCHAIN","GOMODCACHE","GOCACHE","GOTMPDIR"],repo,env,timeout=60)
    h.original(out/"go-env.original.json",goenv)
    if json.loads(goenv)["GOVERSION"]!="go1.24.13":
        raise RuntimeError("Incorrect selected Go")
    argv=[sys.executable,"-B","tools/p10r3/generate_catalog_and_pack_ledgers.py"]
    intent={
        "source":before,"argv":argv,"selected_environment":h.GO_SELECTION,
        "driver_sha256":h.digest(pathlib.Path(__file__).read_bytes()),
        "shared_helper_sha256":h.digest(HELPER.read_bytes()),
        "generator_sha256":h.digest((repo/"tools/p10r3/generate_catalog_and_pack_ledgers.py").read_bytes()),
        "allowed_outputs":[PREFIX+n for n in NAMES],"original_raw_sha256":RAW_HASHES,
        "wall_limit_seconds":600,
        "scope":"Actual derived generation; raw producers and release gates are not rerun.",
    }
    h.original(out/"intent.original.json",intent)
    started_utc, started=h.utc(),time.monotonic()
    timed_out=False
    with (out/"stdout.original").open("xb") as stdout,(out/"stderr.original").open("xb") as stderr:
        process=subprocess.Popen(argv,cwd=repo,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        h.original(out/"process-start.original.json",{"pid":process.pid,"started_utc":started_utc})
        try:
            code=process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=5)
    finished_utc,elapsed=h.utc(),time.monotonic()-started
    after=h.source(repo)
    witness_after=h.dependency_witness(repo)
    changed=h.capture(["git","diff","--name-only"],repo).decode().splitlines()
    untracked=h.capture(["git","ls-files","--others","--exclude-standard"],repo).decode().splitlines()
    h.original(out/"source-after.original.json",after)
    h.original(out/"input-witness-after.original.json",witness_after)
    after_files=manifest(repo,NAMES)
    h.original(out/"derived-after.original.json",after_files)
    checks=[]
    def check(name,condition):checks.append({"check":name,"pass":bool(condition)})
    check("actual generator exit zero",code==0 and not timed_out)
    check("same HEAD tree branch",all(before[k]==after[k] for k in ("head","tree","branch")))
    check("only declared derived outputs changed",set(changed)<=set(PREFIX+n for n in NAMES) and not untracked)
    check("all dependency bytes unchanged",witness_before==witness_after)
    check("fresh raw evidence unchanged",all(h.digest((repo/PREFIX/n).read_bytes())==d for n,d in RAW_HASHES.items()))
    fp=witness_before["fingerprint"]
    derived={n:json.loads((repo/PREFIX/n).read_bytes()) for n in NAMES if n.endswith(".json")}
    for name in ["p10-505-catalog-coverage-matrix.json","p10-apple-cherri-crosswalk.json","baseline-state.json"]:
        obj=derived[name]
        check(name+" exact source",obj["sourceCommit"]==args.expected_source)
        check(name+" current dependency fingerprint",obj["inputDependencyFingerprint"]==fp)
    for name in [n for n in NAMES if n.endswith(".md")]:
        raw=(repo/PREFIX/name).read_text()
        check(name+" source and fingerprint",args.expected_source in raw and fp in raw)
    matrix=derived["p10-505-catalog-coverage-matrix.json"]
    raw=json.loads((repo/PREFIX/"p10-505-execution-evidence.json").read_bytes())
    check("505 distinct catalog entries",matrix["totalCatalogEntries"]==505 and len(matrix["entries"])==505 and len({e["cherriName"] for e in matrix["entries"]})==505)
    summary=matrix["summary"]
    check("505 same callable/construct scope",summary["totalEntries"]==505 and summary["callableActions"]==497 and summary["compilerConstructs"]==8)
    counters={"legacySupportedCount":"legacyPassCount","v2SupportedCount":"v2PassCount","plistIdentifierVerifiedCount":"plistIdentifierPassCount",
        "parameterContractVerifiedCount":"parameterContractPassCount","decompileSupportedCount":"decompilePassCount",
        "roundTripVerifiedCount":"roundTripPassCount","structuralRoundTripVerifiedCount":"structuralRoundTripCount"}
    check("measured local counters preserved",all(summary[k]==raw[v]==505 for k,v in counters.items()))
    check("six measured dimensions preserved",summary["parameterDimensionSummaries"]==raw["parameterDimensionSummaries"])
    check("native and runtime remain zero",summary["nativeSpecimenParityCount"]==summary["appleRuntimeExecutedCount"]==0 and summary["blockedDeviceCount"]==summary["needsEvidenceCount"]==505)
    cross=derived["p10-apple-cherri-crosswalk.json"]
    baseline=derived["baseline-state.json"]
    check("crosswalk and baseline denominators agree",cross["denominators"]==baseline["counts"] and cross["denominators"]["cherriCatalogTotalEntries"]==505)
    check("existing 15-action pack inventory preserved",derived["p10-pack-15-go-only-audit.json"]["summary"]["totalGoOnlyEvaluated"]==15)
    for name in NAMES:
        h.original(out/"derived"/name,(repo/PREFIX/name).read_bytes())
    receipt={
        "source":before,"source_after":after,"argv":argv,"started_utc":started_utc,"finished_utc":finished_utc,
        "elapsed_seconds":elapsed,"exit_code":code,"timed_out":timed_out,"input_fingerprint_before":fp,
        "input_fingerprint_after":witness_after["fingerprint"],"changed_paths":changed,
        "outputs":after_files,"checks":checks,"generation_valid":all(c["pass"] for c in checks),
        "raw_evidence_provenance":{"execution_source":"11f3c80ca261dd59f198cb3693f893c22e6c340f",
            "parameter_source":"9ce44842761ec4bb639e1f2c80c08d86c022b778","raw_sha256":RAW_HASHES},
        "release_gate_execution":False,"native_or_device_credit":False,
    }
    h.original(out/"process.original.json",receipt)
    h.original(out/"originals-manifest.json",{"files":[{"path":p.relative_to(out).as_posix(),"bytes":p.stat().st_size,"sha256":h.digest(p.read_bytes())} for p in sorted(out.rglob("*")) if p.is_file()]})
    print(json.dumps(receipt),flush=True)
    return 0 if receipt["generation_valid"] else 1

if __name__=="__main__":
    raise SystemExit(main())
