import json,os,signal,sys,time,unittest,shutil
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(sys.argv[1]);out=Path(sys.argv[2])
sys.path.insert(0,str(root/"tools/shortcuts-simulator-qa"))
names=["test_listapps_git_batch.ListAppsGitBatchTests.test_actual_listapps_source_uses_one_git_and_retains_both_head_observations","test_listapps_git_batch.ListAppsGitBatchTests.test_original_ten_second_stream_archive_and_per_file_limits_are_preserved","test_listapps_git_batch.ListAppsGitBatchTests.test_actual_regular_git_modes_and_physical_uid_identity_are_retained","test_listapps_git_batch.ListAppsGitBatchTests.test_export_attributes_cannot_substitute_or_omit_raw_selected_bytes","test_listapps_git_batch.ListAppsGitBatchTests.test_git_symlink_and_submodule_modes_reject_even_when_physical_file_is_regular","test_listapps_git_batch.ListAppsGitBatchTests.test_missing_git_entry_cannot_be_satisfied_by_an_untracked_physical_file","test_listapps_git_batch.ListAppsGitBatchTests.test_physical_mutation_is_retained_with_expected_and_actual_blob_then_blocks_native","test_listapps_git_batch.ListAppsGitBatchTests.test_same_invocation_physical_mutation_after_first_read_is_rejected","test_listapps_git_batch.ListAppsGitBatchTests.test_same_invocation_head_change_is_observed_only_after_closing_physical_reads","test_listapps_git_batch.ListAppsGitBatchTests.test_same_invocation_physical_mode_change_is_rejected","test_listapps_git_batch.ListAppsGitBatchTests.test_existing_ancestor_symlink_and_file_limits_remain_fail_closed","test_listapps_git_batch.ListAppsGitBatchTests.test_redirects_are_rejected_before_any_git_process","test_listapps_git_batch.ListAppsGitBatchTests.test_failed_spawn_retains_original_failure_without_fabricated_pid_or_journal","test_listapps_git_batch.ListAppsGitBatchTests.test_cancellation_after_actual_spawn_keeps_owned_cleanup_and_original_journals","test_listapps_git_batch.ListAppsGitBatchTests.test_started_journal_failure_still_retains_and_cleans_the_actual_child","test_listapps_git_batch.ListAppsGitBatchTests.test_expired_source_budget_cannot_start_git_or_native","test_listapps_git_batch.ListAppsGitBatchTests.test_descriptor_reads_reject_replaced_or_symlinked_ancestors","test_listapps_git_batch.ListAppsGitBatchTests.test_cancellation_at_directory_or_file_open_closes_owned_handles","test_git_source_batch.TerminalSourceBatchTests.test_launch_failure_retains_no_fabricated_pid","test_git_source_batch.TerminalSourceBatchTests.test_actual_deadline_includes_all_object_requests","test_git_source_batch.TerminalSourceBatchTests.test_cancellation_during_popen_registration_retains_owned_pid","test_git_source_batch.TerminalSourceBatchTests.test_unknown_group_cannot_authenticate_zero_exit","test_git_source_batch.TerminalSourceBatchTests.test_original_receipts_are_create_only","test_git_source_batch.TerminalSourceBatchTests.test_metadata_and_cleanup_errors_preserve_first_outcome_without_pid","test_git_source_batch.TerminalSourceBatchTests.test_launch_and_cleanup_errors_preserve_first_outcome_without_pid","test_git_source_batch.TerminalSourceBatchTests.test_cleanup_error_after_zero_exit_retains_transcript_without_authentication","test_git_source_batch.TerminalSourceBatchTests.test_unstarted_cleanup_does_not_import_process_observer","test_project_prerequisite_observation.ObservationTests.test_same_byte_replacement_during_read_is_rejected","test_project_prerequisite_observation.ObservationTests.test_real_alias_after_physical_read_is_rejected","test_project_prerequisite_observation.ObservationTests.test_source_binding_uses_actual_git_objects_and_rejects_mutation","test_simulator_listapps_observation.ListAppsTests.test_source_change_after_listapps_blocks_exact_output","test_simulator_listapps_observation.ListAppsTests.test_late_zero_exit_cannot_claim_ready","test_simulator_listapps_observation.ListAppsTests.test_phase_budget_prevents_new_child_after_deadline"]
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
def flatten(node):
 if isinstance(node,unittest.TestSuite):
  for child in node:yield from flatten(child)
 else:yield node.id()
assert list(flatten(suite))==names, list(flatten(suite))
(out/"selection.original.json").write_text(json.dumps(names,indent=2)+"\n")
# Preserve existing synthetic private Git transcripts just before their
# original fixture cleanup, after the test's existing owned-child reaping.
import test_git_source_batch as terminal_tests
old_setup=terminal_tests.TerminalSourceBatchTests.setUp
def retained_setup(self):
 old_setup(self)
 cleanup=self.temporary.cleanup
 def retained_cleanup():
  destination=out/"products"/("terminal-"+self._testMethodName)
  if self.originals.is_dir() and not destination.exists():
   shutil.copytree(self.originals,destination)
  cleanup()
 self.temporary.cleanup=retained_cleanup
terminal_tests.TerminalSourceBatchTests.setUp=retained_setup
events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  events.append({"id":test.id(),"event":"start","at":time.monotonic()});super().startTest(test)
 def addSuccess(self,test):
  events.append({"id":test.id(),"event":"pass"});super().addSuccess(test)
 def addFailure(self,test,error):
  events.append({"id":test.id(),"event":"fail","exception":str(error[1])});super().addFailure(test,error)
 def addError(self,test,error):
  events.append({"id":test.id(),"event":"error","exception":str(error[1])});super().addError(test,error)
 def addSkip(self,test,reason):
  events.append({"id":test.id(),"event":"skip","reason":reason});super().addSkip(test,reason)
 def addSubTest(self,test,subtest,error):
  events.append({"id":subtest.id(),"parent":test.id(),"event":"subtest-pass" if error is None else "subtest-fail","exception":None if error is None else str(error[1])})
  super().addSubTest(test,subtest,error)
def expired(signum,frame):raise TimeoutError("Focused source verification owner deadline")
signal.signal(signal.SIGALRM,expired);signal.alarm(90)
started=time.monotonic()
try:result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
finally:
 signal.alarm(0);(out/"events.original.json").write_text(json.dumps(events,sort_keys=True,indent=2)+"\n")
value={"testsRun":result.testsRun,"failed":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),"elapsedMs":round((time.monotonic()-started)*1000),"nativeExecution":False,"events":events}
(out/"tests.original.json").write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
sys.exit(0 if result.wasSuccessful() else 1)
