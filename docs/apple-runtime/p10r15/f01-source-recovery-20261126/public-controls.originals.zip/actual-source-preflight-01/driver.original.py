import hashlib,json,signal,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
repo=Path(sys.argv[1]);out=Path(sys.argv[2]);expected=sys.argv[3]
sys.path.insert(0,str(repo/"tools/shortcuts-simulator-qa"))
import git_source_batch as batch
import project_prerequisite_observation as observation
def expired(signum,frame):raise TimeoutError("Actual source-only owner deadline")
signal.signal(signal.SIGALRM,expired);signal.alarm(25)
started=time.monotonic()
originals=out/"originals";originals.mkdir(mode=0o700)
value=batch.verify_raw_sources(repo,expected,observation.QA_SOURCE_FILES,
 deadline=started+10,failure_cleanup_deadline=started+90,
 originals=originals,tree_inventory=True,
 file_limits={p:observation.source_limit(p,qa=True) for p in observation.QA_SOURCE_FILES},
 stdout_limit=1024*1024)
signal.alarm(0)
requests=(originals/"stdin.original").read_bytes().splitlines()
assert value["status"]=="SOURCE_VERIFIED"
assert len(value["sourceFiles"])==len(observation.QA_SOURCE_FILES)==62
assert requests[0]==requests[-1]==b"HEAD" and requests.count(b"HEAD")==2
assert value["headBefore"]==value["headAfter"]==expected
assert value["process"]["parentReaped"] and value["process"]["groupAfterCleanup"]["state"]=="ABSENT"
assert value["elapsedMs"]<10000
print(json.dumps({"source":expected,"status":value["status"],"files":62,"treeObjectCount":value["treeObjectCount"],"elapsedMs":value["elapsedMs"],"nativeExecution":False,"formalAcceptanceGranted":False}))
