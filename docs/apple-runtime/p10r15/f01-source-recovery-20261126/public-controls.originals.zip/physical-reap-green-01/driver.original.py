import hashlib,json,os,signal,sys,time,unittest
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(sys.argv[1]);out=Path(sys.argv[2])
sys.path.insert(0,str(root/"tools/shortcuts-simulator-qa"))
import test_listapps_git_batch as target
names=[
 "test_source_reads_reuse_directory_handles_with_fresh_file_checks",
 "test_failed_source_deadline_reaps_own_parent_without_authentication",
]
events=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  events.append({"id":test.id(),"event":"start","at":time.monotonic()})
  super().startTest(test)
 def addSuccess(self,test):
  events.append({"id":test.id(),"event":"pass"});super().addSuccess(test)
 def addFailure(self,test,error):
  events.append({"id":test.id(),"event":"fail","exception":str(error[1])});super().addFailure(test,error)
 def addError(self,test,error):
  events.append({"id":test.id(),"event":"error","exception":str(error[1])});super().addError(test,error)
 def addSkip(self,test,reason):
  events.append({"id":test.id(),"event":"skip","reason":reason});super().addSkip(test,reason)
def expired(signum,frame):raise TimeoutError("Original diagnostic test owner deadline")
signal.signal(signal.SIGALRM,expired);signal.alarm(60)
started=time.monotonic()
try:
 result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(unittest.TestSuite(target.ListAppsGitBatchTests(n) for n in names))
finally:
 signal.alarm(0)
 (out/"events.original.json").write_text(json.dumps(events,sort_keys=True,indent=2)+"\n")
value={"testsRun":result.testsRun,"failed":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),"elapsedMs":round((time.monotonic()-started)*1000),"nativeExecution":False,"events":events}
(out/"tests.original.json").write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
sys.exit(0 if result.wasSuccessful() else 1)
