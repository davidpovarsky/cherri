"""Independent intake of focused corrected-observer execution and unchanged parameter evidence."""
import collections
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path("/mnt/development/projects/evidence/cherri-p10r15-505-refresh-20261123")
OUT = ROOT / "observer-11f3c80ca261"
PARAMETER_ORIGINALS = ROOT / "producer-9ce44842761e"
REPO = pathlib.Path("/mnt/development/projects/worktrees/cherri-p10r15-505-refresh-20261123")
SOURCE = "11f3c80ca261dd59f198cb3693f893c22e6c340f"
DRIVER_SHA256 = "c67b51a24bae7909257366c75a6f542f36613d7e46e779f1eeef564c29aa6639"
NAMES = ["p10-505-execution-evidence.json", "p10-505-parameter-contract-evidence.json"]
TESTS = ["TestP10_VerifyAndRecord505CatalogExecution", "TestP10_CatalogRawActionIdentifierRequiresFixtureTarget"]
EXPECTED_EVENTS = TESTS + [
    "TestP10_CatalogRawActionIdentifierRequiresFixtureTarget/" + alias + "/" + case
    for alias in ("raw", "rawaction")
    for case in ("target_alone", "target_then_normalization", "wrong_target",
                 "wrong_target_then_normalization", "normalization_only",
                 "missing_target", "catalog_placeholder_only")
]
DIMENSIONS = ["requiredParams", "missingRequiredRejected", "optionalParams",
              "enumValidation", "dynamicReference", "platformGate"]
checks = []
def check(label, condition):
    checks.append({"check": label, "pass": bool(condition)})
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def read(name):
    return json.loads((OUT / name).read_bytes())
def git(*args):
    return subprocess.run(["git","-C",str(REPO),*args],text=True,capture_output=True,check=True).stdout.strip()

manifest = read("originals-manifest.json")
for row in manifest["files"]:
    path = OUT / row["path"]
    check("manifest path within originals: " + row["path"], path.resolve().is_relative_to(OUT.resolve()))
    raw = path.read_bytes()
    check("original bytes match manifest: " + row["path"], len(raw)==row["bytes"] and sha(raw)==row["sha256"])
before, after = read("source-before.original.json"), read("source-after.original.json")
process, intent = read("process.original.json"), read("intent.original.json")
input_before, input_after = read("input-witness-before.original.json"), read("input-witness-after.original.json")
check("clean exact corrected-observer source before and after", before==after and before["head"]==SOURCE and before["status"]=="")
check("still at clean corrected-observer source during independent intake", git("rev-parse","HEAD")==SOURCE and git("status","--porcelain=v1","--untracked-files=all")=="")
check("identical source dependency witnesses", input_before==input_after)
check("execution wrapper succeeded", process["execution_valid"] and process["exit_code"]==0 and not process["timed_out"])
check("frozen driver bytes", sha((ROOT/"run_catalog_observer_checks.py").read_bytes())==DRIVER_SHA256==intent["driver_sha256"])
check("Go 1.24.13 selected", read("go-env.original.json")["GOVERSION"]=="go1.24.13")
events=[json.loads(line) for line in (OUT/"stdout.original.jsonl").read_bytes().splitlines() if line.strip()]
runs=[e["Test"] for e in events if e.get("Test") and e.get("Action")=="run"]
passes=[e["Test"] for e in events if e.get("Test") and e.get("Action")=="pass"]
check("two exact parent tests plus 14 controls ran once and passed", sorted(runs)==sorted(EXPECTED_EVENTS) and sorted(passes)==sorted(EXPECTED_EVENTS))
check("no failing or skipped Go events", not any(e.get("Action") in ("fail","skip") for e in events))
check("one package pass", sum(e.get("Action")=="pass" and not e.get("Test") for e in events)==1)
check("only affected execution artifact was produced", sorted(p.name for p in (OUT/"artifacts").iterdir())==[NAMES[0]])
raws={NAMES[0]:(OUT/"artifacts"/NAMES[0]).read_bytes(),
      NAMES[1]:(PARAMETER_ORIGINALS/"artifacts"/NAMES[1]).read_bytes()}
check("parameter evidence bytes retain exact C0 identity", sha(raws[NAMES[1]])=="74c5ed6ffb65594937aefcf248cef7f1d5ed47388fc57352c148f478e14f8eb5" and raws[NAMES[1]]==(REPO/"docs/apple-runtime/p10"/NAMES[1]).read_bytes())
parameter_process=json.loads((PARAMETER_ORIGINALS/"process.original.json").read_bytes())
check("parameter original successful source remains C0", parameter_process["source"]["head"]=="9ce44842761ec4bb639e1f2c80c08d86c022b778" and parameter_process["execution_valid"] and "TestP10_ParameterContractMatrix_AllCatalogActions" in parameter_process["passed"])
reuse=json.loads((ROOT/"observer-source-equivalence.original.json").read_bytes())
check("source equivalence witness matches corrected source", reuse["sourceCommit"]==SOURCE and reuse["changedSourcePathsSinceC0"]==["p10_catalog_execution_test.go","p10_catalog_identifier_observer_test.go"] and reuse["existingProducerBodiesUnchanged"])
check("parameter producer whole file unchanged", sha((REPO/reuse["parameterProducerWholeFile"]["path"]).read_bytes())==reuse["parameterProducerWholeFile"]["sha256"] and reuse["parameterProducerWholeFile"]["unchangedFromC0"])
execution, params=[json.loads(raws[n]) for n in NAMES]
entries=execution["entries"]; contracts=params["entries"]
check("catalog 505 / callable 497 / constructs 8", execution["totalCatalogEntries"]==505 and execution["callableCount"]==497 and execution["constructCount"]==8 and len(entries)==505)
check("parameter catalog 505 / callable 497 / constructs 8", params["totalCatalog"]==505 and params["callableCount"]==497 and params["constructCount"]==8 and len(contracts)==505)
check("parameter schema 2.0.0", params["schemaVersion"]=="2.0.0")
check("all parameter contracts passed", params["allContractsPassed"] is True and params["passedCount"]==505 and params["failedCount"]==0 and all(e["contractPassed"] is True for e in contracts))
ex_by={e["name"]:e for e in entries}; con_by={e["actionName"]:e for e in contracts}
check("505 unique shared action names", len(ex_by)==505 and len(con_by)==505 and set(ex_by)==set(con_by))
check("identical per-action identifier and construct identity", all(ex_by[n]["shortcutIdentifier"]==con_by[n]["shortcutIdentifier"] and ex_by[n]["compilerConstruct"]==con_by[n]["compilerConstruct"] for n in ex_by))
check("exactly 8 construct records", sum(e["compilerConstruct"] is True for e in entries)==8 and sum(e["compilerConstruct"] is True for e in contracts)==8)
COUNTERS={
    "legacyPassCount":"legacySupported","v2PassCount":"v2Supported",
    "plistIdentifierPassCount":"plistIdentifierVerified","parameterContractPassCount":"parameterContractVerified",
    "decompilePassCount":"decompileSupported","roundTripPassCount":"roundTripVerified",
    "structuralRoundTripCount":"structuralRoundTripPass"}
for count, flag in COUNTERS.items():
    check(count+" equals all 505 actual flags", execution[count]==505==sum(e.get(flag) is True for e in entries))
check("505 full workflow semantic comparisons", all(e["comparisonModeUsed"]=="FULL_WORKFLOW_SEMANTIC_COMPARISON" for e in entries))
check("no native specimen credit", execution["nativeSpecimenParityCount"]==0 and all(e["nativeSpecimenParityStatus"]=="NEEDS_EVIDENCE" for e in entries))
check("no Apple runtime credit", execution["appleRuntimeExecutedCount"]==0 and all(e["appleRuntimeExecutedStatus"]=="BLOCKED_DEVICE" for e in entries))
check("six identical dimension summaries", execution["parameterDimensionSummaries"]==params["dimensionSummaries"] and len(params["dimensionSummaries"])==6)
summaries={d["dimension"]:d for d in params["dimensionSummaries"]}
check("exact six dimensions", set(summaries)==set(DIMENSIONS))
counts={}
for dim in DIMENSIONS:
    summary=summaries[dim]; counted=collections.Counter(e[dim]["status"] for e in contracts)
    counts[dim]=dict(counted)
    check(dim+" has only PASS or NOT_APPLICABLE", set(counted)<={"PASS","NOT_APPLICABLE"})
    check(dim+" summary matches 505 records", summary["totalCatalog"]==505 and summary["constructsExcluded"]==8
        and summary["eligible"]==summary["tested"]==summary["pass"]==counted["PASS"]
        and summary["notApplicable"]==counted["NOT_APPLICABLE"]
        and summary["fail"]==summary["notTested"]==summary["blocked"]==0
        and counted["PASS"]+counted["NOT_APPLICABLE"]==505)
raw_action=ex_by["rawAction"]
check("rawAction exact Legacy and V2 custom fixture identity", raw_action["legacyEmittedIdent"]==raw_action["v2EmittedIdent"]=="is.workflow.actions.custom.p10test")
deltas=[]
for name in NAMES:
    baseline=(REPO/"docs/apple-runtime/p10"/name).read_bytes()
    prior=json.loads(baseline); fresh=json.loads(raws[name])
    changed_top=[key for key in sorted(set(prior)|set(fresh)) if key!="entries" and prior.get(key)!=fresh.get(key)]
    key="name" if name==NAMES[0] else "actionName"
    prior_by={e[key]:e for e in prior["entries"]}; fresh_by={e[key]:e for e in fresh["entries"]}
    changed_records=[{"name":n,"changed_fields":[f for f in sorted(set(prior_by.get(n,{}))|set(fresh_by.get(n,{}))) if prior_by.get(n,{}).get(f)!=fresh_by.get(n,{}).get(f)]} for n in sorted(set(prior_by)|set(fresh_by)) if prior_by.get(n)!=fresh_by.get(n)]
    deltas.append({"path":"docs/apple-runtime/p10/"+name,"baseline_sha256":sha(baseline),"fresh_sha256":sha(raws[name]),"baseline_bytes":len(baseline),"fresh_bytes":len(raws[name]),"byte_identical":baseline==raws[name],"json_equivalent":prior==fresh,"changed_top_level_fields":changed_top,"changed_action_records":changed_records})
check("only execution rawAction V2 identity changed", len(deltas[0]["changed_action_records"])==1 and deltas[0]["changed_action_records"][0]=={"name":"rawAction","changed_fields":["v2EmittedIdent"]} and not deltas[0]["changed_top_level_fields"])
check("parameter evidence JSON and bytes unchanged", deltas[1]["byte_identical"] and deltas[1]["json_equivalent"])
check("allowed comparison exclusions unchanged", execution["allowedExclusions"]==json.loads((REPO/"docs/apple-runtime/p10"/NAMES[0]).read_bytes())["allowedExclusions"])
report={
    "schema":"cherri-p10-505-observer-independent-intake/v1","sourceCommit":SOURCE,"sourceTree":before["tree"],
    "producerDriverSha256":DRIVER_SHA256,"validatorSha256":sha(pathlib.Path(__file__).read_bytes()),
    "originalsManifestSha256":sha((OUT/"originals-manifest.json").read_bytes()),
    "producerStartedUTC":process["started_utc"],"producerFinishedUTC":process["finished_utc"],
    "producerElapsedSeconds":process["elapsed_seconds"],"checks":checks,
    "passed":all(c["pass"] for c in checks),"dimensionCounts":counts,"artifacts":deltas,
    "nativeSpecimenCredit":False,"appleRuntimeCredit":False,
    "parameterEvidenceReuse":reuse["parameterReuse"],
    "sourceEquivalenceWitnessSha256":sha((ROOT/"observer-source-equivalence.original.json").read_bytes()),
    "scope":"Independent inspection of original finite producer run and its bytes; no additional compiler execution or test rerun."
}
path=ROOT/"observer-independent-intake-11f3c80ca261.json"
with path.open("xb") as f:f.write((json.dumps(report,indent=2)+"\n").encode())
print(json.dumps({"report":str(path),"sha256":sha(path.read_bytes()),"passed":report["passed"],
                  "checks":len(checks),"failures":[c["check"] for c in checks if not c["pass"]],
                  "artifacts":[{k:v for k,v in d.items() if k!="changed_action_records"}|{"changed_action_count":len(d["changed_action_records"])} for d in deltas]}))
raise SystemExit(0 if report["passed"] else 1)
