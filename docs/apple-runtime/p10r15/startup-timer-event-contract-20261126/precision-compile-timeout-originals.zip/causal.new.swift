import Foundation
import Dispatch

private final class HeldStartClock: @unchecked Sendable {
    private let lock = NSLock()
    private let releaseGate = DispatchSemaphore(value: 0)
    private var first = true
    func now() -> TimeInterval {
        lock.lock()
        let wait = first
        first = false
        lock.unlock()
        if wait {
            precondition(releaseGate.wait(timeout: .now() + 1) == .success, "injected start gate released")
        }
        return ProcessInfo.processInfo.systemUptime
    }
    func release() { releaseGate.signal() }
}
@main
enum CausalHeartbeatOrder {
    static func expect(_ value: @autoclosure () -> Bool, _ reason: String) {
        if !value() { fatalError(reason) }
    }
    static func read(_ path: URL) throws -> [[String: Any]] {
        let bytes = try Data(contentsOf: path)
        expect(bytes.count <= CherriStartupLifecycleObserver.maximumBytes, "bounded bytes")
        return try String(data: bytes, encoding: .utf8)!.split(separator: "\n").map {
            try JSONSerialization.jsonObject(with: Data($0.utf8)) as! [String: Any]
        }
    }
    static func main() throws {
        let nonce = String(repeating: "a", count: 32)
        let context = CherriStartupLifecycleObserver.Context(arguments: ["--uitesting"], environment: [
            "CHERRI_STARTUP_OBSERVATION_NONCE": nonce,
            "CHERRI_STARTUP_OBSERVATION_TEST": "CherriEditorUITests/testD03CurrentDocumentationSearchUI"
        ])!
        precondition(CommandLine.arguments.count == 2, "one owned observation directory")
        let root = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        func path(_ part: String) -> URL { root.appendingPathComponent(part).appendingPathComponent(nonce + ".jsonl") }
        let gate = HeldStartClock()
        let activity = ProcessInfo.processInfo.beginActivity(
            options: [.userInitiated, .latencyCritical],
            reason: "Verify independent startup-observer timer delivery")
        defer { ProcessInfo.processInfo.endActivity(activity) }
        let heartbeat = CherriStartupLifecycleObserver(context: context, output: path("heartbeat"), now: { gate.now() },
                                                        lifetime: 0.30, interval: 0.02)
        heartbeat.start()
        // Start the observation interval only after the independent timer is armed.
        gate.release() // Injected queue-start fixture; release only at the first drain boundary.
        heartbeat.drainForTesting()
        // This blocks the caller; the independent writer queue must still progress.
        let callerBlockStarted = ProcessInfo.processInfo.systemUptime
        Thread.sleep(forTimeInterval: 0.12)
        let callerBlockFinished = ProcessInfo.processInfo.systemUptime
        heartbeat.drainForTesting()
        let observationCompleted = ProcessInfo.processInfo.systemUptime
        let actualRows = try read(path("heartbeat"))
        let heartbeats = actualRows.filter { $0["phase"] as? String == "heartbeat" }
        let observation: [String: Any] = ["variant": "precision-activity-and-barrier-order", "injectedStartGate": true, "heartbeatCount": heartbeats.count,
            "allOffMain": heartbeats.allSatisfy { $0["mainThread"] as? Bool == false },
            "lifetimeSeconds": 0.30, "intervalSeconds": 0.02, "callerBlockedSeconds": 0.12,
            "activityOptions": ["userInitiated", "latencyCritical"],
            "callerBlockStartedUptime": callerBlockStarted, "callerBlockFinishedUptime": callerBlockFinished,
            "actualCallerBlockedSeconds": callerBlockFinished - callerBlockStarted,
            "observationCompletedUptime": observationCompleted, "actualRows": actualRows]
        let raw = try JSONSerialization.data(withJSONObject: observation, options: [.sortedKeys])
        try FileHandle.standardOutput.write(contentsOf: raw + Data([10]))
        expect(heartbeats.count >= 2, "real independent timer advanced")
        expect(heartbeats.allSatisfy { $0["mainThread"] as? Bool == false }, "heartbeat is not a main-thread readiness signal")
        heartbeat.stopAndDrainForTesting()

    }
}
