import importlib.util,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(r'C:\Users\DAVID\Code\cherri-p10r15-ai-provider-20261121\tools\language-ai-eval')))
import test_anthropic_adapter
path=Path(__file__).parent/'adapter-9487.original.py'
spec=importlib.util.spec_from_file_location('old_anthropic_adapter',path)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
test_anthropic_adapter.adapter=module
suite=unittest.TestSuite(test_anthropic_adapter.FixedTransportControls(name) for name in (
'test_late_eof_cannot_be_a_successful_http_response',
'test_late_body_is_preserved_as_incomplete'))
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
