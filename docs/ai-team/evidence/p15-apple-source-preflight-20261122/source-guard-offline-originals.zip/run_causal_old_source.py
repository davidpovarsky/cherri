"""Expected-red offline reproduction of the original lost source rejection."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
import unittest

BASE = Path(__file__).resolve().parent
SOURCE = BASE / "causal-old-source"
sys.path.insert(0, str(SOURCE / "tools/shortcuts-simulator-qa"))
import test_project_prerequisite_qa as controls

DESTINATION = BASE / "causal-old-red"
DESTINATION.mkdir(exist_ok=False)


class OriginalLostReceipt(unittest.TestCase):
    def test_rejected_dirty_status_has_a_private_source_receipt(self):
        owned = controls.QAIntegrationTests()
        owned.setUp()
        self.addCleanup(owned.doCleanups)
        cfg, env = owned.case()
        (Path(cfg["repo"]) / "PRIVATE_SOURCE_STATUS_CANARY").write_bytes(b"owned synthetic control")
        run, result = owned.run_case(cfg, env)
        root = Path(cfg["observation"])
        summary = json.loads((root / "public/summary.json").read_bytes())
        source = json.loads((root / "private/source.json").read_bytes())
        shutil.copytree(root, DESTINATION / "observation.original")
        (DESTINATION / "driver-result.original.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
        (DESTINATION / "stdout.original").write_bytes(run.stdout)
        (DESTINATION / "stderr.original").write_bytes(run.stderr)
        raw = (SOURCE / "tools/shortcuts-simulator-qa/project_prerequisite_observation.py").read_bytes()
        receipt = {
            "scope": "LOCAL_POSIX_OFFLINE_SYNTHETIC_CAUSAL_OLD_SOURCE",
            "apple_execution": False, "original_source_base": "d2f86d2998bb15d9271a58279a51a400eb13d3d5",
            "observer_git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
            "owned_control_source": cfg["source"], "new_qa_controls_only": True,
            "returncode": result["returncode"], "prepare_calls": len(result["prepare_calls"]),
            "reason": summary["reason"], "status": summary["prerequisiteStatus"],
            "source_before": source["before"], "source_after": source["after"],
            "original_member_count": len(summary["members"]),
            "failure_detail_retained": (root / "private/source-preflight.json").exists(),
        }
        (DESTINATION / "receipt.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
        self.assertEqual((receipt["returncode"], receipt["prepare_calls"], receipt["reason"], receipt["status"]),
                         (70, 0, "SOURCE_REJECTED", "NOT_STARTED"))
        self.assertTrue(receipt["failure_detail_retained"],
                        "EXPECTED RED: original observer discards the authentic dirty-status cause")


started = time.monotonic()
with (DESTINATION / "test.stderr.original").open("x") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(OriginalLostReceipt))
print(json.dumps({"expected_red": True, "tests": result.testsRun,
    "failures": len(result.failures), "errors": len(result.errors),
    "elapsed_seconds": time.monotonic() - started, "evidence": str(DESTINATION)}))
raise SystemExit(0 if result.wasSuccessful() else 1)
