"""One bounded offline observer replay; preserve direct streams and all events."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import unittest

BASE = Path(__file__).resolve().parent
ROOT = Path("/workspace/scratch/e782d4e64deb/cherri-apple-source-guard-20261122")
HERE = ROOT / "tools/shortcuts-simulator-qa"
sys.path.insert(0, str(HERE))
MODULES = (("test_project_prerequisite", 8), ("test_project_prerequisite_observation", 31),
           ("test_project_prerequisite_qa", 13))
import project_prerequisite_observation as subject
NAMES = tuple(sorted(set((*subject.QA_SOURCE_FILES, subject.QA + "test_project_prerequisite.py"))))


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def binding(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def inventory():
    result = []
    for module, expected in MODULES:
        tree = ast.parse((HERE / (module + ".py")).read_bytes())
        ids = [module + "." + node.name + "." + fn.name
               for node in tree.body if isinstance(node, ast.ClassDef)
               for fn in node.body if isinstance(fn, ast.FunctionDef) and fn.name.startswith("test_")]
        assert len(ids) == len(set(ids)) == expected
        result.extend(ids)
    assert len(result) == len(set(result)) == 52
    return sorted(result)


def child(destination):
    events = (destination / "events.jsonl").open("x", encoding="utf-8")
    class Result(unittest.TextTestResult):
        def emit(self, kind, test, **extra):
            events.write(json.dumps({"kind": kind, "test": test.id(), "utc": utc(), **extra},
                                    sort_keys=True) + "\n")
            events.flush()
        def startTest(self, test):
            self.started = time.monotonic()
            self.emit("START", test)
            super().startTest(test)
        def addSuccess(self, test):
            self.emit("PASS", test, elapsed_seconds=time.monotonic() - self.started)
            super().addSuccess(test)
        def addFailure(self, test, err):
            self.emit("FAIL", test, elapsed_seconds=time.monotonic() - self.started,
                      traceback=self._exc_info_to_string(err, test))
            super().addFailure(test, err)
        def addError(self, test, err):
            self.emit("ERROR", test, elapsed_seconds=time.monotonic() - self.started,
                      traceback=self._exc_info_to_string(err, test))
            super().addError(test, err)
        def addSkip(self, test, reason):
            self.emit("SKIP", test, reason=reason)
            super().addSkip(test, reason)
        def addSubTest(self, test, subtest, err):
            self.emit("SUBPASS" if err is None else "SUBFAIL", test, subtest=str(subtest),
                      **({} if err is None else {"traceback": self._exc_info_to_string(err, test)}))
            super().addSubTest(test, subtest, err)
    suite = unittest.defaultTestLoader.loadTestsFromNames(inventory())
    result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
    events.close()
    return 0 if result.wasSuccessful() and result.testsRun == 52 and not result.skipped else 1


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--child":
        return child(Path(sys.argv[2]))
    assert len(sys.argv) == 2
    destination = Path(sys.argv[1]).absolute()
    destination.mkdir(exist_ok=False)
    sources = {name: binding(ROOT / name) for name in NAMES}
    originals = destination / "source"
    originals.mkdir()
    for name in NAMES:
        target = originals / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT / name).read_bytes())
    (destination / "driver.original.py").write_bytes(Path(__file__).read_bytes())
    ids = inventory()
    before = {"source": sources, "test_ids": ids, "expected_parents": 52,
              "outer_seconds": 150, "scope": "LOCAL_POSIX_OFFLINE_CONTROLS",
              "apple_execution": False, "provider_calls": False, "compiler_calls": False}
    (destination / "intent.json").write_bytes(encode(before))
    start, started = time.monotonic(), utc()
    print(json.dumps({"launch": "ONCE", "expected_parents": 52, "started_utc": started, "outer_seconds": 150}), flush=True)
    timed_out = False
    argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--child", str(destination)]
    with (destination / "stdout.original").open("xb") as stdout, \
         (destination / "stderr.original").open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=HERE, stdin=subprocess.DEVNULL,
                                   stdout=stdout, stderr=stderr, start_new_session=True,
                                   env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        try:
            code = process.wait(timeout=150)
        except subprocess.TimeoutExpired:
            timed_out = True
            try: os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError: pass
            try: code = process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try: os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError: pass
                code = process.wait(timeout=2)
    after = {name: binding(ROOT / name) for name in NAMES}
    events = [json.loads(line) for line in (destination / "events.jsonl").read_text().splitlines()] \
        if (destination / "events.jsonl").exists() else []
    starts = [row["test"] for row in events if row["kind"] == "START"]
    passes = [row["test"] for row in events if row["kind"] == "PASS"]
    try:
        os.killpg(process.pid, 0)
        group_state = "PRESENT"
    except ProcessLookupError:
        group_state = "ABSENT"
    except OSError as error:
        group_state = "UNKNOWN:" + type(error).__name__
    receipt = {"scope": "LOCAL_POSIX_OFFLINE_SYNTHETIC_CONTROLS",
               "apple_execution": False, "compiler_calls": False, "provider_calls": False,
               "outer_group_state": group_state, "driver": binding(Path(__file__)), "argv": argv, "pid": process.pid, "started_utc": started, "finished_utc": utc(),
               "elapsed_seconds": time.monotonic() - start, "outer_seconds": 150,
               "exit_code": code, "timed_out": timed_out, "source_unchanged": sources == after,
               "started": len(starts), "passed": len(passes),
               "failed": sum(row["kind"] == "FAIL" for row in events),
               "errors": sum(row["kind"] == "ERROR" for row in events),
               "subcases": sum(row["kind"] == "SUBPASS" for row in events),
               "subcase_failures": sum(row["kind"] == "SUBFAIL" for row in events),
               "skipped": sum(row["kind"] == "SKIP" for row in events),
               "unstarted": sorted(set(ids) - set(starts)), "source_after": after,
               "stdout": binding(destination / "stdout.original"),
               "stderr": binding(destination / "stderr.original"),
               "events": binding(destination / "events.jsonl") if events else None}
    (destination / "receipt.json").write_bytes(encode(receipt))
    print(json.dumps({key: receipt[key] for key in ("started", "passed", "failed", "errors", "skipped", "subcases", "subcase_failures", "unstarted", "elapsed_seconds", "exit_code", "timed_out", "source_unchanged", "outer_group_state", "stdout", "stderr", "events")}, sort_keys=True), flush=True)
    return 0 if code == 0 and not timed_out and sources == after and sorted(passes) == ids and group_state == "ABSENT" else 1


if __name__ == "__main__":
    raise SystemExit(main())
