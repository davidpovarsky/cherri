#!/usr/bin/env python3
"""One bounded, real-Git unittest parent; preserve direct output and subcase terminals."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
MANIFEST = HERE / "fixture-execution-source-manifest.json"
OUT = HERE / "actual-fixture-first-60s"

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

def state(manifest):
    root = Path(manifest["source_root"])
    actual = []
    for expected in manifest["files"]:
        data = (root / expected["path"]).read_bytes()
        observed = {"path":expected["path"], "bytes":len(data), "sha256":hashlib.sha256(data).hexdigest(), "git_blob":hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}
        assert all(observed[k] == expected[k] for k in observed), observed
        actual.append(observed)
    return actual

def child():
    import unittest
    manifest = json.loads(MANIFEST.read_text())
    state(manifest)
    events = (OUT / "events.original.jsonl").open("x", encoding="utf-8", buffering=1)
    launches = (OUT / "subprocess-launches.original.jsonl").open("x", encoding="utf-8", buffering=1)
    def audit(event, args):
        if event == "subprocess.Popen":
            executable, argv, cwd, _environment = args
            # Environment and credentials are deliberately not logged.
            launches.write(json.dumps({"utc":utc(), "event":event, "executable":os.fsdecode(executable), "argv":[os.fsdecode(x) for x in argv], "cwd":os.fsdecode(cwd) if cwd is not None else None}) + "\n")
    sys.addaudithook(audit)
    def emit(kind, **fields):
        record = {"utc":utc(), "kind":kind, **fields}
        text = json.dumps(record, sort_keys=True)
        events.write(text + "\n")
        print(text, flush=True)
    class Result(unittest.TextTestResult):
        def startTest(self, test):
            emit("parent-start", test=test.id())
            super().startTest(test)
        def addSubTest(self, test, subtest, err):
            emit("subcase-terminal", test=test.id(), params=dict(subtest.params), status="PASS" if err is None else "FAIL", detail=None if err is None else self._exc_info_to_string(err, test))
            super().addSubTest(test, subtest, err)
        def addSuccess(self, test):
            emit("parent-terminal", test=test.id(), status="PASS")
            super().addSuccess(test)
        def addFailure(self, test, err):
            emit("parent-terminal", test=test.id(), status="FAIL", detail=self._exc_info_to_string(err, test))
            super().addFailure(test, err)
        def addError(self, test, err):
            emit("parent-terminal", test=test.id(), status="ERROR", detail=self._exc_info_to_string(err, test))
            super().addError(test, err)
    sys.path.insert(0, str(Path(manifest["source_root"]) / "tools/p10r3"))
    suite = unittest.defaultTestLoader.loadTestsFromName(manifest["parent"])
    assert suite.countTestCases() == 1
    result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
    emit("suite-terminal", tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped), successful=result.wasSuccessful())
    state(manifest)
    events.close()
    launches.close()
    raise SystemExit(0 if result.wasSuccessful() else 1)

def members(pgid):
    found = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            tail = (entry / "stat").read_text().rsplit(") ", 1)[1].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        if int(tail[2]) == pgid:
            found.append({"pid":int(entry.name), "state":tail[0], "pgid":int(tail[2]), "session":int(tail[3])})
    return sorted(found, key=lambda x:x["pid"])

def supervise():
    manifest = json.loads(MANIFEST.read_text())
    assert manifest["timeout_seconds"] == 60
    OUT.mkdir(exist_ok=False)
    temporary = OUT / "temporary"
    temporary.mkdir()
    before = state(manifest)
    write_json(OUT / "source-before.json", before)
    argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--child"]
    intent = {"schema":"cherri-r23-fixture-process/v1", "status":"NOT_STARTED", "utc":utc(), "argv":argv, "cwd":manifest["source_root"], "timeout_seconds":60, "parent":manifest["parent"], "expected_subcases":manifest["expected_subcases"], "candidate_sha256":"d991e5ef311935d33be7b38a0c7ec18de332410e5a57b38a33e8b7717786c8bd", "driver_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "source_manifest_sha256":hashlib.sha256(MANIFEST.read_bytes()).hexdigest(), "python":sys.version, "platform":sys.platform}
    write_json(OUT / "intent.json", intent)
    env = dict(os.environ)
    env.update({"PYTHONDONTWRITEBYTECODE":"1", "TMPDIR":str(temporary), "PYTHONUNBUFFERED":"1"})
    started, began = utc(), time.monotonic()
    timed_out, signals = False, []
    with (OUT / "stdout.original.txt").open("xb") as stdout, (OUT / "stderr.original.txt").open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=manifest["source_root"], env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        assert os.getpgid(process.pid) == process.pid
        write_json(OUT / "started.json", {"utc":started, "pid":process.pid, "pgid":process.pid})
        try:
            process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timed_out = True
        finally:
            remaining = members(process.pid)
            if remaining:
                assert all(x["session"] == process.pid for x in remaining)
                os.killpg(process.pid, signal.SIGKILL)
                signals.append({"signal":"SIGKILL", "utc":utc(), "members":remaining})
            process.wait(timeout=5)
    elapsed, finished = time.monotonic() - began, utc()
    after = state(manifest)
    write_json(OUT / "source-after.json", after)
    remaining = members(process.pid)
    streams = {}
    for name in ["stdout.original.txt", "stderr.original.txt", "events.original.jsonl", "subprocess-launches.original.jsonl"]:
        path = OUT / name
        if path.exists():
            data = path.read_bytes()
            streams[name] = {"bytes":len(data), "sha256":hashlib.sha256(data).hexdigest()}
    events = [json.loads(line) for line in (OUT / "events.original.jsonl").read_text().splitlines()] if (OUT / "events.original.jsonl").exists() else []
    subcases = [e for e in events if e["kind"] == "subcase-terminal"]
    parents = [e for e in events if e["kind"] == "parent-terminal"]
    valid = (not timed_out and process.returncode == 0 and not remaining and before == after and [e["params"] for e in subcases] == manifest["expected_subcases"] and all(e["status"] == "PASS" for e in subcases) and len(parents) == 1 and parents[0]["status"] == "PASS")
    receipt = {**intent, "status":"PASS" if valid else "FAIL", "started_utc":started, "finished_utc":finished, "elapsed_seconds":elapsed, "pid":process.pid, "exit_code":process.returncode, "timed_out":timed_out, "signals":signals, "remaining_members":remaining, "source_unchanged":before == after, "subcases_terminal":len(subcases), "subcases_pass":sum(e["status"] == "PASS" for e in subcases), "parent_terminals":parents, "streams":streams, "temporary_fixture_remaining":[str(x.relative_to(temporary)) for x in temporary.iterdir()], "scope":"One original unittest parent with 11 actual-Git subcases; no full 22-parent suite, no production R23 PASS claim."}
    write_json(OUT / "receipt.json", receipt)
    print(json.dumps({k:receipt[k] for k in ["status","elapsed_seconds","exit_code","timed_out","subcases_terminal","subcases_pass","source_unchanged","remaining_members","temporary_fixture_remaining"]}))
    raise SystemExit(0 if valid else 1)

if __name__ == "__main__":
    child() if sys.argv[1:] == ["--child"] else supervise()
