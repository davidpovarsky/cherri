#!/usr/bin/env python3
"""Materialize exact reviewed candidate and immutable import/data inputs; no tests."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "fixture-source-d991e5ef"
SOURCE.mkdir(exist_ok=False)

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

records = []
def put(path, data, expected_blob, provenance):
    assert blob(data) == expected_blob, (path, blob(data), expected_blob)
    target = SOURCE / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    records.append({"path": path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                    "git_blob": expected_blob, "provenance": provenance})

def original(name, path, expected_blob):
    carrier = HERE / "originals" / name
    response = json.loads(carrier.read_text(encoding="utf-8"))
    assert response.get("isError") is False
    content = response["structuredContent"]["content"]
    put(path, content.encode("utf-8"), expected_blob, str(carrier.relative_to(HERE)))

candidate = HERE / "candidate/tools/p10r3/test_coverage_and_gates.py"
data = candidate.read_bytes()
assert hashlib.sha256(data).hexdigest() == "d991e5ef311935d33be7b38a0c7ec18de332410e5a57b38a33e8b7717786c8bd"
put("tools/p10r3/test_coverage_and_gates.py", data, "0c0e9853318827de3f5023f167c7405f20de9e70", "reviewed candidate; patch SHA256 2963c2eb362ad65e84795b361ba91a9346861d7cc314169b3dc72558f862ddc2")
inputs = [
 ("gate.github-response.original.json", "tools/p10r3/run_release_gates.py", "d650f6b51cc7a52746bea46763662799f1831cb3"),
 ("dependency-generate_catalog_and_pack_ledgers.github-response.original.json", "tools/p10r3/generate_catalog_and_pack_ledgers.py", "0efd1d36b5313972ad331eb73b7248c5a74f255a"),
 ("dependency-verify_ledger_consistency.github-response.original.json", "tools/p10r3/verify_ledger_consistency.py", "47d099d3ea1ea9f9a7e7540064178f29093603ed"),
 ("dependency-verify_or_generate_pack.github-response.original.json", "tools/p10r3/verify_or_generate_pack.py", "e838954036ef03e88ab625abc3232f55b8ea3011"),
 ("dependency-catalog-matrix-blob.github-response.original.json", "docs/apple-runtime/p10/p10-505-catalog-coverage-matrix.json", "509e4152f81106debbbceb3bd6377a45200e349a"),
 ("dependency-coverage-schema.github-response.original.json", "docs/apple-runtime/p10/coverage-evidence.schema.json", "b2c93e07cd619bc7151fa113a5ad73a240b01972"),
 ("dependency-crosswalk.github-response.original.json", "docs/apple-runtime/p10/p10-apple-cherri-crosswalk.json", "a1bea16efa01552f83fcf3fb6f81ab9a4c31f620"),
 ("dependency-pack15.github-response.original.json", "docs/apple-runtime/p10/p10-pack-15-go-only-audit.json", "2ab51a730bfba7bb9271167366608018b40bd7fc"),
 ("dependency-device-manifest.github-response.original.json", "docs/apple-runtime/p10/device-acceptance-manifest.json", "8200598f92af29ed878b2dd6958bc515a791f6fd"),
 ("baseline.github-response.original.json", "docs/apple-runtime/p10/baseline-state.json", "68aebdc5bb85619ecd9ee2c67867a23b10166063"),
]
for args in inputs:
    original(*args)
original_tree = ast.parse((HERE / "test_coverage_and_gates.py.original.txt").read_text())
candidate_tree = ast.parse(data.decode())
def methods(tree):
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "TestP10CoverageAndGates")
    return {n.name: ast.dump(n, include_attributes=False) for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")}
before, after = methods(original_tree), methods(candidate_tree)
parent = "test_c5_06_r23_protected_ios_file_modified_fails_closed"
assert len(before) == len(after) == 22 and before.keys() == after.keys()
assert [name for name in before if before[name] != after[name]] == [parent]
expected = [{"state": "explicit_baseline_clean"}]
for path in ["ios/CherriUITests/CherriEditorUITests.swift", "ios/CherriApp/Views/CodeEditorView.swift"]:
    for state in ["unstaged_change", "staged_change", "committed_change_clean_tree", "committed_exact_restoration"]:
        expected.append({"path": path, "state": state})
expected.extend([{"state": "unprotected_committed_change"}, {"state": "unavailable_baseline_fails_closed"}])
assert len(expected) == 11
manifest = {"schema": "cherri-r23-fixture-scope/v1", "base_commit": "db222ea190b90e875290b76fea5c6a5925ad89e9", "source_root": str(SOURCE), "parent": "test_coverage_and_gates.TestP10CoverageAndGates." + parent, "expected_subcases": expected, "required_parent_count": 1, "untouched_parent_asts": 21, "timeout_seconds": 60, "files": sorted(records, key=lambda x:x["path"])}
(HERE / "fixture-execution-source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"status":"MATERIALIZED_NOT_EXECUTED", "source_files":len(records), "expected_subcases":len(expected), "candidate_sha256":hashlib.sha256(data).hexdigest(), "source_root":str(SOURCE)}))
